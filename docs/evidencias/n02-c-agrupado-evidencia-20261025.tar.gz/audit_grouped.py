"""Audit fixed120nativeguardcalls and preregistered group-mean decision."""
import hashlib,json,math,statistics,sys
from pathlib import Path
from xml.etree import ElementTree as ET
w=Path('artifacts/recorridos-n02-c-20261025');run=Path(sys.argv[1])
def pairs(rows):
 out={}
 for k,v in rows:
  assert k not in out,k
  out[k]=v
 return out
def invalid(x):raise ValueError(x)
def parse(x):return json.loads(x,object_pairs_hook=pairs,parse_constant=invalid)
def read(p):return parse(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def finite(x):return isinstance(x,(float,int)) and not isinstance(x,bool) and math.isfinite(x) and x>=0
r=read(run/'result.json');assert r['result']=='PASS' and r['sources_unchanged']
assert r['cleanup'] and all(v['absent'] for v in r['cleanup'].values())
assert read(run/'telegram-notification.json')['delivery']=='sent'
runner=read(run/'runner.json');assert not Path(runner['temporary']).exists()
f=read(w/'freeze.json');assert runner['command']==f['command'][1:]
for p,h in f['sha256'].items():assert sha(p)==h,p
journal=[parse(line) for line in (run/'pytest-reports.jsonl').read_text().splitlines()];assert len(journal)==3 and {j['when'] for j in journal}=={'setup','call','teardown'}
assert all(j['outcome']=='passed' and finite(j['duration']) for j in journal)
cases=ET.parse(run/'pytest.xml').findall('.//testcase');assert len(cases)==1
case=cases[0];assert case.get('name')=='test_grouped_held_seal_guard_reference'
assert not any(case.find(k) is not None for k in ['failure','error','skipped'])
props=pairs((p.get('name'),p.get('value')) for p in case.findall('./properties/property'))
samples=parse(props['n02c_guard_samples']);groups=parse(props['n02c_guard_groups']);assert len(samples)==120 and len(groups)==12
assert {(s['round'],s['method'],s['repetition']) for s in samples}=={(i,m,j) for i in range(6) for m in ['baseline','candidate'] for j in range(10)}
expected_order=[(i,m,j) for i in range(6) for m in (['baseline','candidate'] if i%2==0 else ['candidate','baseline']) for j in range(10)]
assert [(s['round'],s['method'],s['repetition']) for s in samples]==expected_order
assert len({s['manifest_digest'] for s in samples})==1
for s in samples:
 assert s['django_debug'] is False and s['reads']==2 and s['bytes']==10554 and s['pre_guard_locks']==4
 assert s['sql_queries']==(7 if s['method']=='baseline' else 4)
 assert s['phase']==('first' if s['round']==0 else 'warm')
 assert all(finite(s[k]) for k in ['wall_seconds','thread_cpu_seconds','sql_execute_seconds'])
 assert len(s['manifest_digest'])==64 and int(s['manifest_digest'],16)>=0
assert props['n02c_baseline_sha256']==sha('artifacts/recorridos-n02-b-20261025/guard-before.py')=='94f391fe875267666ef2316ae5470965f9cc888481241adbb8232e72deb6761c'
assert {(g['round'],g['method']) for g in groups}=={(i,m) for i in range(6) for m in ['baseline','candidate']}
for g in groups:
 selected=[s for s in samples if s['round']==g['round'] and s['method']==g['method']]
 assert g['count']==len(selected)==10 and g['phase']==('first' if g['round']==0 else 'warm')
 for key,source in [('mean_guard_seconds','wall_seconds'),('mean_cpu_seconds','thread_cpu_seconds'),('mean_sql_execute_seconds','sql_execute_seconds')]:
  assert finite(g[key]) and math.isclose(g[key],statistics.fmean(s[source] for s in selected),abs_tol=1e-12,rel_tol=1e-12)
 assert math.isclose(g['total_guard_seconds'],sum(s['wall_seconds'] for s in selected),abs_tol=1e-12,rel_tol=1e-12)
by_group={(g['round'],g['method']):g for g in groups};warm_deltas=[]
for i in range(1,6):
 before=by_group[i,'baseline']['mean_guard_seconds']*1000;after=by_group[i,'candidate']['mean_guard_seconds']*1000
 warm_deltas.append({'round':i,'baseline_mean_ms':before,'candidate_mean_ms':after,'reduction_ms':before-after,'improves':after<before})
summary={}
for method in ['baseline','candidate']:
 gs=[g for g in groups if g['method']==method and g['phase']=='warm'];vals=[g['mean_guard_seconds']*1000 for g in gs]
 individual=[s['wall_seconds']*1000 for s in samples if s['method']==method]
 summary[method]={'first_group_mean_ms':by_group[0,method]['mean_guard_seconds']*1000,'warm_group_median_mean_ms':statistics.median(vals),'warm_group_min_mean_ms':min(vals),'warm_group_max_mean_ms':max(vals),'warm_groups':5,'calls_per_group':10,'individual_calls':len(individual),'individual_min_ms':min(individual),'individual_max_ms':max(individual),'warm_group_cpu_median_mean_ms':statistics.median(g['mean_cpu_seconds']*1000 for g in gs),'warm_group_sql_median_mean_ms':statistics.median(g['mean_sql_execute_seconds']*1000 for g in gs),'queries_each':7 if method=='baseline' else 4,'reads_each':2,'bytes_each':10554}
before=summary['baseline']['warm_group_median_mean_ms'];after=summary['candidate']['warm_group_median_mean_ms'];summary['reduction_ms']=before-after;summary['reduction_percent']=100*(before-after)/before
favorable=all(p['improves'] for p in warm_deltas) and after<before
prior=Path('artifacts/local-ci/20261025-131908-9c8862ce');source_map=read(prior/'source-hashes.json');checked=0
for p,h in source_map.items():
 if p.startswith(('apps/','config/','templates/','static/','tests/','scripts/')) or p in ('pyproject.toml','uv.lock'):
  assert sha(p)==h,p;checked+=1
prior_audit=read('artifacts/recorridos-n02-b-20261025/guard-audit.json');assert prior_audit['result']=='PASS_N02B_HELD_SEAL_GUARD'
for key in ['parser_commit','hiredis_commit']:assert read(prior/'native-manifest.json')[key]==read(run/'native-manifest.json')[key]
paths=[run/'result.json',run/'pytest.xml',run/'source-hashes.json',run/'pytest-reports.jsonl',run/'runner.json',run/'native-manifest.json',run/'telegram-notification.json',w/'freeze.json',w/'previous-oracle-identity.json',Path(__file__),Path('artifacts/recorridos-n02-b-20261025/guard-audit.json'),prior/'source-hashes.json']
a={'result':'PASS_N02C_FIXED_GROUPED_GUARD_EVIDENCE','run':str(run),'cases':1,'guard_samples':samples,'groups':groups,'summary':summary,'warm_pair_deltas':warm_deltas,'temporal_decision':'FAVORABLE_LOCAL_GROUPED_STAGE' if favorable else 'INCONCLUSIVE_FIXED_CONTRAST','warm_pairs_improved':sum(p['improves'] for p in warm_deltas),'decision_rule':'All5warmgroupmeansimproveANDmedianmeanlower;noadaptiveextension','runtime_sources_verified_unchanged':checked,'previous_oracle_cases_reused':16,'physical_reads':240,'pre_guard_row_lock_witnesses':480,'source_freeze_unchanged':True,'owned_resources_absent':True,'terminal_telegram':'sent','pytest_command_seconds':next(s['seconds'] for s in r['steps'] if s['name']=='pytest'),'scope':'Local2smallimageheldsealguard groupedmean contrast only,noHTTP/fullsizeMOD09/p95/wholeblockacceptance','sha256':{str(p):sha(p) for p in paths}}
(w/'grouped-audit.json').write_text(json.dumps(a,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in a.items() if k not in ['guard_samples','groups','sha256']}))
