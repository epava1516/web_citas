# Grafo alfa — instrumentos N01D

Contrato340/341: N00aceptado1/13,N01abierto,alfa. Base reconstruida preservada; contexto semántico N01C conservado. Este refresco es AST focal de dos instrumentos nuevos y conciliación del runner por inserciones:13nodos/61relaciones previas reancladas sin borrarlas. No es reconstrucción completa. Este corte añade semántica nativa literal del protocolo350, aún sin medición de aplicación.

1940fuentes,18092nodos,80119relaciones,858comunidades; membresías previas preservadas más comunidad instrumental.1506fuentes ejecutables originales intactas; runner variante explícita de medición. Observador opcional Client.request, sin cuerpos/parámetros/SQL;8pruebas de contrato PASS, no medición de rendimiento de app. Fixtures dinámicos dentro de call pueden aportar peticiones; no confundir con acciones principales. N01D aún sin ejecutar recorridos.

Semántica selectiva previa, referencias estáticas no prueban runtime.100anotaciones ambiguas previas conservadas. Consumo nativo desconocido, ceros técnicos no significan coste cero. HTML sólo proyección de comunidades, JSON completo. Seguimiento17 vista líneas1–4; exclusiones anteriores conservadas.

