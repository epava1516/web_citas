"""Audit synthetic run identity, outcomes and scalar-only per-operation records."""
import collections,hashlib,json,math,sys
from pathlib import Path
from xml.etree import ElementTree as ET
run=Path(sys.argv[1]);out=Path('artifacts/recorridos-n01-d-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=json.loads((run/'result.json').read_text());assert r['result']=='PASS' and r['sources_unchanged'] and r['observe_http_operations']
assert all(v['absent'] for v in r['cleanup'].values());assert json.loads((run/'telegram-notification.json').read_text())['delivery']=='sent'
f=json.loads((out/'freeze.json').read_text())
for p,h in f['sha256'].items():assert sha(p)==h,p
cases=ET.parse(run/'pytest.xml').findall('.//testcase');assert len(cases)==11
fields={'method','route_name','status','request_seconds_instrumented','sql_queries','sql_execute_seconds','exception_class','observer_error_class'}
result=[];samples=0
for c in cases:
 assert not any(c.find(k) is not None for k in ['failure','error','skipped'])
 props={p.attrib['name']:p.attrib['value'] for p in c.findall('./properties/property')}
 events=json.loads(props['http_operation_samples']);assert len(events)==int(props['http_operation_count']) and events
 groups=collections.defaultdict(list)
 for e in events:
  assert set(e)==fields
  assert e['exception_class'] is None and e['observer_error_class'] is None,e
  assert isinstance(e['status'],int) and 100<=e['status']<=599
  assert isinstance(e['sql_queries'],int) and e['sql_queries']>=0
  for k in ['request_seconds_instrumented','sql_execute_seconds']:assert isinstance(e[k],(int,float)) and math.isfinite(e[k]) and e[k]>=0
  assert isinstance(e['route_name'],str) and isinstance(e['method'],str)
  groups[(e['method'],e['route_name'],e['status'])].append(e)
 rows=[]
 for (method,route,status),es in groups.items():
  rows.append({'method':method,'route_name':route,'status':status,'n':len(es),'request_ms':[round(e['request_seconds_instrumented']*1000,3) for e in es],'sql_queries':[e['sql_queries'] for e in es],'sql_execute_ms':[round(e['sql_execute_seconds']*1000,3) for e in es]})
 result.append({'case':c.attrib['classname']+'::'+c.attrib['name'],'operations':len(events),'groups':rows});samples+=len(events)
a={'result':'PASS_FUNCTIONAL_AND_SCALAR_OBSERVATION_AUDIT','run':str(run),'cases':len(cases),'operation_samples':samples,'case_observations':result,'scope':'Instrumented synchronous Django Client calls during test call, including dynamically invoked fixture calls; expected denials are outcomes, no load error-rate or latency budget acceptance. No product candidate or causal improvement.','cleanup':'owned resources absent','terminal_telegram':'sent','source_freeze_unchanged':True,'sha256':{str(p):sha(p) for p in [run/'result.json',run/'pytest.xml',run/'source-hashes.json',out/'freeze.json']}}
(out/'operations-audit.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps({k:v for k,v in a.items() if k!='case_observations'}))
