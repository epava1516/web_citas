"""Independent held-seal candidate audit; stage comparison, not whole MOD09 acceptance."""
import ast,hashlib,json,math,statistics,sys
from pathlib import Path
from xml.etree import ElementTree as ET
w=Path('artifacts/recorridos-n02-b-20261025');run=Path(sys.argv[1])
def pairs(rows):
 out={}
 for k,v in rows:
  assert k not in out,k
  out[k]=v
 return out
def invalid(x):raise ValueError(x)
def parse(x):return json.loads(x,object_pairs_hook=pairs,parse_constant=invalid)
def read(p):return parse(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def finite(x):return isinstance(x,(float,int)) and not isinstance(x,bool) and math.isfinite(x) and x>=0
r=read(run/'result.json');assert r['result']=='PASS' and r['sources_unchanged']
assert r['cleanup'] and all(v['absent'] for v in r['cleanup'].values())
assert read(run/'telegram-notification.json')['delivery']=='sent'
runner=read(run/'runner.json');assert not Path(runner['temporary']).exists()
f=read(w/'freeze.json');assert runner['command']==f['command'][1:]
for p,h in f['sha256'].items():assert sha(p)==h,p
initial=Path('artifacts/local-ci/20261025-130439-39bc72b1')
iresult=read(initial/'result.json');assert iresult['result']=='ERROR' and iresult['sources_unchanged']
assert all(v['absent'] for v in iresult['cleanup'].values()) and not Path(read(initial/'runner.json')['temporary']).exists()
assert read(initial/'telegram-notification.json')['delivery']=='sent'
original=read(w/'freeze-initial.json')
excluded={'tests/test_held_seal_image_batch.py','docs/362-n02-b-prerregistro-guard-imagenes-sello-20261025.md','graphify-out/graph.json','graphify-out/SOURCE_MANIFEST.json'}
for p,h in original['sha256'].items():
 if p not in excluded:assert sha(p)==h,p
assert original['images']==f['images'] and original['platform']==f['platform'] and original['cpu_affinity']==f['cpu_affinity']
for key in ['parser_commit','hiredis_commit']:assert read(initial/'native-manifest.json')[key]==read(run/'native-manifest.json')[key]
journal=[parse(line) for line in (run/'pytest-reports.jsonl').read_text().splitlines()];assert len(journal)==6
assert all(j['outcome']=='passed' and finite(j['duration']) for j in journal)
assert len({(j['nodeid'],j['when']) for j in journal})==6
expected={'test_held_seal_guard_paired_reference_and_preexisting_locks','test_held_seal_rejects_changed_last_file_without_success_audits','test_generation_seals_and_later_validations_use_it','test_seal_expires_at_the_earliest_loaded_expiry_and_on_code_change','test_physical_bytes_changed_between_children_roll_back_all_batch_audits'}
expected|={'test_any_input_change_disables_the_seal_and_matches_full_validation['+m+']' for m in ['selection_ciphertext','coverage_read_digest','action_payload','binding_digest','part_ciphertext','image_ciphertext','newer_selection','deleted_read']}
expected|={'test_pipeline_never_bypasses_original_full_fresh_guards['+m+']' for m in ['session','ciphertext','source']}
cases=ET.parse(run/'pytest.xml').findall('.//testcase')
new_names={'test_held_seal_guard_paired_reference_and_preexisting_locks','test_held_seal_rejects_changed_last_file_without_success_audits'}
assert len(cases)==2 and {c.get('name') for c in cases}==new_names
prior=ET.parse(initial/'pytest.xml').findall('.//testcase');assert len(prior)==16 and {c.get('name') for c in prior}==expected
for c in prior:
 if c.get('name') in new_names:assert c.find('failure') is not None
 else:assert not any(c.find(k) is not None for k in ['failure','error','skipped'])
priorjournal=[parse(line) for line in (initial/'pytest-reports.jsonl').read_text().splitlines()];assert len(priorjournal)==48
for row in priorjournal:
 if row['when']=='call' and row['nodeid'].split('::')[-1] in new_names:assert row['outcome']=='failed'
 else:assert row['outcome']=='passed'
for c in cases:assert not any(c.find(k) is not None for k in ['failure','error','skipped'])
props={c.get('name'):pairs((p.get('name'),p.get('value')) for p in c.findall('./properties/property')) for c in cases}
paired=props['test_held_seal_guard_paired_reference_and_preexisting_locks'];samples=parse(paired['n02b_held_guard_samples']);assert len(samples)==12
assert {(s['round'],s['method']) for s in samples}=={(i,m) for i in range(6) for m in ['baseline','candidate']}
assert len({s['bytes'] for s in samples})==len({s['manifest_digest'] for s in samples})==1
for s in samples:
 assert s['django_debug'] is False and s['reads']==2 and s['bytes']>0 and s['pre_guard_locks']==4
 assert s['sql_queries']==(7 if s['method']=='baseline' else 4)
 assert s['phase']==('first' if s['round']==0 else 'warm')
 assert all(finite(s[k]) for k in ['wall_seconds','thread_cpu_seconds','sql_execute_seconds'])
 assert len(s['manifest_digest'])==64 and int(s['manifest_digest'],16)>=0
old=(w/'guard-before.py').read_text();assert hashlib.sha256(old.encode()).hexdigest()==paired['n02b_baseline_sha256']=='94f391fe875267666ef2316ae5470965f9cc888481241adbb8232e72deb6761c'
tree=ast.parse(Path('tests/test_held_seal_image_batch.py').read_text());literal=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='BASELINE_SOURCE' for t in n.targets));assert literal==old
late=parse(props['test_held_seal_rejects_changed_last_file_without_success_audits']['n02b_late_drift']);assert late=={'guard_calls':1,'pre_guard_locks':4,'reads':2,'audit_counts_unchanged':True,'restored_and_revalidated':True}
summary={}
for method in ['baseline','candidate']:
 selected=[s for s in samples if s['method']==method];warm=[s['wall_seconds']*1000 for s in selected if s['phase']=='warm'];assert len(warm)==5
 summary[method]={'first_ms':selected[0]['wall_seconds']*1000,'warm_median_ms':statistics.median(warm),'warm_min_ms':min(warm),'warm_max_ms':max(warm),'warm_samples':5,'sql':selected[0]['sql_queries'],'reads':2,'bytes':selected[0]['bytes']}
before=summary['baseline']['warm_median_ms'];after=summary['candidate']['warm_median_ms'];summary['reduction_ms']=before-after;summary['reduction_percent']=100*(before-after)/before
paths=[run/'result.json',run/'pytest.xml',run/'source-hashes.json',run/'pytest-reports.jsonl',run/'runner.json',run/'native-manifest.json',run/'telegram-notification.json',w/'freeze.json',Path(__file__),initial/'result.json',initial/'pytest.xml',initial/'source-hashes.json',initial/'pytest-reports.jsonl',w/'freeze-initial.json']
a={'result':'PASS_N02B_HELD_SEAL_GUARD','run':str(run),'cases':16,'current_run_cases':2,'reused_original_cases':14,'initial_failed_run':str(initial),'guard_samples':samples,'summary':summary,'late_drift':late,'source_freeze_unchanged':True,'owned_resources_absent':True,'terminal_telegram':'sent','pytest_command_seconds':next(s['seconds'] for s in r['steps'] if s['name']=='pytest'),'scope':'Actual2imageheldsealguard stage only; source-native pipeline and4locksperguard,notfull-sizeMOD09/p95/HTTPacceptance','sha256':{str(p):sha(p) for p in paths}}
(w/'guard-audit.json').write_text(json.dumps(a,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in a.items() if k not in ['guard_samples','sha256']}))
