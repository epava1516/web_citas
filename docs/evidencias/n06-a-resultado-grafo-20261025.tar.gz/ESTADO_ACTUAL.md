# Grafo alfa — resultado N06A y siguiente camino encolado

N00/N01aceptados2/13,N06abierto.357auditado2PASS3inicios SQL116/116/124:11create_draft+2manager+14resto+89/89/97tareas eager. Conteo por etapa,no fracción de latencia ni camino normal por resta. Sin candidato/appoptimizada ni N+1de copia demostrado. Siguiente medir petición y trabajo con broker/worker reales locales.

Refresco semántico focal357/340/341/README/vista17líneas1–4; aclaración temporal exige tiempos anteriores/posteriores y diferencia sólo comparable,AST previo preservado: 1949fuentes,18231nodos/80412relaciones,864comunidades. No reconstrucción completa ni semántica exhaustiva.1506ejecutables originales intactos,runner de medición variante explícita;consumo nativo desconocido. JSONcompleto/HTMLcomunidades;100anotaciones ambiguas y exclusiones previas conservadas. Relaciones documentales no prueban runtime.

