# Grafo alfa — resultado N06A y siguiente camino encolado

N00/N01aceptados2/13,N06abierto.357auditado2PASS3inicios SQL116/116/124:11create_draft+2manager+14resto+89/89/97tareas eager. Conteo por etapa,no fracción de latencia ni camino normal por resta. Sin candidato/appoptimizada ni N+1de copia demostrado. Siguiente medir petición y trabajo con broker/worker reales locales.

Refresco semántico focal357/340/341/README/vista17líneas1–4; aclaración temporal exige tiempos anteriores/posteriores y diferencia sólo comparable,AST previo preservado: 1949fuentes,18231nodos/80412relaciones,864comunidades. No reconstrucción completa ni semántica exhaustiva.1506ejecutables originales intactos,runner de medición variante explícita;consumo nativo desconocido. JSONcompleto/HTMLcomunidades;100anotaciones ambiguas y exclusiones previas conservadas. Relaciones documentales no prueban runtime.

# Graph Report - web_modelos_mod08_vps  (2026-10-25)

## Corpus Check
- 1949 files · ~0 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 18231 nodes · 71757 edges · 864 communities (507 shown, 357 thin omitted)
- Extraction: 100% EXTRACTED · 0% INFERRED · 0% AMBIGUOUS
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- Usuarios y solicitudes de derechos
- Exportación cifrada de portabilidad
- Fotografías y descubrimiento
- Copias y respuestas de derechos
- Proyección del estado de publicación
- Visibilidad y promociones
- Supresión y restricciones por finalidad
- Moderación de perfiles y fotografías
- Copias privadas de derechos
- Contexto de publicación pública
- Cobertura de portabilidad por lotes
- Seguimiento documental del desarrollo
- Moderación y apelaciones de anuncios
- Verificación de solicitudes de derechos
- Vistas de portabilidad
- Comunicaciones y respuestas finales
- Publicación según finalidad
- Medición de carga HTTP
- Contexto de detalle propio
- Revisión de selección portátil
- Reglas y formularios de perfiles
- Paginación y autoridad promocional
- Invalidación de borradores privados
- Localización de interfaces
- Promociones y conciliación documental
- Planificación de la beta
- Información adicional de acceso
- Precedencia del contrato beta
- Contrato y relevo técnico
- Inventario de recursos propios
- Búsqueda y catálogos geográficos
- Contratos y conciliación normativa
- Vistas de acceso a datos
- Instrumentación de fases de capacidad
- Medición de recursos de capacidad
- Publicación y descubrimiento territorial
- Autenticación multifactor e interfaces móviles
- Gestión de reclamaciones
- Huellas y firmas de operaciones
- Fichas públicas y posicionamiento
- Rectificación y revisión de destinatarios
- Gestión del ciclo de perfiles
- Contenido de entregas de acceso
- Cobertura del derecho de acceso
- Revisiones de conservación
- Registro y almacenamiento de recuperación
- Ejecución de rectificación de cuenta
- Inventario de recorridos beta
- Costes de filtros combinados
- Huellas de fuentes y revisiones
- Documentación de copias privadas
- Gestión de reclamaciones privadas
- Cobertura del censo geográfico
- Catálogo de promociones
- Cuentas y aceptación legal
- Registro de evidencias de desarrollo
- Resúmenes de contenido e imágenes
- Entrega privada de objetos
- Conciliación de herramientas y documentación
- Lectura de denuncias y galería
- Cifrado de objetos almacenados
- Privacidad y alertas urgentes
- Índice histórico de evidencias
- Conciliación legal e histórica
- Agencias y conflictos de representación
- Trabajos de exportación portable
- Inspección y alertas urgentes
- Conciliación de catálogo y medios
- Exportación y cobertura de portabilidad
- Decisiones y restricciones de denuncias
- Registro de decisiones
- Diagnósticos de materialización
- Cargas preparadas y limpieza
- Perfilado de procesos trabajadores
- Verificación y consentimiento
- Cola de avisos privados
- Manifiestos paginados de fuentes
- Arquitectura y agencias
- Rectificación e historial de acceso
- Medición temporal de solicitudes
- Planes de supresión
- Ejecución de supresión
- Aplicación de recuperación y medios
- Sellos de validación
- Adaptación del perfil romántico
- Referencias oficiales de tecnologías
- Liberación de contexto WSGI
- Equivalencia de canonicalización nativa
- Inventario de claves de cifrado
- Orígenes de históricos Redis
- Asignación y vinculación de derechos
- Ejecución y respuesta de supresión
- Contratos de exposición comercial
- Taxonomía y descubrimiento geográfico
- Protocolo de carga HTTP
- Cuentas y confirmación de correo
- Interfaces de comunicaciones de derechos
- Diseño de seguridad y privacidad
- Paginación y escala territorial
- Cadena de evidencias de derechos
- Contraste TCP y materialización
- Conciliación de pruebas y privacidad
- Unicidad y detección de duplicados
- Cuentas y condiciones legales
- Copias y respuestas de derechos
- Conciliación de contratos históricos
- Inventario de pantallas y estados
- Analizadores nativos de RDB
- Ventanas de eventos operativos
- Supresión de cuentas y concurrencia
- Supresión y propiedad recuperada
- Borrado y recuperación de medios
- Selección binaria de portabilidad
- Planes de modernización técnica
- Calibración de mezcla territorial
- Instantáneas de directorios de pruebas
- Lectura de objetos por flujo
- Calendario de finalidades
- Observación de procesos trabajadores
- Metadatos públicos y SEO
- Recepción y acuses privados
- Ámbitos del historial Redis
- Marco legal y privacidad
- Política y conciliación de capacidad
- Conciliación de rutas promocionales
- Excepciones de tratamiento
- Plantilla de inspección de derechos
- Base de diagnóstico y restauración
- Mapas y metadatos públicos
- Autoría del historial
- Recursos y atribución de carga
- Conciliación de referencias AST
- Derechos de cuentas sin perfil
- Apelaciones y restricciones fotográficas
- Contenido de objetos privados
- Partes de datos exportados
- Requisitos del producto romántico
- Inventarios y criptografía histórica
- Conciliación de cookies y legislación
- Planes y ámbitos de supresión
- Dependencias del almacenamiento local
- Inventario de evidencias de derechos
- Auditoría técnica de seguridad
- Plan de validación de seguridad
- Retención del cliente generador
- Observación de recursos del kernel
- Conciliación de protección de datos
- Conciliación de acceso y portabilidad
- Conciliación del informe histórico
- Recibos y respuestas de derechos
- Lecturas de presentación pública
- Pruebas de sellos de validación
- Vistas de tratamiento y excepciones
- Procedencia de registros retenidos
- Respuesta y cierre de portabilidad
- Precedencia de fuentes contractuales
- Alertas y cautelas de privacidad
- Estadísticas y atribución de consultas
- Verificación paralela de objetos
- Revisión y apelaciones de agencias
- Operaciones de avisos
- Registro y restauración de supresión
- Clientes de lectura de objetos
- Sellos de validación de derechos
- Tareas de purga y conciliación
- Análisis local del grafo
- Inventario de consumidores de secretos
- Eventos operativos y tareas
- Ciclo de vida de anuncios
- Paginación y pertenencia promocional
- Conciliación del corpus histórico
- Supresión de imágenes compartidas
- Conciliación de candidata B16
- Almacenamiento de artefactos diagnósticos
- Diagnóstico de recorridos escalares
- Pruebas del transporte asíncrono
- Verificación sin extracción de objetos
- Controlador de capacidad VPS
- Autoridad de claves de recuperación
- Rectificación de cuenta
- Rutas escalares de portabilidad
- Conciliación comercial y contraseñas
- Selección y origen de portabilidad
- Favoritos y restricciones por finalidad
- Similitud visual de imágenes
- Inspección y selección de denuncias
- Operación de seguridad e incidentes
- Requisitos y autoridad de recuperación
- Conciliación de CSS e integración
- Topología de servidores de comparación
- Pruebas del cargador canónico
- Revisión de reintroducción fotográfica
- Propuestas de rectificación
- Recibos de recuperación de medios
- Continuidad y rotación de credenciales
- Instrumentación de trabajadores WSGI
- Guardas de bases de diagnóstico
- Sesiones de clientes de objetos
- Revisión y apelaciones de gestores
- Transporte de eventos operativos
- Calendario y cadena de evidencias
- Repositorio de objetos privados
- Corrección de ruta promocional
- Informes de operación y purga
- Concurrencia y recursos multimedia
- Conciliación ECMAScript y Django
- Relaciones y ámbitos de modelos
- Transporte HTTP de entregas
- Lectura continua de objetos
- Evaluación de instantáneas operativas
- Propuestas de rectificación de campos
- Proyección de etiquetas comerciales
- Despacho y pendientes territoriales
- Seguridad transaccional y trazas
- Plantillas de gestión comercial
- Interfaces móviles de tratamiento
- Formularios de respuesta parcial
- Serialización canónica de derechos
- Preparación de entrega final
- Carga HTTP de estados mixtos
- Observación del consumo de CPU
- Atribución de hidratación promocional
- Diagnóstico de esperas de capacidad
- Ciclo de procesos Gunicorn
- Plantillas de consultas propias
- Vinculación de páginas preparadas
- Calendario de finalidades
- Correctivas de regresión beta
- Claves HMAC de dominio
- Preparación de adaptadores
- Atribución de petición promocional
- Cola y reparación de trabajadores
- Exportación y densidad de similitud
- Protocolo de medición VPS
- Orígenes acotados de historial Redis
- Plantillas legales y representación
- Diagnóstico de fuentes de capacidad
- Cobertura paginada de portabilidad
- Lectores masivos de evidencias
- Prerregistro de controles HTTP
- Contratos de derechos y portabilidad
- Anonimización de patrones SQL
- Diagnóstico de descifrado
- Revisión independiente de rectificación
- Rotación de claves criptográficas
- Proyección de mensajes del intermediario
- Prórrogas y atención de derechos
- Restauración y reversión beta
- Calibración de filtros HTTP
- Sondeo de recursos y límites
- Control de pila canónica
- Actualización transaccional de publicación
- Metadatos históricos de Redis
- Formularios de información de acceso
- Revisión de cobertura portable
- Contraste de materialización y UUID
- Paralelismo y duración de pruebas
- Retención privada y purgas
- Autoridades del proxy y recuperación
- Captura de recursos propios
- Conciliación de rutas y omisiones
- Auditoría de dependencias de derechos
- Observación de límites síncronos
- Inventario de orígenes retenidos
- Interfaces de agencias y organizaciones
- Plantillas de conservación y finalidades
- Diagnóstico de cadena SQL
- Candidata de evidencias integradas
- Lotes de cobertura y entrega
- Comandos de evaluación operativa
- Disposición y reintroducción fotográfica
- Formularios de levantamiento de restricciones
- Detalles de rectificación
- Rectificación de selección fotográfica
- Datos de copias de cuenta
- Validación de exclusiones portables
- Formularios de selección portátil
- Procesamiento de avisos privados
- Protocolo de mezcla final
- Contraste de fuentes MOD09
- Comprobación del entorno de capacidad
- Notificaciones de pruebas
- Mensajes y aclaraciones de derechos
- Configuración tecnológica e integración
- Migraciones de recuperación y retención
- Lectura histórica retenida Redis
- Privacidad de registros HTTP
- Observabilidad y transporte de eventos
- Equivalencia de políticas de publicación
- Controles HTTP combinados
- Composición SQL de cobertura
- Diseño de copias por paquetes
- Construcción de artefactos canónicos
- Controles del salón de deliberación
- Vistas de pedidos promocionales
- Escala de estados pendientes
- Presupuesto y calibración HTTP
- Señales históricas y testigos
- Prerregistro del carril de capacidad
- Revisión privada de recargas
- Contabilidad de mediciones
- Observación de entrada del servidor
- Ejecución del entorno de capacidad
- Inventario de dependencias secretas
- Diagnóstico de estados desconocidos
- Perfilado de entrega por proxy
- Restauración diagnóstica de PostgreSQL
- Recepción y prioridad de derechos
- Cargador del núcleo canónico
- Carga de imágenes rectificadas
- Conciliación de rotación de claves
- Recursos territoriales y volumen
- Atribución del coste combinado
- HTTP combinado a escala
- Diseño de reintroducción fotográfica
- Contrato de rectificación de cuenta
- Análisis de costes y capacidad
- Rol de ejecución y permisos
- Preparación de exportación portable
- Diagnóstico de publicaciones pendientes
- Conciliación de fuentes de interfaz
- Extremos de exportación y similitud
- Interfaz de formularios de copia
- Conciliación de regresión y requisitos
- Conciliación de exclusiones históricas
- Supresión de contactos y cuentas
- Rol y cadena de portabilidad
- Diseños canónicos y snapshots
- Dependencias del proyecto
- Rutas territoriales sintéticas
- Ordenación por duración de pruebas
- Plantillas de revisión de excepciones
- Calendario y levantamiento de publicación
- Temporización de solicitudes
- Inventario de reutilización fotográfica
- Filtros de acceso y recuperación
- Núcleo de serialización canónica
- Paquetes de imágenes de copia
- Rotación e inventario de secretos
- Control del cliente corregido
- Inventario de supresión y conservación
- Autoridad de revisión de cobertura
- Atención y aclaración de reclamaciones
- Conservación de cargas preparadas
- Autoridad de excepciones en espera
- Portabilidad del contenido fotográfico
- Auditoría de terminación técnica
- Actas de disposición técnica
- Observadores de recursos y conexiones
- Muestreo de sentencias PostgreSQL
- Rotación y aislamiento del intermediario
- Contrato de preparación de capacidad
- Instantáneas operativas agregadas
- Medición de contraste visual
- Evaluación de atención operativa
- Recuperación operativa de medios
- Avisos privados de rectificación
- Vistas de seguimiento de conservación
- Descomposición de latencia promocional
- Medidas de privacidad de publicación
- Atribución del circuito exportador
- Plan de cierre integrado
- Comunicaciones de derechos ejecutados
- Coste y dependencias del listado
- Intervalos de actualización
- Comprobación de enlaces documentales
- Codificación de snapshots diagnósticos
- Ejecución de integración local
- Atribución del planificador asíncrono
- Observación diagnóstica de cadenas
- Planificación del generador de carga
- Pruebas de restricciones de privacidad
- Contexto de fuentes de inspección
- Ámbito de validación del proxy
- Línea base de carga beta
- Transporte y recuperación de eventos
- Rotación de firmas de recibos
- Resolución independiente de reclamaciones
- Copia de cuenta sin perfil
- Revisión de conservación por finalidad
- Limitación y oposición por finalidad
- Entrega privada de portabilidad
- Salón local de deliberación
- Lanzador de capacidad VPS
- Controles del catálogo promocional
- Plantillas de apelaciones organizativas
- Panel y autenticación multifactor
- Plantillas de rectificación y destinatarios
- Plantillas de respuestas finales
- Interfaces de selección portátil
- Atribución de preparación promocional
- Instrumentación WSGI de cadena
- Heurísticas de estabilidad de capacidad
- Contextos del observador de conexiones
- Instrumentación de perfiles profesionales
- Inventario de rutas y concurrencia
- Liberación de respuestas WSGI
- Retención de objetos WSGI
- Transporte JSON de portabilidad
- Continuidad de servicios y outbox
- Inicio de comprobación de contacto
- Inventario de supresión de cuenta
- Cobertura declarada de portabilidad
- Contratos de moderación y vigencia
- Plantillas de revisión de cobertura
- Exportación y suplementos de acceso
- Interfaces de verificación y respuesta
- Muestreo de entregas privadas
- Manejador de eventos operativos
- Aislamiento de colas de pruebas
- Transporte binario de portabilidad
- Simulacro de escalada urgente
- Rectificación de canales de contacto
- Formularios de copias privadas
- Autoridad comercial sobre personas
- Revocación de clave HMAC
- Coste de hidratación de página
- Procedencia de lecturas históricas
- Estados mixtos en HTTP
- Control contractual del combinado
- Ejecución de restricciones por finalidad
- Consulta paginada de copias
- Observación de tareas Celery
- Diagnóstico del generador asíncrono
- Lector de archivos de diagnóstico
- Sonda de caducidad de entregas
- Sondas de caducidad y recuperación
- Sondeo de conservación de portabilidad
- Integración HTTP de políticas
- Atribución secuencial posterior TCP
- Recorrido del perfil en navegador
- Flujo de portabilidad con historial
- Localización del levantamiento de publicación
- Rechazo de historial rectificado
- Atribución de costes a escala
- Estado terminal del controlador
- Deuda del siguiente contrato
- Protocolo de reconstrucción del grafo
- Copias cifradas por partes
- Levantamiento de restricciones por finalidad
- Inventario de evidencias por finalidad
- Contrato de verificación y representación
- Inventario de colección de pruebas
- Sonda de borrado multimedia
- Revisión fotográfica y recibos privados
- Preparación de decisiones de tratamiento
- Revisión de divulgación de campos
- Planes SQL de cadenas
- Rectificación de cuentas sin perfil
- Guardas del intermediario Redis
- Estados de fallo de servicios
- Configuración del perfil de despliegue
- Perfilado de materialización de búsqueda
- Levantamiento de publicación en móvil
- Restauración del calendario de publicación
- Rectificación de tablas tarifarias
- Coste de relaciones heredadas
- Estadísticas de preparación promocional
- Contraste de estructura del historial
- Fuentes sobre paralelismo y planes
- Equivalencia de estados territoriales mixtos
- Integración del plan mixto
- Escenario HTTP mixto territorial
- Rutas de escenarios mixtos
- Carga con mezcla confirmada
- Inicialización del observador
- Preparación de mezcla corta
- Preparación contractual de mezcla
- Escenario contractual HTTP combinado
- Memoria terminal del controlador
- Preparación de candidata común
- Purga de confirmaciones de entrega
- Sonda de retención de exportaciones
- Sondeo del receptor operativo
- Observador TCP de publicación
- Plantillas de cierre de derechos
- Interfaces de restricciones por finalidad
- Plantilla de exportación privada
- Plantilla de propuesta de rectificación
- Diagnóstico de proyección de etiquetas
- Coste de políticas públicas
- Atribución de lectura promocional
- Localización del cierre de acceso
- Comparación de constructores ORM
- Cierre WSGI de descifrado
- Pruebas de diagnóstico de esperas
- Coste por etapas de exportación
- Configuración del correo
- Recuperación del trabajador de avisos
- Duración de objetos WSGI
- Control de tareas de recuperación
- Migraciones de consentimiento y fotografías
- Configuración del rol de evidencias
- Correctivas de historial y dependencias
- Correcciones de rutas públicas
- Finalización de estadísticas promocionales
- Coste del oráculo nativo
- Diagnóstico de arranque de servicios
- Observabilidad del escenario mixto
- Escenario HTTP de mil perfiles
- Carga HTTP combinada
- Candidata de pruebas funcionales
- Medidas durante supresión pendiente
- Objetos cifrados y entrega proxy
- Implementación de baseline diagnóstico
- Preparación de herramientas nativas
- Sondeo de alertas urgentes
- Reconstrucción de copias multipartes
- Lanzamiento persistente de procesos
- Interfaz de inspección de reclamaciones
- Recuperación de avisos y medios
- Cierre de acceso y recibos
- Interfaces finales de rectificación
- Inventario del ámbito de acceso
- Plantilla de omisiones portables
- Pruebas de similitud visual
- Preparación inicial de trabajadores
- Modelos de cadena de evidencias
- Documentación de almacenamiento beta
- Diagnóstico de límites del transporte
- Límites del trabajador síncrono
- Admisión y manejo síncrono
- Escala de estados mixtos
- Preparación de mezcla confirmada
- Derechos vinculados sin anuncio
- Contrato de interfaces comunes
- Emisor HTTP asíncrono
- Informe de tiempos del catálogo
- Informes intermedios de integración
- Sondeo de eventos operativos
- Cola interna de derechos
- Perfilado nativo de consultas
- Relojes de estabilidad WSGI
- Inicio y salud de aplicación
- Contraejemplos arquitectónicos PostgreSQL
- Control de instrumentación de capacidad
- Diagnóstico de conflictos nativos
- Atribución de variabilidad de solicitudes
- Publicación sin cuenta propia
- Autoridad del calendario de publicación
- Pruebas de selección binaria
- Migración del estado de publicación
- Inventario de trabajos portables
- Ejemplo de configuración productiva
- Fases del cliente HTTP
- Preparación de carga combinada
- Preparación del escenario combinado
- Calendario de restricciones por finalidad
- Aislamiento del intermediario de pruebas
- Sonda de recuperación de avisos
- Cola de restricciones por finalidad
- Plantilla de triaje de denuncias
- Revisión de respuesta de acceso
- Interfaz de comunicaciones a destinatarios
- Plantilla de información adicional
- Formulario de solicitud de derechos
- Interfaz de cierre de portabilidad
- Selección de imágenes portables
- Plantilla de evaluación portable
- Coste de codificación canónica
- Equivalencia territorial con pendientes
- Equivalencia territorial a escala
- Equivalencia territorial de estados mixtos
- Promociones públicas en móvil
- Invalidación condicional de publicación
- Rotación de credenciales PostgreSQL
- Iteración de respuestas observadas
- Configuración del núcleo
- Migración de índices tarifarios
- Migración de conflictos fotográficos
- Migración de dependencias de borradores
- Priorización de solicitudes de representación
- Migración de fechas de conservación
- Roles de ejecución y migración
- Contrato de publicación por finalidad
- Ejecución de pruebas por alcance
- Documentación del salón de deliberación
- Reserva de memoria de diagnóstico
- Filtros geográficos dinámicos
- Filtros geográficos de búsqueda
- Cola privada de reclamaciones
- Interfaz de decisiones de denuncias
- Plantilla de ejecución de supresión
- Planificación de supresión por finalidad
- Interfaz de inspección de denuncias
- Cola de eliminación de archivos
- Cola operativa de avisos
- Cola de reutilización fotográfica
- Propuesta de levantamiento por finalidad
- Preparación de imágenes de reemplazo
- Interfaz de propuesta de divulgación
- Asignación de solicitudes de derechos
- Evaluación de conjuntos portables
- Medición de consumidores escalares
- Controles SQL de WSGI
- Rotación de recibos firmados
- Migración inicial del catálogo
- Migración de productos promocionales
- Migración de auditoría promocional
- Migración de pedidos promocionales
- Migración de comprobación promocional
- Contexto del entorno de aplicación
- Migración de estado de cuenta
- Migración de autenticación multifactor
- Migración de aceptación legal
- Migración de revisión de agencias
- Migración de revisión de gestores
- Migración de representación anterior
- Migración de apelaciones de representantes
- Migración de apelaciones de agencias
- Migración de verificación telefónica
- Migración de versión de derechos
- Migración de supresión de publicación
- Migración de versiones de derechos
- Migración de supresión de cuenta
- Migración inicial de anuncios
- Migración de importes tarifarios
- Migración de áreas de desplazamiento
- Migración de envíos de anuncios
- Migración de decisiones de moderación
- Migración de origen de revisión
- Migración de base de aprobación
- Migración de apelaciones
- Migración de favoritos
- Migración de acciones de vigencia
- Migración de confirmación del ciclo
- Migración de revisión del ciclo
- Migración de índices textuales
- Migración de orden público
- Migración inicial de medios
- Migración de imágenes por revisión
- Migración de firmas de archivos
- Migración de comparación fotográfica
- Migración de resolución de coincidencias
- Migración de restricciones fotográficas
- Migración de apelaciones fotográficas
- Migración de opciones de borrado
- Esquema inicial de seguridad
- Migración de representación en denuncias
- Migración de asignación de denuncias
- Migración de opciones de denuncias
- Migración de revisión de restricciones
- Migración de avisos simulados
- Migración de solicitudes y acceso
- Migración de prioridad de derechos
- Migración de opciones de derechos
- Migración de representación en derechos
- Migración de mensajes de derechos
- Migración de versiones de acceso
- Migración de preguntas aclaratorias
- Migración de pruebas de identidad
- Migración de retirada de derechos
- Migración de exportaciones y descargas
- Migración de purga de exportaciones
- Migración de prórrogas de derechos
- Migración de acceso a denuncias
- Migración de acceso a reclamaciones
- Migración de asignación de reclamaciones
- Migración de decisiones de reclamaciones
- Migración de decisiones de reclamación
- Migración de opciones de reclamaciones
- Migración de avisos de reclamaciones
- Migración de acceso fotográfico reclamado
- Migración de intentos de avisos
- Migración de recuperación de avisos
- Migración de exportación de imágenes
- Migración de respuestas y avisos
- Migración de respuestas de acceso
- Migración de retención de publicación
- Migración de inventario de supresión
- Migración de planes de supresión
- Migración de ejecución de supresión
- Migración de versiones de pruebas
- Migración de alertas urgentes
- Migración de acuses de respuesta
- Migración de opciones de solicitudes
- Migración de levantamiento de restricciones
- Migración de mensajes de reclamación
- Migración de partes de exportación
- Migración de propuestas de rectificación
- Migración de lectura de rectificación
- Migración de opciones de expedientes
- Migración de notificaciones de rectificación
- Migración de ejecución de rectificación
- Migración de respuesta de rectificación
- Migración de avisos a gestores
- Migración de inventario de destinatarios
- Migración de evaluación de destinatarios
- Migración de evaluación de destinatarios
- Migración de carga de rectificación
- Migración de disposición fotográfica
- Migración de revisión de recargas
- Migración de confirmación de correo
- Migración de sujeto de cuenta
- Migración de huellas de cuenta
- Migración de rectificación de cuenta
- Migración de versión de rectificación
- Migración de exportación de cuenta
- Migración de inventario de supresión
- Migración de supresión de cuenta
- Migración de revisión de conservación
- Migración de planes de finalidad
- Migración de revisión de planes
- Migración de restricciones de tratamiento
- Migración de levantamiento por finalidad
- Migración de propuestas de excepción
- Migración de retención de publicación
- Migración de fundamentos de levantamiento
- Migración de cautelas de publicación
- Migración de calendario de publicación
- Migración de revisión de copias
- Migración de información de copias
- Migración de políticas de copia
- Migración de versiones de información
- Migración de lectura de copias
- Migración de lecturas y MFA
- Migración de vínculo informativo exportado
- Migración de evaluación de portabilidad
- Migración de revisión de portabilidad
- Migración de selección de portabilidad
- Migración de lectura de selección
- Migración de revisión de selección
- Migración de vínculo de portabilidad
- Migración de lectura binaria
- Migración de cobertura de portabilidad
- Migración de lectura de cobertura
- Migración de revisión de cobertura
- Migración de exportación con cobertura
- Migración de borradores de portabilidad
- Migración de revisión de respuestas
- Migración de cierre de portabilidad
- Migración de outbox de recuperación
- Migración de productor de recuperación
- Migración de borradores de respuesta
- Migración de revisión de acceso
- Migración de cobertura de acceso
- Migración de revisión de cobertura
- Migración de contabilidad de acceso
- Migración de inventario de acceso
- Migración de decisiones por campo
- Migración de cierre de acceso
- Migración de retención de borradores
- Migración de avisos a destinatarios
- Migración de páginas de selección
- Migración de sellado de exportaciones
- Migración de entrega de objetos
- Migración de hojas integradas
- Instalación de herramientas diagnósticas
- Plantilla de aceptación de invitaciones
- Interfaz de tokens de cuenta
- Plantilla de enlace caducado
- Formulario de denuncia de contenido
- Decisión de reintroducción fotográfica
- Disposición fotográfica de rectificación
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Referencias de autoría histórica
- Autoría del historial
- Referencias de autoría histórica
- Inventario diferencial y deuda
- Acta final y deuda
- Contrato de recorridos alfa
- Inventario y priorización N00
- Diagnóstico y presupuestos N01
- Diagnóstico N01 auditado
- Segmentos y medición N01
- Diagnóstico N01 auditado
- Preparación nativa y diagnóstico
- Diagnóstico N01 auditado
- Observación HTTP sintética
- Prerregistro de operaciones HTTP
- Resultado de operaciones HTTP
- Base de agregados operativos
- Resultado de operaciones HTTP
- Resultado de operaciones HTTP
- Atribución de inicio de revisión
- Resultado de operaciones HTTP

## God Nodes (most connected - your core abstractions)
1. `User` - 818 edges
2. `unseal()` - 524 edges
3. `RightsAction` - 468 edges
4. `Listing` - 429 edges
5. `Person` - 419 edges
6. `fingerprint()` - 366 edges
7. `Revision` - 355 edges
8. `Client` - 329 edges
9. `seal()` - 312 edges
10. `RightsRequest` - 301 edges

## Surprising Connections (you probably didn't know these)
- `User` ----> `prepare()`  [EXTRACTED]
  apps/core/models.py → tests/capacity_async_preflight.py
- `User` ----> `finish()`  [EXTRACTED]
  apps/core/models.py → tests/capacity_delivery_flow.py
- `User` ----> `populate()`  [EXTRACTED]
  apps/core/models.py → tests/capacity_target_fixture.py
- `User` ----> `resume()`  [EXTRACTED]
  apps/core/models.py → tests/diagnostic_baseline.py
- `User` ----> `test_chain_plans_with_real_history()`  [EXTRACTED]
  apps/core/models.py → tests/test_capacity_chain_explain.py

## Import Cycles
- None detected.

## Communities (864 total, 357 thin omitted)

### Community 0 - "Usuarios y solicitudes de derechos"
Cohesion: 0.02
Nodes (163): User, Meta, ErasureInventory, Meta, ProcessingExecution, Meta, ProcessingPlanRead, ProcessingPurposePlan (+155 more)

### Community 1 - "Exportación cifrada de portabilidad"
Cohesion: 0.03
Nodes (150): validated_kernel(), cipher(), unseal(), RightsPortabilityCoverage, Meta, RightsPortabilityCoverageRead, Meta, RightsPortabilityCoverageReview (+142 more)

### Community 2 - "Fotografías y descubrimiento"
Cohesion: 0.04
Nodes (64): kernel_identity(), post_worker_init(), prepare_static_structures(), backend_delta(), backend_snapshot(), namespace_pid(), owned_backend(), process_cpu() (+56 more)

### Community 3 - "Copias y respuestas de derechos"
Cohesion: 0.03
Nodes (110): seal(), RightsAccessScopeInventory, RightsExportInformationBinding, close(), closure_for_export(), require_complete_delivery(), signature(), validate_closure() (+102 more)

### Community 4 - "Proyección del estado de publicación"
Cohesion: 0.02
Nodes (146): real_checks(), Command, PublicationDirty, PublicationState, Meta, _rules_version, all_state_current(), eligible_ignoring_expiry() (+138 more)

### Community 5 - "Visibilidad y promociones"
Cohesion: 0.03
Nodes (129): Municipality, bump_one(), eligible(), enabled(), live_entitlements(), ranked(), rotation(), PromotionProduct (+121 more)

### Community 6 - "Supresión y restricciones por finalidad"
Cohesion: 0.03
Nodes (102): canonical(), inspect(), InventoryForm, source_manifest(), PrivacyHoldReleaseProposal, PrivacyPublicationHold, Meta, ProcessingPlanReview (+94 more)

### Community 7 - "Moderación de perfiles y fotografías"
Cohesion: 0.03
Nodes (108): Command, demo_image(), is_rectification_history(), ordinary_matches(), rectification_history_ids(), locked_pair(), resolve(), allowed_match() (+100 more)

### Community 8 - "Copias privadas de derechos"
Cohesion: 0.03
Nodes (107): operation_error(), RightsCopyPageReview, Meta, RightsExport, Meta, RightsExportDownload, RightsExportPreview, inspect_page() (+99 more)

### Community 9 - "Contexto de publicación pública"
Cohesion: 0.03
Nodes (93): candidates(), _detail_query_template(), memoize_publication_field_clean(), clean(), independent(), _PageReadCursor, _publication_annotations(), _publication_memo_key() (+85 more)

### Community 10 - "Cobertura de portabilidad por lotes"
Cohesion: 0.04
Nodes (101): RightsAction, RightsPortabilityImageRead, RightsPortabilitySelectionRead, batch_projection(), project(), inspect_batch(), _inspect, inspect() (+93 more)

### Community 11 - "Seguimiento documental del desarrollo"
Cohesion: 0.03
Nodes (31): Portabilidad: vincular cobertura, entrega y respuesta final, Auditoría de pendientes para aceptación CR-09, Restauración sin reintroducir datos retirados o suprimidos, Operación del registro de recuperación, Medición del avance del contrato, Recursos locales y aislamiento tras restauración, Matriz de ejecución y cierre por derecho — CR09, Preparación de orígenes Redis RDB/AOF (+23 more)

### Community 12 - "Moderación y apelaciones de anuncios"
Cohesion: 0.05
Nodes (74): Appeal, MatchResolution, PhotoAppeal, PhotoRestriction, Meta, agency_publication(), test_agency_two_people_shared_phone_editor_publication_and_revoke(), test_browser_agency_independent_review_of_two_publications() (+66 more)

### Community 13 - "Verificación de solicitudes de derechos"
Cohesion: 0.06
Nodes (78): PurposeReleaseProposal, Meta, RightsMessage, RightsProofEvent, RightsWithdrawal, current(), execute(), inspect() (+70 more)

### Community 14 - "Vistas de portabilidad"
Cohesion: 0.04
Nodes (44): caption(), editors(), proposal(), LocalizedForm, Catalog, Decision, DecisionsBase, ImageCatalog (+36 more)

### Community 15 - "Comunicaciones y respuestas finales"
Cohesion: 0.05
Nodes (71): acknowledge(), approved(), authorized_targets(), checked_ack(), checked_delivery(), deliver(), delivery_evidence(), inspect_notice() (+63 more)

### Community 16 - "Publicación según finalidad"
Cohesion: 0.03
Nodes (68): account_preferences, contratos/09, Evidencia, Evidencia, Evidencia, Evidencia, Evidencia, Evidencia (+60 more)

### Community 17 - "Medición de carga HTTP"
Cohesion: 0.05
Nodes (56): fetch_http(), run_async_open_loop(), GCObserver, generator_gc_overlap(), prepare_generator_gc(), PublicationSampler, create_backlog(), events() (+48 more)

### Community 18 - "Contexto de detalle propio"
Cohesion: 0.04
Nodes (64): RepresentationAction, build_detail_context_prototype(), patch_detail_view(), visit(), build_generic_reader(), read(), build_scoped_generic_context(), context() (+56 more)

### Community 19 - "Revisión de selección portátil"
Cohesion: 0.05
Nodes (53): RightsPortabilityAssessment, Meta, RightsPortabilityReview, Meta, RightsPortabilitySelection, Meta, checked_assessment(), inspect_assessment() (+45 more)

### Community 20 - "Reglas y formularios de perfiles"
Cohesion: 0.04
Nodes (56): AuthorizedRateFormSet, ContactsForm, Meta, DetailsForm, Meta, RateForm, Meta, RelatedSelect (+48 more)

### Community 21 - "Paginación y autoridad promocional"
Cohesion: 0.04
Nodes (61): order_population(), _snapshot_order_population(), _sql_order_population(), candidate_binding(), compared(), joined_authority(), test_joined_all_pages(), test_joined_checked_pending() (+53 more)

### Community 22 - "Invalidación de borradores privados"
Cohesion: 0.04
Nodes (57): Migration, Migration, expire_listings(), refresh_publication_state(), sweep_publication_state(), main(), start(), wait_clean() (+49 more)

### Community 23 - "Localización de interfaces"
Cohesion: 0.04
Nodes (31): RateWindow, main(), test_localized_destination_confirmation_preserves_token_and_account(), test_audited_access_localization_preserves_private_post_read(), test_temporary_browser_orm_thread_closes_connection(), operation(), test_anonymous_complaint_localization_preserves_private_intake(), browser() (+23 more)

### Community 24 - "Promociones y conciliación documental"
Cohesion: 0.03
Nodes (63): Migration, Migration, preserve_selected_labels(), specs(), B15, CB10, 103-roadmap-beta-clasificados-20261020.md, etapa0del roadmap (+55 more)

### Community 25 - "Planificación de la beta"
Cohesion: 0.28
Nodes (4): Acta17 — Aceptación técnica local B00, B00 corpus conciliado, Descifrado tras revocación reproducido, Whole corpus reviewed false

### Community 26 - "Información adicional de acceso"
Cohesion: 0.06
Nodes (49): source(), scoped(), RightsCopyInformation, Meta, RightsCopyInformationRead, RightsCopyInformationReview, Meta, checked_information() (+41 more)

### Community 27 - "Precedencia del contrato beta"
Cohesion: 0.04
Nodes (88): AD01, AD02, AD03, AD04, AD05, AD06, AD07, AD08 (+80 more)

### Community 28 - "Contrato y relevo técnico"
Cohesion: 0.04
Nodes (40): .ai/tasks/desarrollo.md, checked, checks, marco legal, geografía, roadmap, matriz B00–B01, antiduplicados (+32 more)

### Community 29 - "Inventario de recursos propios"
Cohesion: 0.06
Nodes (57): build_census(), capture_census(), producer_records(), reviewed_content_census(), scope_dependencies(), associated_content_records(), await_external_review(), capture_content() (+49 more)

### Community 30 - "Búsqueda y catálogos geográficos"
Cohesion: 0.06
Nodes (39): Command, Command, Category, GeographicSource, Province, Region, Service, Zone (+31 more)

### Community 31 - "Contratos y conciliación normativa"
Cohesion: 0.05
Nodes (9): Decisiones para cerrar el contrato de desarrollo, Contrato funcional de desarrollo — versión 1.1 hacia beta, B00-311 — Reglamento IA, infancia y límites de aplicabilidad, B00-312 — Autónomos e inteligencia competitiva, B00-313 — Consumidores y garantía de la libertad sexual, B00-314 — Propiedad intelectual y límites de la captura penal, B00-315 — PSD2: captura histórica y roles de pagos, B00-316 — IVA y servicios de pago: condiciones y límite de captura (+1 more)

### Community 32 - "Vistas de acceso a datos"
Cohesion: 0.06
Nodes (22): close_response(), CloseForm, review(), current(), independent(), localize_form(), prepare(), ProposalForm (+14 more)

### Community 33 - "Instrumentación de fases de capacidad"
Cohesion: 0.06
Nodes (68): _active(), Collector, _counter(), _plan(), scope(), _wrapper(), observed(), modules() (+60 more)

### Community 34 - "Medición de recursos de capacidad"
Cohesion: 0.06
Nodes (40): CapacityPhaseWriter, decode_phase(), validate_phase(), CapacityContainerPending, CapacityResourceObserver, CapacityResourceReader, check(), verify_capacity_identity() (+32 more)

### Community 35 - "Publicación y descubrimiento territorial"
Cohesion: 0.05
Nodes (41): PostalCode, Person, Meta, VerificationCheck, test_real_worker_and_beat_expire_and_bump_without_changing_editorial_state(), beat_completed(), start(), wait_for() (+33 more)

### Community 36 - "Autenticación multifactor e interfaces móviles"
Cohesion: 0.06
Nodes (36): challenge(), cipher(), CodeForm, consume_totp(), decrypt(), encrypt(), enroll(), PasswordForm (+28 more)

### Community 37 - "Gestión de reclamaciones"
Cohesion: 0.11
Nodes (60): ModerationDecision, Meta, act(), ComplaintAction, ComplaintMessage, ComplaintResolution, action(), coordinator() (+52 more)

### Community 38 - "Huellas y firmas de operaciones"
Cohesion: 0.07
Nodes (50): domain_signing_key(), validate_domain_key(), fingerprint(), operation_fingerprints(), benchmark(), _fresh(), measure(), native() (+42 more)

### Community 39 - "Fichas públicas y posicionamiento"
Cohesion: 0.05
Nodes (32): document, Reference Core Web Vitals y búsqueda, Google https://developers.google.com/search/docs/appearance/core-web-vitals, Reference directrices generales de datos estructurados de Google https://developers.google.com/search/docs/appearance/structured-data/sd-policies, Reference elemento script del estándar HTML https://html.spec.whatwg.org/multipage/scripting.html#the-script-element, Reference Evidencia evidencias/seo-publico-preparacion0110.json, Reference evidencia evidencias/sitemaps-preparacion0110.json, Reference Guía SEO para desarrolladores, Google https://developers.google.com/search/docs/fundamentals/get-started-developers, Reference Informe y huellas evidencias/seo-estructurado-preparacion0110.json (+24 more)

### Community 40 - "Rectificación y revisión de destinatarios"
Cohesion: 0.08
Nodes (33): RightsRectificationRecipientAssessment, Meta, RightsRectificationRecipientInventory, RightsRectificationRecipientReview, inspect(), propose(), read_stamp(), validate_decisions() (+25 more)

### Community 41 - "Gestión del ciclo de perfiles"
Cohesion: 0.08
Nodes (36): person_queryset(), document(), index(), accept_consent(), age(), CodeForm, ConsentForm, ConsentInviteForm (+28 more)

### Community 42 - "Contenido de entregas de acceso"
Cohesion: 0.08
Nodes (38): console_mail_projections(), account_mail_projection(), broker_records(), compile_package(), log_records(), mail_records(), project_group(), projected_fields() (+30 more)

### Community 43 - "Cobertura del derecho de acceso"
Cohesion: 0.07
Nodes (36): compile_coverage(), container_paths(), decision(), action(), ActionForm, calendar_months(), case_export_forms(), inspect() (+28 more)

### Community 44 - "Revisiones de conservación"
Cohesion: 0.09
Nodes (36): RetentionReview, Meta, RetentionReviewEvent, Meta, authorized(), locked(), plan_decisions(), reconcile() (+28 more)

### Community 45 - "Registro y almacenamiento de recuperación"
Cohesion: 0.11
Nodes (27): canonical(), Checkpoint, digest(), LedgerIntegrityError, RecoveryLedger, valid_hash(), RecoveryStore, test_command_requires_isolation_and_valid_authority_then_deletes_and_replays() (+19 more)

### Community 46 - "Ejecución de rectificación de cuenta"
Cohesion: 0.11
Nodes (38): enabled(), inspect_token(), purge_expired_delivery(), start(), RightsAccountEmailConfirmation, RightsRectificationExecution, RightsRectificationNotification, RightsRectificationProposalRead (+30 more)

### Community 47 - "Inventario de recorridos beta"
Cohesion: 0.06
Nodes (48): apps/catalog/promotion_exposure.py, apps/catalog/promotion_order_urls.py, apps/catalog/promotion_urls.py, apps/catalog/tasks.py, apps/core/urls.py, apps/core/views.py, apps/listings/discovery.py, apps/listings/moderation_views.py (+40 more)

### Community 48 - "Costes de filtros combinados"
Cohesion: 0.06
Nodes (24): artifacts/beta-promotion-fix-20261020/attribution269-audit.json, artifacts/beta-promotion-fix-20261020/attribution270-audit.json, artifacts/beta-promotion-fix-20261020/contract265-audit.json, artifacts/beta-promotion-fix-20261020/short262-audit.json, checked, protocolo239, Decisión y alcance finito, Integración245 (+16 more)

### Community 49 - "Huellas de fuentes y revisiones"
Cohesion: 0.08
Nodes (34): part_tables(), _parts(), source_rows(), _union(), aggregate(), fingerprint_profile(), private_credentials(), scrub() (+26 more)

### Community 50 - "Documentación de copias privadas"
Cohesion: 0.06
Nodes (7): Revisión persistente de páginas de copia privada, Compilación de decisiones por páginas, Contactos registrados de la propia cuenta en copias privadas, Relaciones de la propia cuenta con agencias, Información adicional de acceso y distinción de portabilidad, Revisión independiente de información de acceso, Información revisada en exportación privada

### Community 51 - "Gestión de reclamaciones privadas"
Cohesion: 0.10
Nodes (27): append(), complete_read(), MessageForm, submit(), validate(), resolve(), resolve_listing(), resolve_report() (+19 more)

### Community 53 - "Catálogo de promociones"
Cohesion: 0.11
Nodes (36): ProductForm, Meta, VersionForm, Meta, PromotionCatalogueAudit, Meta, audit(), authority() (+28 more)

### Community 54 - "Cuentas y aceptación legal"
Cohesion: 0.09
Nodes (34): LegalAcceptance, Meta, LegalDocument, Meta, replace_terms(), test_localized_acceptance_preserves_stale_version_and_missing_document_gates(), email_path(), legal_docs() (+26 more)

### Community 55 - "Registro de evidencias de desarrollo"
Cohesion: 0.04
Nodes (41): Aviso oficial, docs/21-resolucion-reclamaciones.md, docs/28-ejecucion-supresion-ambitos.md, docs/30-supresion-imagenes-almacenamiento.md, docs/31-recuperacion-borrado-archivos.md, docs/33-supresion-contactos-invitaciones.md, docs/34-supresion-cuenta.md, docs/36-atencion-derechos.md (+33 more)

### Community 56 - "Resúmenes de contenido e imágenes"
Cohesion: 0.10
Nodes (40): image_contents(), content_digest(), _native_sha256(), operation_content_digests(), _supported_key(), images(), test_bulk_fresh_metadata_is_three_queries_and_preserves_single_bytes(), test_bulk_rejects_mapping_changed_during_actual_blob_lock_wait() (+32 more)

### Community 57 - "Entrega privada de objetos"
Cohesion: 0.10
Nodes (32): authorize_token(), _binding(), _directory(), _grant_digest(), invalidate_restored_deliveries(), _path(), proxy_or_direct(), purge_export_deliveries() (+24 more)

### Community 58 - "Conciliación de herramientas y documentación"
Cohesion: 0.07
Nodes (42): 4e69f29cbf6a55e96b002550c0e0acaf6d4ed32712f1823f4acd9c85ad4bdbae, 7831760d2d38a263433a1e137bc1c05bf8a2a2a8c46f462d6f9b5d39f402307f, artifacts/beta-promotion-fix-20261020/b00-331-*, c2a8d4dc42bbede33cd5eca452d621e6b866a9e4c47d4bd26794409d58ed2964, conciliación289, ledger, B00-331 — Pruebas de portabilidad, objetos y autoridad, LOGIN (+34 more)

### Community 59 - "Lectura de denuncias y galería"
Cohesion: 0.07
Nodes (32): AgencyMember, Auditoría de referencia, B09-343 — Diagnóstico de lecturas de la cola de denuncias, N+1, permitted, acta19, referencia de autoridad, comparación reproducible (+24 more)

### Community 60 - "Cifrado de objetos almacenados"
Cohesion: 0.12
Nodes (39): _aad(), _authenticate_frames(), authenticated_plaintext(), _b64(), _canonical(), decrypt(), encrypt(), _header() (+31 more)

### Community 61 - "Privacidad y alertas urgentes"
Cohesion: 0.08
Nodes (17): apply(), HoldForm, fresh_authority(), queue_reports(), authorize(), authorized(), queue(), AccessForm (+9 more)

### Community 62 - "Índice histórico de evidencias"
Cohesion: 0.04
Nodes (47): roadmap beta, Contrato16 v1.6/MOD-06, seguimiento17, Evidencias de desarrollo: índice histórico, release PyPI, docs/22-procesamiento-avisos.md, docs/23-copia-derechos-datos-imagenes.md, docs/24-respuestas-cierre-derechos.md (+39 more)

### Community 63 - "Conciliación legal e histórica"
Cohesion: 0.07
Nodes (40): artifacts/beta-promotion-fix-20261020/b00-308-corrections.json, b00-308-before-*, producto01, seguridad03, decisiones05, acta16, DEC-037, DEC-038 (+32 more)

### Community 64 - "Agencias y conflictos de representación"
Cohesion: 0.11
Nodes (30): accept_invitation(), add_person(), AgencyForm, assign(), AssignmentForm, can_manage_person(), create(), InvitationForm (+22 more)

### Community 65 - "Trabajos de exportación portable"
Cohesion: 0.13
Nodes (37): RightsPortabilityExportJob, Meta, check_authority(), claim(), dispatch(), enqueue(), failure_location(), finish_attempt() (+29 more)

### Community 66 - "Inspección y alertas urgentes"
Cohesion: 0.12
Nodes (36): ReportAccess, UrgentReportAlert, Meta, test_urgent_restriction_hides_every_surface_and_preserves_peer_and_audit(), decision(), prepared(), test_case_change_invalidates_old_read_even_with_fresh_decision_form(), test_legacy_or_older_page_audit_cannot_authorize_current_decision() (+28 more)

### Community 67 - "Conciliación de catálogo y medios"
Cohesion: 0.07
Nodes (17): Command, catalogue(), Migration, B00-317 — Mapa histórico, configuración y contraste de representación, B00-318 — Catálogo y anuncios históricos frente al contrato romántico, B00-319 — Núcleo y medios: guardas actuales y límites de la captura, CR-05 — Fotografías y coincidencias, interfaz v1, Almacenamiento privado S3 (+9 more)

### Community 68 - "Exportación y cobertura de portabilidad"
Cohesion: 0.10
Nodes (27): checked_action(), checked_reason(), checked_reason_body(), validate_approved_coverage(), validate_coverage_pages(), coverage_summary(), validate_binding(), _validate_export_binding (+19 more)

### Community 69 - "Decisiones y restricciones de denuncias"
Cohesion: 0.15
Nodes (37): act(), fresh_authority(), ReportAction, Restriction, coordinator(), test_coordinator_recovers_assignment_after_reviewer_loses_permission(), test_report_author_cannot_coordinate_own_case(), test_unassignment_cannot_reopen_resolved_case() (+29 more)

### Community 70 - "Registro de decisiones"
Cohesion: 0.08
Nodes (43): DEC-001, DEC-002, DEC-003, DEC-004, DEC-005, DEC-006, DEC-007, DEC-008 (+35 more)

### Community 71 - "Diagnósticos de materialización"
Cohesion: 0.07
Nodes (33): joined_authority_candidate(), test_joined_authority_balanced_roi(), dispatch(), execute(), fetch(), read(), snapshot(), materialization_candidate() (+25 more)

### Community 72 - "Cargas preparadas y limpieza"
Cohesion: 0.15
Nodes (37): MediaPreparationCleanup, cleanup_due_preparations(), cleanup_one(), delete_prepared(), prepare_cleanup(), retention_reason(), RightsRectificationPhotoUpload, expire() (+29 more)

### Community 73 - "Perfilado de procesos trabajadores"
Cohesion: 0.12
Nodes (36): Collector, _phase(), scope(), functions(), run(), test_callback_failure_preserves_domain_failure_and_teardown(), broken_clock(), DomainFailure (+28 more)

### Community 74 - "Verificación y consentimiento"
Cohesion: 0.11
Nodes (27): PhoneClaim, Meta, VerificationEvent, normalize_phone(), publication_ready(), receive_event(), simulate_event(), start_age_check() (+19 more)

### Community 75 - "Cola de avisos privados"
Cohesion: 0.13
Nodes (32): ComplaintNotice, ReportNotice, SimulatedComplaintNoticeDelivery, SimulatedNoticeDelivery, process_outbox(), simulated_adapter(), enqueue_ack(), enqueue_outcome() (+24 more)

### Community 76 - "Manifiestos paginados de fuentes"
Cohesion: 0.13
Nodes (22): _fresh_source(), inspection_source(), _InspectionSource, scope(), shared_row_reference(), source_digest(), source_fingerprint(), materialize_physical() (+14 more)

### Community 77 - "Arquitectura y agencias"
Cohesion: 0.08
Nodes (30): document, Reference ADR-001 adr/001-base-tecnica.md, Reference brainstorming y viabilidad evidencias/mod08-brainstorm-web-20261011.md, Reference contrato14 14-contrato-funcional-v1.md, Reference contrato16 16-contrato-ejecucion-desarrollo.md, Reference contrato de medios contratos/05-fotografias-coincidencias.md, Reference Copia íntegra anterior 17-historial/2026-10-09-02-arquitectura-antes-organizacion.md, Reference core/urls.py ../apps/core/urls.py (+22 more)

### Community 78 - "Rectificación e historial de acceso"
Cohesion: 0.08
Nodes (10): document, Reference evidencia evidencias/acceso-historico-rectificacion.json, Reference evidencia evidencias/conservacion-cargas-preparadas.json, Reference Evidencia evidencias/rectificacion-cargas-sustitucion.json, Reference Evidencia evidencias/regresion-ci-7f00034.json, document, Documented status, Reference Evidencia evidencias/acceso-historico-rectificacion.json (+2 more)

### Community 79 - "Medición temporal de solicitudes"
Cohesion: 0.11
Nodes (41): collect(), phase_snapshot(), Response, test_client_pair_ids_align_with_tcp_samples_and_exclude_profiled(), post(), test_concurrent_writers_stay_bounded(), write(), test_consumption_and_close_then_record() (+33 more)

### Community 80 - "Planes de supresión"
Cohesion: 0.11
Nodes (26): prepare(), authorized_inventory(), current_plan_actor(), DecisionForm, normalized_decisions(), PlanForm, prepare(), record() (+18 more)

### Community 81 - "Ejecución de supresión"
Cohesion: 0.13
Nodes (36): ErasureExecution, Meta, test_scoped_proof_expiring_during_read_denies_erasure_without_effects(), read_then_expire(), payload(), plan_fixture(), test_actual_scoped_deletion_replay_isolated_sources_and_sessions(), test_execution_concurrent_same_key_has_one_effect() (+28 more)

### Community 82 - "Aplicación de recuperación y medios"
Cohesion: 0.14
Nodes (23): RecoveryApplication, RecoveryMediaJob, Meta, RecoveryOutbox, apply_database(), queue_media(), reconcile(), stored_receipt() (+15 more)

### Community 83 - "Sellos de validación"
Cohesion: 0.12
Nodes (37): _pipeline_connection(), _replay(), _replay_serial(), check(), full_rejects(), generated(), native_pipeline(), test_existing_native_pipeline_is_not_nested_and_remains_operational() (+29 more)

### Community 84 - "Adaptación del perfil romántico"
Cohesion: 0.08
Nodes (29): document, Reference acta12 actas/12-beta-b02b03-aceptacion-local-20261020.md, Reference auditoría común evidencias/b02b03-common-terminal-audit-20261020.json, Reference Auditoría posterior evidencias/beta-copy-functional-terminal-audit-20261020.json, Reference contrato funcional1.1 14-contrato-funcional-v1.md, Reference Evidencia de ejecuciones evidencias/beta-perfil-verificacion-inicial-20261020.json, Reference evidencia evidencias/beta-copy-residual-delta-20261020.json, Reference negativo conservado evidencias/beta-copy-negative-terminal-audit-20261020.json (+21 more)

### Community 85 - "Referencias oficiales de tecnologías"
Cohesion: 0.08
Nodes (44): argon2-cffi official reference, blake3 official reference, boto3/botocore official reference, Caddy official reference, Celery official reference, Claude Code official reference, Codex official reference, cryptography official reference (+36 more)

### Community 86 - "Liberación de contexto WSGI"
Cohesion: 0.09
Nodes (32): render_owned_context(), assert_owned_links_released(), observe_contexts(), capture(), render_engine(), synthetic_processor(), SyntheticProcessorError, test_invalid_context_keeps_native_type_error() (+24 more)

### Community 87 - "Equivalencia de canonicalización nativa"
Cohesion: 0.10
Nodes (39): Data, Dict, Float, Int, List, native_check(), nested(), Number (+31 more)

### Community 88 - "Inventario de claves de cifrado"
Cohesion: 0.10
Nodes (25): checked_registry(), _classify(), collect_inventory(), InventoryUnavailable, _readers(), Command, keys(), metric() (+17 more)

### Community 89 - "Orígenes de históricos Redis"
Cohesion: 0.12
Nodes (21): collect_aux(), collect_physical(), decode_body(), decoder_limits(), private_file(), aux_decoder(), capture(), metadata_decoder() (+13 more)

### Community 90 - "Asignación y vinculación de derechos"
Cohesion: 0.14
Nodes (33): account(), test_account_link_is_audited_idempotent_and_creates_no_profile(), test_account_link_rejects_conflict_mixed_reference_erased_and_representation(), action(), prepared(), test_assignment_and_coordinator_recovery_preserve_dates_and_replay(), test_author_cannot_assign_own_request_and_stale_version_cannot_reset(), test_independent_coordinator_recovers_after_assignee_loses_permission() (+25 more)

### Community 91 - "Ejecución y respuesta de supresión"
Cohesion: 0.10
Nodes (25): apply(), current_erasure_actor(), execute(), ExecutionForm, RightsExportPart, Meta, test_declared_label_is_optional_and_does_not_replace_profile_type(), test_label_filter_keeps_declared_woman_and_unknown_types_distinct() (+17 more)

### Community 92 - "Contratos de exposición comercial"
Cohesion: 0.08
Nodes (23): document, F01, F02, F03, F04, F05, F06, F07 (+15 more)

### Community 93 - "Taxonomía y descubrimiento geográfico"
Cohesion: 0.09
Nodes (21): document, Reference contrato14 14-contrato-funcional-v1.md, Reference contrato14 v1.1 14-contrato-funcional-v1.md, Reference contrato de borradores contratos/04-borradores-catalogo-geografia.md, Reference contrato de descubrimiento contratos/08-descubrimiento.md, Reference Correos: información de códigos postales y correspondencias https://www.correos.es/es/es/herramientas/codigos-postales/detalle?query=30205%2C+ESP&searchtype=001, Reference CR-07 actas/02-cr07-local.md, Reference INE: municipios y códigos por provincias https://www.ine.es/dyngs/INEbase/operacion.htm?c=Estadistica_C&cid=1254736177031&idp=1254735976614&menu=ultiDatos (+13 more)

### Community 94 - "Protocolo de carga HTTP"
Cohesion: 0.09
Nodes (5): B07 — Corto beta acotado con fase Beat, B07 — Confirmación única del corto acotado, B07 — Modo específico beta HTTP contractual, B07 — Calibración de quince subidas, B07 — Protocolo definitivo beta HTTP900s

### Community 95 - "Cuentas y confirmación de correo"
Cohesion: 0.12
Nodes (21): accept_current(), AcceptanceForm, dashboard(), docs(), EmailForm, limited(), LoginForm, recover() (+13 more)

### Community 96 - "Interfaces de comunicaciones de derechos"
Cohesion: 0.09
Nodes (12): inbox(), NoticeForm, visible(), AccessForm, DecisionForm, prepare(), target_title(), CommunicationForm (+4 more)

### Community 97 - "Diseño de seguridad y privacidad"
Cohesion: 0.09
Nodes (27): document, Reference Categorías especiales y bases de legitimación, AEPD https://www.aepd.es/preguntas-frecuentes/2-tus-obligaciones-como-responsable-del-tratamiento/5-bases-legitimadoras-del-tratamiento/FAQ-0215-cuales-son-las-bases-de-legitimacion-para-el-tratamiento-de-las-categorias-especiales-de-datos, Reference Django: checklist de despliegue https://docs.djangoproject.com/en/6.0/howto/deployment/checklist/, Reference DSA y contenido ilegal, Comisión Europea https://digital-strategy.ec.europa.eu/en/factpages/tackling-illegal-content-online-digital-services-act, Reference Evaluación de riesgos, AEPD https://evalua-riesgo.aepd.es/, Reference Guía de cookies, AEPD https://www.aepd.es/guias/guia-cookies.pdf, Reference LOPDGDD, BOE https://www.boe.es/buscar/act.php?id=BOE-A-2018-16673, Reference LSSI, BOE https://www.boe.es/buscar/act.php?id=BOE-A-2002-13758 (+19 more)

### Community 98 - "Paginación y escala territorial"
Cohesion: 0.09
Nodes (15): document, Documented status, Reference Auditoría evidencias/b07-territory196-preparation-20261021-audit.json, Reference matriz180 180-matriz-cobertura-b07-censo-geografico-20261021.md, document, Documented status, Reference Auditoría evidencias/b07-territory197-filters-pages-20261021-audit.json, Reference Auditoría evidencias/b07-territory198-filters-pages-20261021-audit.json (+7 more)

### Community 99 - "Cadena de evidencias de derechos"
Cohesion: 0.13
Nodes (24): backfill_missing(), ChainTicket, configure_role(), record_tombstone(), require_runtime_chain(), _runtime_is_trusted(), _source_rows(), _source_rows_pipeline() (+16 more)

### Community 100 - "Contraste TCP y materialización"
Cohesion: 0.09
Nodes (20): línea de base108, corrección109, contrato16, criterios de medición, auditoría de planes, auditoría10000, auditoría de atribución1000, auditados (+12 more)

### Community 101 - "Conciliación de pruebas y privacidad"
Cohesion: 0.09
Nodes (4): B00-327 — Pruebas capturadas y alcance de evidencia, B00-328 — Pruebas de privacidad, descubrimiento y medios, B00-329 — Excepciones, publicación y recuperación, B00-330 — Derechos, copias y comprobación vigente de supresión

### Community 102 - "Unicidad y detección de duplicados"
Cohesion: 0.10
Nodes (11): document, Reference contrato14 14-contrato-funcional-v1.md, Reference fotografías/coincidencias contratos/05-fotografias-coincidencias.md, Reference Google libphonenumber: normalización y validación https://github.com/google/libphonenumber, Reference ImageHash: métodos perceptuales y resistentes a recortes https://github.com/JohannesBuchner/imagehash/blob/master/README.rst, Reference moderación/publicación contratos/06-moderacion-publicacion.md, Reference OpenCV: correspondencias y verificación mediante homografía https://docs.opencv.org/4.12.0/d1/de0/tutorial_py_feature_homography.html, Reference PDQ: implementación y comparación de huellas https://github.com/facebook/ThreatExchange/blob/main/pdq/README.md (+3 more)

### Community 103 - "Cuentas y condiciones legales"
Cohesion: 0.10
Nodes (25): aviso-legal/, Copia anterior a consolidación, seguimiento17, contrato de cuentas/legal, DSA: condiciones y notificación de contenido, AEPD: deber de informar y separación del consentimiento, Ley General de Publicidad, LSSI: identificación e información contractual (+17 more)

### Community 104 - "Copias y respuestas de derechos"
Cohesion: 0.10
Nodes (7): document, Documented status, Reference operación 12-operacion-seguridad.md, document, Documented status, Reference AEPD: derechos https://www.aepd.es/en/rights-and-duties/know-your-rights, Reference RGPD en EUR-Lex https://eur-lex.europa.eu/legal-content/ES/ALL/?uri=CELEX%3A32016R0679

### Community 105 - "Conciliación de contratos históricos"
Cohesion: 0.09
Nodes (4): B00-323 — Contratos, historial y precedencia vigente, B00-324 — Derechos por etapas y precedencia del grafo, B00-325 — Conservación, portabilidad y diseños de capacidad, B00-326 — Contratos, diagnósticos y relevos históricos

### Community 106 - "Inventario de pantallas y estados"
Cohesion: 0.09
Nodes (9): Inventario finito de pantallas y estados para GS-01, Inventario residual tras GS01 — 2026-10-19, GS01 — puerta de separación técnica local, 2026-10-19, URL name referenced by template: rights_inspect, URL name referenced by template: rights_portability_export, Private copy generation template, database_value(), run() (+1 more)

### Community 107 - "Analizadores nativos de RDB"
Cohesion: 0.13
Nodes (21): aux(), hex(), main(), quiet(), array(), aux(), db(), function() (+13 more)

### Community 108 - "Ventanas de eventos operativos"
Cohesion: 0.13
Nodes (19): Command, _constant(), _integer(), load_window(), _object(), summarize_window(), _valid(), WindowUnavailable (+11 more)

### Community 109 - "Supresión de cuentas y concurrencia"
Cohesion: 0.12
Nodes (22): AccountToken, RecoveryCode, data(), prepared_erasure(), test_account_execution_denies_unreviewed_editorial_stale_and_production_scopes(), test_account_scoped_execution_preserves_evidence_and_procedural_channel(), test_mobile_account_inventory_plan_execution_and_response(), attempt() (+14 more)

### Community 110 - "Supresión y propiedad recuperada"
Cohesion: 0.13
Nodes (22): PhoneChallenge, RepresentationInvitation, _projection(), snapshot(), capture(), finalized(), ids(), validate_empty_replacement() (+14 more)

### Community 111 - "Borrado y recuperación de medios"
Cohesion: 0.15
Nodes (29): erase_due_media(), erase_one(), MediaErasure, Meta, MediaErasureRecovery, requeue(), setup(), test_distinct_blob_with_shared_storage_path_prevents_file_deletion() (+21 more)

### Community 112 - "Selección binaria de portabilidad"
Cohesion: 0.11
Nodes (21): prepare(), audited_images(), checked_images(), test_binary_page_save_keeps_one_copy_and_fresh_versions_preserving_native_choices(), checked_versions(), counted(), unshared(), test_binary_save_rechecks_late_changes_after_final_snapshot_and_rolls_back() (+13 more)

### Community 113 - "Planes de modernización técnica"
Cohesion: 0.09
Nodes (14): document, Reference Acta10 actas/10-entrega-tecnica-local-alpha-20261020.md, Reference recibo evidencias/test-optimization-bulk-history-control-20261019.json, Reference recibo evidencias/test-optimization-native-batch-control-20261019.json, Reference Recibo terminal evidencias/test-optimization-terminal-audit-20261019.json, Análisis estático del repositorio — Claude Code, Sello de entrega de portabilidad — diseño, no adoptado, Plan de modernización técnica — MOD-08 (+6 more)

### Community 114 - "Calibración de mezcla territorial"
Cohesion: 0.10
Nodes (12): document, Documented status, Reference Auditoría evidencias/b07-territory200-tcp-functional-20261021-audit.json, document, Documented status, Reference Auditoría evidencias/b07-territory201-balanced-tcp-20261021-audit.json, document, Documented status (+4 more)

### Community 115 - "Instantáneas de directorios de pruebas"
Cohesion: 0.15
Nodes (23): _admin(), cache_key(), context(), _empty_fixture_database(), _quiescent(), seed_or_restore(), Snapshot, SnapshotBusy (+15 more)

### Community 116 - "Lectura de objetos por flujo"
Cohesion: 0.14
Nodes (34): legacy_read(), observe(), Client, get_object(), tombstone(), test_mock_read_cancellation_closes_body_and_private_scratch(), CancelBody, CancelTarget (+26 more)

### Community 117 - "Calendario de finalidades"
Cohesion: 0.16
Nodes (21): PurposeCalendarEvent, Meta, record(), test_actual_release_and_calendar_follow_up_observe_each_other_after_wait(), attempt(), operation(), test_changed_case_reference_after_scope_wait_is_denied(), attempt() (+13 more)

### Community 118 - "Observación de procesos trabajadores"
Cohesion: 0.14
Nodes (25): collect_events(), post_worker_init(), route_response(), WorkerObserver, call(), application(), status(), test_opt_in_gc_records_real_collection_and_removes_callback() (+17 more)

### Community 119 - "Metadatos públicos y SEO"
Cohesion: 0.11
Nodes (14): canonical(), Head, pub_client(), test_browser_metadata_navigation_and_retirement(), retire(), test_only_available_listing_languages_are_indexable_and_pending_content_excluded(), test_public_metadata_localization_filters_privacy_and_origin(), Documents (+6 more)

### Community 120 - "Recepción y acuses privados"
Cohesion: 0.15
Nodes (26): Complaint, Meta, moderator(), payload(), test_actor_replay_foreign_receipt_and_escaped_reference_do_not_confer_access(), test_anonymous_encrypted_intake_minimal_receipt_replay_and_no_automatic_change(), test_audited_triage_separate_permission_mfa_and_own_case_exclusion(), test_channel_errors_keep_privacy_headers() (+18 more)

### Community 121 - "Ámbitos del historial Redis"
Cohesion: 0.18
Nodes (23): history_records(), scoped_history(), results_visit(), visit(), project_result(), task_reference(), message(), test_encrypted_history_reader_binds_source_cutoff_and_preserves_partial() (+15 more)

### Community 122 - "Marco legal y privacidad"
Cohesion: 0.11
Nodes (15): document, Reference Categorías especiales y legitimación, AEPD https://www.aepd.es/preguntas-frecuentes/2-tus-obligaciones-como-responsable-del-tratamiento/5-bases-legitimadoras-del-tratamiento/FAQ-0215-cuales-son-las-bases-de-legitimacion-para-el-tratamiento-de-las-categorias-especiales-de-datos, Reference Código Penal, LO 10/1995 https://www.boe.es/buscar/act.php?id=BOE-A-1995-25444, Reference contrato funcional vigente 14-contrato-funcional-v1.md, Reference Defensa de consumidores, RDL 1/2007 https://www.boe.es/buscar/act.php?id=BOE-A-2007-20555, Reference Directrices EDPB01/2022, versión2, apartado4.2.2, párrafo110 https://www.edpb.europa.eu/system/files/2023-04/edpb_guidelines_202201_data_subject_rights_access_v2_en.pdf, Reference DSA, Reglamento (UE) 2022/2065 https://eur-lex.europa.eu/legal-content/ES/ALL/?uri=CELEX%3A32022R2065, Reference Guía de cookies, AEPD https://www.aepd.es/guias/guia-cookies.pdf (+7 more)

### Community 123 - "Política y conciliación de capacidad"
Cohesion: 0.11
Nodes (9): document, Reference acta16 actas/16-beta-b07-aceptacion-local-20261023.md, Reference contrato16§16 16-contrato-ejecucion-desarrollo.md#16-consolidación-del-rendimiento-de-lectura--mod-04, Reference criterios de carga criterios-revision-benchmark-carga.md, Reference línea base108 108-linea-base-beta-b07-20261020.md, Reference roadmap103 103-roadmap-beta-clasificados-20261020.md, document, Reference Equivalencia244 216-equivalencia-local-production-checked-b07-20261022.md (+1 more)

### Community 124 - "Conciliación de rutas promocionales"
Cohesion: 0.11
Nodes (21): acta18, B08-341 — Paridad promocional en transacción heredada, promotion_paging, READ COMMITTED, state_page, acta18, dirty_1001, B08-342 — Fallback promocional con umbrales reales (+13 more)

### Community 125 - "Excepciones de tratamiento"
Cohesion: 0.11
Nodes (28): account_preferences, AEPD, limitación del tratamiento, consumed_action, Excepciones acotadas a restricciones de tratamiento, erasure_execute, erasure_execution.execute, /es|en/moderation/rights/<uuid:case_id>/exceptions/<int:proposal_id>/review/, /es|en/moderation/rights/<uuid:case_id>/exceptions/<uuid:plan_id>/prepare/ (+20 more)

### Community 126 - "Plantilla de inspección de derechos"
Cohesion: 0.11
Nodes (32): URL name referenced by template: erasure_final, URL name referenced by template: erasure_inventory, URL name referenced by template: media_erasure_jobs, URL name referenced by template: privacy_hold_release, URL name referenced by template: privacy_publication_hold, URL name referenced by template: processing_final, URL name referenced by template: processing_prepare, URL name referenced by template: purpose_restriction_queue (+24 more)

### Community 127 - "Base de diagnóstico y restauración"
Cohesion: 0.17
Nodes (23): _admin(), _adopt(), BaselineCleanupError, capture(), codec(), _create_database(), _create_login(), _drop_login() (+15 more)

### Community 128 - "Mapas y metadatos públicos"
Cohesion: 0.12
Nodes (15): add_urls(), candidates(), directory(), index(), listings(), robots(), xml_response(), health() (+7 more)

### Community 129 - "Autoría del historial"
Cohesion: 0.09
Nodes (31): Commit 02ddf4cc6b9972a619bcda966266831ff2951b97, Commit 069062714deabce869114d9c472ffb0cdbc67d47, Commit 08174b882e07aaa6c6855274565e8a0520e2f200, Commit 19a099066711924dd53f7a449321c41b31692d64, Commit 2b44b5223ae8426c1f5ef74bb9162eb6b582ace0, Commit 2ef2a884399fb434d57fc139c7a2c182798de620, Commit 3a677646dd2834eceaa64e89f8fdb6db8dff57c8, Commit 3c92e2c6674e85f95cd7200827d9c517eaf7e4ad (+23 more)

### Community 130 - "Recursos y atribución de carga"
Cohesion: 0.11
Nodes (3): document, document, document

### Community 131 - "Conciliación de referencias AST"
Cohesion: 0.11
Nodes (28): 121a6bc6a9f4daa26b6c36e554ee3f153be2a5a9445082bc7c0763d026612d3d, 778ddb24a18fa9654277901f4e6a99d1b3f8a78da793e92500f722b0da4302e9, artifacts/beta-promotion-fix-20261020/b00-338-*, before_task_publish, builtins.str, Visibilidad, política del perfil, revisión de cobertura (+20 more)

### Community 132 - "Derechos de cuentas sin perfil"
Cohesion: 0.11
Nodes (14): account_subject, seguimiento17, matriz88, Derechos de una cuenta sin perfil, locked_profile_case, person, RightsProof, RightsRectificationProposal (+6 more)

### Community 133 - "Apelaciones y restricciones fotográficas"
Cohesion: 0.14
Nodes (15): conflict(), latest_decision(), queue(), review(), submit(), queue(), review(), reviewer_allowed() (+7 more)

### Community 134 - "Contenido de objetos privados"
Cohesion: 0.14
Nodes (16): _new_s3_client(), repository(), context(), image_bytes(), part_bytes(), purge_export_objects(), purge_orphan_export_objects(), seal_binary() (+8 more)

### Community 135 - "Partes de datos exportados"
Cohesion: 0.14
Nodes (18): _archive(), chunk_packages(), data_packages(), json_chunks(), stored_payload(), files(), test_cli_reconstructs_without_network_or_application_runtime(), test_invalid_copy_leaves_no_output_or_temporary_file() (+10 more)

### Community 136 - "Requisitos del producto romántico"
Cohesion: 0.12
Nodes (26): document, Reference contrato16 16-contrato-ejecucion-desarrollo.md, Reference Contrato funcional 1.1 14-contrato-funcional-v1.md, Reference Contrato funcional v1 14-contrato-funcional-v1.md, REQ-001, REQ-002, REQ-003, REQ-004 (+18 more)

### Community 137 - "Inventarios y criptografía histórica"
Cohesion: 0.12
Nodes (29): AAD, AESGCM, AESOCB3, apps/safety/object_storage/codec.py, artifacts/beta-promotion-fix-20261020/b00-303-base-ledger175.json, b00-303-*, registro de fuentes, B00-303 — Runtime, criptografía e inventarios históricos (+21 more)

### Community 138 - "Conciliación de cookies y legislación"
Cohesion: 0.12
Nodes (27): artifacts/beta-promotion-fix-20261020/b00-304-*, b00-304-external-original-attempts.json, registro vigente, pista de copia en un dominio universitario, informe CGPJ indexado, Cython, B00-304 — Cookies, legislación y diagnóstico, faulthandler (+19 more)

### Community 139 - "Planes y ámbitos de supresión"
Cohesion: 0.11
Nodes (11): Decisiones por finalidad de supresión y conservación, Ejecución parcial de supresión por ámbitos, ejecución por ámbitos, create_draft, Supresión de contenido editorial y alias, ErasureExecution, locked_manager_person, Person.publication_erased_at (+3 more)

### Community 140 - "Dependencias del almacenamiento local"
Cohesion: 0.12
Nodes (20): pytest_collection_modifyitems(), require_object_store_image(), test_available_image_check_is_read_only_and_bounded(), inspect(), test_missing_dependency_is_error_without_daemon_output(), inspect(), test_transitive_fixture_dependency_checked_once(), test_unrelated_selection_never_inspects_docker() (+12 more)

### Community 141 - "Inventario de evidencias de derechos"
Cohesion: 0.15
Nodes (22): specs(), base(), action(), runtime(), set_role(), test_backfill_restored_rows_preserves_existing_links_and_detects_drift(), test_chain_inventory_scopes_metadata_and_excludes_current_procedure(), test_concurrent_runtime_inserts_and_rollback_share_head() (+14 more)

### Community 142 - "Auditoría técnica de seguridad"
Cohesion: 0.12
Nodes (22): document, IMP001, IMP002, IMP003, IMP004, IMP005, IMP006, IMP007 (+14 more)

### Community 143 - "Plan de validación de seguridad"
Cohesion: 0.12
Nodes (13): document, G-01 Alcance, G-02 Privacidad, G-03 Acceso, G-04 Medios, G-05 Integridad/abuso, G-06 Operación, G-07 Moderación (+5 more)

### Community 144 - "Retención del cliente generador"
Cohesion: 0.12
Nodes (10): document, Documented status, Reference Auditoría evidencias/b07-client-task-release-20261021-audit.json, Reference terminal189 189-protocolo-beta-http-900s-b07-20261021.md, document, Documented status, Reference Auditoría evidencias/b07-task-release-native-calibration-20261021-audit.json, document (+2 more)

### Community 145 - "Observación de recursos del kernel"
Cohesion: 0.12
Nodes (11): document, Documented status, Reference 181 181-colector-recursos-servicios-beta-b07-20261021.md, document, Documented status, Reference Auditoría terminal evidencias/b07-resources207-kernel-functional-20261022-audit.json, Reference matriz180 180-matriz-cobertura-b07-censo-geografico-20261021.md, document (+3 more)

### Community 146 - "Conciliación de protección de datos"
Cohesion: 0.12
Nodes (21): artículo 9, artifacts/beta-promotion-fix-20261020/b00-306-*, registro de fuentes, B00-306 — RGPD por partes y portales institucionales, EIPD, source:431a0t1dyvxb0w4a79z7, source:9b7spltl0q7anf9xz0yf, source:u09oolq9q5tku9xah8zq (+13 more)

### Community 147 - "Conciliación de acceso y portabilidad"
Cohesion: 0.12
Nodes (3): B00-320 — Seguridad y derechos: capturas 1–2 y resultado telefónico, B00-321 — Seguridad, acceso y autorización posterior a bloqueos, B00-322 — Seguridad, portabilidad y autoridad de consulta privada

### Community 148 - "Conciliación del informe histórico"
Cohesion: 0.12
Nodes (27): 81f556537d14d59d750928255735b86ea93ee91481e80f23cdbf5cd1c81ce1bd, artifacts/beta-promotion-fix-20261020/b00-336-*, Contrato14, análisis19, acta16, visibilidad, contrato romántico, PublicationContext (+19 more)

### Community 149 - "Recibos y respuestas de derechos"
Cohesion: 0.11
Nodes (29): Receipt acknowledgement does not mean agreement, Clarification receipt and identity limitation, Partial erasure response guidance, Private extension notice and delivery distinction, Reviewed image download POST control, Reviewed package part download POST control, Private export download POST control, Restriction and erasure distinction (+21 more)

### Community 150 - "Lecturas de presentación pública"
Cohesion: 0.13
Nodes (14): _measure(), describe(), names(), PagePresentation, selected_photo(), test_committed_changes_after_guard_precede_presentation_reads(), after_guard(), update_other_connection() (+6 more)

### Community 151 - "Pruebas de sellos de validación"
Cohesion: 0.18
Nodes (21): RightsExportValidationSeal, Meta, login(), observe(), full(), holds(), recording(), replay() (+13 more)

### Community 152 - "Vistas de tratamiento y excepciones"
Cohesion: 0.16
Nodes (12): execution(), ExecutionForm, LocalizedProcessingForm, preparation(), PreparationForm, review(), ReviewForm, prepare() (+4 more)

### Community 153 - "Procedencia de registros retenidos"
Cohesion: 0.16
Nodes (17): checked_capture(), checked_scoped_captures(), collect(), docker_output(), main(), scoped_origin_name(), signed_subject_log_event(), subject_log_signature() (+9 more)

### Community 154 - "Respuesta y cierre de portabilidad"
Cohesion: 0.15
Nodes (14): allowed(), close_response(), CloseForm, DecisionForm, DraftForm, prepare_response(), review_response(), ReviewForm (+6 more)

### Community 155 - "Precedencia de fuentes contractuales"
Cohesion: 0.12
Nodes (21): B15, roadmap103B15, contrato14§6.1, acta16, Registro por fuente, nota oficial26julio2023, nota oficial18octubre2023, Revista del Ministerio Fiscal16/2025 (+13 more)

### Community 156 - "Alertas y cautelas de privacidad"
Cohesion: 0.11
Nodes (10): document, document, Reference Correctiva N2 evidencias/cr09-correo-autoridad-urgencias-correctiva-20261009.json, Reference Evidencia evidencias/alertas-autoridad0110.json, Reference evidencia evidencias/alertas-autoridad-runtime0110.json, Reference Evidencia evidencias/alertas-seguimiento0110.json, Reference prueba del simulacro ../tests/test_urgent_report_drill.py, Reference Runtime evidencias/alertas-seguimiento-runtime0110.json (+2 more)

### Community 157 - "Estadísticas y atribución de consultas"
Cohesion: 0.12
Nodes (21): statement_family(), data_checksums(), planner_metadata(), prepared_metadata(), test_statistics_after_promotional_fixture(), read(), snapshot(), test_backend_mapping_is_scoped_and_rejects_reused_or_moved_pid() (+13 more)

### Community 158 - "Verificación paralela de objetos"
Cohesion: 0.15
Nodes (28): real_settings(), test_mock_iterator_close_after_failure_does_not_mask_domain(), fail(), objects(), test_mock_metadata_exception_cannot_mask_earlier_physical_failure(), objects(), verify(), test_mock_two_pending_ordered_exception_and_wait_for_started_jobs() (+20 more)

### Community 159 - "Revisión y apelaciones de agencias"
Cohesion: 0.16
Nodes (17): AgencyAppeal, AgencyReview, Meta, rejected_agency(), test_agency_appeal_cannot_reopen_changed_state_or_be_resolved_by_member(), test_agency_appeal_reopens_without_verification_and_preserves_original(), test_concurrent_agency_appeal_resolution_changes_version_once(), resolve() (+9 more)

### Community 160 - "Operaciones de avisos"
Cohesion: 0.19
Nodes (20): NoticeRecovery, Meta, allowed(), locked_report(), queue(), recover(), RecoveryForm, requeue() (+12 more)

### Community 161 - "Registro y restauración de supresión"
Cohesion: 0.15
Nodes (13): RecoveryLedgerState, Meta, export_batch(), prepare_batch(), test_actual_media_receipt_passes_typed_validation(), test_committed_file_survives_db_failure_and_retry_confirms_it(), fail_ack(), test_concurrent_producer_replay_and_tamper_rollback() (+5 more)

### Community 162 - "Clientes de lectura de objetos"
Cohesion: 0.17
Nodes (18): client(), read_clients(), configured(), real_settings(), test_mock_config_drift_inside_constructor_never_retains_wrong_target(), changing_create(), test_mock_every_configuration_field_is_fresh(), test_mock_lifecycle_nested_failure_cap_and_all_close_attempts() (+10 more)

### Community 163 - "Sellos de validación de derechos"
Cohesion: 0.17
Nodes (18): _annotated(), caller_digest(), _caller_values(), value(), _code_version(), create(), decode(), encode() (+10 more)

### Community 164 - "Tareas de purga y conciliación"
Cohesion: 0.16
Nodes (17): deliver_safety_notices(), generate_portability_export(), purge_expired_access_coverage(), purge_expired_access_field_decision(), purge_expired_access_response_drafts(), purge_expired_access_scope_inventory(), purge_expired_account_confirmation_delivery(), purge_expired_copy_information() (+9 more)

### Community 165 - "Análisis local del grafo"
Cohesion: 0.13
Nodes (11): document, Documented status, Reference conciliación295 295-conciliacion-informe-grafo-historico-b00-20261024.md, Reference consolidación104 104-consolidacion-contrato-beta-b00b01-20261020.md, Reference Contrato16 §15 16-contrato-ejecucion-desarrollo.md#15-delegación-sin-máximo-numérico--mod-03, Reference docs02 02-arquitectura.md, Reference Evidencia de alcance del refresco evidencias/b00b01-grafo-actualizacion-20261020.json, Reference examen del 2026-10-09 evidencias/examen-graphify-20261009.json (+3 more)

### Community 166 - "Inventario de consumidores de secretos"
Cohesion: 0.16
Nodes (15): Bindings, BodyCalls, inventory(), collect(), imported(), project(), test_assigned_alias_is_explicitly_outside_supported_resolution(), test_current_closure_contains_report_receipts_and_rights_operations() (+7 more)

### Community 167 - "Eventos operativos y tareas"
Cohesion: 0.14
Nodes (15): _allowed(), _emit(), publication_read(), PublicationEventsMiddleware, task_result(), RecoveryAwareTask, recorded_events(), test_logging_failure_cannot_break_response_or_task() (+7 more)

### Community 168 - "Ciclo de vida de anuncios"
Cohesion: 0.22
Nodes (24): LifecycleAction, expire_one(), own(), payload(), test_action_history_does_not_expose_previous_manager_events(), test_agency_editor_assignment_mfa_and_revocation(), test_availability_expires_without_beat_and_resume_preserves_dates(), test_availability_pause_resume_withdraw_and_old_retry() (+16 more)

### Community 169 - "Paginación y pertenencia promocional"
Cohesion: 0.13
Nodes (15): Auditoría, Auditoría, Auditoría funcional, Auditoría, Auditoría de planes, B08–B11 — Prototipo aislado de paginación comercial por agregación, person_queryset, rights AS MATERIALIZED (+7 more)

### Community 170 - "Conciliación del corpus histórico"
Cohesion: 0.13
Nodes (24): 4bcf6d33e29b899e7ac07d28f03e87d6fc884aa2e354320bdf25dc794abc0cd9, 5dcae68ccbaf2302f8bfc475fb433f208ed1dd16d8b000e2ccef5e96529dbcf9, 6eb5b716022fa051a36e223d16621c83d875da3f7847a887522265379f89b68b, artifacts/beta-promotion-fix-20261020/b00-339-*, B00_accepted=false, bb82c74de6c1936cabf566657ce303a537c882c1fa7dc84d647a574604ede366, captured_source_dispositions_complete=true, salida del roadmap (+16 more)

### Community 171 - "Supresión de imágenes compartidas"
Cohesion: 0.12
Nodes (10): docs/31, docs/32, Supresión de imágenes, huellas y almacenamiento, erase_media_files, erased, erasing, MediaErasure, record_match (+2 more)

### Community 172 - "Conciliación de candidata B16"
Cohesion: 0.13
Nodes (10): document, Reference evidencia auditada evidencias/b16-contractual-http-audit-20261025.json, document, Reference acta22 actas/22-beta-b16-aceptacion-local-20261025.md, Reference auditoría de grupos adicionales evidencias/b16-additional-groups-audit-20261025.json, Reference auditoría operativa375 evidencias/b16-operational-gates-reconciliation-20261025.json, Reference disposición374 evidencias/b16-selection-tcp-disposition-20261025.json, Reference matriz de candidata evidencias/b16-final-candidate-reconciliation-20261025.json (+2 more)

### Community 173 - "Almacenamiento de artefactos diagnósticos"
Cohesion: 0.16
Nodes (16): ArchiveSink, _check(), parse_mountinfo(), tmpfs_bytes(), writable_storage(), write_artifact(), test_archive_ceiling_is_enforced_by_kernel_rlimit(), test_archive_explicit_ceiling_survives_default_changes() (+8 more)

### Community 174 - "Diagnóstico de recorridos escalares"
Cohesion: 0.17
Nodes (20): benchmark(), counted_leaves(), wrapper(), observed(), wrapper(), scope(), source_census(), statistics() (+12 more)

### Community 175 - "Pruebas del transporte asíncrono"
Cohesion: 0.14
Nodes (26): test_client_phases_preserve_partial_timeout_and_emitter_accounting(), exercise(), handler(), test_completed_http_tasks_are_released_while_ledger_is_retained(), fetch(), tracked_create_task(), test_local_tcp_chunked_body_post_headers_and_redirect_status(), exercise() (+18 more)

### Community 176 - "Verificación sin extracción de objetos"
Cohesion: 0.17
Nodes (25): Discard, encoded(), outcome(), test_codec_exact_negative_class_message_order_and_atomic_read_output(), test_codec_same_total_and_identical_source_read_order(), __init__(), read(), Source (+17 more)

### Community 177 - "Controlador de capacidad VPS"
Cohesion: 0.21
Nodes (26): command(), test_backlog_requires_exact_small_territorial_observer_mode(), test_backlog_watchdog_covers_preparation_without_relaxing_other_commands(), test_beta_http_functional_is_exclusive_bounded_and_never_delivery_measurement(), test_combined_cycle_covers_every_selected_page_with_balanced_locales(), test_combined_filters_are_exclusive_functional100_with_unchanged_quotas(), test_combined_full_load10000_reaches_controller_with_unchanged_budget(), test_combined_population_reaches_controller_without_relaxing_exclusivity() (+18 more)

### Community 178 - "Autoridad de claves de recuperación"
Cohesion: 0.13
Nodes (5): Command, Command, Command, test_wrong_ledger_key_preserves_commands_data_sessions_and_files(), snapshot()

### Community 179 - "Rectificación de cuenta"
Cohesion: 0.16
Nodes (15): apply(), display(), locked_subject(), source(), validate(), test_account_proposal_http_is_audited_encrypted_and_rejects_stale_source(), test_account_source_is_subject_scoped_and_binds_credentials(), test_account_wait_precedes_revision_and_blob_locks_and_refreshes_credentials() (+7 more)

### Community 180 - "Rutas escalares de portabilidad"
Cohesion: 0.17
Nodes (19): _scalar_paths(), pure_benchmark(), original(), paths(), candidate(), original(), outcome(), test_lazy_mutation_send_close_and_throw() (+11 more)

### Community 181 - "Conciliación comercial y contraseñas"
Cohesion: 0.13
Nodes (20): b00-300-audit.json, Canonical, CCBill, roadmap103, consolidación104, DAFO98, registro individual vigente, B00 — SEO, seguridad y fuentes comerciales conciliadas (+12 more)

### Community 182 - "Selección y origen de portabilidad"
Cohesion: 0.13
Nodes (3): Evaluación de portabilidad por conjuntos, Selección granular aprobada de portabilidad, Portabilidad de conjuntos con origen mixto

### Community 183 - "Favoritos y restricciones por finalidad"
Cohesion: 0.15
Nodes (12): add(), index(), remove(), Favorite, Meta, blocked_response(), require_unrestricted(), restricted() (+4 more)

### Community 184 - "Similitud visual de imágenes"
Cohesion: 0.21
Nodes (23): _axis_windows(), CandidateResult, compare_images(), compare_signatures(), consider(), compute_signature(), confirm_match(), _good_matches() (+15 more)

### Community 185 - "Inspección y selección de denuncias"
Cohesion: 0.16
Nodes (18): Report, Meta, test_report_inspection_rechecks_authority_after_scope_wait(), after_scope_wait(), record_decryption(), revoke(), login_reviewer(), native_ids() (+10 more)

### Community 186 - "Operación de seguridad e incidentes"
Cohesion: 0.14
Nodes (12): 06-marco-legal.md, auditoría100, acta B-B09, primer fallo de arranque, Ensayo BB06 propio, documentación oficial de Django, Operación de seguridad e incidentes, safety.execute_rights_request (+4 more)

### Community 187 - "Requisitos y autoridad de recuperación"
Cohesion: 0.14
Nodes (14): roadmap103, acta15, Evidencia, Auditoría, matriz auditada, B13 — Matriz vigente de requisitos y autoridad de recuperación, RECOVERY_MODE, RecoveryLedger (+6 more)

### Community 188 - "Conciliación de CSS e integración"
Cohesion: 0.14
Nodes (21): 618ab375a3a210b6dd9abca5ae8db8cedf837dad25b53e7ce846f011fde9e07c, 663a126f65493dc73a3de7f1fdf17da2697666747234408968018e073174a5ad, artifacts/beta-promotion-fix-20261020/b00-334-*, c58b67eac4c77fc84edf0608bad9ca1a5750b8bea6559b36bb171f08d3c51966, wrapper actual, repositorio de objetos seleccionado, CI local, guard de recuperación (+13 more)

### Community 189 - "Topología de servidores de comparación"
Cohesion: 0.13
Nodes (13): server_topology(), compatible_order_reference(), call(), OrderVariantMiddleware, test_default_preserves_four_sync_workers(), test_frozen_order_reference_keeps_original_arguments_with_snapshot_keyword(), reference(), test_threaded_candidate_rejects_other_modes_or_normal_resources() (+5 more)

### Community 190 - "Pruebas del cargador canónico"
Cohesion: 0.20
Nodes (23): artifact(), child(), rejected(), test_absent_build_uses_reference(), test_changed_binary_at_same_path_is_rejected(), test_concurrent_load_is_single_and_sealed(), test_duplicate_manifest_fields_are_rejected(), test_failed_initialization_never_retries_or_reuses_an_old_mapping() (+15 more)

### Community 191 - "Revisión de reintroducción fotográfica"
Cohesion: 0.23
Nodes (16): RightsPhotoReintroduction, Meta, RightsPhotoReintroductionRead, active(), decide(), inspect(), locked(), permission() (+8 more)

### Community 192 - "Propuestas de rectificación"
Cohesion: 0.18
Nodes (12): RightsRectificationSourceRead, display(), source(), validate(), prepare(), preview(), ProposalForm, propose() (+4 more)

### Community 193 - "Recibos de recuperación de medios"
Cohesion: 0.20
Nodes (17): _destroy_one(), checked_unseal(), destroy_due(), destroy_one, Unresolved normalized identifier reference, verified_receipts(), identifier(), require() (+9 more)

### Community 194 - "Continuidad y rotación de credenciales"
Cohesion: 0.15
Nodes (4): B13 — Continuidad y moderación, 2026-10-21, B13 — Cierre estático de consumidores HMAC, B13 — Rotación de login PostgreSQL y conexiones existentes, B13 — Rotación de credencial Redis y transporte Kombu

### Community 195 - "Instrumentación de trabajadores WSGI"
Cohesion: 0.18
Nodes (18): application(), observation(), outputs(), write(), Response, test_domain_failure_remains_identical_and_hook_is_restored(), original(), test_listing_phase_marker_bypasses_both_profilers_and_drains() (+10 more)

### Community 196 - "Guardas de bases de diagnóstico"
Cohesion: 0.15
Nodes (19): require_diagnostic(), baseline_modules(), test_aead_roundtrip_preserves_original_expiry_and_authenticated_end(), test_baseline_index_stream_is_bounded_and_ordered(), test_baseline_rejects_acceptance_before_resources(), test_capture_archive_expanded_count_remains_finite_and_normal_default(), test_controller_error_scrubs_timeout_command_secrets(), test_dependency_identity_binds_lock_versions_and_python() (+11 more)

### Community 197 - "Sesiones de clientes de objetos"
Cohesion: 0.19
Nodes (23): configured(), test_native_fallback_always_constructs_fresh_session(), Client, close(), __init__(), Keys, Session, client() (+15 more)

### Community 198 - "Revisión y apelaciones de gestores"
Cohesion: 0.17
Nodes (16): ManagerAppeal, ManagerReview, Meta, manager_rejection(), test_concurrent_manager_appeal_resolution_records_one_result(), resolve(), test_manager_appeal_cannot_approve_obsolete_authorization(), test_manager_appeal_independence_persistence_and_no_auto_publication() (+8 more)

### Community 199 - "Transporte de eventos operativos"
Cohesion: 0.18
Nodes (8): _after_fork_child(), _after_fork_parent(), _before_fork(), NonBlockingOperationalHandler, main(), drain(), rss_bytes(), sample()

### Community 200 - "Calendario y cadena de evidencias"
Cohesion: 0.15
Nodes (11): backfill(), install(), uninstall(), install(), Migration, uninstall(), Migration, runtime_functions() (+3 more)

### Community 202 - "Corrección de ruta promocional"
Cohesion: 0.15
Nodes (13): document, Reference auditoría causal evidencias/b08-perfil-causal-audit-20261020.json, Reference Auditoría común de instantánea evidencias/b08-snapshot-common-terminal-audit-20261020.json, Reference Auditoría común evidencias/b08-common-terminal-audit-20261020.json, Reference Auditoría de baseline1000/10000 evidencias/b07-diagnostico1000-10000-audit-20261020.json, Reference Auditoría de comparación evidencias/b08-diagnostico1000-10000-audit-20261020.json, Reference Auditoría de escala de instantánea evidencias/b08-snapshot1000-10000-audit-20261020.json, Reference auditoría de paridad/instantánea evidencias/b08-snapshot-parity-audit-20261020.json (+5 more)

### Community 203 - "Informes de operación y purga"
Cohesion: 0.15
Nodes (4): B12 — Informes locales de ventanas de eventos, B12 — Coste del snapshot y rotación propia, B12 — Evaluación administrativa y runbook local, B12 — Supervisión de medios y trabajo de purga física

### Community 204 - "Concurrencia y recursos multimedia"
Cohesion: 0.15
Nodes (20): apps/mediafiles/services.py, artifacts/beta-promotion-fix-20261020/b00-305-*, registro vigente, config/settings.py, decode_image, B00-305 — Concurrencia, recursos y medios, HX-Request, memory.high (+12 more)

### Community 205 - "Conciliación ECMAScript y Django"
Cohesion: 0.14
Nodes (18): 05c765e5376ad2dec3496c1eb986c9ae1a26bd17ff3e8a8af195681a286a33c3, artifacts/beta-promotion-fix-20261020/b00-335-*, contrato14, capa de middleware, reglas de formulario del servidor, lector de medios actual, settings actual, ledger (+10 more)

### Community 206 - "Relaciones y ámbitos de modelos"
Cohesion: 0.15
Nodes (20): 29dbb6357595b79cebad33b7c0b84f82dc3b96ef03819c1b13f41d9e18c818e8, 704fe95396ae99fa5035cdebc163807524c97d734da69e414c87474e5b0a59a2, apps_safety_models_meta, artifacts/beta-promotion-fix-20261020/b00-337-*, contrato de perfil, similitud, código actual de modelos, revisión de cobertura (+12 more)

### Community 207 - "Transporte HTTP de entregas"
Cohesion: 0.17
Nodes (11): open_client(), operator(), post(), PrivateDeliveryRedirect, PrivateProxyTransport, SourceHTTPHandler, Connection, test_capacity_client_uses_actual_bound_peer_and_consumes_whole_body() (+3 more)

### Community 208 - "Lectura continua de objetos"
Cohesion: 0.21
Nodes (20): Body, mock_case(), operation(), Client, get_object(), run(), tombstone_check(), reference() (+12 more)

### Community 210 - "Evaluación de instantáneas operativas"
Cohesion: 0.25
Nodes (18): assess(), collect_snapshot(), codes(), test_command_observes_real_durable_delay_read_only_and_never_echoes_paths(), test_database_failure_never_returns_partial_assessment(), fail(), test_empty_observation_never_reports_healthy_and_missing_window_is_visible(), test_failed_jobs_purge_eligibility_and_disabled_processor_have_fixed_responses() (+10 more)

### Community 211 - "Propuestas de rectificación de campos"
Cohesion: 0.19
Nodes (19): RightsRectificationProposal, Meta, display(), source(), validate(), test_catalog_form_requires_active_compatible_categories_and_services(), test_contact_proposal_requires_verified_owner_and_audited_binding(), test_correction_text_obeys_listing_editor_limits_and_contact_rules() (+11 more)

### Community 212 - "Proyección de etiquetas comerciales"
Cohesion: 0.15
Nodes (9): conciliación del corto existente, auditoría terminal, auditoría negativa, auditoría, Diagnóstico del orden comercial global restringido a candidatos, auditoría terminal, Diagnóstico de proyección SQL de etiquetas comerciales, Auditoría (+1 more)

### Community 213 - "Despacho y pendientes territoriales"
Cohesion: 0.16
Nodes (8): document, Documented status, Reference 180 180-matriz-cobertura-b07-censo-geografico-20261021.md, Reference Auditoría terminal evidencias/b07-backlog211-native-dispatch-20261022-audit.json, document, Documented status, Reference Auditoría independiente evidencias/b07-equivalence213-unknown49-20261022-audit.json, Reference matriz180 180-matriz-cobertura-b07-censo-geografico-20261021.md

### Community 214 - "Seguridad transaccional y trazas"
Cohesion: 0.16
Nodes (20): artifacts/beta-promotion-fix-20261020/b00-302-*, b00-302-architecture-reading-plan.json, registro de fuentes, config/settings.py, CSP, B00-302 — Seguridad, transacciones y trazas, MFA, Report-Only (+12 more)

### Community 215 - "Plantillas de gestión comercial"
Cohesion: 0.13
Nodes (9): Conditional indexing and bilingual metadata, Published product configuration immutable, Simulated payment outcome only, Promotion does not alter editorial dates, Preview does not grant promotion, Versioned release form, Catalogue configuration without sales, Product draft and released versions (+1 more)

### Community 216 - "Interfaces móviles de tratamiento"
Cohesion: 0.16
Nodes (9): test_mobile_apply_and_subject_favorites_block(), assert_execution(), assert_preparation(), assert_review(), choices(), labels(), test_execution_scope_choices_preserved(), test_mobile_processing_preparation() (+1 more)

### Community 217 - "Formularios de respuesta parcial"
Cohesion: 0.17
Nodes (7): final(), FinalForm, final(), ProcessingForm, assert_form(), check_missing_preparation(), test_partial_response_effective_execution_type()

### Community 218 - "Serialización canónica de derechos"
Cohesion: 0.21
Nodes (13): canonical(), canonical_bytes(), _check(), content_reference(), reference_check(), test_action_fingerprint_still_keyed_and_distinct_from_content(), test_canonical_utf8_bytes_keep_the_keyed_fingerprint(), test_content_reference_binds_dataset_position_and_entire_row() (+5 more)

### Community 219 - "Preparación de entrega final"
Cohesion: 0.16
Nodes (17): document, Reference 3226PASS+4subpruebas/122SKIP/1FAIL evidencias/c-final-shared-restore-failure-20261019.json, Reference 3PASS/0SKIP evidencias/c-restore-corrective-terminal-20261019.json, Reference acta10 actas/10-entrega-tecnica-local-alpha-20261020.md, Reference acta productiva pendiente actas/11-preparacion-produccion-pendiente-20261019.md, Reference Auditoría comparativa evidencias/test-optimization-terminal-audit-20261019.json, Reference B-B09 actas/09-bb-aceptacion-tecnica-local-20261019.md, Reference B-F08 actas/08-bf-aceptacion-tecnica-local-20261019.md (+9 more)

### Community 220 - "Carga HTTP de estados mixtos"
Cohesion: 0.16
Nodes (12): 2c890e8a78f1c797112fc42ebc2799cec280d6fe540dc1d5df348109e4ccf2e2, 384823f5325f7a0c345a84b0db998db8082ec81430232f52d8078f99ea2e71da, c79d1b79bdf1cf4413cf4397a4339c659a716529bcb6cb2ea0ddfa934a156bd6, B07 — HTTP mixto1000 con rutas corregidas, e4672764-5015-4acf-bc7d-498248255dd2, mixed251-audit.json, sha256:6936424d8c105237645efd3424be6ef31c74f7cb32904db3c963ddf9a7e1f44e, artifacts/beta-promotion-fix-20261020/mixed252-audit.json (+4 more)

### Community 221 - "Observación del consumo de CPU"
Cohesion: 0.18
Nodes (10): cpu_counters(), cpu_delta(), group_path(), OwnedCPUObserver, read_group(), fixture(), test_cpu_delta_uses_elapsed_and_cumulative_counters_without_counting_wait_as_cpu(), test_missing_optional_controller_interfaces_stay_explicit() (+2 more)

### Community 222 - "Atribución de hidratación promocional"
Cohesion: 0.16
Nodes (17): PhaseRecorder, call(), test_current_promotional_request_phases(), fetch(), measured_read(), read(), snapshot(), sql() (+9 more)

### Community 223 - "Diagnóstico de esperas de capacidad"
Cohesion: 0.21
Nodes (10): AdaptationProxy, adapted_fetch(), wrapped(), scope(), measured(), wrapped(), scope(), test_proxy_preserves_adaptation_result_and_restores_on_throw() (+2 more)

### Community 224 - "Ciclo de procesos Gunicorn"
Cohesion: 0.17
Nodes (10): compact_scalene_profile(), server(), sample(), stop_scalene_master(), wait_observed_exit(), test_owned_complete_target_delivery(), worker(), test_observed_exit_rejects_live_process_and_unreaped_zombie() (+2 more)

### Community 225 - "Plantillas de consultas propias"
Cohesion: 0.15
Nodes (13): build_page_template(), resolved(), template(), PageSeed, explicit_only(), test_page_template_parity(), test_page_template_rechecks_dependencies(), test_owned_page_template_roi() (+5 more)

### Community 226 - "Vinculación de páginas preparadas"
Cohesion: 0.19
Nodes (14): _prepared_page_binding(), test_dirty_preparation_degradation_is_detected(), test_binding_restores_attributes_on_error_and_nested_scope(), test_disabled_binding_does_not_touch_connection(), test_existing_prepare_threshold_is_preserved(), test_full_population_read_keeps_client_binding_for_wide_parameters(), __iter__(), WideRead (+6 more)

### Community 227 - "Calendario de finalidades"
Cohesion: 0.17
Nodes (7): CalendarFilterForm, queue(), permission(), CalendarFilterForm, detail(), FollowUpForm, queue()

### Community 228 - "Correctivas de regresión beta"
Cohesion: 0.16
Nodes (4): Regresión funcional amplia y relevo persistente, Correctivas de la regresión amplia y eficiencia de pruebas, Correctivas de consentimiento vigente y preflight de pruebas, Vigencia del catálogo durante validación nativa

### Community 229 - "Claves HMAC de dominio"
Cohesion: 0.17
Nodes (14): Inventario actualizado de productores, Auditoría funcional negativa, Auditoría, Aceptación acotada, B13 — Separación opcional entre firma Django y HMAC de dominio, domain_signing_key, .env, rights_operation_fingerprints (+6 more)

### Community 230 - "Preparación de adaptadores"
Cohesion: 0.17
Nodes (18): Roadmap103, guardia312, gates de apertura, contacto, edad/procedencia, comunicación interna revisada, outbox, tarea (+10 more)

### Community 231 - "Atribución de petición promocional"
Cohesion: 0.16
Nodes (6): Auditoría independiente, B07–B09 — Atribución actual de la petición promocional completa, PublicationContext, ServerSideCursor.fetchmany, B07 — Control limpio tras el diagnóstico sync, Atribución del coste de preparación de pruebas

### Community 232 - "Cola y reparación de trabajadores"
Cohesion: 0.17
Nodes (9): matriz180, 215, 217, B07 — Backlog escalable con reparación de worker real, emitted_at, READ_REPAIR, resource_preparation_excluded, scheduler_awoke_at (+1 more)

### Community 233 - "Exportación y densidad de similitud"
Cohesion: 0.16
Nodes (3): B10-363 — Auditoría terminal de medición actual MOD-09, B10-364 — Crecimiento y densidad del detector de similitud, B10-365 — Conciliación de exportación, similitud y deuda

### Community 234 - "Protocolo de medición VPS"
Cohesion: 0.15
Nodes (6): Native sealed kernel, Separate marked Scalene windows, Isolated late SQL plans, Fresh streaming final read, Repeat only successful measure once, Server synthetic measurement handoff

### Community 235 - "Orígenes acotados de historial Redis"
Cohesion: 0.26
Nodes (15): main(), prepare_origin(), prepare_origins(), read_origin(), identity(), scoped_body(), origins(), read() (+7 more)

### Community 236 - "Plantillas legales y representación"
Cohesion: 0.13
Nodes (6): Form template, Legal Index template, Legal template, Manager Queue template, Manager Review template, Representation template

### Community 237 - "Diagnóstico de fuentes de capacidad"
Cohesion: 0.21
Nodes (16): context_observed(), measured(), iterated(), measured(), observe(), measured(), profile_report(), scope() (+8 more)

### Community 238 - "Cobertura paginada de portabilidad"
Cohesion: 0.23
Nodes (16): fixture(), test_empty_datasets_still_require_reads_and_binary_mode_is_separate(), test_full_scalar_and_binary_page_boundaries(), test_approved_dataset_exclusion_covers_rows_without_selection(), test_changed_source_invalidates_old_row_declarations(), test_completed_draft_still_requires_strict_compilation(), test_exact_field_exclusions_and_empty_rows(), test_fully_selected_row_rejects_unnecessary_omission() (+8 more)

### Community 239 - "Lectores masivos de evidencias"
Cohesion: 0.20
Nodes (13): install(), uninstall(), backwards(), forwards(), Migration, test_bulk_all_families_events_and_tombstone_equal_producers(), test_bulk_detects_owner_changes_and_missing_rows_with_same_head(), test_bulk_invoker_properties_and_foreign_case_exclusion() (+5 more)

### Community 240 - "Prerregistro de controles HTTP"
Cohesion: 0.17
Nodes (4): document, document, Reference evidencia de auditoría evidencias/b16-short-http-terminal-audit-20261025.json, document

### Community 241 - "Contratos de derechos y portabilidad"
Cohesion: 0.16
Nodes (3): CR-09 — Denuncias, derechos y reclamación sin cuenta, Contrato complementario de rutas — inventario GS01, MOD-08 — generación asíncrona de portabilidad

### Community 242 - "Anonimización de patrones SQL"
Cohesion: 0.16
Nodes (14): query_pattern(), test_discovery_cost_checkpoint(), context_init(), from_db(), initialized(), instrument_form_method(), measured(), iterator() (+6 more)

### Community 243 - "Diagnóstico de descifrado"
Cohesion: 0.20
Nodes (11): Collector, scope(), observed(), _timed(), test_failure_restores_aliases_and_batch_rollback(), fail_second(), test_fresh_crypto_result_is_never_shared_and_invalid_token_is_rechecked(), test_real_runtime_batch_unseal_breakdown() (+3 more)

### Community 244 - "Revisión independiente de rectificación"
Cohesion: 0.20
Nodes (15): assert_form(), check_missing_preparation(), test_rectification_recipient_review_and_close_requirements(), independent_case(), test_independent_audited_review_needs_fresh_source_and_preserves_publication(), test_mobile_final_profile_correction_response_and_close(), test_mobile_independent_source_and_proposal_review(), final_authority() (+7 more)

### Community 245 - "Rotación de claves criptográficas"
Cohesion: 0.21
Nodes (10): encryption_cipher(), explicit_keys(), report(), test_bounded_predecessors_read_all_but_encrypt_only_with_active(), test_key_configuration_rejects_invalid_input_without_echo(), test_previous_keys_require_explicit_active_key(), test_real_object_reference_rotation_preserves_old_bytes_and_new_key_writes(), test_signing_rotation_revokes_session_and_changes_hmac_without_changing_explicit_cipher_keys() (+2 more)

### Community 246 - "Proyección de mensajes del intermediario"
Cohesion: 0.30
Nodes (14): load_json(), periodic_tasks(), project_message(), unique_object(), validate_envelope(), message(), test_duplicate_json_keys_are_not_silently_discarded(), test_excessive_json_nesting_becomes_typed_rejection() (+6 more)

### Community 247 - "Prórrogas y atención de derechos"
Cohesion: 0.25
Nodes (15): RightsExtension, ids(), test_attention_filters_and_pagination_only_include_authorized_cases(), test_media_attention_survives_case_closure_and_respects_permissions_and_coi(), test_mobile_attention_filter_preserves_request(), test_overdue_filter_uses_extended_target_without_changing_original_notice_target(), payload(), prepared() (+7 more)

### Community 248 - "Restauración y reversión beta"
Cohesion: 0.18
Nodes (3): B13 — Restauración y retirada bajo contrato beta, 2026-10-21, B13 — Estrategia de rollback de aplicación y esquema, B13 — Retorno beta con escrituras y workers reales

### Community 250 - "Sondeo de recursos y límites"
Cohesion: 0.21
Nodes (9): cgroup_chain(), optional_text(), process_snapshot(), ResourceProbe, TrialLimits, test_limits_require_five_sustained_execution_samples_and_detect_new_oom(), sample(), test_resource_stop_preserves_partial_ledger() (+1 more)

### Community 251 - "Control de pila canónica"
Cohesion: 0.22
Nodes (15): Frame, install(), getframe(), kernel(), try_check(), validated_kernel(), test_eligible_loader_integrity_error_preserved_and_frames_released(), broken() (+7 more)

### Community 252 - "Actualización transaccional de publicación"
Cohesion: 0.19
Nodes (8): ListingsConfig, _enqueue_refresh(), schedule_refresh(), independent_legacy_flag(), test_nested_committed_writes_schedule_one_refresh(), test_rollback_does_not_suppress_later_committed_refresh(), rolled_back(), test_rolled_back_savepoint_preserves_outer_refresh()

### Community 253 - "Metadatos históricos de Redis"
Cohesion: 0.25
Nodes (11): checked_physical(), hex_bytes(), integer(), physical_review(), checked_aux(), review_material(), checked_origin(), read_bundle() (+3 more)

### Community 254 - "Formularios de información de acceso"
Cohesion: 0.19
Nodes (7): FieldForm, InformationForm, initial_fields(), ReadForm, review(), ReviewForm, test_fieldset_schema_data_and_default()

### Community 255 - "Revisión de cobertura portable"
Cohesion: 0.21
Nodes (6): condition_captions(), DecisionForm, PageForm, review(), captions(), test_forms_defaults_raw_bounds_and_tristate()

### Community 256 - "Contraste de materialización y UUID"
Cohesion: 0.19
Nodes (9): Auditoría, Django5.2, PostgreSQL17, EXPLAIN17, Contraste finito: consumo completo de derechos promocionales, rights, rights.iterator(chunk_size=500), Auditoría (+1 more)

### Community 257 - "Paralelismo y duración de pruebas"
Cohesion: 0.17
Nodes (3): Común afectado y comparación de trabajadores pytest, Regresión funcional correctiva y espera persistente, Análisis de duraciones y paralelismo de pruebas

### Community 258 - "Retención privada y purgas"
Cohesion: 0.18
Nodes (8): B12 — Retención privada y auditoría de cobertura, 2026-10-21, B12 — Conciliación de purgas e inventario opcional, 2026-10-21, Acta14 — Aceptación técnica local B12, 2026-10-21, B12 aceptado localmente, Cobertura no verificada salud desconocida, Eventos best effort, Monitor administrativo manual, Vencimiento retención borrado

### Community 259 - "Autoridades del proxy y recuperación"
Cohesion: 0.19
Nodes (11): matriz141, Aceptación acotada, Auditoría del corte, B13 — Autoridades del proxy y ledger de recuperación, RecoveryLedger, RIGHTS_DELIVERY_GENERATION, RIGHTS_DELIVERY_PROXY_SECRET, Auditoría terminal (+3 more)

### Community 260 - "Captura de recursos propios"
Cohesion: 0.18
Nodes (6): B07 — Colector opcional de recursos de servicios propios, document, Documented status, Reference Auditoría terminal evidencias/b07-service-resources-phase195-20261021-audit.json, Reference captura181 181-colector-recursos-servicios-beta-b07-20261021.md, Reference matriz180 180-matriz-cobertura-b07-censo-geografico-20261021.md

### Community 262 - "Auditoría de dependencias de derechos"
Cohesion: 0.19
Nodes (4): document, Reference Detalle 48-revision-privada-recargas.md, Reference docs51 51-derechos-cuentas-sin-perfil.md, Reference evidencia evidencias/revision-privada-recargas.json

### Community 263 - "Observación de límites síncronos"
Cohesion: 0.28
Nodes (14): close_sync_boundary_hooks(), collect_sync_boundaries(), install_sync_boundary_hooks(), handle(), pre_request(), post_worker_init(), worker_exit(), config() (+6 more)

### Community 264 - "Inventario de orígenes retenidos"
Cohesion: 0.24
Nodes (12): inspect_origin(), identity(), inventory_log_captures(), log_capture_references(), visit(), main(), capture_declaration(), test_capture_metadata_does_not_admit_content_or_ambiguous_declarations() (+4 more)

### Community 265 - "Interfaces de agencias y organizaciones"
Cohesion: 0.14
Nodes (6): Agency Appeal template, Agency template, Manager Appeal template, Organization Queue template, Organization Review template, Simulator template

### Community 266 - "Plantillas de conservación y finalidades"
Cohesion: 0.16
Nodes (16): Restriction follow-up history template, Named URL purpose_calendar_queue, Named URL rights_inspect, Restriction follow-up history, Purpose restriction review calendar template, Named URL purpose_calendar_detail, Named URL rights_inspect, Purpose restriction review calendar (+8 more)

### Community 267 - "Diagnóstico de cadena SQL"
Cohesion: 0.22
Nodes (6): Collector, Cursor, observed(), wrapper(), scope(), wrapped_cursor()

### Community 268 - "Candidata de evidencias integradas"
Cohesion: 0.21
Nodes (11): candidate_functions(), __init__(), Inline, source_statements(), visit_Name(), scope(), application(), start() (+3 more)

### Community 269 - "Lotes de cobertura y entrega"
Cohesion: 0.19
Nodes (11): coverage_batches(), error_html(), Errors, handle_data(), handle_endtag(), handle_starttag(), __init__(), queued_generation() (+3 more)

### Community 270 - "Comandos de evaluación operativa"
Cohesion: 0.16
Nodes (3): Command, Command, SnapshotUnavailable

### Community 271 - "Disposición y reintroducción fotográfica"
Cohesion: 0.23
Nodes (8): active_withdrawals(), detect(), ledger(), action(), test_latest_explicit_file_decision_is_scoped_and_survives_unrelated_corrections(), record(), test_protected_exact_and_visual_candidates_are_private_and_scoped(), test_review_requires_independence_current_audit_and_invalidates_changed_resources()

### Community 272 - "Formularios de levantamiento de restricciones"
Cohesion: 0.20
Nodes (5): PublicationReleaseForm, queue(), QueueForm, ReleaseForm, test_inherited_operations_and_required_errors_preserved()

### Community 273 - "Detalles de rectificación"
Cohesion: 0.25
Nodes (11): display(), choice(), label(), Editor, field(), source(), validate(), assert_form() (+3 more)

### Community 274 - "Rectificación de selección fotográfica"
Cohesion: 0.27
Nodes (12): available(), changes(), initial(), PhotoForm, source(), validate(), add_source_photo(), test_eight_source_photos_are_editable_and_valid() (+4 more)

### Community 275 - "Datos de copias de cuenta"
Cohesion: 0.29
Nodes (9): scope_matches(), source(), agency_relationships(), contact_data(), date(), image_inventory(), legal_acceptances(), personal_contacts() (+1 more)

### Community 276 - "Validación de exclusiones portables"
Cohesion: 0.32
Nodes (15): exclusion(), _validate_decision(), changed(), facts(), old_exclusion(), outcome(), test_all_provenance_and_nullable_combinations_match_previous_exclusion(), test_all_statuses_keep_their_specific_conditions() (+7 more)

### Community 277 - "Formularios de selección portátil"
Cohesion: 0.22
Nodes (5): ImageInspectionForm, inspect_image(), review(), ReviewForm, test_review_defaults_bounds_and_photo_ids()

### Community 278 - "Procesamiento de avisos privados"
Cohesion: 0.20
Nodes (11): apps.safety.tasks.deliver_safety_notices, ComplaintNotice, Procesamiento de avisos privados — CR-09, FOR UPDATE SKIP LOCKED, /moderation/notices/, /moderation/notices/{report|complaint|rights}/{id}/, NoticeRecovery, recovery_version (+3 more)

### Community 280 - "Contraste de fuentes MOD09"
Cohesion: 0.20
Nodes (3): B10 — Contraste actual de fuentes respecto a MOD-09, B10-361 — Comprobación previa actual de MOD-09, B10-362 — Prerregistro de medición actual MOD-09

### Community 281 - "Comprobación del entorno de capacidad"
Cohesion: 0.27
Nodes (12): app_lifetime(), collect_failed_service_states(), command_timeout(), controller_self_probe(), main(), absent(), container(), emit() (+4 more)

### Community 282 - "Notificaciones de pruebas"
Cohesion: 0.22
Nodes (10): main(), notify(), pytest_sessionfinish(), pytest_sessionstart(), test_failed_delivery_keeps_test_result_and_redacts_provider_diagnostics(), fail(), test_notification_uses_openclaw_without_exposing_credentials(), run() (+2 more)

### Community 283 - "Mensajes y aclaraciones de derechos"
Cohesion: 0.31
Nodes (15): clarification(), prepared(), test_clarification_is_encrypted_replay_safe_and_does_not_reset_clock(), test_concurrent_same_reply_creates_one_message_and_one_version_increment(), reply(), test_mobile_clarification_persists_without_account_or_text_disclosure(), test_new_clarification_invalidates_old_staff_form_and_scope_marker(), test_older_clarifications_are_accessible_with_audited_cursor() (+7 more)

### Community 284 - "Configuración tecnológica e integración"
Cohesion: 0.20
Nodes (11): Always retain JUnit evidence, Explicit manual hosted CI, Pinned librdb test tooling, Read only private proxy volume, PostgreSQL persistence, Shared private delivery volume, Redis append only persistence, Technology inventory dated 2026-10-11 (+3 more)

### Community 285 - "Migraciones de recuperación y retención"
Cohesion: 0.14
Nodes (5): Migration, Migration, Migration, Migration, Migration

### Community 286 - "Lectura histórica retenida Redis"
Cohesion: 0.27
Nodes (12): inspect_aof(), line(), test_argument_limits_reject_before_reading_body(), test_deleted_values_remain_historical_without_parameter_disclosure(), test_large_retained_arguments_are_drained_without_materializing_values(), ObservedStream, read(), test_short_reads_and_missing_crlf_are_handled_safely() (+4 more)

### Community 287 - "Privacidad de registros HTTP"
Cohesion: 0.22
Nodes (6): SafeAccessLogger, PrivateRequestFilter, test_development_http_log_hides_report_capability(), test_django_http_warning_hides_report_receipt_secret(), test_photo_and_draft_access_logs_hide_private_identifiers(), test_publication_queue_early_responses_receive_private_headers()

### Community 288 - "Observabilidad y transporte de eventos"
Cohesion: 0.20
Nodes (3): B12 — Observabilidad operativa de beta, B12 — Eventos operativos acotados, B12 — Transporte acotado de eventos

### Community 289 - "Equivalencia de políticas de publicación"
Cohesion: 0.22
Nodes (12): apps/listings/submissions.py:97–110, artifacts/beta-promotion-fix-20261020/policy242b-negative-audit.json, artifacts/beta-promotion-fix-20261020/policy243-negative-audit.json, artifacts/beta-promotion-fix-20261020/policy244-audit.json, B07 — equivalencia local de PRODUCTION y checked, manager_version, PROMOTION_TEST_MODE, publicly_visible (+4 more)

### Community 292 - "Diseño de copias por paquetes"
Cohesion: 0.22
Nodes (8): apps/safety/rights_data_parts.py, Evidencia, Docker, Copias de datos por paquetes: diseño de entrega, JSONEncoder.iterencode, rights-data-manifest-v1, rights-data-part-N.zip, RightsExportPart

### Community 293 - "Construcción de artefactos canónicos"
Cohesion: 0.18
Nodes (6): build(), artifact_fingerprints(), outcome(), test_builder_and_loader_share_build_identity(), test_reference_and_unavailable_kernel_fallback_preserve_order(), test_standalone_builder_imports_without_build_or_project_path()

### Community 296 - "Vistas de pedidos promocionales"
Cohesion: 0.25
Nodes (7): credentials(), detail(), ListingChoice, OrderForm, orders(), ProductChoice, SimulationForm

### Community 301 - "Revisión privada de recargas"
Cohesion: 0.23
Nodes (7): Evidencia, evidencia, dependent_evidence, Revisión privada de recargas: contrato de implementación, encrypted_reason, review_version, validate_submission

### Community 302 - "Contabilidad de mediciones"
Cohesion: 0.31
Nodes (10): counts(), distribution(), review(), run_open_loop(), worker(), population(), test_error_latency_and_pending_are_not_hidden_by_success_population(), test_fixed_drain_classifies_pending_and_late_response_cannot_rewrite_snapshot() (+2 more)

### Community 303 - "Observación de entrada del servidor"
Cohesion: 0.22
Nodes (7): post_worker_init(), parse_service_samples(), test_ingress_composes_product_startup_before_observer(), prepare(), test_ingress_hook_avoids_eager_handlers_and_restores_callback_resources(), guarded(), test_service_ledger_preserves_ids_and_rejects_duplicates_nonfinite_without_paths()

### Community 304 - "Ejecución del entorno de capacidad"
Cohesion: 0.33
Nodes (11): absent(), controller_terminal_state(), durable(), extract(), file_digest(), host_tools(), limit_client_log(), main() (+3 more)

### Community 305 - "Inventario de dependencias secretas"
Cohesion: 0.29
Nodes (9): DependencyInventoryError, inventory(), __init__(), visit_Call(), visit_FunctionDef(), Visitor, test_current_direct_hmac_producers_are_all_classified(), test_removed_producer_is_registry_drift() (+1 more)

### Community 306 - "Diagnóstico de estados desconocidos"
Cohesion: 0.24
Nodes (12): extended_unknown_candidate(), install(), dispatch(), set_arm(), response_signature(), test_extended_unknown_balanced_roi(), context_init(), execute() (+4 more)

### Community 307 - "Perfilado de entrega por proxy"
Cohesion: 0.27
Nodes (7): Opener, Response, run(), test_explicit_profile_only_marker_reaches_private_get_with_full_timing(), test_missing_or_invalid_profile_keeps_original_string_get(), test_profile_does_not_relax_original_redirect_scope(), test_profile_does_not_relax_private_cache_control()

### Community 308 - "Restauración diagnóstica de PostgreSQL"
Cohesion: 0.21
Nodes (13): test_actual_original_approval_roundtrip_and_config_rejection(), ambiguous_create(), ambiguous_login(), checked_login(), disk_full(), expired_proof(), fail_copy(), refused_cleanup() (+5 more)

### Community 309 - "Recepción y prioridad de derechos"
Cohesion: 0.26
Nodes (12): data(), test_brief_request_without_reference_or_contact_is_received_for_clarification(), test_concurrent_receipt_replays_create_one_rights_request(), submit(), test_internal_target_uses_calendar_month_not_thirty_days(), test_mobile_representation_request_without_account_and_private_reload(), test_rights_only_permission_still_requires_current_mfa(), test_rights_permission_is_separate_mfa_required_and_inspection_audited() (+4 more)

### Community 310 - "Cargador del núcleo canónico"
Cohesion: 0.30
Nodes (10): _after_fork(), _after_fork_parent(), _before_fork(), KernelIntegrityError, _load(), _memfd(), _read(), _sha() (+2 more)

### Community 311 - "Carga de imágenes rectificadas"
Cohesion: 0.32
Nodes (8): baseline(), check_actor(), check_current(), discard(), eligible(), prepare(), upload(), UploadForm

### Community 312 - "Conciliación de rotación de claves"
Cohesion: 0.23
Nodes (11): roadmap103, OP005, acta15, matriz literal, B13 — Conciliación literal final y verificación de candidata, Acta15 — Aceptación técnica local B13, B13 aceptado localmente, Límites rotación claves (+3 more)

### Community 313 - "Recursos territoriales y volumen"
Cohesion: 0.24
Nodes (5): document, Documented status, Reference Auditoría217 evidencias/b07-resources217-territorial10000-20261022-audit.json, Reference Auditoría de preflight evidencias/b07-image-recovery-preflight-20261022.json, Reference matriz180 180-matriz-cobertura-b07-censo-geografico-20261021.md

### Community 316 - "Diseño de reintroducción fotográfica"
Cohesion: 0.24
Nodes (7): active_withdrawals, Evidencia, Recarga de imágenes tras rectificación, Match, RightsPhotoReintroduction, RightsRectificationPhotoDisposition, uploaded_blob

### Community 317 - "Contrato de rectificación de cuenta"
Cohesion: 0.24
Nodes (5): authorized_proof, Rectificación de cuenta — contrato de implementación, person.subject, session_version, source_snapshot

### Community 318 - "Análisis de costes y capacidad"
Cohesion: 0.24
Nodes (14): Análisis del bloqueo y DAFO — coste y capacidad de servicio, Índices parciales sin autoridad, Captura escalar índice conservados, Comparación causal inconclusa, Contrato histórico 10k 20RPS, CR09 aceptación histórica octubre 9, Cuatro workers seis no adoptados, Dirty intervención retirada (+6 more)

### Community 319 - "Rol de ejecución y permisos"
Cohesion: 0.28
Nodes (6): _owned_database(), _private_write(), runtime_role_environment(), test_owned_native_reconnect_probe(), test_owned_context_rejects_unverified_alias_before_provision(), test_owned_runtime_child_login_acl_optin_and_private_cleanup()

### Community 320 - "Preparación de exportación portable"
Cohesion: 0.25
Nodes (5): ApprovedCoverage, ApprovedSelection, ExportForm, job_status(), prepare()

### Community 321 - "Diagnóstico de publicaciones pendientes"
Cohesion: 0.25
Nodes (7): Auditoría, Instrumentos diagnósticos y colección de regresión, 108, Auditoría, Auditoría, Negativo auditado, Diagnóstico de estados pendientes todavía públicos

### Community 322 - "Conciliación de fuentes de interfaz"
Cohesion: 0.24
Nodes (3): Registro con IDs, versiones y hashes, B00 — Conciliación parcial de fuentes UX, B00 — Conciliación ampliada de fuentes UX

### Community 323 - "Extremos de exportación y similitud"
Cohesion: 0.26
Nodes (10): propuesta97, contraste histórico, Auditoría actual, compare_signatures, confirm_match, detect_matches, B10-347 — Extremos de exportación y similitud, FAISS (+2 more)

### Community 324 - "Interfaz de formularios de copia"
Cohesion: 0.24
Nodes (4): B11-350 — Interfaz de formularios de copia, Acta20 — Aceptación técnica local B11, B11 cuatro formularios separados, Mantenimiento sin mejora CPU acreditada

### Community 326 - "Conciliación de exclusiones históricas"
Cohesion: 0.26
Nodes (6): document, Reference auditoría actual evidencias/b16-seven-current-exclusions-audit-20261024.json, Reference búsqueda de testigos originales evidencias/b16-excluded-witness-search-20261024.json, Reference evidencia de reutilización evidencias/b16-territory-exclusions-reuse-20261024.json, Reference Matriz individual evidencias/b16-official-exclusion-dispositions-20261024.json, Reference preparación313 313-preparacion-candidata-comun-b16-20261024.md

### Community 328 - "Rol y cadena de portabilidad"
Cohesion: 0.22
Nodes (3): Reproducción dirigida del ciclo de bloqueos de publicación, MOD-08 pieza 11 — cadena acotada de metadatos de portabilidad, MOD08 pieza11: adopción local del rol y de la cadena

### Community 329 - "Diseños canónicos y snapshots"
Cohesion: 0.22
Nodes (3): MOD-08 — forma canónica y referencias de contenido v2, MOD-08 pieza 10 — baseline de diagnóstico, diseño y restricción, MOD-08 — snapshots de bootstrap por worker

### Community 331 - "Rutas territoriales sintéticas"
Cohesion: 0.33
Nodes (6): balanced_territorial_cycle(), territorial_routes(), test_balanced_cycle_rejects_incompatible_base(), test_balanced_territorial_cycle_preserves_contract_mix(), test_invalid_territorial_census_rejected(), test_territorial_cycle_covers_languages_filters_and_boundaries()

### Community 332 - "Ordenación por duración de pruebas"
Cohesion: 0.29
Nodes (7): file_costs(), order_items(), pytest_addoption(), pytest_collection_modifyitems(), test_direct_cli_validates_history_before_creating_resources(), test_invalid_duration_cannot_silently_change_scheduling(), test_long_single_case_file_precedes_many_short_cases_without_losing_local_order()

### Community 333 - "Plantillas de revisión de excepciones"
Cohesion: 0.22
Nodes (12): Purpose-plan independent review template, Named URL processing_execute, Named URL rights_inspect, Purpose-plan independent review, Scoped erasure exception proposal template, Named URL purpose_exception_review, Named URL rights_inspect, Scoped erasure exception proposal (+4 more)

### Community 334 - "Calendario y levantamiento de publicación"
Cohesion: 0.22
Nodes (12): Publication restriction review calendar template, Named URL publication_purpose_release, Named URL rights_queue, Publication restriction review calendar, Publication release and follow-up template, Named URL publication_calendar_queue, Named URL rights_inspect, Publication release and follow-up (+4 more)

### Community 335 - "Temporización de solicitudes"
Cohesion: 0.30
Nodes (8): compact(), matrix(), _matrix_valid(), observe(), _open(), sample_id(), _valid(), write_record()

### Community 336 - "Inventario de reutilización fotográfica"
Cohesion: 0.23
Nodes (9): test_reuse_evidence_changes_invalidate_erasure_before_mutation(), setup_review(), test_two_independent_decisions_block_then_resolve_one_version(), deciding(), test_waiting_inspection_rechecks_original_proof_after_scope_lock(), inspecting(), test_waiting_scoped_image_rechecks_after_actual_media_redaction(), observed() (+1 more)

### Community 337 - "Filtros de acceso y recuperación"
Cohesion: 0.27
Nodes (3): AccountGateMiddleware, RecoveryGateMiddleware, SecurityHeadersMiddleware

### Community 338 - "Núcleo de serialización canónica"
Cohesion: 0.31
Nodes (12): _pure, _walk, Boxed Python objects retain GIL and explicit iterator mutation/error ordering, canonical_python_budget, check, Decline native attempt for invalid depth, low recursion budget, altered isfinite or impure input, Source apps/safety/_canonical_kernel.pyx, Exact builtin recursive preflight avoids callbacks before declining to Python (+4 more)

### Community 339 - "Paquetes de imágenes de copia"
Cohesion: 0.34
Nodes (7): archive(), packages(), test_archive_consumes_single_pass_images_without_changing_zip_bytes(), test_default_grouping_targets_eight_mib_and_preserves_larger_individual_images(), test_packages_fit_actual_zip_size_without_losing_or_duplicating_content(), test_single_attachment_over_limit_and_duplicate_rejected(), test_unsafe_or_oversized_snapshot_is_rejected()

### Community 341 - "Control del cliente corregido"
Cohesion: 0.27
Nodes (6): document, Documented status, Reference auditoría evidencias/b07-corrected-client-short-20261021-audit.json, Reference auditoría independiente del ledger evidencias/b07-corrected-client-confirmation-20261021-audit.json, Reference contrato16 MOD-08 16-contrato-ejecucion-desarrollo.md#mod-08--perfil-cpu-del-vps-autorizado-2026-10-12, Reference matriz180 180-matriz-cobertura-b07-censo-geografico-20261021.md

### Community 342 - "Inventario de supresión y conservación"
Cohesion: 0.27
Nodes (7): AEPD, derecho de supresión, dependent_evidence, Inventario previo a supresión y conservación, ErasureInventory, execution_ready=false, PhoneClaim, source_manifest

### Community 343 - "Autoridad de revisión de cobertura"
Cohesion: 0.27
Nodes (8): authorize_reviewer(user,case), checked_body, acta17, context, Auditoría, reproducción, B00-340 — Autoridad de revisión de cobertura y conciliación final, pg_blocking_pids

### Community 345 - "Conservación de cargas preparadas"
Cohesion: 0.27
Nodes (3): document, Documented status, Reference Evidencia normalizada evidencias/conservacion-cargas-preparadas.json

### Community 346 - "Autoridad de excepciones en espera"
Cohesion: 0.27
Nodes (10): cease, Variantes y autoridad de excepciones durante la espera, evidencias/excepciones-ambito-perfil.json, evidencias/excepciones-autoridad-tardia.json, evidencias/excepciones-oposicion.json, pg_blocking_pids, PurposeExceptionReview, test_purpose_exception_late_authority (+2 more)

### Community 348 - "Auditoría de terminación técnica"
Cohesion: 0.25
Nodes (3): Auditoría de terminación B-B — 2026-10-19, B-F — terminación técnica local del frontend, 2026-10-19, Acta09 — Terminación B-B técnica local, 2026-10-19

### Community 349 - "Actas de disposición técnica"
Cohesion: 0.27
Nodes (12): Acta21 — Disposición técnica local B10, B10 disposición P2 aceptada, MOD09 FAIL objetivos 2s 5s, Acta22 — Aceptación técnica local B16, 3700 PASS conciliados 129 SKIP, B14 B15 B17 no aceptados, B16 candidata integrada aceptada, Capacidad pública contractual (+4 more)

### Community 350 - "Observadores de recursos y conexiones"
Cohesion: 0.29
Nodes (8): install_admission_hooks(), enqueue(), handle(), init(), write(), post_worker_init(), post_worker_init(), response()

### Community 351 - "Muestreo de sentencias PostgreSQL"
Cohesion: 0.26
Nodes (3): PGStatementSampler, test_sampler_rejects_unowned_database_before_connect(), forbidden_connect()

### Community 352 - "Rotación y aislamiento del intermediario"
Cohesion: 0.22
Nodes (5): test_owned_redis_rotation_preserves_pending_queue_and_requires_client_replacement(), broker(), docker(), test_old_fresh_and_other_project_messages_are_isolated(), test_queue_generation_rejects_unsafe_names()

### Community 353 - "Contrato de preparación de capacidad"
Cohesion: 0.29
Nodes (9): modules(), test_invalid_launcher_flags_stop_before_output_or_docker(), test_native_profiler_cannot_enter_acceptance_or_preflight(), test_normal_and_recovery_inventory_names_all_own_resources(), test_preflight_and_object_writer_cannot_bypass_owned_mode(), test_preflight_is_explicit_same_whole_budget_and_has_no_workload(), test_preflight_rejects_every_load_and_instrumentation_flag(), test_recovery_removes_proxy_objects_and_shared_volume_and_detects_leftover() (+1 more)

### Community 354 - "Instantáneas operativas agregadas"
Cohesion: 0.27
Nodes (11): test_database_failure_is_sanitized_and_command_never_writes_partial_json(), fail(), test_due_notice_boundary_and_private_values_never_emitted(), test_due_wait_uses_eligibility_not_original_creation_age(), test_empty_snapshot_has_explicit_scope_and_read_only_aggregates(), test_expiry_registry_covers_simple_periodic_safety_purges(), test_export_leases_and_expiry_boundary_use_real_durable_rows(), test_inherited_transaction_rejected_without_changing_it() (+3 more)

### Community 355 - "Medición de contraste visual"
Cohesion: 0.41
Nodes (10): backdrop(), collect(), luminance(), measured(), over(), ratio(), rgba(), test_contrast_reference_pairs_and_alpha() (+2 more)

### Community 356 - "Evaluación de atención operativa"
Cohesion: 0.38
Nodes (8): _assess(), add(), count_issue(), lag(), AssessmentUnavailable, _cadence(), _count(), _number()

### Community 357 - "Recuperación operativa de medios"
Cohesion: 0.29
Nodes (5): authorized_case(), can_recover(), queue(), recover(), RecoveryForm

### Community 358 - "Avisos privados de rectificación"
Cohesion: 0.33
Nodes (7): RightsRectificationManagerNotice, Meta, acknowledge(), allowed(), create(), inbox(), visible()

### Community 359 - "Vistas de seguimiento de conservación"
Cohesion: 0.28
Nodes (4): inspect(), permitted_request(), queue(), ReviewForm

### Community 360 - "Descomposición de latencia promocional"
Cohesion: 0.27
Nodes (5): ANALYZE, Auditoría, B07 — Referencia corta con estadísticas promocionales finalizadas, p95observable1234,081ms, B07 — Descomposición de la última carga corta

### Community 361 - "Medidas de privacidad de publicación"
Cohesion: 0.29
Nodes (8): RGPD, artículos 18, 19 y 21, AEPD, Medidas de privacidad sobre publicación, lifecycle_version, PrivacyPublicationHold, RightsAction, RightsProof, validate_submission

### Community 362 - "Atribución del circuito exportador"
Cohesion: 0.29
Nodes (8): canonical_bytes(), Auditoría corregida, primer instrumento con su límite, B10-348 — Atribución del circuito de exportación, inspect_page, inspection_source, _read_image_blob, source_copy

### Community 366 - "Intervalos de actualización"
Cohesion: 0.38
Nodes (6): refresh_intervals(), events(), test_ambiguous_or_partial_capture_never_invented(), test_dispatch_and_dirty_age_are_distinct_metrics(), test_invalid_measurements_rejected(), test_snapshot_error_preserved_without_dirty_age_claim()

### Community 367 - "Comprobación de enlaces documentales"
Cohesion: 0.37
Nodes (7): anchors(), check(), retired_source(), destination(), links(), main(), markdown_text()

### Community 368 - "Codificación de snapshots diagnósticos"
Cohesion: 0.33
Nodes (8): decode(), encode(), record(), importable_header(), _json(), key(), metadata(), records()

### Community 369 - "Ejecución de integración local"
Cohesion: 0.41
Nodes (8): durable(), hashes(), main(), interrupted(), run(), process_start_ticks(), recover(), regression_lane_files()

### Community 370 - "Atribución del planificador asíncrono"
Cohesion: 0.36
Nodes (4): difference(), ObservedLoop, SelectorProbe, snapshot()

### Community 371 - "Observación diagnóstica de cadenas"
Cohesion: 0.33
Nodes (9): test_cursor_forwards_and_reports_only_numeric_event_rows(), __enter__(), execute(), __exit__(), fetchall(), Original, test_observer_scope_restores_aliases_and_pipeline_after_failure(), test_wrapper_preserves_return_and_exception_without_scope() (+1 more)

### Community 372 - "Planificación del generador de carga"
Cohesion: 0.32
Nodes (9): execute(), scenario(), test_blocking_callback_is_observed_without_inventing_cpu(), test_cpu_callback_is_observed_as_cpu(), busy(), test_normal_timer_is_not_callback_cpu(), test_observed_transport_preserves_original_accounting(), fetch() (+1 more)

### Community 373 - "Pruebas de restricciones de privacidad"
Cohesion: 0.38
Nodes (10): owner_client(), pending_update(), test_approval_race_cannot_republish_held_profile(), apply_hold(), approve(), test_ground_and_proof_scope_are_checked_and_case_stays_open(), test_hold_removes_exposure_and_blocks_forced_status_and_manager_lifecycle(), test_mobile_hold_persists_after_reload_without_closing_request() (+2 more)

### Community 374 - "Contexto de fuentes de inspección"
Cohesion: 0.27
Nodes (8): state(), rows_fingerprint(), test_changed_versions_with_identical_content_fall_back_to_full_comparison(), test_drift_or_projection_mutation_rejected_and_context_reset(), test_exception_resets_context_without_turning_failure_into_success(), test_no_transaction_or_forged_context_rejected(), test_reuse_fresh_exit_and_expired_context(), test_wrong_scope_and_cross_thread_context_denied()

### Community 375 - "Ámbito de validación del proxy"
Cohesion: 0.35
Nodes (9): closed_grants(), observe(), actual_read(), checked(), test_access_proxy_authorization_and_replay_remain_unchanged(), test_closed_tokens_validate_once_per_operation_and_read_physical_bytes_fresh(), test_failed_physical_validation_resets_scope_before_next_real_token(), failed() (+1 more)

### Community 376 - "Línea base de carga beta"
Cohesion: 0.32
Nodes (4): document, Reference Auditoría100 evidencias/b07-diagnostico100-audit-20261020.json, Reference auditoría grande evidencias/b07-diagnostico1000-10000-audit-20261020.json, Reference B04–B06 actas/13-beta-b04b06-aceptacion-local-20261020.md

### Community 378 - "Rotación de firmas de recibos"
Cohesion: 0.32
Nodes (7): cierre estático147, Auditoría terminal, B13 — Clasificación de firma: recibos e integridad de entradas, Report.payload_digest, Report.receipt_digest, RightsRequest.payload_digest, RightsRequest.receipt_digest

### Community 379 - "Resolución independiente de reclamaciones"
Cohesion: 0.32
Nodes (7): ComplaintAccess, ComplaintAction, ComplaintNotice, ComplaintResolution, Resolución independiente de reclamaciones — CR-09, ReportAccess, Restriction

### Community 380 - "Copia de cuenta sin perfil"
Cohesion: 0.32
Nodes (8): Evidencia, runtime, Evidencia, Copia privada de cuenta sin perfil, partial=true, ReviewedCopyField, RightsExport, subject-account-copy-v1

### Community 381 - "Revisión de conservación por finalidad"
Cohesion: 0.32
Nodes (7): RGPD, artículo5.1.e, AEPD, principios de tratamiento AEPD, Calendario y revisión de conservación por finalidad, reconcile_retention_reviews, retention_purpose_count, RetentionReview

### Community 382 - "Limitación y oposición por finalidad"
Cohesion: 0.32
Nodes (7): RGPD artículos18/19/21, AEPD oposición, AEPD limitación, Limitación y oposición por finalidad, processing_review.record, ProcessingPlanRead, ProcessingPurposePlan

### Community 384 - "Salón local de deliberación"
Cohesion: 0.53
Nodes (9): append(), ask(), execute(), load_events(), locked(), main(), now(), render() (+1 more)

### Community 385 - "Lanzador de capacidad VPS"
Cohesion: 0.27
Nodes (4): main(), save(), snapshot(), test_sql_plan_mode_is_exclusive()

### Community 386 - "Controles del catálogo promocional"
Cohesion: 0.32
Nodes (4): main(), unrelated_task_log(), test_any_other_tracked_change_blocks_even_with_ledger(), test_independent_task_ledger_is_hashed_without_mutating_it()

### Community 387 - "Plantillas de apelaciones organizativas"
Cohesion: 0.23
Nodes (4): Agency Appeal Queue template, Agency Appeal Review template, Manager Appeal Queue template, Manager Appeal Review template

### Community 388 - "Panel y autenticación multifactor"
Cohesion: 0.26
Nodes (3): Dashboard template, Mfa Recovery template, Mfa template

### Community 389 - "Plantillas de rectificación y destinatarios"
Cohesion: 0.26
Nodes (9): Recipient and gap assessment proposal template, Recipient and gap assessment proposal, Audited recipient candidate inventory template, Named URL recipient_assessment, Audited recipient candidate inventory, Independent rectification proposal review template, Named URL rectification_recipients, Named URL rights_rectification_photo (+1 more)

### Community 390 - "Plantillas de respuestas finales"
Cohesion: 0.29
Nodes (6): URL name referenced by template: rights_access_close, URL name referenced by template: rights_inspect, Prepare final access response template, URL name referenced by template: rights_inspect, URL name referenced by template: rights_portability_response_close, Prepare final portability response template

### Community 391 - "Interfaces de selección portátil"
Cohesion: 0.29
Nodes (10): Inspected field catalog, Selected mixed field assessment guidance, Paginated portable field selection guidance, Selection restart and audit guidance, rights portability select template, Selected image inspection POST control, Mixed field eligibility evidence display, Selected field rows display (+2 more)

### Community 392 - "Atribución de preparación promocional"
Cohesion: 0.33
Nodes (9): test_native_authorization_query_attribution(), sql(), wrapped(), call(), test_native_promotional_preparation_cost(), span(), sql(), wrapped() (+1 more)

### Community 393 - "Instrumentación WSGI de cadena"
Cohesion: 0.32
Nodes (5): application(), test_original_response_is_closed_once(), close(), __iter__(), Response

### Community 394 - "Heurísticas de estabilidad de capacidad"
Cohesion: 0.44
Nodes (6): gate(), quantile(), samples(), test_drift_and_spread_rejected(), test_exact_sample_budget(), test_linear_quantiles_and_stable_control()

### Community 395 - "Contextos del observador de conexiones"
Cohesion: 0.33
Nodes (9): test_admission_hooks_preserve_native_results_and_isolate_thread_contexts(), Connection, handle(), __init__(), invoke(), write(), test_native_handler_exception_resets_admission_context(), Connection (+1 more)

### Community 396 - "Instrumentación de perfiles profesionales"
Cohesion: 0.32
Nodes (7): test_owned_professional_probe(), test_professional_argv_keeps_measure_clean(), test_professional_flow_excludes_legacy_profiles(), forbidden(), test_professional_parser_rejects_mixed_native(), test_professional_sampling_stops_after_invalid_capture(), post()

### Community 397 - "Inventario de rutas y concurrencia"
Cohesion: 0.32
Nodes (7): test_owned_detail_template_threads(), read(), begin(), worker(), documented(), routes(), test_every_route_appears_in_a_contract_or_flow_document()

### Community 398 - "Liberación de respuestas WSGI"
Cohesion: 0.30
Nodes (10): test_owned_wsgi_close_release(), call(), start_response(), inspect_cycles(), render_with_release(), release(), residual_path(), label() (+2 more)

### Community 399 - "Retención de objetos WSGI"
Cohesion: 0.30
Nodes (10): test_owned_wsgi_incoming_retention(), call(), start_response(), inspect_cycles(), render_with_release(), release(), residual_path(), label() (+2 more)

### Community 400 - "Transporte JSON de portabilidad"
Cohesion: 0.32
Nodes (9): test_native_closed_selected_json_over_local_tcp(), counted(), measured(), call(), post(), ready_with_binary(), rss(), sample() (+1 more)

### Community 401 - "Continuidad de servicios y outbox"
Cohesion: 0.30
Nodes (8): test_owned_service_outage_preserves_outbox_and_recovers_once(), dispatch(), docker(), events(), ready_broker(), start_worker(), stop_worker(), wait()

### Community 403 - "Inventario de supresión de cuenta"
Cohesion: 0.35
Nodes (5): allow_erased_account, Inventario y decisiones de supresión de cuenta propia, ErasureExecution, ErasureInventory.account_subject, User.account_erased_at

### Community 407 - "Plantillas de revisión de cobertura"
Cohesion: 0.31
Nodes (4): URL name referenced by template: rights_inspect, Review access coverage template, URL name referenced by template: rights_inspect, Review portability coverage template

### Community 408 - "Exportación y suplementos de acceso"
Cohesion: 0.31
Nodes (5): URL name referenced by template: rights_inspect, Supplemental access copy template, URL name referenced by template: rights_inspect, URL name referenced by template: rights_portability_response_prepare, Deliver approved portable fields template

### Community 409 - "Interfaces de verificación y respuesta"
Cohesion: 0.31
Nodes (9): Final portability response review, Independent decision recording control, Response draft inspection control, Synthetic authorization without delivery, rights portability response review template, Simulation production limitation, Scoped second reviewer guidance, Development only verification guidance (+1 more)

### Community 410 - "Muestreo de entregas privadas"
Cohesion: 0.44
Nodes (7): sampled(), response(), test_native_controller_timing_does_not_install_cprofile(), operation(), test_post_validation_profile_is_exclusively_legacy_diagnostic(), test_private_download_requires_redirect_eof_and_privacy(), test_proxy_client_allows_ordinary_save_without_delivery_redirect()

### Community 411 - "Manejador de eventos operativos"
Cohesion: 0.33
Nodes (6): test_broken_pipe_becomes_counter_without_exception_details(), test_initialization_failure_retires_every_duplicate(), duplicate(), fail(), test_real_pipe_and_fork_lifecycle(), test_size_limit_and_closed_handler_never_start_a_writer()

### Community 412 - "Aislamiento de colas de pruebas"
Cohesion: 0.29
Nodes (4): test_refresh_accumulation_blocks_bounded_inventory(), test_next_case_isolated_without_deleting_previous_backlog(), test_previous_case_can_leave_a_real_backlog(), test_subprocess_inherits_current_case_generation()

### Community 413 - "Transporte binario de portabilidad"
Cohesion: 0.35
Nodes (8): test_native_closed_binary_delivery_over_local_tcp(), counted(), measured(), call(), post(), ready_with_binary(), rss(), sample()

### Community 414 - "Simulacro de escalada urgente"
Cohesion: 0.36
Nodes (7): test_report_decision_rechecks_revocation_after_scoped_locks(), after_outbox(), revoke(), test_urgent_owner_revocation_escalates_to_authorized_substitute(), followed(), mark(), operate()

### Community 415 - "Rectificación de canales de contacto"
Cohesion: 0.47
Nodes (6): normalize_telegram(), binding(), claim(), display(), source(), validate()

### Community 416 - "Formularios de copias privadas"
Cohesion: 0.42
Nodes (4): CopyPresentationForm, ExportForm, PageReviewForm, ReviewedCopyField

### Community 417 - "Autoridad comercial sobre personas"
Cohesion: 0.38
Nodes (6): candidate_eligible=false, Auditoría, Auditoría independiente, B07–B09 — Autoridad comercial sobre la persona enlazada, live_entitlements, person_queryset

### Community 418 - "Revocación de clave HMAC"
Cohesion: 0.38
Nodes (6): OP005, acta15, Auditoría terminal, B13 — Revocación de la clave HMAC de dominio, SAFETY_HMAC_KEY, SECRET_KEY_FALLBACKS

### Community 419 - "Coste de hidratación de página"
Cohesion: 0.38
Nodes (7): Auditoría, paridad inicial, la plantilla ORM de página rechazada, B09 — Descomposición de Python en hidratación de página, Model.__init__, prefetch_one_level, SQLCompiler.as_sql

### Community 420 - "Procedencia de lecturas históricas"
Cohesion: 0.38
Nodes (4): document, Reference procedencia de dos fuentes DB evidencias/b00-additional-db-source-provenance-20261021.json, Reference procedencia del registro de vigencia evidencias/b00-control-register-provenance-20261021.json, Reference terminal189 189-protocolo-beta-http-900s-b07-20261021.md

### Community 421 - "Estados mixtos en HTTP"
Cohesion: 0.38
Nodes (4): B07 — estados mixtos en HTTP funcional, mixed_state_plan.py, publicly_visible, transaction.atomic

### Community 422 - "Control contractual del combinado"
Cohesion: 0.38
Nodes (4): artifacts/beta-promotion-fix-20261020/combined296-audit.json, B07 — contractual con controlador corregido, OOMFalse, runningFalse

### Community 423 - "Ejecución de restricciones por finalidad"
Cohesion: 0.38
Nodes (5): account_preferences, Ejecución durable de restricciones por finalidad, processing_execution.execute, ProcessingExecution, PurposeRestriction

### Community 424 - "Consulta paginada de copias"
Cohesion: 0.38
Nodes (5): copy_page_read, Consulta paginada de fuentes de copia privada, inspect_page, RightsExportPreview, source_copy

### Community 425 - "Observación de tareas Celery"
Cohesion: 0.47
Nodes (6): _dirty_snapshot(), _postrun(), _prerun(), _published(), _write(), connect()

### Community 426 - "Diagnóstico del generador asíncrono"
Cohesion: 0.38
Nodes (6): observed_transport(), factory(), pytest_collection_modifyitems(), pytest_runtest_setup(), observed(), pytest_runtest_teardown()

### Community 428 - "Sonda de caducidad de entregas"
Cohesion: 0.51
Nodes (7): command(), fixture(), action(), launch(), main(), state(), wait()

### Community 429 - "Sondas de caducidad y recuperación"
Cohesion: 0.31
Nodes (3): main(), database_probe(), main()

### Community 430 - "Sondeo de conservación de portabilidad"
Cohesion: 0.49
Nodes (7): command(), fixture(), action(), launch(), wait(), main(), state()

### Community 435 - "Integración HTTP de políticas"
Cohesion: 0.33
Nodes (6): NoRedirect, test_policy_checked_real_http100(), capture(), http_get(), observe_handler(), observed()

### Community 436 - "Atribución secuencial posterior TCP"
Cohesion: 0.33
Nodes (7): test_post_tcp_sequential_attribution(), capture_order(), capture(), observe(), call(), read(), sql_event()

### Community 437 - "Recorrido del perfil en navegador"
Cohesion: 0.49
Nodes (5): correct_and_submit(), open_renewal_window(), review(), test_profile_publish_reject_correct_renew_pause_and_withdraw(), translated()

### Community 438 - "Flujo de portabilidad con historial"
Cohesion: 0.42
Nodes (8): test_large_history_native_approval_closure_and_binary_delivery(), measured(), run(), counter(), ready(), rss(), sample(), save_progress()

### Community 439 - "Localización del levantamiento de publicación"
Cohesion: 0.42
Nodes (6): localized_release_labels(), test_localized_mobile_execute_received_proposal(), mobile(), test_localized_mobile_proposal_and_public_receipt(), confirm(), propose()

### Community 440 - "Rechazo de historial rectificado"
Cohesion: 0.42
Nodes (3): terminal, conciliación acotada, Correctiva focal del rechazo de historial rectificado

### Community 442 - "Estado terminal del controlador"
Cohesion: 0.42
Nodes (4): controller_terminal_state, B07 — estado terminal durable del controlador, OOMKilled, --rm

### Community 445 - "Copias cifradas por partes"
Cohesion: 0.42
Nodes (3): document, Reference Integración actual N218PASS evidencias/capacidad-paquetes-objetivo-n2-20261009.json, Reference N18PASS/reproducción2FAIL evidencias/capacidad-paquetes-objetivo-n1-20261009.json

### Community 446 - "Levantamiento de restricciones por finalidad"
Cohesion: 0.42
Nodes (5): Levantamiento comunicado de restricciones por finalidad, purpose_release.execute, PurposeReleaseProposal, PurposeRestrictionRead, resume_requested

### Community 447 - "Inventario de evidencias por finalidad"
Cohesion: 0.42
Nodes (5): account_erasure_inventory.source, dependent_evidence, Inventario seleccionado de evidencias por finalidad, evidencias/inventario-finalidades-regresion.json, evidencias/inventario-finalidades-runtime.json

### Community 448 - "Contrato de verificación y representación"
Cohesion: 0.42
Nodes (8): CR-03 — Verificación y representación, interfaz v1, Edad simulada bloqueada producción, OTP no acredita control real, Procedencia PhoneClaim, Procedimientos futuros producción, Publication ready local, Real checks compartido, Transferencia invalida controles

### Community 449 - "Inventario de colección de pruebas"
Cohesion: 0.39
Nodes (5): pytest_addoption(), pytest_collection_finish(), pytest_collectreport(), pytest_configure(), pytest_sessionfinish()

### Community 450 - "Sonda de borrado multimedia"
Cohesion: 0.50
Nodes (6): fixture(), action(), launch(), wait(), main(), state()

### Community 452 - "Revisión fotográfica y recibos privados"
Cohesion: 0.36
Nodes (3): complaint_message URL reference, photo_reuse_image URL reference, photo_reuse_queue URL reference

### Community 453 - "Preparación de decisiones de tratamiento"
Cohesion: 0.36
Nodes (3): erasure_plan URL reference, processing_review URL reference, rights_inspect URL reference

### Community 454 - "Revisión de divulgación de campos"
Cohesion: 0.36
Nodes (4): URL name referenced by template: rights_inspect, Independent field disclosure review template, URL name referenced by template: rights_inspect, Independent information review template

### Community 455 - "Planes SQL de cadenas"
Cohesion: 0.50
Nodes (5): run(), explain(), scrub(), shape(), statements()

### Community 456 - "Rectificación de cuentas sin perfil"
Cohesion: 0.53
Nodes (5): test_account_final_rectification_concurrent_close(), test_account_final_rectification_review_and_atomic_close(), test_account_recipient_flow_does_not_require_or_modify_owned_agency_profiles(), test_account_without_profile_review_receive_and_execute(), concurrently_close()

### Community 457 - "Guardas del intermediario Redis"
Cohesion: 0.42
Nodes (5): test_ci_broker_identity_is_checked_before_redis_client(), client(), inspect(), test_invalid_benchmark_selection_stops_before_service_commands(), forbidden()

### Community 458 - "Estados de fallo de servicios"
Cohesion: 0.44
Nodes (6): test_controller_terminal_state_failure_does_not_export_stderr(), inspect(), test_controller_terminal_state_preserves_identity_without_configuration(), inspect(), test_failed_service_state_capture_keeps_oom_exit_and_continues(), run()

### Community 459 - "Configuración del perfil de despliegue"
Cohesion: 0.50
Nodes (5): render_profile(), test_missing_optional_domain_key_preserves_legacy_profile(), test_optional_encryption_predecessors_reach_app_worker_and_beat(), test_prepared_profile_keeps_private_ports_roles_keys_and_limits(), test_prepared_profile_rejects_missing_operator_inputs()

### Community 460 - "Perfilado de materialización de búsqueda"
Cohesion: 0.36
Nodes (6): test_discovery_materialization_and_explicit_stage_times(), context_init(), initialized(), render(), sql_timer(), validate()

### Community 461 - "Levantamiento de publicación en móvil"
Cohesion: 0.42
Nodes (5): test_mobile_execute_received_proposal(), mobile(), test_mobile_proposal_and_public_receipt(), confirm(), propose()

### Community 463 - "Rectificación de tablas tarifarias"
Cohesion: 0.57
Nodes (4): changes(), display(), source(), validate()

### Community 464 - "Coste de relaciones heredadas"
Cohesion: 0.46
Nodes (4): B09, B09 — Atribución actual de relaciones profesionales heredadas, EXISTS, PublicationContext

### Community 465 - "Estadísticas de preparación promocional"
Cohesion: 0.46
Nodes (5): ANALYZE, Auditoría, documentación PostgreSQL17, B07–B09 — Estadísticas tras la preparación promocional, pg_prepared_statements

### Community 469 - "Integración del plan mixto"
Cohesion: 0.46
Nodes (4): B07 — Integración del plan mixto escalable, mixed246-audit.json, setval, test_counterfactual_mixed_plan_rolls_back_then_matches_actual_pages

### Community 470 - "Escenario HTTP mixto territorial"
Cohesion: 0.46
Nodes (4): artifacts/beta-promotion-fix-20261020/mixed247-negative-audit.json, B07 — HTTP mixto con mil perfiles, OOM, sha256:6936424d8c105237645efd3424be6ef31c74f7cb32904db3c963ddf9a7e1f44e

### Community 471 - "Rutas de escenarios mixtos"
Cohesion: 0.46
Nodes (4): artifacts/beta-promotion-fix-20261020/mixed250-audit.json, B07 — rutas estables en escenario mixto, route_geography, setval

### Community 472 - "Carga con mezcla confirmada"
Cohesion: 0.46
Nodes (4): capacity_committed_mixed.py, B07 — HTTP con mezcla confirmada antes de carga, protected_details, tests/capacity_committed_mixed.py

### Community 476 - "Escenario contractual HTTP combinado"
Cohesion: 0.46
Nodes (3): B07 — Contractual HTTP combinado, EXIT137, report.json

### Community 477 - "Memoria terminal del controlador"
Cohesion: 0.46
Nodes (4): ArchiveSink, B07 — memoria del procesamiento terminal, OOMKilledFalse, report[proof_key]

### Community 479 - "Purga de confirmaciones de entrega"
Cohesion: 0.46
Nodes (6): account_delivery_probe_, account_delivery_probe_<id>, Beat, Evidencia normalizada, Purga de entrega de confirmación — worker y Beat, modelos

### Community 480 - "Sonda de retención de exportaciones"
Cohesion: 0.64
Nodes (5): command(), launch(), main(), state(), wait()

### Community 481 - "Sondeo del receptor operativo"
Cohesion: 0.46
Nodes (4): main(), run_probe(), collect_sink(), receive()

### Community 482 - "Observador TCP de publicación"
Cohesion: 0.46
Nodes (3): post_worker_init(), observed(), RouteMiddleware

### Community 485 - "Plantilla de exportación privada"
Cohesion: 0.46
Nodes (3): URL name referenced by template: rights_copy_information_prepare, URL name referenced by template: rights_image_inspect, Prepare private account copy template

### Community 486 - "Plantilla de propuesta de rectificación"
Cohesion: 0.46
Nodes (7): Phone replacement and shared binding guidance, Photo selection and ordering guidance, Correction proposal guidance, Replacement image upload preparation link, Permission and other actor conditional review link, Tariff replacement editor guidance, rights rectification template

### Community 487 - "Diagnóstico de proyección de etiquetas"
Cohesion: 0.43
Nodes (6): test_label_projection_balanced_roi(), dispatch_page(), dispatch_ranking(), execute(), read(), snapshot()

### Community 488 - "Coste de políticas públicas"
Cohesion: 0.39
Nodes (5): test_policy_checked_cost100(), capture(), measured_get(), observe(), render()

### Community 489 - "Atribución de lectura promocional"
Cohesion: 0.39
Nodes (5): test_promotional_read_attribution(), instrument(), call(), observed_get(), sql_event()

### Community 490 - "Localización del cierre de acceso"
Cohesion: 0.50
Nodes (4): partial_reviewed_fixture(), test_close_form_values_legacy(), test_close_labels_invalid_partial_and_revocation(), captions()

### Community 491 - "Comparación de constructores ORM"
Cohesion: 0.50
Nodes (6): test_constructor_original_vs_deferred_postgres_rows(), captured(), record(), consume(), experiment(), no_sql()

### Community 492 - "Cierre WSGI de descifrado"
Cohesion: 0.50
Nodes (4): test_original_response_is_closed_once(), close(), __iter__(), Response

### Community 493 - "Pruebas de diagnóstico de esperas"
Cohesion: 0.50
Nodes (5): test_preserves_return_and_exception_without_scope(), fail(), test_records_only_counts_and_exclusive_nested_spans(), test_scope_restores_driver_pipeline_and_phase_after_exception(), fail()

### Community 494 - "Coste por etapas de exportación"
Cohesion: 0.39
Nodes (5): test_native_closed_flow_cost(), count_sql(), measured(), run(), ready()

### Community 495 - "Configuración del correo"
Cohesion: 0.57
Nodes (4): startup(), test_development_keeps_local_console_default(), test_explicit_smtp_configuration_does_not_connect_or_send(), test_production_rejects_missing_or_local_mail_backend()

### Community 496 - "Recuperación del trabajador de avisos"
Cohesion: 0.50
Nodes (5): test_prefork_outbox_failure_natural_backoff_then_unique_recovery(), assessment(), dispatch(), events(), wait()

### Community 497 - "Duración de objetos WSGI"
Cohesion: 0.43
Nodes (6): test_owned_wsgi_object_lifetime(), call(), start_response(), inspect_cycles(), tracked(), typename()

### Community 498 - "Control de tareas de recuperación"
Cohesion: 0.50
Nodes (5): beat_probe_queue(), test_actual_beat_removes_prior_schedule_during_recovery(), published(), test_actual_worker_ignores_recovery_and_executes_normal_probe(), wait_for()

### Community 503 - "Finalización de estadísticas promocionales"
Cohesion: 0.52
Nodes (5): auditoría focal, auditoría TCP funcional, B07 — Finalización de estadísticas del escenario promocional, finalize_promotional_statistics, get_autocommit

### Community 504 - "Coste del oráculo nativo"
Cohesion: 0.52
Nodes (4): B07 — coste del oráculo nativo de pruebas, hydrate=True, reference_territorial_order, select_related

### Community 505 - "Diagnóstico de arranque de servicios"
Cohesion: 0.52
Nodes (3): artifacts/beta-promotion-fix-20261020/startup248-preflight-audit.json, B07 — Evidencia de servicios fallidos antes de limpieza, OOMKilled

### Community 506 - "Observabilidad del escenario mixto"
Cohesion: 0.52
Nodes (3): artifacts/beta-promotion-fix-20261020/mixed249-negative-audit.json, B07 — HTTP mixto1000 tras diagnóstico de arranque, sha256:6936424d8c105237645efd3424be6ef31c74f7cb32904db3c963ddf9a7e1f44e

### Community 507 - "Escenario HTTP de mil perfiles"
Cohesion: 0.52
Nodes (3): artifacts/beta-promotion-fix-20261020/mixed256-audit.json, B07 — HTTP confirmado de 1.000 perfiles, protected_details

### Community 510 - "Medidas durante supresión pendiente"
Cohesion: 0.52
Nodes (4): consumir, Nueva medida durante una supresión pendiente, evidencias/excepciones-nueva-medida.json, pg_blocking_pids

### Community 513 - "Preparación de herramientas nativas"
Cohesion: 0.62
Nodes (3): build(), git(), main()

### Community 514 - "Sondeo de alertas urgentes"
Cohesion: 0.71
Nodes (4): command(), launch(), main(), wait()

### Community 515 - "Reconstrucción de copias multipartes"
Cohesion: 0.57
Nodes (3): integer(), main(), reconstruct()

### Community 516 - "Lanzamiento persistente de procesos"
Cohesion: 0.62
Nodes (3): alive(), main(), process_start_ticks()

### Community 517 - "Interfaz de inspección de reclamaciones"
Cohesion: 0.52
Nodes (4): complaint_action URL reference, complaint_photo URL reference, complaint_resolve URL reference, report_inspect URL reference

### Community 519 - "Cierre de acceso y recibos"
Cohesion: 0.43
Nodes (5): Private report receipt and notice status template, Private report receipt and notice status, Approved access response closure template, Named URL rights_inspect, Approved access response closure

### Community 520 - "Interfaces finales de rectificación"
Cohesion: 0.43
Nodes (5): Independent recipient assessment review template, Independent recipient assessment review, Final rectification response template, Named URL rights_inspect, Final rectification response

### Community 521 - "Inventario del ámbito de acceso"
Cohesion: 0.52
Nodes (4): URL name referenced by template: rights_access_field_prepare, URL name referenced by template: rights_access_supplement, URL name referenced by template: rights_inspect, Access scope inventory template

### Community 522 - "Plantilla de omisiones portables"
Cohesion: 0.52
Nodes (4): URL name referenced by template: rights_inspect, URL name referenced by template: rights_portability_coverage, URL name referenced by template: rights_portability_image_coverage, Justify omitted images template

### Community 523 - "Pruebas de similitud visual"
Cohesion: 0.57
Nodes (4): jpeg(), test_flat_and_tiny_images_are_not_identity_matches(), test_positive_recompression_and_crop_candidate_and_confirmation(), test_unrelated_synthetic_images_never_confirm()

### Community 524 - "Preparación inicial de trabajadores"
Cohesion: 0.52
Nodes (4): test_default_gunicorn_hook_runs_preparation_and_propagates_failure(), failure(), test_static_preparation_has_no_network_database_or_language_side_effects(), forbidden()

### Community 525 - "Modelos de cadena de evidencias"
Cohesion: 0.60
Nodes (3): RightsEvidenceEvent, Meta, RightsEvidenceHead

### Community 533 - "Derechos vinculados sin anuncio"
Cohesion: 0.60
Nodes (4): Vinculación de derechos a un perfil sin anuncio, link, link_person_id, manager_version

### Community 534 - "Contrato de interfaces comunes"
Cohesion: 0.60
Nodes (5): Interfaces comunes v1, CSRF sesión objetos privados, Health DB público, Redis IDs PostgreSQL negocio, SSR ES EN sin trackers

### Community 535 - "Emisor HTTP asíncrono"
Cohesion: 0.67
Nodes (4): _run(), finished(), launch(), worker()

### Community 536 - "Informe de tiempos del catálogo"
Cohesion: 0.60
Nodes (3): pytest_addoption(), pytest_runtest_logreport(), pytest_terminal_summary()

### Community 537 - "Informes intermedios de integración"
Cohesion: 0.60
Nodes (3): pytest_addoption(), pytest_configure(), pytest_runtest_logreport()

### Community 538 - "Sondeo de eventos operativos"
Cohesion: 0.60
Nodes (3): main(), retry_failure(), success()

### Community 540 - "Cola interna de derechos"
Cohesion: 0.60
Nodes (5): Internal rights attention filters, Permission conditional calendar links, Conditional exhausted file deletion attention link, Unconfirmed extension notice attention text, rights queue template

### Community 541 - "Perfilado nativo de consultas"
Cohesion: 0.53
Nodes (4): capture(), bind_backend(), sample(), statements()

### Community 542 - "Relojes de estabilidad WSGI"
Cohesion: 0.67
Nodes (3): application(), start(), host_state()

### Community 544 - "Contraejemplos arquitectónicos PostgreSQL"
Cohesion: 0.60
Nodes (3): test_freeze_and_reindex_preserve_observed_heap_versions_but_schema_can_change(), read(), test_restored_hash_function_does_not_repair_stored_generated_digest()

### Community 545 - "Control de instrumentación de capacidad"
Cohesion: 0.67
Nodes (3): test_owned_small_case_instrumentation(), diagnosed(), sql_observed()

### Community 546 - "Diagnóstico de conflictos nativos"
Cohesion: 0.53
Nodes (3): test_native_conflict_plan_after_small_fixture_statistics(), observe(), save()

### Community 547 - "Atribución de variabilidad de solicitudes"
Cohesion: 0.53
Nodes (4): test_owned_request_aa_attribution(), observed(), gc_event(), sql()

### Community 549 - "Autoridad del calendario de publicación"
Cohesion: 0.60
Nodes (3): test_calendar_permission_revoked_during_query(), with_query(), revoke()

### Community 550 - "Pruebas de selección binaria"
Cohesion: 0.60
Nodes (3): test_guided_binary_page_requires_current_token_and_preserves_other_choices(), catalog(), ready_with_history()

### Community 551 - "Migración del estado de publicación"
Cohesion: 0.70
Nodes (3): Migration, trigger_sql(), collect()

### Community 554 - "Ejemplo de configuración productiva"
Cohesion: 0.70
Nodes (3): Real payments disabled, Preparation only production hardening, Internal backend network

### Community 562 - "Cola de restricciones por finalidad"
Cohesion: 0.70
Nodes (4): Purpose restrictions listing template, Named URL purpose_restriction_release, Named URL rights_inspect, Purpose restrictions listing

### Community 563 - "Plantilla de triaje de denuncias"
Cohesion: 0.70
Nodes (4): Private report triage queue template, Named URL report_inspect, Named URL urgent_report_alerts, Private report triage queue

### Community 570 - "Plantilla de evaluación portable"
Cohesion: 0.70
Nodes (4): Dataset assessment evidence display, Independent assessment review guidance, Review action recording form, rights portability review template

### Community 577 - "Rotación de credenciales PostgreSQL"
Cohesion: 0.60
Nodes (3): test_owned_login_rotation_requires_old_session_termination(), django_query(), docker()

### Community 602 - "Propuesta de levantamiento por finalidad"
Cohesion: 0.83
Nodes (3): Purpose restriction release proposal template, Named URL rights_inspect, Purpose restriction release proposal

### Community 603 - "Preparación de imágenes de reemplazo"
Cohesion: 0.83
Nodes (3): Private replacement image preparation template, Named URL rights_rectification, Private replacement image preparation

### Community 846 - "Inventario diferencial y deuda"
Cohesion: 0.06
Nodes (69): Admin offline y delete_selected no ejecutado, apply_recovery_ledger, apps.listings.tasks.refresh_publication_state, apps.mediafiles.tasks.process_blob, apps.mediafiles.tasks.recover_media_jobs, apps.safety.tasks.deliver_safety_notices, apps.safety.tasks.generate_portability_export, Beat condicionado y recuperación (+61 more)

### Community 847 - "Acta final y deuda"
Cohesion: 0.17
Nodes (20): Beta con usuarios: G01–G08 y autorización expresa, Beta técnica local: datos sintéticos y PostgreSQL real, Roadmap: estado final del contrato, B00–B13 y B16: 15 de 18 aceptados localmente, Acta23: cierre local del contrato en alfa, Auditoría previa: 18 puntos y siete entregables de contrato16, B10: evaluación y disposición P2 con FAIL MOD09 preservado, B14: proveedores no elegidos ni integrados (+12 more)

### Community 849 - "Inventario y priorización N00"
Cohesion: 0.10
Nodes (38): N00: evaluación inicial pendiente de aceptación independiente, I01 — Listado orgánico, I02 — Listado promocionado, I03 — Búsquedas y filtros, I04 — Paginación, I05 — Ficha pública, I06 — Entrega de imágenes, I07 — Favoritos (+30 more)

### Community 850 - "Diagnóstico y presupuestos N01"
Cohesion: 0.17
Nodes (21): N00 aceptación local estructural: 1/13, sin PASS de 443 unidades, Primer sublote: listado orgánico ES 10/100; restantes escenarios no sustituidos, N00 contrasta 28 familias con unidades heterogéneas sin sumar funcionalidades, N00 no realiza medición nueva de latencia, SQL o recursos, Nueve grupos priorizados sin tráfico real supuesto ni prioridad automática MOD09, N00 conserva 1507 SHA ejecutables sin mejora de rendimiento atribuida, Rendimiento individual pendiente y evidencia familiar no implica PASS por acción, Tabla N00: comparación documental sin producto ni mediciones nuevas (+13 more)

### Community 851 - "Diagnóstico N01 auditado"
Cohesion: 0.35
Nodes (10): N01A audited diagnostic: 2 PASS, 0 FAIL/ERROR/SKIP (2026-10-25), Owned containers absent, temporary removed and terminal Telegram sent, 1507 frozen executable/document/graph SHAs unchanged through execution and audit, Independent audit checks exact selection, six phases, JUnit, sources and cleanup, Initial organic ES listing: Django HTTP Client, real PostgreSQL, 200/population/page/no-store oracles, Mandatory before/after table on every block closure; comparable base/candidate or declared absent baseline, Before candidates: separate first/later requests at same size and fix warmed states, selection, resources and oracles, Promotion, filters, deep pages, EN, detail, browser, concurrency and remaining groups pending (+2 more)

### Community 852 - "Segmentos y medición N01"
Cohesion: 0.21
Nodes (11): Promotions, retention/scale, combined filters, deeper pages, negatives, browser/load and eight other groups remain pending, Audit execution, JUnit, samples, oracles, cleanup and Telegram before interpretation, Official local runner PostgreSQL17 Redis7.4 one worker librdb2.4.0, N00 accepted 1/13; N01 and N04 in progress, Declared profile type excludes special trans selector, One transactional case; 100 profiles; 10 segments × 6 = 60 serial requests, Wall and execute-wrapper measurements, no SQL-server-only time, Independent fixture oracles and per-sample response gates (+3 more)

### Community 853 - "Diagnóstico N01 auditado"
Cohesion: 0.32
Nodes (7): N00 accepted 1/13; N01 and N04 open; alpha, Detail exposes no route marker, 12 empty searches: state/trusted_state, 36 listing/page2/profile requests: fallback state_unknown_over_limit, N01B audited reference: 1 PASS, 60 requests, 10 segments, six samples each, Promotions, depth, combined filters, sizes, negative states, worker/browser/load and eight remaining groups pending; no production acceptance, 57.552s pytest step includes fixture and samples; 60 samples and all oracles passed; isolated PG17/Redis7.4 removed; Telegram terminal sent

### Community 854 - "Preparación nativa y diagnóstico"
Cohesion: 0.19
Nodes (13): N01B observó 36 fallback/state_unknown_over_limit sin declarar defecto, Auditar 1 caso/120 muestras; promociones, escala, concurrencia, browser/worker, negativos y otros ocho grupos pendientes, populate(100) reutiliza población; oráculos y parámetros conservados, PostgreSQL17/Redis7.4 y librdb2.4.0 locales; preservar 1507 fuentes y B por bytes, Sin estados manuales ni sustitución de state_page, guards o límites, Preparación síncrona no acredita worker/Beat, throughput, SLA o cadencia, Wall/SQL por petición y mantenimiento separado; sin p95, TCP, capacidad o mejora de código, 120 peticiones, gates y hashes de IDs/orden/tamaño; campos de negocio Listing exactos (+5 more)

### Community 855 - "Diagnóstico N01 auditado"
Cohesion: 0.44
Nodes (9): No product change, capacity claim or N01/N04 closure, One JUnit case, three journal phases, two phases of 10 segments × 6 samples, N01C audited operational preparation: 1 PASS, 120 requests, Native refresh_publication_state --all with VACUUM/ANALYZE, Proposals unaccepted; scenario/oracles/resources/budgets review and remaining S01 pending, Listing/page2/profile fallback→state; details retain their guard, 19 proposed S02–S09 representatives, 93 citations and 29 selectors checked, Listing SQL 29→32 while observed median falls (+1 more)

### Community 856 - "Observación HTTP sintética"
Cohesion: 0.18
Nodes (17): measure_request(), timed(), owned_run(), pytest_configure(), pytest_runtest_call(), measured(), test_call_hook_restores_client_even_if_test_raises(), test_exception_is_unchanged_and_its_message_is_never_recorded() (+9 more)

### Community 857 - "Prerregistro de operaciones HTTP"
Cohesion: 0.12
Nodes (32): Auditoría de colección, muestras, identidad y aviso Telegram, Campos permitidos de captura por petición, Comparación conserva selección, datos, orden y recursos, Refresco focal grafo y congelación de fuentes antes de ejecutar, Contrato340, Fixtures sintéticos existentes; sin cobros/proveedores reales, Llamadas síncronas Django Client.request durante call, Runner oficial, PostgreSQL17, Redis7.4 y librdbv2.4.0 locales (+24 more)

### Community 858 - "Resultado de operaciones HTTP"
Cohesion: 0.32
Nodes (11): Pasada serial; 102.253s pytest no es latencia; SQL síncrono de conexión durante call, Misma base de aplicación; sólo runner e instrumento nuevos, 11PASS,109peticiones; sin aceptación de rendimiento; N01 abierto y N00 aceptado1/13, N00aceptado1/13,N01abierto; sin aceptación por instrumentación, Lote Django/PostgreSQL17 y Redis7.4; dobles SQL del instrumento separados, Mutaciones y reintentos heterogéneos; sin ganancia causal, Sin p95/p99, cumplimiento<800ms ni garantía de producción; presupuestos pendientes, 109 operaciones HTTP observadas; denegaciones esperadas (+3 more)

### Community 859 - "Base de agregados operativos"
Cohesion: 0.13
Nodes (24): Auditar selección, 18 muestras, oráculos, identidad, limpieza y recibos Telegram; sin p95/p99, test_snapshot_publication_backlog_baseline: 0/10/100 PublicationDirty sintéticas, apps.core.operational_snapshot.collect_snapshot, Base diagnóstica sin SLO inventado ni aceptación de rendimiento N10, N01E — conciliación primaria de fichas y siguiente base operativa, Ejecución prevista: runner serial focused, PostgreSQL17/Redis7.4, timeout900s, Pared, consultas y SQL; oráculos de cuenta, edad, alcance durable y sólo lectura, N01 abierto; N00 aceptado 1/13 (+16 more)

### Community 860 - "Resultado de operaciones HTTP"
Cohesion: 0.23
Nodes (16): Sólo collect_snapshot; orden 0/10/100; conexiones reutilizadas; sin frío controlado ni mejora causal ni candidato de aplicación, PublicationDirty 0: primera 183.843ms; mediana5 119.093ms; rango 97.073–168.268ms; 50 consultas, PublicationDirty 100: primera 128.480ms; mediana5 73.149ms; rango 66.514–95.859ms; 50 consultas, PublicationDirty 10: primera 138.306ms; mediana5 74.147ms; rango 69.455–88.817ms; 50 consultas, 1/13, N01 abierto; lote no cierra N01/N10, Fuentes congeladas sin cambios; recursos propios retirados; avisos runner y auditoría entregados por Telegram según resultado, 50 consultas incluyen preparación transaccional y agregaciones; sin extrapolar coste a otras tablas, tamaños o planes, 47,556s pytest no es tiempo de servicio; sin cuotas dedicadas, tráfico, broker/worker medidos, restauración o proveedor verificados (+8 more)

### Community 861 - "Resultado de operaciones HTTP"
Cohesion: 0.10
Nodes (38): Cero diferencias no autorizadas y negativos preservados, Coste candidato≤referencia; mejora exige reducción estricta, Trabajo costoso requiere muestras justificadas y prueba persistente, Criterios354 anteriores a cualquier candidato, SHA completos y condiciones equivalentes antes de atribuir causalidad, Planificación conserva mediciones pendientes antes del candidato, p95<800ms y errores<1% sólo protocolo de mezcla pública, MOD09 p95≤2s/5s, FAIL y excepción provisional sin ampliar (+30 more)

### Community 862 - "Atribución de inicio de revisión"
Cohesion: 0.11
Nodes (24): N00/N01 aceptados 2/13; N06 iniciado, no aceptado; sin candidato, tests/test_revised_listings.py::test_revised_version_keeps_approved_snapshot_and_reuses_bytes, create_draft: copia datos/fotos y registra process_blob.delay al confirmar, Criterios 354 preservados, Antes de medir: integrar AST y semántica, verificar y congelar fuentes/dependencias/migraciones/instrumentos/grafo/imágenes, Comparaciones futuras: congelar referencia por estado/etapa antes del candidato, tests/test_listing_start_cost_baseline.py::test_listing_start_query_attribution, Límites 355 preservados (+16 more)

### Community 863 - "Resultado de operaciones HTTP"
Cohesion: 0.20
Nodes (8): Vista vigente: sin candidato; camino normal pendiente, sin repetir A sin hipótesis/candidato, N00/N01 aceptados 2/13; N12–N14 condicionados sin PASS automático, Pared N06A 456.182/496.601/556.703 ms; SQL 202.946/256.990/285.061 ms, N06A: atribución auditada; 2 PASS, tres inicios; no candidato de aplicación, Estudiar helpers worker/broker y prerregistrar camino normal; permisos, instantánea, bytes, paridad, reintento y revocación preservados, N01D anterior 349,918/390,576/566,035 ms; N06A última 456,182/496,601/556,703 ms; mejora no evaluable, SQL 116/116/124: create_draft 11, gestor 2, resto 14, tareas eager 89/89/97, Índice documental referencia atribución N06A y 2PASS

## Knowledge Gaps
- **1 isolated node(s):** `publication_signals programa refresh_publication_state`
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 792 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)
- **357 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `User` connect `Usuarios y solicitudes de derechos` to `Exportación cifrada de portabilidad`, `Fotografías y descubrimiento`, `Copias y respuestas de derechos`, `Visibilidad y promociones`, `Supresión y restricciones por finalidad`, `Moderación de perfiles y fotografías`, `Copias privadas de derechos`, `Cobertura de portabilidad por lotes`, `Moderación y apelaciones de anuncios`, `Verificación de solicitudes de derechos`, `Vistas de portabilidad`, `Comunicaciones y respuestas finales`, `Medición de carga HTTP`, `Contexto de detalle propio`, `Revisión de selección portátil`, `Paginación y autoridad promocional`, `Invalidación de borradores privados`, `Localización de interfaces`, `Promociones y conciliación documental`, `Información adicional de acceso`, `Inventario de recursos propios`, `Publicación y descubrimiento territorial`, `Autenticación multifactor e interfaces móviles`, `Gestión de reclamaciones`, `Rectificación y revisión de destinatarios`, `Gestión del ciclo de perfiles`, `Contenido de entregas de acceso`, `Cobertura del derecho de acceso`, `Revisiones de conservación`, `Ejecución de rectificación de cuenta`, `Catálogo de promociones`, `Cuentas y aceptación legal`, `Entrega privada de objetos`, `Privacidad y alertas urgentes`, `Agencias y conflictos de representación`, `Invalidación condicional de publicación`, `Trabajos de exportación portable`, `Inspección y alertas urgentes`, `Exportación y cobertura de portabilidad`, `Decisiones y restricciones de denuncias`, `Cargas preparadas y limpieza`, `Verificación y consentimiento`, `Cola de avisos privados`, `Manifiestos paginados de fuentes`, `Planes de supresión`, `Ejecución de supresión`, `Aplicación de recuperación y medios`, `Sellos de validación`, `Inventario de claves de cifrado`, `Orígenes de históricos Redis`, `Asignación y vinculación de derechos`, `Ejecución y respuesta de supresión`, `Cuentas y confirmación de correo`, `Interfaces de comunicaciones de derechos`, `Supresión de cuentas y concurrencia`, `Supresión y propiedad recuperada`, `Borrado y recuperación de medios`, `Selección binaria de portabilidad`, `Instantáneas de directorios de pruebas`, `Calendario de finalidades`, `Recepción y acuses privados`, `Ámbitos del historial Redis`, `Base de diagnóstico y restauración`, `Inventario de evidencias de derechos`, `Lecturas de presentación pública`, `Respuesta y cierre de portabilidad`, `Estadísticas y atribución de consultas`, `Revisión y apelaciones de agencias`, `Operaciones de avisos`, `Ciclo de vida de anuncios`, `Rectificación de cuenta`, `Favoritos y restricciones por finalidad`, `Inspección y selección de denuncias`, `Revisión y apelaciones de gestores`, `Propuestas de rectificación de campos`, `Revisión independiente de rectificación`, `Rotación de claves criptográficas`, `Prórrogas y atención de derechos`, `Formularios de información de acceso`, `Disposición y reintroducción fotográfica`, `Datos de copias de cuenta`, `Mensajes y aclaraciones de derechos`, `Restauración diagnóstica de PostgreSQL`, `Recepción y prioridad de derechos`, `Inventario de reutilización fotográfica`, `Avisos privados de rectificación`, `Pruebas de restricciones de privacidad`, `Ámbito de validación del proxy`, `Transporte JSON de portabilidad`, `Transporte binario de portabilidad`, `Simulacro de escalada urgente`, `Sonda de caducidad de entregas`, `Sondas de caducidad y recuperación`, `Sondeo de conservación de portabilidad`, `Sonda de borrado multimedia`, `Rectificación de cuentas sin perfil`, `Sonda de retención de exportaciones`, `Localización del cierre de acceso`, `Comparación de constructores ORM`?**
  _High betweenness centrality (0.056) - this node is a cross-community bridge._
- **Why does `Revision` connect `Moderación de perfiles y fotografías` to `Usuarios y solicitudes de derechos`, `Exportación cifrada de portabilidad`, `Fotografías y descubrimiento`, `Proyección del estado de publicación`, `Apelaciones y restricciones fotográficas`, `Visibilidad y promociones`, `Copias privadas de derechos`, `Contexto de publicación pública`, `Cobertura de portabilidad por lotes`, `Moderación y apelaciones de anuncios`, `Verificación de solicitudes de derechos`, `Inventario de evidencias de derechos`, `Comunicaciones y respuestas finales`, `Disposición y reintroducción fotográfica`, `Medición de carga HTTP`, `Contexto de detalle propio`, `Rectificación de selección fotográfica`, `Reglas y formularios de perfiles`, `Transporte JSON de portabilidad`, `Lecturas de presentación pública`, `Invalidación de borradores privados`, `Localización de interfaces`, `Estadísticas y atribución de consultas`, `Búsqueda y catálogos geográficos`, `Registro y restauración de supresión`, `Publicación y descubrimiento territorial`, `Autenticación multifactor e interfaces móviles`, `Gestión de reclamaciones`, `Ciclo de vida de anuncios`, `Gestión del ciclo de perfiles`, `Ejecución de rectificación de cuenta`, `Huellas de fuentes y revisiones`, `Rectificación de cuenta`, `Gestión de reclamaciones privadas`, `Recorrido del perfil en navegador`, `Flujo de portabilidad con historial`, `Carga de imágenes rectificadas`, `Topología de servidores de comparación`, `Privacidad y alertas urgentes`, `Revisión de reintroducción fotográfica`, `Propuestas de rectificación`, `Sonda de borrado multimedia`, `Inspección y alertas urgentes`, `Cargas preparadas y limpieza`, `Manifiestos paginados de fuentes`, `Inventario de reutilización fotográfica`, `Ejecución de supresión`, `Aplicación de recuperación y medios`, `Propuestas de rectificación de campos`, `Ejecución y respuesta de supresión`, `Diagnóstico de esperas de capacidad`, `Sonda de retención de exportaciones`, `Comparación de constructores ORM`, `Pruebas de diagnóstico de esperas`, `Supresión y propiedad recuperada`, `Coste por etapas de exportación`, `Selección binaria de portabilidad`, `Revisión independiente de rectificación`, `Pruebas de restricciones de privacidad`, `Metadatos públicos y SEO`?**
  _High betweenness centrality (0.023) - this node is a cross-community bridge._
- **Why does `Listing` connect `Visibilidad y promociones` to `Usuarios y solicitudes de derechos`, `Exportación cifrada de portabilidad`, `Mapas y metadatos públicos`, `Fotografías y descubrimiento`, `Copias y respuestas de derechos`, `Apelaciones y restricciones fotográficas`, `Proyección del estado de publicación`, `Moderación de perfiles y fotografías`, `Atribución de preparación promocional`, `Supresión y restricciones por finalidad`, `Copias privadas de derechos`, `Contexto de publicación pública`, `Moderación y apelaciones de anuncios`, `Verificación de solicitudes de derechos`, `Inventario de evidencias de derechos`, `Medición de carga HTTP`, `Contexto de detalle propio`, `Reglas y formularios de perfiles`, `Paginación y autoridad promocional`, `Invalidación de borradores privados`, `Localización de interfaces`, `Estadísticas y atribución de consultas`, `Búsqueda y catálogos geográficos`, `Operaciones de avisos`, `Publicación y descubrimiento territorial`, `Autenticación multifactor e interfaces móviles`, `Vistas de pedidos promocionales`, `Ciclo de vida de anuncios`, `Gestión del ciclo de perfiles`, `Cobertura del derecho de acceso`, `Sondas de caducidad y recuperación`, `Huellas de fuentes y revisiones`, `Diagnóstico de estados desconocidos`, `Gestión de reclamaciones privadas`, `Recorrido del perfil en navegador`, `Favoritos y restricciones por finalidad`, `Topología de servidores de comparación`, `Invalidación condicional de publicación`, `Agencias y conflictos de representación`, `Sonda de borrado multimedia`, `Inspección y alertas urgentes`, `Exportación y cobertura de portabilidad`, `Decisiones y restricciones de denuncias`, `Diagnósticos de materialización`, `Manifiestos paginados de fuentes`, `Planes de supresión`, `Ejecución de supresión`, `Aplicación de recuperación y medios`, `Propuestas de rectificación de campos`, `Asignación y vinculación de derechos`, `Ejecución y respuesta de supresión`, `Sonda de retención de exportaciones`, `Plantillas de consultas propias`, `Vinculación de páginas preparadas`, `Comparación de constructores ORM`, `Supresión de cuentas y concurrencia`, `Supresión y propiedad recuperada`, `Pruebas de restricciones de privacidad`, `Metadatos públicos y SEO`, `Actualización transaccional de publicación`?**
  _High betweenness centrality (0.018) - this node is a cross-community bridge._
- **What connects `publication_signals programa refresh_publication_state` to the rest of the system?**
  _1 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Usuarios y solicitudes de derechos` be split into smaller, more focused modules?**
  _Cohesion score 0.023339197453296472 - nodes in this community are weakly interconnected._
- **Should `Exportación cifrada de portabilidad` be split into smaller, more focused modules?**
  _Cohesion score 0.030997150997151 - nodes in this community are weakly interconnected._
- **Should `Fotografías y descubrimiento` be split into smaller, more focused modules?**
  _Cohesion score 0.04274978178024739 - nodes in this community are weakly interconnected._