# Grafo alfa — resultado guard de imágenes N02B

N00/N01aceptados2/13,N02/N06abiertos,alfa. Resultado363:2PASS nuevos más14oráculos originalesPASS reutilizados con identidad;no una batería16PASS. Guard real con2imágenes:7→4SQL,2lecturas/hash iguales y4locksPG previos porinvocación,12muestras. Mediana30,659→23,557ms pero2/5parejas peores/rangos solapados:tiempo inconcluso/adopción pendiente. Fallos instrumentales/configuración preservados,fuentes/limpieza/Telegramverificados. Objetivos2s/5s/FAIL/excepciónMOD09 conservados;no aceptación de flujo completo.

Refresco semántico focal363/341/README/vista17líneas1–4,AST previo intacto. 1958fuentes,18378nodos/80792relaciones,870comunidades. Base completa previa preservada,no reconstrucción global ni semántica exhaustiva.1505ejecutables originales intactos,1runnerinstrumental y1candidato de guard explícito.100anotacionesambiguas/exclusiones previas conservadas;JSONcompleto,HTMLcomunidades. Consumo nativo desconocido.

