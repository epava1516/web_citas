# Grafo alfa — ensayo pareado de metadatos N02A

N00/N01aceptados2/13,N02/N06abiertos. Protocolo360:5casos previstos,24observaciones pareadas de primitivas existentes;dos sujetos secuenciales1500revisiones/~16MiBJSON/16WebP~64MiBcadauno.48SQLsingle/3bulk y16lecturas/hash completos esperados,filas/orden iguales. Primera pareja separada y5posteriores,DEBUGFalse;sin candidato integrado,HTTP/autorización/p95MOD09 ni mejora global. Objetivos2s/5s yFAIL/excepción preservados.

Refresco focal semántico360 más ASTnuevo test_current_image_metadata_benchmark.py,5nodos/19relaciones/3funciones. 1954fuentes,18313nodos/80613relaciones,867comunidades. ASTprevio y base reconstruida preservados,no reconstrucción completa ni semántica exhaustiva.1506ejecutables originales intactos,runner variante instrumental;consumo nativo desconocido. JSONcompleto/HTMLcomunidades;100anotaciones ambiguas/exclusiones previas conservadas,vista17líneas1–4. Semántica no prueba ejecución.

