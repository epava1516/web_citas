def _verify_current_images(export, person):
    from .rights_exports import image_content

    binding = RightsExportPortabilityBinding.objects.select_related("review__selection").get(
        export=export
    )
    declarations = unseal(binding.review.selection.encrypted_selection).get("images", [])
    for declaration in declarations:
        _, current = image_content(person, declaration["photo"])
        if hashlib.sha256(current).hexdigest() != declaration["content_digest"]:
            raise ValidationError("Portable image content changed")
        del current

