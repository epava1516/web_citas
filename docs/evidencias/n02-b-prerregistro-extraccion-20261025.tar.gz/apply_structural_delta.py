"""Fresh instrument AST and one stdlib-AST/import-resolved caller substitution."""
import ast,collections,hashlib,json,re
from pathlib import Path
w=Path(__file__).resolve().parent;s=w/'graph-integrated';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();norm=lambda x:re.sub('[^a-z0-9]+','_',x.lower()).strip('_');fileid=lambda p:'file_'+norm(p)
g=json.loads((s/'graph.json').read_text());nodes={n['id']:n for n in g['nodes']};edges=g['links'];m=json.loads((s/'SOURCE_MANIFEST.json').read_text());proof=json.loads((w/'semantic-integration.json').read_text());proof['semantic_changed_sources']=proof['changed_sources'].copy()
p='tests/test_held_seal_image_batch.py';raw=json.loads((w/'fresh-ast-completed.json').read_text());assert not raw['failed_sources'];assert json.loads((w/'python-definition-reconciliation.json').read_text())['python_declarations']==13
assert p not in m
m[p]={'sha256':sha(p),'bytes':Path(p).stat().st_size,'category':'code','input_path':str(Path(p).resolve()),'input_sha256':sha(p),'semantic_scope':'fresh_graphify_and_standard_Python_AST','extraction_origin':'fresh_N02B_instrument_AST'}
nodes[fileid(p)]={'id':fileid(p),'label':p,'source_file':p,'source_location':'L1','file_type':'code','extraction_origin':'declared_corpus_manifest'}
for n in raw['nodes']:
 if n.get('source_file')!=p:continue
 assert n['id'] not in nodes
 n={**n,'extraction_origin':'fresh_N02B_instrument_AST'};nodes[n['id']]=n
 edges.append({'source':fileid(p),'target':n['id'],'relation':'has_extracted_entity','source_file':p,'source_location':n.get('source_location'),'confidence':'EXTRACTED','confidence_score':1.0,'weight':1.0,'extraction_origin':'extraction_provenance_not_application_dependency'})
for rawedge in raw['edges']:
 e={**rawedge,'extraction_origin':'fresh_N02B_instrument_AST'}
 for k in ('source','target'):
  if e[k] in nodes:continue
  identity=e[k];matches=[i for i,n in nodes.items() if n.get('external') and n.get('label')==identity]
  key=matches[0] if len(matches)==1 else 'n02b_instrument_reference_'+norm(identity)
  if key not in nodes:nodes[key]={'id':key,'label':identity,'source_file':None,'source_location':None,'file_type':'concept','external':True,'resolution_status':'unresolved_static_reference_not_runtime_binding','extraction_origin':'fresh_N02B_instrument_AST'}
  e[k]=key
 e.setdefault('confidence_score',1.0 if e['confidence']=='EXTRACTED' else .85);edges.append(e)
# Parent proved exact source and whole remaining-module AST identity before reusing it.
app='apps/safety/rights_portability_export.py';candidate=json.loads((w.parent/'candidate-scope.json').read_text());assert sha(app)==candidate['after_sha256'] and m[app]['sha256']==candidate['before_sha256']
old_source=(w.parent/'rights-portability-export-before.py').read_text();new_source=Path(app).read_text()
def stripped(text):
 t=ast.parse(text);t.body=[n for n in t.body if not isinstance(n,ast.FunctionDef) or n.name!='_verify_current_images'];return ast.dump(t,include_attributes=False)
assert stripped(old_source)==stripped(new_source)
f=next(n for n in ast.parse(new_source).body if isinstance(n,ast.FunctionDef) and n.name=='_verify_current_images')
imports=[n for n in ast.walk(f) if isinstance(n,ast.ImportFrom)];assert len(imports)==1 and imports[0].module=='rights_exports' and imports[0].level==1 and [n.name for n in imports[0].names]==['image_contents']
calls=[n for n in ast.walk(f) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='image_contents'];assert len(calls)==1
caller='apps_safety_rights_portability_export_verify_current_images';oldtarget='apps_safety_rights_exports_image_content';newtarget='apps_safety_rights_exports_image_contents';assert caller in nodes and newtarget in nodes
removed=[e for e in edges if e.get('source_file')==app and e['source']==caller and e['target']==oldtarget and e['relation']=='calls'];assert len(removed)==1
edges=[e for e in edges if e not in removed]
line=calls[0].lineno
edges.append({'source':caller,'target':newtarget,'relation':'calls','source_file':app,'source_location':'L'+str(line),'evidence_quote':new_source.splitlines()[line-1],'confidence':'EXTRACTED','confidence_score':1.0,'weight':1.0,'context':'statically_resolved_relative_import_not_runtime_binding','extraction_origin':'focused_Python_AST_guard_call_substitution'})
m[app].update(sha256=sha(app),bytes=Path(app).stat().st_size,input_sha256=sha(app),input_path=str(Path(app).resolve()),semantic_scope='Prior full AST preserved outside changed guard; changed call resolved by fresh stdlib AST and exact local import',extraction_origin='focused_guard_AST_with_identical_remaining_module')
proof['changed_sources']+= [app,p];proof['structural_delta']={'instrument':p,'instrument_sha256':sha(p),'instrument_raw_nodes':len(raw['nodes']),'instrument_raw_relations':len(raw['edges']),'instrument_named_functions':13,'app_scope':candidate,'app_removed_relations':removed,'app_added_call_line':line,'full_graph_AST_not_rebuilt':True}
a=json.loads((s/'.graphify_analysis.json').read_text());communities={int(k):list(v) for k,v in a['communities'].items()};assigned={i for v in communities.values() for i in v};cid=max(communities);communities[cid]+=sorted(set(nodes)-assigned)
labels={int(k):v for k,v in json.loads((s/'.graphify_labels.json').read_text()).items()};labels[cid]='Guard de imágenes con sello'
for c,ids in communities.items():
 for i in ids:nodes[i].update(community=c,community_name=labels[c])
assert all(e[k] in nodes for e in edges for k in ('source','target'))
g.update(nodes=list(nodes.values()),links=edges);g['graph']['corpus_files']=len(m);g['graph']['structural_sources']+=1
a['communities']=communities
proof.update(source_files=len(m),nodes=len(nodes),relations=len(edges),communities=len(communities),scope='Preserved full base; scoped protocol semantics, fresh instrument AST and stdlib AST/import caller substitution; remaining application module AST identical. Static graph is not runtime proof.')
(s/'graph.json').write_text(json.dumps(g,indent=2,ensure_ascii=False));(s/'SOURCE_MANIFEST.json').write_text(json.dumps(m,indent=2));(s/'.graphify_analysis.json').write_text(json.dumps(a));(s/'.graphify_labels.json').write_text(json.dumps(labels));(w/'semantic-integration.json').write_text(json.dumps(proof,indent=2))
print(json.dumps({k:proof[k] for k in ['source_files','nodes','relations','communities','scope']}))
