"""Fresh Python AST supplement; retain unresolved bindings instead of guessing."""
import ast
import collections
import json
import re
from pathlib import Path

root = Path.cwd()
work = Path(__file__).resolve().parent
raw = json.loads((work / 'fresh-ast.json').read_text())
nodes = {n['id']: dict(n) for n in raw['nodes']}
edges = [dict(e) for e in raw['edges']]
norm = lambda s: re.sub('[^a-z0-9_]', '_', s.lower())
lookup = collections.defaultdict(list)
for n in nodes.values():
    lookup[(n.get('source_file'), n.get('label', '').lstrip('.').removesuffix('()'), n.get('source_location'))].append(n)
decls = []

class Collect(ast.NodeVisitor):
    def __init__(self, path):
        self.path, self.stack = path, []

    def visit_named(self, node):
        scope = [d['name'] for d in self.stack]
        candidates = []
        for line in [node.lineno] + [d.lineno for d in node.decorator_list]:
            candidates.extend(lookup.get((self.path, node.name, f'L{line}'), []))
        candidates = {n['id']: n for n in candidates}
        existing = next(iter(candidates.values())) if len(candidates) == 1 else None
        generated = norm(str(Path(self.path).with_suffix(''))) + '_' + '_'.join(norm(x) for x in scope + [node.name])
        identity = existing['id'] if existing and node.name != 'Meta' else generated
        row = {'file': self.path, 'name': node.name, 'scope': scope, 'line': node.lineno,
               'end': node.end_lineno, 'kind': type(node).__name__, 'id': identity,
               'canonical_id': generated,
               'existing': existing['id'] if existing else None,
               'parent': self.stack[-1]['id'] if self.stack else None}
        decls.append(row)
        self.stack.append(row)
        self.generic_visit(node)
        self.stack.pop()

    visit_ClassDef = visit_named
    visit_FunctionDef = visit_named
    visit_AsyncFunctionDef = visit_named

for path in json.loads((work / 'detect.json').read_text())['files']['code']:
    path = Path(path)
    if path.suffix == '.py':
        Collect(str(path.relative_to(root))).visit(ast.parse(path.read_text()))

# An omitted declaration can collide with a DIFFERENT upstream symbol, e.g.
# destroy_one versus _destroy_one, or nested Client versus Session.client.
# Rekey that existing symbol to its actual full lexical identity first.
normalization_rekeys = []
conflict_aliases = {}
for missing in decls:
    if missing['existing'] or missing['id'] not in nodes:
        continue
    previous = [d for d in decls if d['existing'] == missing['id']]
    assert len(previous) == 1, (missing, previous)
    previous = previous[0]
    old_id, new_id = previous['id'], previous['canonical_id']
    assert new_id != old_id and new_id not in nodes, (old_id, new_id)
    node = nodes.pop(old_id)
    node['id'] = new_id
    nodes[new_id] = node
    previous['id'] = new_id
    lexical_prefix = previous['scope'] + [previous['name']]
    for d in decls:
        if d['parent'] == old_id and d['scope'][:len(lexical_prefix)] == lexical_prefix:
            d['parent'] = new_id
    conflict_aliases[old_id] = [previous, missing]
    normalization_rekeys.append({'old': old_id, 'new': new_id,
                                 'conflicting_declaration': missing['canonical_id']})

meta_aliases = collections.defaultdict(list)
added, rekeyed, multi = [], [], []
for d in decls:
    if d['name'] == 'Meta' and d['existing']:
        # One flat extractor identity can represent several nested Meta classes.
        for other in decls:
            if other['file'] == d['file'] and other['name'] == 'Meta':
                meta_aliases[d['existing']].append(other)
        nodes.pop(d['existing'], None)
        rekeyed.append({'old': d['existing'], 'new': d['id'], 'file': d['file'], 'line': d['line']})
    if not d['existing'] or d['name'] == 'Meta':
        if d['id'] in nodes:
            n = nodes[d['id']]
            assert n['source_file'] == d['file']
            n.setdefault('additional_declaration_locations', []).append(f"L{d['line']}")
            multi.append(d)
        else:
            nodes[d['id']] = {'id': d['id'], 'label': d['name'], 'file_type': 'code',
                              'source_file': d['file'], 'source_location': f"L{d['line']}",
                              'qualified_name': '.'.join(d['scope'] + [d['name']]),
                              '_origin': 'fresh_python_standard_ast', '_callable': True,
                              '_callable_class': d['kind'] == 'ClassDef'}
            if not d['existing']:
                added.append(d)

unresolved = []
for edge in edges:
    match = re.match(r'L(\d+)', str(edge.get('source_location', '')))
    line = int(match.group(1)) if match else None
    for endpoint in ['source', 'target']:
        old = edge[endpoint]
        if old not in conflict_aliases:
            continue
        choices = conflict_aliases[old]
        exact = [d for d in choices if d['file'] == edge.get('source_file') and line == d['line']]
        enclosing = [d for d in choices if d['file'] == edge.get('source_file') and line is not None and d['line'] <= line <= d['end']]
        selected = exact or (enclosing if endpoint == 'source' else [])
        if len(selected) == 1:
            edge[endpoint] = selected[0]['id']
        else:
            alias = old + '_unresolved_normalized_reference'
            nodes[alias] = {'id': alias, 'label': 'Unresolved normalized identifier reference',
                            'file_type': 'concept', 'source_file': choices[0]['file'],
                            'source_location': edge.get('source_location'),
                            'resolution_status': 'ambiguous_static_reference_not_runtime_binding',
                            'candidate_nodes': sorted({d['id'] for d in choices}),
                            '_origin': 'fresh_python_standard_ast_reconciliation'}
            edge[endpoint] = alias
            edge.update(original_relation=edge['relation'], relation='references_unresolved',
                        confidence='AMBIGUOUS', confidence_score=.2)
            unresolved.append({'file': edge.get('source_file'), 'line': line, 'alias': alias})
    for endpoint in ['source', 'target']:
        original = edge[endpoint]
        if original not in meta_aliases:
            continue
        choices = meta_aliases[original]
        exact = [d for d in choices if d['file'] == edge.get('source_file') and line == d['line']]
        enclosing = [d for d in choices if d['file'] == edge.get('source_file') and line is not None and d['line'] <= line <= d['end']]
        parent = [d for d in choices if d['parent'] == edge.get('source')]
        selected = exact or enclosing or parent
        if len(selected) == 1:
            edge[endpoint] = selected[0]['id']
        else:
            alias = original + '_unresolved_lexical_reference'
            nodes[alias] = {'id': alias, 'label': 'Unresolved nested Meta reference',
                            'file_type': 'concept', 'source_file': choices[0]['file'],
                            'source_location': edge.get('source_location'),
                            'resolution_status': 'ambiguous_static_reference_not_runtime_binding',
                            'candidate_nodes': sorted({d['id'] for d in choices}),
                            '_origin': 'fresh_python_standard_ast_reconciliation'}
            edge[endpoint] = alias
            edge.update(original_relation=edge['relation'], relation='references_unresolved',
                        confidence='AMBIGUOUS', confidence_score=.2)
            unresolved.append({'file': edge.get('source_file'), 'line': line, 'alias': alias})

file_ids = {n['source_file']: n['id'] for n in nodes.values()
            if n.get('label') == Path(n.get('source_file', '')).name and n.get('file_type') == 'code'}
for d in decls:
    parent = d['parent'] or file_ids[d['file']]
    assert parent in nodes and d['id'] in nodes
    nodes[d['id']].setdefault('qualified_name', '.'.join(d['scope'] + [d['name']]))
    edges.append({'source': parent, 'target': d['id'], 'relation': 'defines',
                  'confidence': 'EXTRACTED', 'confidence_score': 1.0,
                  'source_file': d['file'], 'source_location': f"L{d['line']}",
                  'weight': 1.0, '_origin': 'fresh_python_standard_ast'})

# Flat public/private spellings can collapse in the upstream normalization.
# Mark affected edges explicitly rather than asserting a runtime binding.
groups = collections.defaultdict(list)
for d in decls:
    groups[(d['file'], tuple(d['scope']), d['name'].strip('_'))].append(d)
collisions = [ds for ds in groups.values() if len({d['name'] for d in ds}) > 1]
collision_ids = {d['id']: ds for ds in collisions for d in ds}
for edge in edges:
    if edge.get('_origin') == 'fresh_python_standard_ast':
        continue
    if edge.get('target') in collision_ids:
        ds = collision_ids[edge['target']]
        edge['lexical_resolution_status'] = 'public_private_normalization_collision_not_runtime_verified'
        edge['candidate_nodes'] = sorted({d['id'] for d in ds})
        edge['confidence'] = 'AMBIGUOUS'
        edge['confidence_score'] = .2

result = {**raw, 'nodes': list(nodes.values()), 'edges': edges}
(work / 'fresh-ast-completed.json').write_text(json.dumps(result, ensure_ascii=False))
proof = {'state': 'FRESH_PYTHON_DEFINITIONS_RECONCILED_NOT_FINAL_GRAPH',
         'python_declarations': len(decls), 'added_missing_declarations': len(added),
         'qualified_meta_rekeys': rekeyed, 'multiple_declaration_locations': multi,
         'normalization_rekeys': normalization_rekeys,
         'unresolved_meta_references': unresolved,
         'public_private_name_collisions': collisions,
         'nodes': len(nodes), 'edges': len(edges),
         'limits': ['Graphify raw AST retained as original evidence',
                    'Static imports/calls are not runtime binding proofs',
                    'Ambiguous public/private resolutions explicitly marked, not guessed',
                    'External references still require materialization/classification']}
(work / 'python-definition-reconciliation.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({k: proof[k] for k in ['state', 'python_declarations', 'added_missing_declarations', 'nodes', 'edges']}))
