"""Audit exact N01A cases, freeze identity, terminal state and owned cleanup."""
import collections,hashlib,json,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
W=Path('artifacts/recorridos-n01-20261025');RUN=Path('artifacts/local-ci/20261025-081326-9844f827');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
freeze=json.loads((W/'freeze.json').read_text());report=json.loads((RUN/'result.json').read_text());runner=json.loads((RUN/'runner.json').read_text())
assert report['result']=='PASS' and report['sources_unchanged']
assert all(s['exit']==0 for s in report['steps']) and report['workers']==1
for p,h in freeze['product_sha256'].items():assert sha(p)==h,p
for p,h in freeze['document_and_graph_sha256'].items():assert sha(p)==h,p
expected=set(freeze['selected']);cases=list(ET.parse(RUN/'pytest.xml').getroot().iter('testcase'))
assert len(cases)==2;actual=set();measure=[]
for c in cases:
 node=c.get('file')+'::'+c.get('name');actual.add(node)
 assert c.find('failure') is None and c.find('error') is None and c.find('skipped') is None
 props={p.get('name'):p.get('value') for p in c.findall('./properties/property')}
 assert props['http_status']=='200' and int(props['dataset_published']) in (10,100)
 assert float(props['http_seconds_instrumented'])>0 and int(props['sql_queries'])>0
 measure.append({'nodeid':node,'published':int(props['dataset_published']),'request_seconds_instrumented':float(props['http_seconds_instrumented']),'sql_queries':int(props['sql_queries']),'junit_case_seconds_including_fixture':float(c.get('time')),'scope':props['scope']})
assert actual==expected
journal=[json.loads(line) for line in (RUN/'pytest-reports.jsonl').read_text().splitlines()]
assert len(journal)==6 and {r['nodeid'] for r in journal}==expected
for node in expected:
 events=[r for r in journal if r['nodeid']==node];assert {r['when'] for r in events}=={'setup','call','teardown'} and all(r['outcome']=='passed' for r in events)
for name,row in report['cleanup'].items():
 assert row['absent']
 inventory=subprocess.run(['docker','container','inspect','--format','{{.Id}}',name],capture_output=True,text=True)
 assert inventory.returncode and 'no such' in (inventory.stdout+inventory.stderr).lower()
assert not Path(runner['temporary']).exists()
assert json.loads((RUN/'telegram-notification.json').read_text())['delivery']=='sent'
result={'result':'PASS_N01A_AUDIT','run':str(RUN),'pass':2,'fail':0,'error':0,'skip':0,'selected_nodeids':sorted(expected),'measurements':measure,'pytest_step_seconds':next(s['seconds'] for s in report['steps'] if s['name']=='pytest'),'frozen_executable_sources_unchanged':len(freeze['product_sha256']),'frozen_documents_and_graph_unchanged_before_audit':True,'owned_containers_absent':True,'temporary_absent':True,'terminal_telegram_delivery':'sent','product_changes':0,'N01_complete':False,'N04_complete':False,'before_after_candidate_comparison':'not_applicable_no_candidate_change; differing populations and order/cache can confound comparison','limits':['One instrumented request per population, no percentile or20RPS/TCP/capacity claim','SQL52/29 and time difference are observations, not causal optimization','Fixture/setup/runner duration differs from application request time','Only organic initialES listing; promotions/filters/deep pages/EN/detail and othergroups remain pending'],'original_sha256':{p.name:sha(p) for p in RUN.iterdir() if p.is_file() and p.suffix in ('.json','.jsonl','.xml','.log')},'freeze_sha256':sha(W/'freeze.json')}
Path('docs/evidencias/n01-a-diagnostico-auditoria-20261025.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
