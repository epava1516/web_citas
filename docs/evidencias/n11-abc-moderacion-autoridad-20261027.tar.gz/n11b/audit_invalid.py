import hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
sys.path.insert(0,'scripts')
from run_local_ci import hashes
W=Path('artifacts/recorridos-n11-20261026/n11b');load=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=load(W/'freeze.json');im=load(W/'runtime-images.json');P=Path('artifacts/local-ci')/im['run'];r=load(P/'result.json');now=hashes();assert set(now)==set(f['sources'])
changed=[p for p,h in f['sources'].items()if now[p]!=h];assert changed==['AGENTS.md'],changed
assert r['result']=='INVALID' and not r['sources_unchanged']
for group in ['extra_sources','docs']:
 for p,h in f[group].items():assert sha(p)==h,p
assert all(im[k]for k in ['matched_actual_runner_pid_and_start_ticks','all_observed','match_prelaunch_freeze'])
for name,row in r['cleanup'].items():
 assert row['absent']and row['removal_exit']==0
 assert subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0
assert not Path(load(P/'runner.json')['temporary']).exists()
tg=load(P/'telegram-notification.json');assert tg['delivery']=='sent'and tg['result']=='INVALID'
rows=[]
for c in ET.parse(P/'pytest.xml').iter('testcase'):
 d=json.loads(next(x for x in c.iter('property')if x.get('name')=='n11b_native_image_authority_wait').get('value'))
 assert all(d[k]for k in ['actual_wait','initial_allowed','actor_matches','request_permission_initial','all_rows_unchanged','files_unchanged','worker_connections_closed','streaming','image_bytes_match','private_no_store'])
 assert d['effective_permission_after']is(not d['revoke'])and d['http_status']==200 and d['derivative_bytes_returned']>0 and d['installed_models']==173
 rows.append({'case':c.get('name'),'JUnit_case_result':'FAIL'if c.find('failure')is not None else'PASS','observed':d})
assert len(rows)==6 and sum(x['JUnit_case_result']=='PASS'for x in rows)==3
proof={'result':'INVALID_RUN_RETAINED_WITH_PRIVATE_READ_OBSERVATIONS_NOT_ACCEPTED_QA','run':P.name,'runner_result':'INVALID','JUnit_counts_observed':{'PASS':3,'FAIL':3,'ERROR':0,'SKIP':0},'junit_seconds':sum(float(s['time'])for s in r['junit']),'source_count':len(f['sources']),'changed_source_only':changed,'source_change_before':f['sources']['AGENTS.md'],'source_change_after':now['AGENTS.md'],'app_and_instrument_sources_stable':True,'cases':rows,'actual_JUnit_sha256':sha(P/'pytest.xml'),'cleanup_verified':True,'telegram':tg,'limits':'No conversion of INVALID to PASS; observed three revoked reads deliver actual derivative under unchanged code, while lateral instruction update breaks whole source freeze. Candidate must have a new stable freeze.'}
(W/'invalid-audit.json').write_text(json.dumps(proof,indent=2));(W/'baseline-instrument.py').write_bytes(Path('tests/test_moderation_image_authority_wait.py').read_bytes());print(json.dumps({k:v for k,v in proof.items()if k!='cases'}))
