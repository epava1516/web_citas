import ast,hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
sys.path.insert(0,'scripts')
from run_local_ci import hashes
W=Path('artifacts/recorridos-n11-20261026/n11c');load=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=load(W/'freeze.json');im=load(W/'runtime-images.json');P=Path('artifacts/local-ci')/im['run'];r=load(P/'result.json')
assert r['result']=='PASS' and r['sources_unchanged'] and r['selection']==f['selection'] and r['workers']==1
assert hashes()==f['sources']==load(P/'source-hashes.json')
for group in ['extra_sources','docs']:
 for p,h in f[group].items():assert sha(p)==h,p
assert all(im[k]for k in ['matched_actual_runner_pid_and_start_ticks','all_observed','match_prelaunch_freeze'])
for name,row in r['cleanup'].items():
 assert row['absent']and row['removal_exit']==0
 assert subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0
assert not Path(load(P/'runner.json')['temporary']).exists()
tg=load(P/'telegram-notification.json');assert tg['delivery']=='sent'and tg['result']=='PASS'
cases=list(ET.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==30
observations={'POST':[],'image':[],'variants':[]};ordinary=[]
for c in cases:
 assert all(c.find(k)is None for k in ['failure','error','skipped'])
 props={v.get('name'):v.get('value')for v in c.iter('property')}
 found=False
 for key,label in [('n11a_native_authority_wait','POST'),('n11b_native_image_authority_wait','image'),('n11c_native_review_authority_variants','variants')]:
  if key not in props:continue
  d=json.loads(props[key]);assert d['actual_wait']and d['files_unchanged']and d['worker_connections_closed']and d['installed_models']==173
  if label=='POST':
   assert d['http_status']==(403 if d['revoke'] else 302)
   assert d['full_snapshot_no_effect']if d['revoke']else d['exact_native_effect']
   assert d['effective_permission_after']is(not d['revoke'])
  elif label=='image':
   assert d['all_rows_unchanged']and d['private_no_store']and d['http_status']==(403 if d['revoke'] else 200)
   assert (not d['streaming']and not d['image_bytes_match']and d['derivative_bytes_returned']==0)if d['revoke']else(d['streaming']and d['image_bytes_match']and d['derivative_bytes_returned']>0)
  else:assert d['http_status']==403 and d['all_rows_unchanged']and d['intervention_verified']
  observations[label].append({'case':c.get('name'),'observed':d});found=True
 if not found:ordinary.append(c.get('classname')+'::'+c.get('name'))
assert {k:len(v)for k,v in observations.items()}=={'POST':4,'image':6,'variants':13}and len(ordinary)==7
assert {r['observed']['mode']for r in observations['variants']}=={'group_permission','account_epoch','mfa_epoch','inactive','erased','final_target_permission','pending_sibling_permission'}
assert Path('tests/test_moderation_image_authority_wait.py').read_bytes()==Path('artifacts/recorridos-n11-20261026/n11b/baseline-instrument.py').read_bytes()
# The root-selected predicate/role controls remain the same in the POST instrument.
old=Path('artifacts/recorridos-n11-20261026/n11a/baseline-instrument.py').read_text();new=Path('tests/test_moderation_authority_wait.py').read_text()
for line in ['assert code == (403 if revoke else 302)','assert none if revoke else effect','effective_permission_after=User.objects.get(pk=actor.pk).has_perm("listings.review_listing")']:
 assert line in old and line in new
for p,v in load(W/'lateral-before-candidate.json')['paths'].items():assert not Path(p).exists()if v.get('absent')else sha(p)==v['sha256'],p
proof={'result':'PASS_SCOPED_N11C_MODERATION_CANDIDATE30_NOT_N11_ACCEPTANCE','run':P.name,'counts':{'PASS':30,'FAIL':0,'ERROR':0,'SKIP':0},'junit_seconds':sum(float(s['time'])for s in r['junit']),'source_count':len(f['sources']),'sources_stable':True,'actual_JUnit_sha256':sha(P/'pytest.xml'),'observations':observations,'ordinary_cases':ordinary,'actual_PG_waits':23,'denied_after_wait':18,'valid_wait_controls':5,'all_models_and_files_scoped_oracles':True,'image_instrument_byteidentical_to_original':True,'original_POST_negative_expectations_preserved':True,'original_A_and_INVALID_B_retained':True,'lateral_paths_preserved':16,'cleanup_verified':True,'telegram':tg,'limits':['Synthetic admitted sessions not new password/TOTP ceremony','Induced QA timings not app performance or SLA','INVALID image baseline retained, not relabeled valid','No universal revocation after last authority read, browser/load or provider claim','N11 common integration matrix/regression still pending; N02deferred,N12-N14conditioned,N15finalgraph/inventory/purge']}
(W/'candidate-audit.json').write_text(json.dumps(proof,indent=2));print(json.dumps({k:v for k,v in proof.items()if k not in ['observations','ordinary_cases']}))
