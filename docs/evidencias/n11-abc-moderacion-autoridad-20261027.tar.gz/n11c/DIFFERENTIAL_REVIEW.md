# Revisión diferencial N11C — candidata no aceptada

Riesgo HIGH, revisión quirúrgica del dominio de moderación y sus dependencias a un salto, recomendación CONDITIONAL pendiente de ejecución estable. Dos decisiones no autorizadas confirmadas en original válido; tres variantes de lectura observadas bajo runner INVALID, no QA aceptado. No seguridad general por ausencia de hallazgos. Se mantienen las garantías y las revisiones de bloques anteriores.

## Contexto y evidencia

Base1d2703d. La guarda inicial de decide procede de2955509c (3octubre), resolve de3e4710a1 (3octubre), exclusión del historial de derechos710c856f; no se presenta como regresión recién introducida. Ambas vistas exigen login, permiso y MFA antes del servicio; sus transacciones bloquean recursos después de admitir al actor. Ataque exige operador previamente autorizado y una espera concurrente: se retira review_listing durante espera Person, el User/caché anterior continúa y el POST302 escribe. No escalada desde anónimo ni acceso sin autorización inicial. N11A original66,291s1PASS3FAIL con código estable demuestra las dos decisiones; oráculoMatchpositivo incompleto se separa.

Lecturas review_photo y match image ambos lados: FileResponse abre el derivado tras locks sin nueva guarda. Las seis observaciones N11B muestran tres controles200 y tres revocados200 con bytes exactos, pero AGENTS.md cambió lateralmente y el runnerINVALID se conserva íntegro. No conversión a PASS ni testigo aceptado. App/instrumentos idénticos durante ese run; nueva candidata necesita freeze estable.

## Cambio y recorrido de autoridad

Cuatro archivos app. Moderation.reviewer_allowed reutiliza la guarda fresca existente appeal_authority con epochs de sesión/MFA y compatibilidad inicial0. require_current_reviewer recarga User/permiso efectivo sin cachés antiguas y compara cuenta/MFA/estadoactivo/noerased con el User admitido, conservando firma de servicios. Guardas antes y después de los locks del target; aprobación adquiere también los locks de revisiones pending antes del primer write y vuelve a validar autoridad después. Se conserva orden agencia→persona→listing→revision y se ordenan siblings; no lockUser nuevo que invierta referencias de dominio. No supuesto de revocación linealizable posterior a la última lectura.

Lecturas nativas revalidan request/session después de locks y antes de abrir almacenamiento. No debilitan conflicto de interés, finalidad, historial de derechos, validación de bytes o estados. No cambio de modelos, migraciones, settings, servicios ni dependencias. El hash de moderation forma parte de RULE_SOURCES; el refresco versionado existente continúa vigente. No afirmar misma versión de proyección entre productos diferentes.

## Oráculo y cobertura

Original de POST preservado byte a byte en n11a/baseline-instrument.py. Reparación positivaMatch sólo contempla efecto nativo esperado de PublicationState al perder elegibilidad: eligible/checksFalse y computed_at dentro de la petición; los demás campos/modelos siguen exactos. Se añaden nombres de campos cambiados sin valores privados. Negativo403 y cero efectos no se relaja. Si el supuesto no cuadra, conservar FAIL y revisar oráculo, sin parche de app para contentarlo.

Selección30: originalesPOST4, originalesimagen6 bajo nuevo freeze, trece variantes (permiso de grupo, epochs cuenta/MFA, inactivo/erased y waits finales de target para cada servicio; siblingpending de aprobación), cinco originales de aprobación/prerrequisitos y dos de resolución/COI/bytes exactos. Todas las esperas deben acreditarse con PostgreSQL real, PID distinto y pg_blocking_pids; no sleep o autoridad simulada. Snapshots todos los modelos/through y archivos. QA no es latencia. Falta ejecutar: ni propuesta ni Ruff acreditan autorización runtime.

## Variantes y alcance

Calibración: check de review_listing antes de lockPerson en las dos decisiones. Generalización única a reviewer_allowed anterior a locks de los mismos módulos encuentra tres lectores. Apelaciones listing/photo tienen guard fresco tras el último lock y testigos Q previos; no nuevos fallos. Colas sin ese wait no se declaran vulnerables por nombre. Se trazan sólo los handlers afectados y autoridad compartida, no un escaneo activo ni una auditoría universal.

## Radio y límites

Sitios estáticos de llamadas relevantes de listings, contados desde AST actual:

- apps/listings/appeals.py:92: reviewer_allowed
- apps/listings/appeals.py:108: reviewer_allowed
- apps/listings/appeals.py:127: reviewer_allowed
- apps/listings/match_review.py:75: require_current_reviewer
- apps/listings/match_review.py:77: require_current_reviewer
- apps/listings/match_views.py:90: reviewer_allowed
- apps/listings/match_views.py:105: reviewer_allowed
- apps/listings/match_views.py:139: reviewer_allowed
- apps/listings/match_views.py:150: reviewer_allowed
- apps/listings/match_views.py:117: resolve
- apps/listings/moderation.py:66: require_current_reviewer
- apps/listings/moderation.py:73: require_current_reviewer
- apps/listings/moderation.py:103: require_current_reviewer
- apps/listings/moderation_views.py:61: reviewer_allowed
- apps/listings/moderation_views.py:78: reviewer_allowed
- apps/listings/moderation_views.py:122: reviewer_allowed
- apps/listings/moderation_views.py:140: reviewer_allowed
- apps/listings/moderation_views.py:95: decide
- apps/listings/photo_appeals.py:20: reviewer_allowed
- apps/listings/photo_appeals.py:39: reviewer_allowed
- apps/listings/photo_appeals.py:66: reviewer_allowed

Dos servicios productivos llamados desde sus dos vistas; imágenes en tres variantes de ruta. Las pruebas directas de decide/resolve y los usos de publicly_visible requieren conciliación de fuentes en N11 general. Esta revisión no sustituye regresión común de I01–I28, grafo final N15, inventario frontend o revisión externa. N02/MOD09 residual diferido, N12/B14,N13/B15,N14/B17 condicionados, QA general aplazado hasta primera versión estable/productiva; registro deuda-pendiente-viva leído tras actualización lateral. Alpha/noindex.
