import hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
sys.path.insert(0,'scripts')
from run_local_ci import hashes
W=Path('artifacts/recorridos-n11-20261026/n11a');load=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=load(W/'freeze.json');im=load(W/'runtime-images.json');P=Path('artifacts/local-ci')/im['run'];r=load(P/'result.json')
assert r['result']=='ERROR' and r['sources_unchanged'] and hashes()==f['sources']==load(P/'source-hashes.json')
assert all(im[k]for k in ['matched_actual_runner_pid_and_start_ticks','all_observed','match_prelaunch_freeze'])
for group in ['extra_sources','docs']:
 for p,h in f[group].items():assert sha(p)==h,p
for name,row in r['cleanup'].items():
 assert row['absent'] and row['removal_exit']==0
 assert subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0
assert not Path(load(P/'runner.json')['temporary']).exists()
tg=load(P/'telegram-notification.json');assert tg['delivery']=='sent'and tg['result']=='ERROR'
cases=list(ET.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==4
rows=[]
for c in cases:
 d=json.loads(next(x for x in c.iter('property')if x.get('name')=='n11a_native_authority_wait').get('value'))
 assert d['actual_wait'] and d['request_permission_initial'] and d['request_cache_warmed'] and d['request_actor_matches'] and d['worker_connections_closed'] and d['files_unchanged'] and d['installed_models']==173
 assert d['http_status']==302 and d['effective_permission_after'] is (not d['revoke'])
 rows.append({'case':c.get('name'),'result':'FAIL'if c.find('failure')is not None else'PASS','observed':d})
assert sum(r['result']=='PASS'for r in rows)==1 and sum(r['result']=='FAIL'for r in rows)==3
assert next(x['observed']for x in rows if x['observed']['surface']=='listing'and x['observed']['revoke'])['exact_native_effect']
assert not next(x['observed']for x in rows if x['observed']['surface']=='match'and not x['observed']['revoke'])['exact_native_effect']
proof={'result':'VERIFIED_ORIGINAL_2_REVOKED_POSTS_STILL302_AND_WRITES_PLUS_MATCH_CONTROL_ORACLE_GAP','run':P.name,'counts':{'PASS':1,'FAIL':3,'ERROR':0,'SKIP':0},'runner_result':'ERROR','source_count':len(f['sources']),'sources_stable':True,'actual_JUnit_sha256':sha(P/'pytest.xml'),'junit_seconds':sum(float(s['time'])for s in r['junit']),'cases':rows,'cleanup_verified':True,'telegram':tg,'scope':'listing revoked exact native effect confirmed; match revoked committed changes confirmed but full effect oracle incomplete; control match oracle gap distinct from product bug; no N11 acceptance'}
(W/'original-audit.json').write_text(json.dumps(proof,indent=2));(W/'baseline-instrument.py').write_bytes(Path('tests/test_moderation_authority_wait.py').read_bytes());print(json.dumps({k:v for k,v in proof.items()if k!='cases'}))
