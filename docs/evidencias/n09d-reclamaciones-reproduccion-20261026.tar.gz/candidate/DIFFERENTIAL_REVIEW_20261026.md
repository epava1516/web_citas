# N09D430 — revisión diferencial previa a runtime

Base f65a53061726fbb53e84c0231101bc5f24d0e4dd, candidato local sin commit. Riesgo del cambio ALTO: autorización, datos privados y efectos sobre publicación. Recomendación **CONDICIONAL / NO ACEPTADO**, pendiente de la selección117 y auditoría terminal. No es certificación de seguridad del repositorio.

## Alcance y resultado provisional

Revisados los cinco archivos de aplicación completos y el instrumento nuevo; conservados sin editar los dos instrumentos429 y el observador419. La comprobación independiente AST está en candidate-source-review.json. Funciones existentes fuera del alcance idénticas; no modelos, migraciones, servicios, dependencias ni configuración modificados por esta corrección. El diff reemplaza guardas de usuario potencialmente cacheado por consultas frescas y añade fronteras después de locks; no elimina requisitos de permiso ni MFA.

| Estado | Cantidad | Evidencia |
| --- | ---: | --- |
| Defectos previos confirmados |6|Baseline062847-a8dd3f53, seis FAIL, espera/revocación y efectos auditados por operación|
| Nuevas vulnerabilidades confirmadas en candidato |0|Revisión de fuente solamente; no conclusión de ausencia|
| Casos runtime del candidato pendientes |117|6esperas,44entradas negativas,4replays,63originales|
| Limitaciones materiales |3|Sin serialización universal; release original realmente restriction; resolución report no tiene diagnóstico429 propio|

## Cambio por archivo

- complaint_authority.py:L8: User nuevo sin cachés heredadas, activo/no borrado, MFA y epochs originales, permiso base y extras; request_actor:L24 añade epochs de sesión. Helper sin locks ni escrituras, sin contrato nuevo de sesión o autenticación.
- complaints.py:L234/L463: admisión actual de inspección/foto y repetición posterior al lock canónico antes de auditoría, descifrado o apertura de imagen; request.user fresco para source_permission. Sin cambios a submit, receipt, queue, action, resolve, formularios o decoradores existentes. Un revisor de intake sin privilegio de fuente puede leer intake; no recibe fotos ni evidence de la fuente.
- complaint_actions.py:L15: act captura epochs inmutables, refresca al entrar y tras locked. Unassign mantiene manage_complaint_assignment; reassess exige además resolve_complaint y mantiene source_permission después de bloqueo. Permitted y guardas de enlaces/versiones siguen vigentes; replay sólo después de autoridad actual.
- complaint_resolutions.py:L43: resolve requiere review_complaint+resolve_complaint actuales antes/después de locked; source_permission/COI posteriores usan actor nuevo. Helpers source_version/source_permission/resolve_report/resolve_listing idénticos. Se mantienen independencia de revisor, asignación, lectura completa, fuente actual, auditoría de todas las imágenes, redacción y no republicación.
- privacy_release.py:L29/L139/L209: cuatro permisos vigentes y estado/epochs en admisión y después del último lock Hold o Proposal/Hold. actor_check/current/source/review/form idénticos. Se conservan independencia del creador de la medida, propósito específico excluido, prueba compatible, notificación, ACK y comprobación posterior independiente, última propuesta/bindings y publicación pausada.

## Callers y alcance transitivo

Conteo AST de llamadas sintácticas: current_actor5 (dos act, dos resolve, una request_actor); request_actor4 (dos inspect, dos photo); current_release_actor4 (dos propose, dos execute). No se confunden estas13llamadas internas con13rutas o13pruebas.

Los seis entrypoints tienen un caller de producción directo cada uno: urls.py para inspect/photo; complaints.action para act; complaints.resolve como resolve_case para resolve; privacy_release.review para propose/execute. act cubre sus seis operaciones existentes; resolve deriva a fuentes listing/report/unidentified. Es alcance funcional compartido, razón de incluir los nueve módulos originales completos. current/source de privacy_release siguen importados por publication_purpose_calendar/publication_purpose_release: su AST permanece idéntico, sin nuevas comprobaciones ni cambio de contrato allí. Conteo estático limitado a resolución explícita de imports/callers de apps/config, no cobertura dinámica ni garantía de ausencia de invocaciones indirectas.

## Historia y guardas reemplazadas

Git blame sobre HEAD y regiones reemplazadas: complaint_actions guard base/asignación nació0990acc1; secuencia de lock de enlaces8b117140 y guard reassess dba21c91. Resolución347b677a, source permission/unidentified f69820b2. Foto enlazada y levantamiento pertenecen a sus módulos originales de octubre; guardas de privacidad/COI/ACK no se retiran. La localización5a8cb5b6 de inspección permanece en sus respuestas originales de entrada y COI; la nueva denegación tras refresh es Forbidden y conserva403/headers privados. No se restaura una guarda cacheada retirada por un arreglo anterior; se aplica el patrón fresh-user ya utilizado en N09A/B/C.

## Análisis adversarial

Atacante: operador inicialmente autorizado con sesión y permisos legítimos; petición ya admitida y bloqueada por otra transacción. El revocador puede retirar un permiso o invalidar cuenta/MFA/epochs durante la espera. Complejidad de explotación media por condición temporal y rol previo, impacto alto por datos privados o efectos editoriales. No requiere ausencia de autenticación.

Secuencia comprobada en baseline: admitir POST o GET; sostener lock canónico en conexión independiente; observar Lock y PID bloqueante; retirar permiso y confirmar antes de liberar; petición continúa con instancia/cache previos. Efectos concretos: acceso privado con auditoría,10.314bytes de imagen, asignación, resolución con avisos o levantamiento de cautela. No se afirma exposición de datos reales.

Candidato: User recién consultado tras bloqueo, epochs comparados con valores originales y todos los permisos de operación comprobados antes de efectos/replay. No se bloquea User; una revocación posterior a la última lectura no queda serializada universalmente. La selección exige403y snapshots intactos en los seis mismos escenarios, no sólo rollback final o falta de cambios.

IDOR y escalada: foto sigue limitada a revision del expediente enlazado y foto no eliminada, con blob listo y acceso intake de versiones actuales; foreign ID no se resuelve por queryset global. Reclamación conserva permitted con historial, sujeto/gestor y autor original; fuentes requieren privilegios distintos. Levantamiento restringe propuesta al expediente y medida a esa propuesta; conserva independiente creador, autor proponente y ACK/canal. No se otorgan roles ni se aceptan IDs como permiso.

## Pruebas y límites

Plan430 previo a freeze: seis instrumentos de espera originales intactos,44negativos de usuario/cache válidos con mutaciones ORM externas y cuatro replays tras ejecución legítima; snapshots de filas escalares con hashes, no payloads. Vistas negativas RequestFactory con sesión explícita: sin acreditación adicional de middleware/transporte/espera. Replays exigen PermissionDenied y referencia del efecto previo intacta. Los63originales incluyen uso legítimo, CSRF, COI, imágenes ajenas, versiones/replays, concurrencia e idiomas/móvil. Comprobación estática de enumeración válida, falta colección/runtime.

Fixture prepared(kind) de privacy_release fija restriction aunque sus etiquetas incluyan object/rectify: no editar ni presentar esas etiquetas como tres tipos cubiertos. Diagnóstico de resolución429 sólo listing; las regresiones originales de report son funcionales, no revocación concurrente adicional. Fuente de reassessment no adquiere locks adicionales; authorized_proof consumidor tampoco. Report resolution puede derivar a decisions.act con locks/guardas propios: no atribuir cobertura universal de esa rama.

## Recomendación y metodología

Mantener candidato sin aceptar hasta117PASSválidos, seis403con espera real, cero efectos en negativos, fuentes congeladas, limpieza y Telegram comprobados; analizar cualquier FAIL por separado sin recortar selección. Después tabla antes/después, evidencia y aceptación local acotada, sin cerrar N09completo139IDs por estos seis arreglos.

Revisión quirúrgica por riesgo sobre repositorio grande: lectura antes/después, AST de entidades intactas, git blame, callers, flujo de datos/locks, modelo de atacante y revisión de oráculos. Skills django-expert/reviewer, django-access-review, security-review adaptada a autenticados, variant-analysis y differential-review; code-security/race-condition leído, sus ejemplos de temporales no constituyen una receta para autorización. Sin Semgrep/Bandit/pip-audit/Gitleaks escaneando el proyecto, sin MCP Semgrep expuesto, sin solicitudes remotas ni nuevos gatesCI. Instalación lateral preservada sin staging. Confianza alta en los seis defectos originales, provisional en candidato hasta runtime; ninguna inferencia de seguridad total por cero hallazgos nuevos.
