"""Bounded AST delta; preserve existing runner graph through insertion-only reanchoring."""
import ast, collections, copy, difflib, hashlib, json, re, shutil
from pathlib import Path
W=Path('artifacts/recorridos-n01-d-20261025'); B=W/'instrument-graph-base'; S=W/'instrument-graph'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
if not B.exists():shutil.copytree('graphify-out',B)
assert not S.exists();shutil.copytree(B,S)
g=json.loads((B/'graph.json').read_text());m=json.loads((B/'SOURCE_MANIFEST.json').read_text())
nodes={n['id']:copy.deepcopy(n) for n in g['nodes']};edges=copy.deepcopy(g['links'])
runner='scripts/run_local_ci.py';old=(W/'runner-before.py').read_text();new=Path(runner).read_text()
assert sha(W/'runner-before.py')==m[runner]['sha256']
line_map={};ops=difflib.SequenceMatcher(a=old.splitlines(),b=new.splitlines(),autojunk=False).get_opcodes()
assert all(op in ('equal','insert') for op,*_ in ops)
for op,a,b,c,d in ops:
 if op=='equal':line_map.update({i+1:c+i-a+1 for i in range(a,b)})
assert len(line_map)==len(old.splitlines())
def signature(text):
 return [(n.name,ast.dump(n.args)) for n in ast.walk(ast.parse(text)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
assert signature(old)==signature(new)
reanchored=collections.Counter()
for kind,rows in [('nodes',nodes.values()),('relations',edges)]:
 for row in rows:
  if row.get('source_file')!=runner:continue
  loc=row.get('source_location');match=re.fullmatch(r'L(\d+)(?:-L?(\d+))?',loc or '')
  assert match,(kind,row)
  lo,hi=int(match[1]),int(match[2] or match[1]);assert lo in line_map and hi in line_map
  row['source_location']='L'+str(line_map[lo])+('-L'+str(line_map[hi]) if match[2] else '')
  reanchored[kind]+=1
m[runner].update(sha256=sha(runner),bytes=Path(runner).stat().st_size,input_sha256=sha(runner),revision_reconciliation='insertion_only_line_mapping; existing graph identities and relationships preserved')
raw=json.loads((W/'instrument-ast.json').read_text());assert not raw['failed_sources']
added=['scripts/http_operation_metrics.py','tests/test_http_operation_metrics.py'];norm=lambda s:re.sub('[^a-z0-9]+','_',s.lower()).strip('_')
for p in added:
 assert p not in m
 m[p]={'sha256':sha(p),'bytes':Path(p).stat().st_size,'category':'code','input_path':str(Path(p).resolve()),'input_sha256':sha(p),'semantic_scope':'AST_full_source_not_semantic_read_claim','extraction_origin':'fresh_graphify_n01d_instrument_AST'}
 fileid='file_'+norm(p);nodes[fileid]={'id':fileid,'label':p,'source_file':p,'source_location':'L1','file_type':'code','extraction_origin':'declared_corpus_manifest'}
 ns=[n for n in raw['nodes'] if n.get('source_file')==p]
 for f in ast.walk(ast.parse(Path(p).read_text())):
  if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef)):
   assert any(n.get('_callable') and n['label']==f.name+'()' and n['source_location']=='L'+str(f.lineno) for n in ns),(p,f.name)
 for n in ns:
  assert n['id'] not in nodes;n=copy.deepcopy(n);n['extraction_origin']='fresh_graphify_n01d_instrument_AST';nodes[n['id']]=n
  edges.append({'source':fileid,'target':n['id'],'relation':'has_extracted_entity','confidence':'EXTRACTED','confidence_score':1.0,'source_file':p,'source_location':n['source_location'],'weight':1.0})
for e in raw['edges']:
 if e.get('source_file') not in added:continue
 e=copy.deepcopy(e)
 for k in ('source','target'):
  ident=e[k]
  if ident in nodes:continue
  matches=[i for i,n in nodes.items() if n.get('external') and n.get('label')==ident]
  target=matches[0] if len(matches)==1 else 'n01d_reference_'+norm(ident)
  nodes.setdefault(target,{'id':target,'label':ident,'source_file':None,'source_location':None,'file_type':'concept','external':True,'resolution_status':'unresolved_static_reference_not_runtime_binding'})
  e[k]=target
 e['extraction_origin']='fresh_graphify_n01d_instrument_AST';edges.append(e)
line=next(i for i,l in enumerate(new.splitlines(),1) if 'command.extend(["-p", "scripts.http_operation_metrics"])' in l)
edges.append({'source':'file_'+norm(runner),'target':'file_'+norm(added[0]),'relation':'references','source_file':runner,'source_location':'L'+str(line),'confidence':'EXTRACTED','confidence_score':1.0,'evidence':'scripts.http_operation_metrics','weight':1.0})
a=json.loads((B/'.graphify_analysis.json').read_text());com={int(k):v for k,v in a['communities'].items()};labels={int(k):v for k,v in json.loads((B/'.graphify_labels.json').read_text()).items()};assigned={i for v in com.values() for i in v};cid=max(com)+1;com[cid]=sorted(set(nodes)-assigned);labels[cid]='Observación HTTP sintética'
for c,ids in com.items():
 for i in ids:nodes[i].update(community=c,community_name=labels[c])
pairs=collections.Counter()
for e in edges:
 assert all(e[k] in nodes for k in ('source','target'));p=(e['source'],e['target']);e['key']=pairs[p];pairs[p]+=1
g.update(nodes=list(nodes.values()),links=edges);g['graph'].update(corpus_files=len(m),structural_sources=g['graph']['structural_sources']+2,extraction_scope='N01D two fresh instrument ASTs and insertion-only runner reconciliation; prior semantic context preserved')
for name,value in [('graph.json',g),('SOURCE_MANIFEST.json',m),('.graphify_analysis.json',{'communities':com}),('.graphify_labels.json',labels)]: (S/name).write_text(json.dumps(value,ensure_ascii=False,indent=2))
product=json.loads(Path('docs/evidencias/b16-final-candidate-reconciliation-20261025.json').read_text())['current_versioned_executable_sources']
assert sha(W/'runner-before.py')==product[runner]
for p,h in product.items():
 if p!=runner:assert sha(p)==h,p
for p,r in m.items():assert sha(p)==r['sha256'],p
proof={'state':'SCOPED_AST_DELTA_VERIFIED','changed_sources':[runner,*added],'semantic_changed_sources':[],'old_graph_sha256':sha(B/'graph.json'),'runner_old_sha256':sha(W/'runner-before.py'),'runner_new_sha256':sha(runner),'runner_reanchored':dict(reanchored),'accepted_existing_sources_unchanged':1506,'runner_measurement_variant':1,'source_files':len(m),'nodes':len(nodes),'relations':len(edges),'communities':len(com),'scope':'Two new instrument ASTs, fresh runner AST archived, existing runner graph preserved with insertion-only location mapping. Prior native semantic context retained. No new semantic extraction and no application behavior acceptance.','native_token_usage':None}
(W/'instrument-graph-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
