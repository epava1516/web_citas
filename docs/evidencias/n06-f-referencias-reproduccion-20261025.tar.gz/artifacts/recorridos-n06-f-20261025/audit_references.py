import hashlib,json,math,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n06-f-20261025');RUN='20261025-162605-8a2766fc';P=Path('artifacts/local-ci')/RUN

def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=read(W/'freeze.json');r=read(P/'result.json');assert r['result']=='PASS' and r['sources_unchanged'] and r['workers']==1 and r['observe_http_operations'];assert r['selection']==f['selection']
assert len(r['junit'])==1 and r['junit'][0]['tests']=='12' and all(r['junit'][0][k]=='0' for k in ['errors','failures','skipped'])
mismatch=[p for p,h in f['sources'].items() if not Path(p).is_file() or sha(p)!=h];assert not mismatch,mismatch
cases=[];allowed={'method','route_name','status','request_seconds_instrumented','sql_queries','sql_execute_seconds','exception_class','observer_error_class'}
for c in E.parse(P/'pytest.xml').iter('testcase'):
 assert not any(c.findall(k) for k in ['failure','error','skipped']);props={p.attrib['name']:p.attrib['value'] for p in c.iter('property')};samples=json.loads(props['http_operation_samples']);assert len(samples)==int(props['http_operation_count']) and samples
 for ordinal,s in enumerate(samples,1):
  assert set(s)==allowed and s['exception_class'] is None and s['observer_error_class'] is None
  assert isinstance(s['sql_queries'],int) and s['sql_queries']>=0
  assert all(math.isfinite(s[k]) and s[k]>=0 for k in ['request_seconds_instrumented','sql_execute_seconds'])
  s['ordinal']=ordinal
 cases.append({'module':c.attrib['classname'],'case':c.attrib['name'],'qa_seconds':float(c.attrib['time']),'samples':samples})
assert len(cases)==12
inventory={}
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];q=subprocess.run(cmd+['--filter',f'label=web-modelos-local-ci-run={RUN}'],capture_output=True,text=True,check=True);inventory[kind]=q.stdout.split();assert not inventory[kind]
runner=read(P/'runner.json');assert not Path(runner['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
prior=read('docs/evidencias/n06-e-conciliacion-acciones-20261025.json');new_actions=[]
for a in prior['actions']:
 route=a['id'].removeprefix('route:R_');observations=[{'case':c['module']+'::'+c['case'],**s} for c in cases for s in c['samples'] if a['kind']=='route' and s['route_name']==route]
 new_actions.append({'id':a['id'],'kind':a['kind'],'prior_scoped_measurement':bool(a['performance_references']),'new_samples':observations,'measurement_now_available':bool(a['performance_references']) or bool(observations)})
counts={'actions':len(new_actions),'HTTP':sum(a['kind']=='route' for a in new_actions),'routes_with_some_reference':sum(a['kind']=='route' and a['measurement_now_available'] for a in new_actions),'routes_without_reference':sum(a['kind']=='route' and not a['measurement_now_available'] for a in new_actions),'newly_referenced_routes':sum(a['kind']=='route' and not a['prior_scoped_measurement'] and bool(a['new_samples']) for a in new_actions),'observed_requests':sum(len(c['samples']) for c in cases),'unresolved_route_samples':sum(s['route_name']=='unresolved' for c in cases for s in c['samples'])}
out={'result':'PASS_N06F_SCOPED_REFERENCE_NOT_N06_CLOSURE','run':RUN,'junit':r['junit'],'junit_sha256':sha(P/'pytest.xml'),'head':f['head'],'source_count':len(f['sources']),'source_mismatches':mismatch,'selection':f['selection'],'counts':counts,'cases':cases,'action_updates':new_actions,'independent_inventory':inventory,'temporary_absent':True,'terminal_telegram':tg,'steps':[{k:v for k,v in x.items() if k!='command'} for x in r['steps']],'native_manifest':read(P/'native-manifest.json'),'scope':'Current original Client-call reference, synthetic fixtures and single observations per transition. Normal setup/direct services/Playwright/other processes not timed; no app candidate,p95,provider or block closure.'}
(W/'references-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(counts);print('REMAINING',[a['id'] for a in new_actions if a['kind']=='route' and not a['measurement_now_available']]);print('CASES',[(c['case'],len(c['samples'])) for c in cases])
