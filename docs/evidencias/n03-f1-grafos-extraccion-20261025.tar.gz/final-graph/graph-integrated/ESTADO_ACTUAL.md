# Grafo alfa — N03F1 límite de generaciones corregido; N03 abierto

3/13 bloques aceptados. F1: referencia 8FAIL/3PASS preservada; candidata49PASS. Guardia por Blob bajo bloqueo antes de I/O, agotados4/5 conservados failed; cuarto intento, lease vigente y comparación ready válidos. Otro mensaje real ACK conserva failed4 sin retry. F2 crecimiento histórico y acta por acción pendientes. MOD09 restante diferido al final; no optimización marginal. Alfa.

Semántica focal388/390/341/README/vista17 primeras4 líneas; AST candidato process y driver: 1997 fuentes, 18868 nodos/81860 relaciones, 900 comunidades. 1501 fuentes ejecutables originales y6 variantes documentadas; nueva variante de process encadenada a D. Tokens nativos desconocidos. Sin reconstrucción global, semántica exhaustiva ni prueba independiente de runtime.

