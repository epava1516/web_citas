import copy,hashlib,json
from pathlib import Path
W=Path('artifacts/recorridos-n07-c-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
census=read('artifacts/recorridos-n07-a-20261025/census.json');native=read('artifacts/recorridos-n07-a-20261025/inventory-review.json');reuse=read(W/'reuse-verification.json')
# Tuple: docs, selected modules, precise group disposition, retained owners.
spec={
'G1':('405 407','test_lifecycle','Lifecycle13 históricos/HTTP N01D; expiry real nativa60s/guardas durante retraso N07B. Complemento cancelación2ESEN pendiente terminal válido. Calendario no SLA.','N07; exposición comercial N08'),
'G2':('407','test_listing_moderation','Cola/formulario ESEN por estado, aprobación exacta/rechazo concurrente/autoridad actuales C16 más originales conciliados; sin tiempo humano o crecimiento100.','N07; derechos N09'),
'G3':('407','test_appeals','Cola antes/open/terminal y formulario ESEN; submit idempotente/revisión independiente, sin publicación automática.','N07; derechos N09'),
'G4':('407','test_match_review test_photo_appeals test_photo_restrictions test_match_dependency_edges','Pares recíprocos/distinct_people/conflicto/permiso/imágenes/apelación/restricción privadas: C16 y originales conciliados. FileResponse sólo handler; N05 conserva cuerpo.','N03/N07; derechos N09; transporte N05/N10'),
'G5':('393 399 402','','Reorder/remove2FAIL500 originales y4PASS correctivo404/autoridad/browser; otras funciones AST idénticas. Upload/productor N03 y privados/sondeos/browser N05. Dos IDs dispatch son mismo productor/lambda, no dos muestras.','N07 gestión; N03 productor; N05 navegador'),
'G6':('393','test_preparation_cleanup','N03 aceptado: global4generaciones,3retries sóloOSError, leases/ready/retención, prefork2restringido/Beat60;49PASS y F2retención3PASS separados. No repetir por pertenecer a N07.','N03/N07; retención/purga N09'),
'G7':('405','test_publication_state test_publication_state_matrix test_publication_dirty_census test_publication_pending_batch test_publication_projection_lifecycle test_publication_refresh_rollback test_publication_refresh_lock_order test_listing_expiry_dispatch test_publication_migration_signal','N07B7SUCCESSreales/rolrestringido/Beat30refresh60expiry/18GETESEN/102filasnativasporfase. Bulk/rawSQL/postcommit/rollback/locks/M2Mreal con puentehistórico limitado. Sweepmanual no prueba3600s.','N07; N11 integración'),
'G8':('393 399','test_media_erasure test_preparation_cleanup','Cinco erasure históricos fuentesconciliadas/once preparation_cleanup actuales F1/lectura privada N05. Wrappers semánticamente intactos; negativos retenidos/referentes y concurrencia acotada. Backlog/purga física operativa general N09/N10; sin proveedor/SLA.','N07 consumer/wrapper; N09/N10 retención/purga/operación'),
'G9':('377 405','test_beta_urgent_withdrawal','Retirada urgente2originales PASS/fuente exacta más guardas N07B; runbook no endpoint/tiempo. Callback cuenta aceptadoN06 no tiempofotográfico; mailreal N10/N12.','N07; cuenta N06/operación N09/transporte N10/N12 condicionado')}
rows=[];groups=[]
for g in native['RECOMMENDATIONS']:
 if 'group' not in g:continue
 key=g['group'].split()[0];docs,mods,reason,owners=spec[key]
 group={'group':g['group'],'ids':g['ids'],'decision':'PENDING_FINAL_CANCELLATION_AND_ROOT_BLOCK_ACCEPTANCE','functional_basis':reason,'retained_owners':owners,'documents':[str(next(Path('docs').glob(n+'-*.md'))) for n in docs.split()],'original_selected_witnesses':[r for r in reuse['witnesses'] if r['module'] in mods.split()],'limits':'Selected recorded outcomes plus source bridge, not fresh all-module run or independent PASS per structural ID.'};groups.append(group)
 for ident in g['ids']:
  original=next(r for r in census if r['id']==ident);row=copy.deepcopy(original);files=set(row['sources'])
  for a in row.get('authority',[]):
   if isinstance(a,dict) and 'file'in a:files.add(a['file'])
  for a in row.get('variants_and_dependencies',{}).get('static_dependency_closure',[]):
   if isinstance(a,dict) and 'file'in a:files.add(a['file'])
  row.update(source_sha256_at_N07_disposition={p:sha(p) for p in sorted(files)},group=key,N07_disposition='PENDING_FINAL_ACCEPTANCE',basis=reason,evidence=group['documents']+['docs/evidencias/n07-testigos-fuentes-conciliacion-20261026.json'],retained_owners=owners,performance_state='Finite named scenario references only; no per-ID universal timing/gain. Alias shares actual witnessed implementation, no duplicate samples.',historical_source_delta_note='Original census fields preserved; current direct/dependency hashes separate, no inherited unchanged assertion.')
  rows.append(row)
assert len(rows)==39 and len({r['id'] for r in rows})==39 and {r['id'] for r in rows}=={r['id'] for r in census}
out={'result':'DRAFT_39_N07_DISPOSITIONS_PENDING_VALID_CANCEL_RUN_AND_ACCEPTANCE','original_census_sha256':sha('artifacts/recorridos-n07-a-20261025/census.json'),'ids':39,'groups':groups,'actions':rows,'commercial_invariant':{'original_actual_worker_beat_verified':reuse['synthetic_autobump_real_worker_beat_proof_verified'],'source':'docs/evidencias/n07-testigos-fuentes-conciliacion-20261026.json','scope':'Seven bump race witnesses and one real prefork/Beat synthetic commercial witness. Original Beat1s diagnostic not native cadence. Editorial state preserved; domain remains N08.'},'limits':'N07 in progress6/13. Native mapping only input; root145outcomes/source bridge reconciled,C16distinct. Not39independent executions. Unsupported3prototypeSKIP not credited. No frontend rewrite/provider/realdata/beta.'}
(W/'dispositions-draft.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('39 IDs/9grupos preservados; aceptación pendiente')
