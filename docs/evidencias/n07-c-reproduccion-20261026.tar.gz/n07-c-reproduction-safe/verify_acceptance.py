import collections,hashlib,json,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n07-c-20261025');read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=read(W/'dispositions-final.json');original=read('artifacts/recorridos-n07-a-20261025/census.json');assert d['ids']==len(d['actions'])==39 and len(d['criteria'])==8
assert {r['id'] for r in d['actions']}=={r['id'] for r in original} and len({r['id'] for r in d['actions']})==39
assert collections.Counter(r['kind'] for r in original)==collections.Counter(r['kind'] for r in d['actions'])
for r in d['actions']:
 old=next(x for x in original if x['id']==r['id'])
 for k in ['id','kind','families','blocks','sources','source_sha256','authority','source_delta']:assert r[k]==old[k],(r['id'],k)
 assert r['N07_disposition']=='ACCEPTED_LOCAL_FINITE_SCOPE_RETAIN_SHARED_OWNERS'
 assert all(sha(p)==h for p,h in r['source_sha256_at_N07_disposition'].items())
 assert all(Path(p).is_file() for p in r['evidence'])
 assert Path(r['final_acceptance']).is_file()
assert len(d['groups'])==9 and sorted(i for g in d['groups'] for i in g['ids'])==sorted(r['id'] for r in original)
assert not subprocess.check_output(['git','diff','--name-only','--','apps','config','templates','static'],text=True).strip()
assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','apps','config','templates','static'],text=True).strip()
re=read(W/'reuse-verification.json');assert re['baseline_executable_sources']==1507 and re['unchanged_baseline_sources']==1500 and re['selected_original_cases']==len(re['witnesses'])==145 and re['selected_test_source_files']==22 and re['synthetic_autobump_real_worker_beat_proof_verified']
for row in re['witnesses']:
 cs=list(E.parse(row['junit']).iter('testcase'));matches=[c for c in cs if c.get('name')==row['case'] and c.get('classname','').endswith(row['module'])]
 assert len(matches)==1 and not any(matches[0].find(k)is not None for k in ['failure','error','skipped'])
 assert sha(row['test_source'])==row['current_test_source_sha256']
proofs=[]
for label,audit_path,freeze_path,expected in [('C16',W/'reference-audit.json',W/'reference-freeze.json',16),('cancel2',W/'cancellation-prereg/reference-audit.json',W/'cancellation-prereg/reference-freeze.json',2)]:
 audit=read(audit_path);freeze=read(freeze_path);run=Path('artifacts/local-ci')/audit['run'];result=read(run/'result.json')
 assert audit['cases']==expected and audit['cleanup_verified'] and audit['telegram']['delivery']=='sent'
 assert result['result']=='PASS' and result['sources_unchanged'] and result['selection']==freeze['selection']
 cs=list(E.parse(run/'pytest.xml').iter('testcase'));assert len(cs)==expected and not any(c.find(k)is not None for c in cs for k in ['failure','error','skipped'])
 delta={p:{'run_sha':h,'current_sha':sha(p)} for p,h in freeze['sources'].items() if sha(p)!=h}
 assert set(delta)<= {'.ai/tasks/desarrollo.md','AGENTS.md'},delta
 for kind in ['container','volume','network']:
  cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+run.name],text=True).strip()
 assert not Path(read(run/'runner.json')['temporary']).exists() and read(run/'telegram-notification.json')['delivery']=='sent'
 proofs.append({'reference':label,'run':run.name,'cases':expected,'junit':result['junit'],'post_terminal_non_product_deltas':delta,'sources_unchanged_during_run':True,'cleanup':True,'telegram':'sent'})
invalid=read(W/'cancellation-prereg/first-invalid-audit.json');assert invalid['result']=='INVALID_PRESERVED_NOT_ACCEPTED'
assert read('artifacts/local-ci/'+invalid['run']+'/result.json')['result']=='INVALID'
assert sha('docs/111-inventario-rendimiento-recorridos-beta-20261020.md')=='380b026c51b5e9647052838bb77a0712e9efff4ccdd857b5df3d4b545d921a95'
out={'result':'PASS_N07_ACCEPTANCE_39_DISPOSITIONS_8_CRITERIA_FINITE_SOURCE_SCOPES','actions':39,'groups':9,'criteria':8,'original_witnesses':145,'original_test_files':22,'new_distinct_runs':proofs,'dispositions_sha256':sha(W/'dispositions-final.json'),'reuse_verification_sha256':sha(W/'reuse-verification.json'),'invalid_first_cancel_run_preserved':True,'application_changes_this_lot':False,'scope':'N07A product correction already402, B/C references/current cancellation; sharedN03/N05/N06/N08/N09/N10 obligations retained. Not39independent cases or145fresh cases; no temporal optimization claimed. Postterminal instruction/worklog deltas no product/test change; terminal valid runs remain source-stable. New skill catalog absentMCP explicitly recorded, no new migrations/services. Graph/document final reconciliation separate required gate.'}
(W/'acceptance-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
