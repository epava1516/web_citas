"""Source-scoped reuse of selected original runtime witnesses, never a fresh QA run."""
import ast,collections,hashlib,json,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n07-c-20261025');read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
product=read('docs/evidencias/b16-final-candidate-reconciliation-20261025.json')['current_versioned_executable_sources'];assert len(product)==1507
variants={'scripts/run_local_ci.py','apps/safety/rights_portability_export.py','apps/core/agencies.py','apps/mediafiles/services.py','apps/mediafiles/similarity.py','apps/mediafiles/tasks.py','apps/mediafiles/views.py'}
assert {p for p,h in product.items() if sha(p)!=h}==variants
for p,h in product.items():
 if p not in variants:assert sha(p)==h,p
f=read(W/'reference-freeze.json');assert sha('scripts/run_local_ci.py')==f['sources']['scripts/run_local_ci.py'] and sha('artifacts/recorridos-n01-d-20261025/runner-before.py')==product['scripts/run_local_ci.py']
def except_functions(text,names):
 t=ast.parse(text);t.body=[n for n in t.body if not isinstance(n,ast.FunctionDef) or n.name not in names];return ast.dump(t,include_attributes=False)
checks=[('apps/safety/rights_portability_export.py','artifacts/recorridos-n02-b-20261025/rights-portability-export-before.py','artifacts/recorridos-n02-b-20261025/candidate-scope.json','_verify_current_images'),('apps/core/agencies.py','artifacts/recorridos-n06-d-20261025/agencies-before.py','artifacts/recorridos-n06-d-20261025/candidate-scope.json','panel'),('apps/mediafiles/views.py','artifacts/recorridos-n07-a-20261025/views-before.py','artifacts/recorridos-n07-a-20261025/candidate-scope.json','reorder')]
for p,b,c,fn in checks:
 scope=read(c);assert sha(b)==scope['before_sha256']==product[p] and sha(p)==scope['after_sha256'];assert except_functions(Path(p).read_text(),{fn})==except_functions(Path(b).read_text(),{fn})
B=read('artifacts/recorridos-n03-b-20261025/candidate-scope.json');C=read('artifacts/recorridos-n03-c-20261025/candidate-scope.json');D=read('artifacts/recorridos-n03-d-20261025/candidate-scope.json');F=read('artifacts/recorridos-n03-f-20261025/candidate-scope.json')
p='apps/mediafiles/services.py';assert sha(p)==F[p]['after_sha256'] and F[p]['before_sha256']==D[p]['after_sha256'] and D[p]['before_sha256']==C['after_sha256'] and C['before_sha256']==B[p]['after'] and B[p]['before']==product[p]
assert except_functions(Path(p).read_text(),{'process'})==except_functions(Path('artifacts/recorridos-n03-c-20261025/services-before.py').read_text(),{'process'})
p='apps/mediafiles/similarity.py';assert sha(p)==B[p]['after'] and B[p]['before']==product[p]
p='apps/mediafiles/tasks.py';assert sha(p)==D[p]['after_sha256'] and D[p]['before_sha256']==product[p];assert except_functions(Path(p).read_text(),{'recover_media_jobs'})==except_functions(Path('artifacts/recorridos-n03-d-20261025/tasks-before.py').read_text(),{'recover_media_jobs'})
raw=Path('artifacts/local-ci/20261024-094540-3a6ec8ac');oldhash=read(raw/'source-hashes.json');relevant={p:h for p,h in product.items() if p.startswith(('apps/','templates/','static/','config/'))};assert {p for p,h in relevant.items() if oldhash.get(p)!=h}=={'apps/listings/publication_signals.py'}
rawresult=read(raw/'result.json');p='apps/listings/publication_signals.py';oldtext=subprocess.check_output(['git','show',rawresult['head']+':'+p],text=True);assert hashlib.sha256(oldtext.encode()).hexdigest()==oldhash[p]
class ActivePath(ast.NodeTransformer):
 def __init__(self):self.imports=self.guards=0
 def visit_ImportFrom(self,n):
  if n.module=='django.apps':assert [(x.name,x.asname) for x in n.names]==[('apps',None)];self.imports+=1;return None
  return n
 def visit_If(self,n):
  if ast.dump(n.test)==ast.dump(ast.parse('model._meta.apps is not apps',mode='eval').body):
   assert not n.orelse and len(n.body)==1 and isinstance(n.body[0],ast.Return) and n.body[0].value is None;self.guards+=1;return None
  return self.generic_visit(n)
transform=ActivePath();tree=transform.visit(ast.parse(Path(p).read_text()));assert transform.imports==transform.guards==1 and ast.dump(tree,include_attributes=False)==ast.dump(ast.parse(oldtext),include_attributes=False)
modules={'test_lifecycle','test_listing_expiry_dispatch','test_beta_exposure_worker','test_promotion_bump_races','test_publication_state','test_publication_state_matrix','test_publication_dirty_census','test_publication_pending_batch','test_publication_refresh_lock_order','test_publication_refresh_rollback','test_media_erasure','test_preparation_cleanup','test_beta_urgent_withdrawal','test_listing_moderation','test_appeals','test_match_review','test_photo_appeals','test_photo_restrictions','test_publication_match_dependency_edges','test_publication_projection_lifecycle','test_owned_private_draft_publication_race','test_private_photo_rights_race'}
selected={};files={};all_counts={};not_credited=[]
prototype='test_owned_private_draft_publication_race';required_modules=modules-{prototype}
for run in ['20261024-094540-3a6ec8ac','20261024-144205-543aec10','20261024-144428-6598f5bf','20261025-094533-b3968c81','20261025-200423-1535dac0','20261025-233639-833fd457']:
 P=Path('artifacts/local-ci')/run;cs=list(E.parse(P/'pytest.xml').iter('testcase'));hashes=read(P/'source-hashes.json');bad=sum(any(c.find(k)is not None for k in ('failure','error')) for c in cs);all_counts[run]={'original_file_cases':len(cs),'original_file_failures_errors':bad,'original_file_skipped':sum(c.find('skipped')is not None for c in cs)}
 for case in cs:
  mod=case.get('classname','').split('.')[-1]
  if mod not in modules and mod!='test_publication_migration_signal':continue
  if mod==prototype:
   assert run=='20261024-094540-3a6ec8ac' and case.find('skipped')is not None
   not_credited.append({'module':mod,'case':case.get('name'),'run':run,'result':'SKIP_not_credited','reason':'Explicit prototype arms replace DB implementation; sparse broad run did not execute them. They are not a mandatory current N07 runtime scenario. Existing accepted0022 trigger source retained; current projection/lock/bulk/rawSQL witnesses selected separately.'})
   continue
  assert not any(case.find(k)is not None for k in ('failure','error','skipped')),(run,case.get('name'))
  path='tests/'+mod+'.py';assert sha(path)==hashes[path],(run,path)
  selected[(mod,case.get('name'))]={'module':mod,'case':case.get('name'),'run':run,'junit':str(P/'pytest.xml'),'test_source':path,'test_source_sha256':hashes[path],'result':'PASS_original_recorded_not_rerun','whole_file_failures_errors':bad};files[path]=sha(path)
assert required_modules<={r['module'] for r in selected.values()} and len(not_credited)==3
worker=read(raw/'beta-exposure-worker-proof.json');assert worker['result']=='PASS' and worker['editorial_state_unchanged'] and worker['real_worker_and_beat'] and worker['synthetic_only'] and worker['simulated_identity_and_payment'];assert len(worker['worker_job_ids'])==4 and worker['worker_expiry_events']==worker['beat_expiry_events']==1 and worker['beat_rechecked'] and all(p['terminated'] for p in worker['processes'])
for role in ('worker','beat'):assert sha(raw/('beta-exposure-'+role+'.log'))==worker[role+'_log_sha256']
current_native=read('artifacts/local-ci/20261025-233639-833fd457/native-manifest.json');old_native=read(raw/'native-manifest.json');assert all(current_native[k]==old_native[k] for k in ('parser_commit','hiredis_commit'))
assert sha('docs/111-inventario-rendimiento-recorridos-beta-20261020.md')=='380b026c51b5e9647052838bb77a0712e9efff4ccdd857b5df3d4b545d921a95'
out={'result':'PASS_SOURCE_SCOPED_ORIGINAL_N07_WITNESSES_RECONCILED_NOT_BLOCK_ACCEPTANCE','baseline_executable_sources':1507,'unchanged_baseline_sources':1500,'documented_variants':{p:sha(p) for p in sorted(variants)},'scoped_AST_checks':['portability_guard_only','agency_panel_only','media_views_reorder_only','process_fence_budget_chain','recovery_selector_only','active_registry_signal_path_identical_after_sole_guard_removal'],'native_parser_hiredis_commits_equal':True,'selected_original_cases':len(selected),'selected_test_source_files':len(files),'source_files':files,'original_files':all_counts,'witnesses':list(selected.values()),'selected_prototype_skips_not_credited':not_credited,'synthetic_autobump_real_worker_beat_proof_verified':True,'limits':'Selected original outcomes not a new integrated run; raw3829file retains3CLI failures and other skipped scopes not credited. Active registry signal bridge preserves historical-model corrective scope. Media generation/corpus changes acceptedN03, views-onlyreorder acceptedN07A, other owner domains retained. Original commercial Beat probe uses1s synthetic schedule, not nativecadence proof. No current-browser universal claim or real provider.'};(W/'reuse-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ('witnesses','source_files')}))
