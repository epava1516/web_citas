import copy,hashlib,json,shutil,tarfile,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n07-c-20261025');S=W/'reproduction-safe';S.mkdir(exist_ok=False)
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(source,dest=None):
 source=Path(source);dest=S/(dest or source.relative_to(W));dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
for name in ['writer-report.json','writer-proposed.py','writer-integration-scope.json','selected-original-oracles.json','pre-source-cut.json','external-index-reconciliation.json','reference-freeze.json','reference-audit.json','reuse-verification.json','dispositions-final.json','acceptance-verification.json','audit_reference.py','verify_reuse.py','verify-reuse-before-prototype-scope-fix.py','verify-reuse-before-signal-instrument-scope-fix.py','verify_acceptance.py','refresh_cancellation_ast.py','build_dispositions.py','package_evidence.py']:
 put(W/name)
for directory,names in {
'prereg':['semantic-inputs.json','semantic-fragment.json','report.json','semantic-integration.json','verification.json'],
'cancellation-prereg':['semantic-inputs.json','semantic-fragment.json','report.json','semantic-integration.json','verification.json','reference-freeze-first-invalid.json','reference-freeze.json','first-invalid-audit.json','reference-audit.json','external-contract-document-deltas.json','audit_reference.py','integrate_semantics.py','finalize_graph.py','verify_graph.py'],
'final':['semantic-inputs.json','semantic-fragment.json','report.json','semantic-integration.json','verification.json','semantic-completeness.json','capabilities-current-session.json','integrate_semantics.py','finalize_graph.py','verify_graph.py']}.items():
 for name in names:put(W/directory/name)
for source in ['tests/test_listing_review_queue_reference.py','tests/test_lifecycle_cancellation.py']:put(source,'instruments/'+Path(source).name)
def strip_outputs(root):
 for element in root.iter():
  for child in list(element):
   if child.tag in ('system-out','system-err'):element.remove(child)
 return root
runs=['20261025-233639-833fd457','20261026-002115-2ce17e96','20261026-002326-91562ec6']
for run in runs:
 root=Path('artifacts/local-ci')/run;dest=S/'runs'/run;dest.mkdir(parents=True)
 result=read(root/'result.json')
 result['steps']=[{k:v for k,v in step.items() if k not in ('command','stdout','stderr')} for step in result['steps']]
 (dest/'result-sanitized.json').write_text(json.dumps(result,indent=2)+'\n')
 for name in ['source-hashes.json','native-manifest.json','telegram-notification.json']:shutil.copy2(root/name,dest/name)
 E.ElementTree(strip_outputs(E.parse(root/'pytest.xml').getroot())).write(dest/'pytest-sanitized.xml',encoding='utf-8',xml_declaration=True)
# Preserve only the selected original cases; no full raw3829 XML/log leakage.
reuse=read(W/'reuse-verification.json');suite=E.Element('testsuite',name='selected_original_recorded_N07_not_fresh_integrated',tests=str(len(reuse['witnesses'])))
cache={}
for witness in reuse['witnesses']:
 path=witness['junit']
 if path not in cache:cache[path]=list(E.parse(path).iter('testcase'))
 matches=[c for c in cache[path] if c.get('name')==witness['case'] and c.get('classname','').endswith(witness['module'])];assert len(matches)==1
 case=copy.deepcopy(matches[0]);strip_outputs(case);case.set('original_run',witness['run']);suite.append(case)
E.ElementTree(suite).write(S/'selected-original-witnesses-sanitized.xml',encoding='utf-8',xml_declaration=True)
manifest={'result':'SANITIZED_N07C_REPRODUCTION','files':{str(p.relative_to(S)):sha(p) for p in sorted(S.rglob('*')) if p.is_file()},'scope':'No raw logs, no stepcommands/systemout/systemerr. Original selected145 cases are not fresh integrated run; broad historical3FAIL129SKIP retained in source audit metadata. Parallel user contract/skills draft raw contents excluded; references and hashes retained. Own sources/full raw evidence preserved ignored locally.'}
(S/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
target=Path('docs/evidencias/n07-c-reproduccion-20261026.tar.gz')
with tarfile.open(target,'w:gz') as tar:tar.add(S,arcname='n07-c-reproduction-safe')
print(json.dumps({'artifact':str(target),'files':len(manifest['files'])+1,'sha256':sha(target),'bytes':target.stat().st_size}))
