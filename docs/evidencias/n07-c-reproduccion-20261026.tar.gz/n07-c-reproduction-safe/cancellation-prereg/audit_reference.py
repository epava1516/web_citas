import hashlib,json,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n07-c-20261025/cancellation-prereg');P=Path('artifacts/local-ci/20261026-002326-91562ec6')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=read(P/'result.json');f=read(W/'reference-freeze.json');h=read(P/'source-hashes.json')
assert r['result']=='PASS' and r['sources_unchanged'] and r['workers']==1 and r['selection']==f['selection'] and r['observe_http_operations']
assert all(sha(p)==v for p,v in f['sources'].items())
missing=set(f['sources'])-set(h);assert len(missing)==6 and all(p.startswith('docs/') for p in missing)
assert all(h[p]==v for p,v in f['sources'].items() if p in h)
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==2 and not any(c.find(k)is not None for c in cs for k in ('failure','error','skipped'))
rows=[]
for c in cs:
 props={p.get('name'):p.get('value') for p in c.iter('property')};d=json.loads(props['availability_cancellation']);lang=d['language']
 assert lang in ('es','en') and d['manual_cancel'] and d['exact_retry_no_extra_event'] and d['old_retry_preserves_new_window'] and d['editorial_snapshot_unchanged'] and d['new_events']==4 and d['public_availability_counts']==[1,0,1,1,0]
 ops=json.loads(props['http_operation_samples']);assert len(ops)==int(props['http_operation_count'])
 assert all(o['exception_class'] is None and o['observer_error_class'] is None for o in ops)
 actions=[o for o in ops if o['method']=='POST' and o['route_name']=='listing_lifecycle'];assert len(actions)==6 and all(o['status']==302 for o in actions)
 assert len([o for o in ops if o['method']=='GET' and o['route_name']=='listing_detail' and o['status']==200])>=1
 rows.append({'case':c.get('name'),'oracle':d,'operations':ops,'operation_scope':props['http_operation_scope']})
assert {x['oracle']['language'] for x in rows}=={'es','en'}
for kind in ('container','volume','network'):
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_N07C_CANCEL_AVAILABILITY_ES_EN_NOT_LATENCY_OPTIMIZATION','run':P.name,'cases':2,'junit':r['junit'],'freeze_sources':len(f['sources']),'documents_verified_separately':sorted(missing),'runner_sources_verified':len(f['sources'])-len(missing),'application_change':False,'cleanup_verified':True,'telegram':tg,'rows':rows,'scope':'Separate two-case synthetic real PostgreSQL regression. Repeated old cancellation key preserves a newer availability window, exact retry no extra event,public counts1/0/1/1/0,editorial snapshot preserved. Eager fixture; no worker/browser/provider/newCSRF/SLA/latencygain. GlobalClient samples include dynamic fixture calls; do not average mutation and retry.'}
(W/'reference-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='rows'}))
