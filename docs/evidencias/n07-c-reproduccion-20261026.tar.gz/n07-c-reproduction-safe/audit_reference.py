import collections,hashlib,json,math,statistics,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n07-c-20261025');P=Path('artifacts/local-ci')/sys.argv[1];read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=read(P/'result.json');f=read(W/'reference-freeze.json');assert r['result']=='PASS' and r['sources_unchanged'] and r['workers']==1 and r['selection']==f['selection'] and r['observe_http_operations'];assert all(sha(p)==h for p,h in f['sources'].items())
h=read(P/'source-hashes.json');missing=set(f['sources'])-set(h);assert missing=={'docs/400-n07-a-prerregistro-medios-publicacion-20261025.md','docs/401-n07-a-carrera-reordenacion-retirada-20261025.md','docs/403-n07-b-prerregistro-publicacion-worker-beat-20261025.md','docs/404-n07-b-correccion-instrumento-publicacion-20261025.md','docs/406-n07-c-prerregistro-colas-revision-apelaciones-20261025.md'},missing;assert all(h[p]==v for p,v in f['sources'].items() if p in h)
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==16 and not any(c.find(k)is not None for c in cs for k in ('failure','error','skipped'))
originals=read(W/'selected-original-oracles.json');assert len(originals)==8
for s in originals:assert sha(s['selector'].split('::')[0])==s['file_sha256']
original_names={s['selector'].split('::')[1] for s in originals};new_cases=[];original_cases=[];raw=[];summaries=[];queue_total=form_total=control_total=0
kindcounts={'moderation':1,'appeal':1,'match':2,'photo_appeal':1}
def finite(sample,scope):
 for k in ('sql_queries','sql_execute_seconds',scope):assert isinstance(sample[k],(int,float)) and not isinstance(sample[k],bool) and math.isfinite(sample[k]) and sample[k]>=0
 assert isinstance(sample['sql_queries'],int)
def summary(rows,kind,lang,surface,state):
 assert [x['ordinal'] for x in rows]==list(range(6));later=rows[1:]
 return {'kind':kind,'language':lang,'surface':surface,'state':state,'samples':6,'first_ms':rows[0]['wall_seconds']*1000,'median5_ms':statistics.median(x['wall_seconds'] for x in later)*1000,'range5_ms':[min(x['wall_seconds'] for x in later)*1000,max(x['wall_seconds'] for x in later)*1000],'cpu_median5_ms':statistics.median(x['cpu_seconds'] for x in later)*1000,'sql_counts':sorted({x['sql_queries'] for x in rows}),'bytes':sorted({x['response_bytes'] for x in rows})}
for c in cs:
 props={p.get('name'):p.get('value') for p in c.iter('property')};ops=json.loads(props['http_operation_samples']);assert len(ops)==int(props['http_operation_count']) and ops
 for x in ops:
  finite(x,'request_seconds_instrumented');assert x['exception_class'] is None and x['observer_error_class'] is None and x['status'] in (200,302,400,403,404,409)
 raw.append({'case':c.get('name'),'classname':c.get('classname'),'operations':ops,'scope':props['http_operation_scope']})
 if 'listing_review_queue_samples' not in props:
  assert c.get('name') in original_names;original_cases.append(c.get('name'));continue
 d=json.loads(props['listing_review_queue_samples']);kind=d['kind'];lang=d['language'];assert kind in kindcounts and lang in ('es','en');new_cases.append((kind,lang));q=d['samples'];forms=d['review_form_samples'];controls=d['authority_controls'];queue_total+=len(q);form_total+=len(forms);control_total+=len(controls)
 states=['before_submit','open','terminal'] if kind=='appeal' else ['open','terminal'];assert [x['state'] for x in q]==[s for s in states for _ in range(6)] and len(forms)==6
 for surface,rows,route in [('queue',q,kind+'_queue'),('review_form',forms,kind+'_review')]:
  for x in rows:
   finite(x,'wall_seconds');assert math.isfinite(x['cpu_seconds']) and x['cpu_seconds']>=0 and x['status']==200 and x['route_name']==route and x['response_language']==x['content_language']==lang and x['observed_cache_control']=='private, no-store' and x['response_bytes']>0
   if surface=='queue':assert x['shown_count']==(kindcounts[kind] if x['state']=='open' else 0)
   else:assert x['state']=='open'
  observed=[x for x in ops if x['method']=='GET' and x['route_name']==route and x['status']==200];assert len(observed)==len(rows)
  for own,global_row in zip(rows,observed):assert own['sql_queries']==global_row['sql_queries'] and own['wall_seconds']>=global_row['request_seconds_instrumented']
  for state in states if surface=='queue' else ['open']:summaries.append(summary([x for x in rows if x['state']==state],kind,lang,surface,state))
 expected_controls=[(s,k,v) for s in states for k,v in [('no_permission',403),('anonymous',302),('stale_mfa',302)]]+[('terminal','permission_revoked',403)]
 assert [(x['state'],x['kind'],x['status']) for x in controls]==expected_controls
 assert all(x['kind']=='anonymous' or x['observed_cache_control']=='private, no-store' for x in controls)
assert len(new_cases)==len(set(new_cases))==8 and set(new_cases)=={(k,l) for k in kindcounts for l in ('es','en')};assert set(original_cases)==original_names and len(original_cases)==8
assert queue_total==108 and form_total==48 and control_total==62 and len(summaries)==26
allops=[x for case in raw for x in case['operations']];assert len(allops)==383
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_N07C_QUEUE_FORM_AND_DECISION_REFERENCES_NOT_N07_ACCEPTANCE','run':P.name,'cases':16,'junit':r['junit'],'source_freeze_count':len(f['sources']),'runner_source_hashes':len(f['sources'])-len(missing),'documents_verified_separately':sorted(missing),'application_change':False,'queue_cases':8,'unchanged_original_cases':8,'queue_GET_samples':queue_total,'form_GET_samples':form_total,'authority_controls':control_total,'global_operation_samples':len(allops),'original_operation_samples':sum(len(x['operations']) for x in raw if x['case'] in original_names),'global_statuses':dict(collections.Counter(x['status'] for x in allops)),'summary':summaries,'raw_cases':raw,'cleanup_verified':True,'telegram':tg,'scope':'One integrated16case focused run. Sparse0/1/2; actuallang/cache/context/render/authority and current HTTP decisions. Self156GET nested in383globaloperations, not539events; no sumSQLbetweenobservers. Setup/dynamiccall/rawORM/body/CPU/concurrency limits per406; no growth100/p95/TCP/provider/temporaloptimization or all39unit acceptance. Userdraftdocfiles preserved outside stage; one structural indexreference only.'};(W/'reference-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ('raw_cases','summary')}));print(json.dumps(summaries))
