# Grafo alfa — N00 aceptado y primer prerregistro N01

Contrato anterior cerrado localmente por acta23 y commit16ac270:15/18aceptados;B14/B15/B17deuda, noPASS. Su grafo de cierre y archivos permanecen inmutables en docs/evidencias/contrato-grafo-registro-final-20261025.json. Base original reconstruida desde cero:1922fuentes,AST/semántica y28lotes. Refrescos posteriores son focales y explícitos, no nuevas reconstrucciones completas.

Contrato340/roadmap341v1.2,N00aceptado por343,1/13bloques aceptados,N01en curso. Prerregistro344 de2casos existentes10/100perfiles,listadoES instrumentado,antesdeejecución;noTCP/p95/capacidad. Tablaantes/después obligatoria porbloquecon evidenciacomparable,ono basecomparable declarada. N12–N14condicionados,MOD09sin prioridadautomática,QAespecífico aplazado,alfa.

Este refresco: 6 documentos, 40 entidades/40 relaciones semánticas nativas con cita,líneas ySHA comprobados. ASTsin cambios. Corpus vigente1930fuentes,17968nodos/79827relaciones,851comunidades. Se conservan membresías de base y se añade una comunidad documental;no detección global nueva. Seguimiento17sólo líneas1–4,con huellas separadas delarchivo completo yvista. Historial/evidencias masivas/vendor yotras exclusiones permanecen explícitas en política.

Semántica selectiva y referencias estáticas;no prueba de runtime,permisos,coste,seguridad,legalidad oPASS. Entidades antiguas sustituidas aún citadas desde otras fuentes conservan handles noresueltos, sin implementación inventada. Las100anotaciones ambiguas de llamadas/bases son anotaciones, no dependencias a sí mismas. Consumo nativo desconocido;ceros técnicos delgenerador no son coste cero.

JSON contiene elgrafo completo;HTMLproyecta sólo comunidades, manteniendo guarda de5000nodos sin abrir un render completo.

