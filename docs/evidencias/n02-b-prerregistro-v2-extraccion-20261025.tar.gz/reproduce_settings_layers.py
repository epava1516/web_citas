"""Pure configuration reproduction; not an application or PostgreSQL test."""
import hashlib,json
from types import SimpleNamespace
from pathlib import Path
from django.conf import UserSettingsHolder
base=SimpleNamespace(DEBUG=False, OTHER='synthetic')
one=UserSettingsHolder(base);one.DEBUG=False
two=UserSettingsHolder(one);two.DEBUG=False
def enumerated(config):return sorted((k,repr(getattr(config,k))) for k in dir(config) if k.isupper())
a,b=enumerated(one),enumerated(two)
assert dict(a)==dict(b) and a!=b
assert sum(k=='DEBUG' for k,_ in a)==2 and sum(k=='DEBUG' for k,_ in b)==3
r={'result':'CONFIRMED_REDUNDANT_OVERRIDE_CHANGES_ENUMERATED_CONFIG','debug_occurrences_before':2,'debug_occurrences_after':3,'effective_values_equal':True,'enumerated_fingerprint_input_equal':False,'scope':'Real Django UserSettingsHolder, isolated synthetic values; pytest fixture source creates nested overrides and seal rule source enumerates dir without deduplication; not application runtime acceptance.'}
Path('artifacts/recorridos-n02-b-20261025/settings-layer-proof.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
