"""Literal protocol amendment and refreshed instrument AST; app unchanged."""
import hashlib,json,re,shutil
from pathlib import Path
from datetime import datetime,timezone
w=Path(__file__).resolve().parent;s=w/'graph-integrated';b=w/'graph-base';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();norm=lambda x:re.sub('[^a-z0-9]+','_',x.lower()).strip('_');fileid=lambda p:'file_'+norm(p)
assert not s.exists() and not b.exists();shutil.copytree('graphify-out',b);shutil.copytree(b,s)
g=json.loads((s/'graph.json').read_text());nodes={n['id']:n for n in g['nodes']};edges=g['links'];m=json.loads((s/'SOURCE_MANIFEST.json').read_text());doc='docs/362-n02-b-prerregistro-guard-imagenes-sello-20261025.md';lines=Path(doc).read_text().splitlines();rebound=0
for row in list(nodes.values())+edges:
 if row.get('source_file')!=doc:continue
 if row.get('evidence_quote'):
  loc=re.fullmatch(r'L(\d+)(?:-L?(\d+))?',row['source_location']);lo=int(loc[1]);hi=int(loc[2] or loc[1]);assert row['evidence_quote'] in '\n'.join(lines[lo-1:hi]);rebound+=1
 if 'source_sha256' in row:row['source_sha256']=sha(doc)
nodes[fileid(doc)]['literal_amendment']={'source_location':'L'+str(len(lines)),'evidence_quote':lines[-1],'source_sha256':sha(doc),'scope':'Parent literal appendix, no new runtime acceptance'}
m[doc].update(sha256=sha(doc),bytes=Path(doc).stat().st_size,input_path=str(Path(doc).resolve()),input_sha256=sha(doc),semantic_scope='Original native quotes L1-L27 unchanged/rebound; parent literal correction appendix only')
p='tests/test_held_seal_image_batch.py';raw=json.loads((w/'fresh-ast-completed.json').read_text());assert not raw['failed_sources'];assert json.loads((w/'python-definition-reconciliation.json').read_text())['python_declarations']==13
oldids={i for i,n in nodes.items() if n.get('source_file')==p and i!=fileid(p)};newids={n['id'] for n in raw['nodes'] if n.get('source_file')==p};assert oldids==newids
for n in raw['nodes']:
 if n.get('source_file')==p:
  previous=nodes[n['id']];nodes[n['id']]={**n,'extraction_origin':'fresh_N02B_instrument_AST','community':previous['community'],'community_name':previous['community_name']}
edges=[e for e in edges if e.get('source_file')!=p]
for identity in newids:
 n=nodes[identity];edges.append({'source':fileid(p),'target':identity,'relation':'has_extracted_entity','source_file':p,'source_location':n.get('source_location'),'confidence':'EXTRACTED','confidence_score':1.0,'weight':1.0,'extraction_origin':'extraction_provenance_not_application_dependency'})
for rawedge in raw['edges']:
 e={**rawedge,'extraction_origin':'fresh_N02B_instrument_AST'}
 for k in ('source','target'):
  if e[k] in nodes:continue
  identity=e[k];matches=[i for i,n in nodes.items() if n.get('external') and n.get('label')==identity];key=matches[0] if len(matches)==1 else 'n02b_instrument_reference_'+norm(identity);assert key in nodes,(key,identity);e[k]=key
 e.setdefault('confidence_score',1.0 if e['confidence']=='EXTRACTED' else .85);edges.append(e)
m[p].update(sha256=sha(p),bytes=Path(p).stat().st_size,input_sha256=sha(p))
assert all(e[k] in nodes for e in edges for k in ('source','target'))
g.update(nodes=list(nodes.values()),links=edges);g['graph']['updated_at']=datetime.now(timezone.utc).isoformat();(s/'graph.json').write_text(json.dumps(g,indent=2,ensure_ascii=False));(s/'SOURCE_MANIFEST.json').write_text(json.dumps(m,indent=2))
proof={'state':'LITERAL_PROTOCOL_AMENDMENT_AND_FRESH_INSTRUMENT_AST','changed_sources':[doc,p],'semantic_changed_sources':[doc],'old_graph_sha256':sha(b/'graph.json'),'native_nodes':0,'native_relations':0,'existing_native_quotes_rebound':rebound,'retired_semantic_nodes':0,'retired_foreign_references_preserved':0,'resolved_legacy_reference_ids':[],'source_files':len(m),'nodes':len(nodes),'relations':len(edges),'communities':len(json.loads((s/'.graphify_analysis.json').read_text())['communities']),'structural_delta':{'instrument':p,'instrument_sha256':sha(p),'instrument_named_functions':13,'app_scope':json.loads((w.parent/'candidate-scope.json').read_text()),'application_unchanged_since_initial_run':True},'failed_run':'20261025-130439-39bc72b1','scope':'Initial14oraclesPASS retained with identical app; only redundant post-generation DEBUG overrides removed in2newtests, fresh AST and literal protocol appendix. No new runtime acceptance, no global graph rebuild.','native_token_usage':None}
(w/'semantic-integration.json').write_text(json.dumps(proof,indent=2));print(json.dumps({k:proof[k] for k in ['source_files','nodes','relations','communities','existing_native_quotes_rebound']}))
