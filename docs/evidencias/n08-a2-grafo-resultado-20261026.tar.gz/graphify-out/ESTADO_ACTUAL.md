# Grafo alfa — N08A2 candidato por página aceptado localmente

412:13PASS321,638sQA/1755huellas/72GETobjetivos+46controles118dentro167Client/paridadexacta/budgets411cumplidos/cleanupTGsent.6segmentosmismaDB/datos/Client/callbacksfuentereal/ordenalternado,primeraseparada+mediana5;fav563→30cursorcalls yXML2402→18,~89–96%menosmediana segunestadoidioma,CPUmenor.0/1costeigual,10menos;NULLforeign/placeholders/counts24/100guardasconservadas,10originalesincl3browseractual156. Memoriahighwater<=318,383MiB/1GiBdiag,noporversión. N08A2localaccepted,nofullN08;7/13,nextN08B25/50/opciones/autobump y17disposiciones. Nop95/load/provider/beta,SLOniQAoverallgainclaim.

Semántica412/17top4nativa,ASTcandidate/pairpreservado;2028fuentes/19515nodos/83306relaciones/934comunidades. NoN15rebuildniglobalsemanticexhaustividad,consumonativeunknown.

