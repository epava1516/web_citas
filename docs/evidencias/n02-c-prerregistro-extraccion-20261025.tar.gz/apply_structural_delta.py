"""Fresh instrument AST and one stdlib-AST/import-resolved caller substitution."""
import ast,collections,hashlib,json,re
from pathlib import Path
w=Path(__file__).resolve().parent;s=w/'graph-integrated';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();norm=lambda x:re.sub('[^a-z0-9]+','_',x.lower()).strip('_');fileid=lambda p:'file_'+norm(p)
g=json.loads((s/'graph.json').read_text());nodes={n['id']:n for n in g['nodes']};edges=g['links'];m=json.loads((s/'SOURCE_MANIFEST.json').read_text());proof=json.loads((w/'semantic-integration.json').read_text());proof['semantic_changed_sources']=proof['changed_sources'].copy()
p='tests/test_held_seal_guard_grouped_reference.py';raw=json.loads((w/'fresh-ast-completed.json').read_text());assert not raw['failed_sources'];assert json.loads((w/'python-definition-reconciliation.json').read_text())['python_declarations']==4
assert p not in m
m[p]={'sha256':sha(p),'bytes':Path(p).stat().st_size,'category':'code','input_path':str(Path(p).resolve()),'input_sha256':sha(p),'semantic_scope':'fresh_graphify_and_standard_Python_AST','extraction_origin':'fresh_N02C_instrument_AST'}
nodes[fileid(p)]={'id':fileid(p),'label':p,'source_file':p,'source_location':'L1','file_type':'code','extraction_origin':'declared_corpus_manifest'}
for n in raw['nodes']:
 if n.get('source_file')!=p:continue
 assert n['id'] not in nodes
 n={**n,'extraction_origin':'fresh_N02C_instrument_AST'};nodes[n['id']]=n
 edges.append({'source':fileid(p),'target':n['id'],'relation':'has_extracted_entity','source_file':p,'source_location':n.get('source_location'),'confidence':'EXTRACTED','confidence_score':1.0,'weight':1.0,'extraction_origin':'extraction_provenance_not_application_dependency'})
for rawedge in raw['edges']:
 e={**rawedge,'extraction_origin':'fresh_N02C_instrument_AST'}
 for k in ('source','target'):
  if e[k] in nodes:continue
  identity=e[k];matches=[i for i,n in nodes.items() if n.get('external') and n.get('label')==identity]
  key=matches[0] if len(matches)==1 else 'n02c_instrument_reference_'+norm(identity)
  if key not in nodes:nodes[key]={'id':key,'label':identity,'source_file':None,'source_location':None,'file_type':'concept','external':True,'resolution_status':'unresolved_static_reference_not_runtime_binding','extraction_origin':'fresh_N02C_instrument_AST'}
  e[k]=key
 e.setdefault('confidence_score',1.0 if e['confidence']=='EXTRACTED' else .85);edges.append(e)
proof['changed_sources']+=[p];proof['structural_delta']={'instrument':p,'instrument_sha256':sha(p),'instrument_named_functions':4,'raw_nodes':len(raw['nodes']),'raw_relations':len(raw['edges']),'application_and_previous_instruments_unchanged':True}
a=json.loads((s/'.graphify_analysis.json').read_text());communities={int(k):list(v) for k,v in a['communities'].items()};assigned={i for v in communities.values() for i in v};cid=max(communities);communities[cid]+=sorted(set(nodes)-assigned)
labels={int(k):v for k,v in json.loads((s/'.graphify_labels.json').read_text()).items()};labels[cid]='Contraste agrupado del guard'
for c,ids in communities.items():
 for i in ids:nodes[i].update(community=c,community_name=labels[c])
assert all(e[k] in nodes for e in edges for k in ('source','target'))
g.update(nodes=list(nodes.values()),links=edges);g['graph']['corpus_files']=len(m);g['graph']['structural_sources']+=1
a['communities']=communities
proof.update(source_files=len(m),nodes=len(nodes),relations=len(edges),communities=len(communities),scope='Preserved full base; scoped protocol semantics, fresh grouped instrument AST; application and previous instrument sources unchanged. Static graph is not runtime proof.')
(s/'graph.json').write_text(json.dumps(g,indent=2,ensure_ascii=False));(s/'SOURCE_MANIFEST.json').write_text(json.dumps(m,indent=2));(s/'.graphify_analysis.json').write_text(json.dumps(a));(s/'.graphify_labels.json').write_text(json.dumps(labels));(w/'semantic-integration.json').write_text(json.dumps(proof,indent=2))
print(json.dumps({k:proof[k] for k in ['source_files','nodes','relations','communities','scope']}))
