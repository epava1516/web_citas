import hashlib,json,math,statistics,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n05-b-20261025');P=Path('artifacts/local-ci')/sys.argv[1];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:assert k not in d;d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
r=read(P/'result.json');f=read(W/'reference-freeze.json');assert r['result']=='PASS' and r['sources_unchanged'] and r['selection']==f['selection'] and r['workers']==1
assert all(sha(p)==h for p,h in f['sources'].items())
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==4 and not any(c.find(k)is not None for c in cs for k in ['failure','error','skipped'])
private=[];poll=[];summary=[]
asset_paths={'css':'static/app.css','form_errors':'static/form-errors.js','htmx':'static/vendor/htmx.min.js'}
def assets(rows,expected):
 seen=set()
 for x in rows:
  if x['status']==304:assert x['decoded_bytes']==0 and x['sha256'] is None and x['body_scope']=='no_new_body_static_revalidation';continue
  assert x['status']==200 and x['sha256']==sha(asset_paths[x['kind']]) and x['decoded_bytes']==Path(asset_paths[x['kind']]).stat().st_size
  seen.add(x['kind'])
 assert expected<=seen
for c in cs:
 props={x.attrib['name']:x.attrib['value'] for x in c.iter('property')}
 if 'n05b_private_delivery'in props:
  d=json.loads(props['n05b_private_delivery']);private.append(d);s=d['stored'];assert s['format']=='WEBP' and not s['exif'] and s['size']==[640,480] and s['original_sha256']!=s['body_sha256']
  assert len(d['api_samples'])==6 and [x['ordinal'] for x in d['api_samples']]==list(range(1,7))
  for x in d['api_samples']+[d['conditional_positive']]:
   assert x['status']==200 and x['body_sha256']==s['body_sha256'] and x['decoded_bytes']==s['decoded_bytes'] and x['cache_control']=='private, no-store' and x['nosniff']=='nosniff'
  assert d['anonymous_denied']['status']==302 and d['after_remove']['status']==404
  assert not d['anonymous_denied']['content_type'].startswith('image/') and not d['after_remove']['content_type'].startswith('image/')
  assert len(d['browser_images'])>=2 and all(x['status']==200 and x['sha256']==s['body_sha256'] and x['decoded_bytes']==s['decoded_bytes'] for x in d['browser_images'])
  assert d['upload_to_preview_seconds']>0 and d['reload_to_preview_seconds']>0
  assets(d['assets'],{'css','form_errors'});assert not d['observer_errors'] and d['process_maxrss_kib']<1024*1024
  later=[x['wall_including_body_seconds'] for x in d['api_samples'][1:]]
  summary.append({'flow':'private','language':d['language'],'bytes':s['decoded_bytes'],'upload_preview_seconds':d['upload_to_preview_seconds'],'reload_preview_seconds':d['reload_to_preview_seconds'],'api_first_seconds':d['api_samples'][0]['wall_including_body_seconds'],'api_later_median_seconds':statistics.median(later),'api_later_range_seconds':[min(later),max(later)],'anonymous':302,'removed':404,'browser':d['browser'],'maxrss_kib':d['process_maxrss_kib']})
 elif 'n05b_polling'in props:
  d=json.loads(props['n05b_polling']);poll.append(d);rows=d['requests'];states=[x['state'] for x in rows];assert states.count('queued')>=2 and 'running'in states and states[-1]=='rejected';assert states==sorted(states,key={'queued':0,'running':1,'rejected':2}.get)
  assert all(x['status']==200 and x['decoded_bytes']>0 and 'no-store'in x['cache_control'] for x in rows)
  starts=[x['start_monotonic'] for x in rows];actual=[b-a for a,b in zip(starts,starts[1:])];assert actual==d['interval_seconds'] and all(math.isfinite(x) and x>0 for x in actual)
  assert d['max_inflight']==1 and d['terminal_quiet_seconds']>=6.5 and d['terminal_no_new_requests'] and d['no_js_poll_count']==0 and not d['observer_errors'];assert d['process_maxrss_kib']<1024*1024
  assets(d['assets'],{'css','form_errors','htmx'})
  summary.append({'flow':'polling','language':d['language'],'requests':len(rows),'states':states,'interval_seconds':actual,'request_duration_median_seconds':statistics.median(x['wall_seconds'] for x in rows),'request_duration_range_seconds':[min(x['wall_seconds'] for x in rows),max(x['wall_seconds'] for x in rows)],'decoded_response_bytes':[x['decoded_bytes'] for x in rows],'terminal_quiet_seconds':d['terminal_quiet_seconds'],'no_js_poll_count':0,'max_inflight':1,'browser':d['browser'],'maxrss_kib':d['process_maxrss_kib']})
 else:raise AssertionError('Missing metric property')
assert len(private)==len(poll)==2 and {x['language'] for x in private}=={x['language'] for x in poll}=={'es','en'}
assert private[0]['stored']==private[1]['stored']
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_N05B_FOUR_BROWSER_DELIVERY_POLLING_REFERENCES_NOT_N05_ACCEPTANCE','run':P.name,'junit':r['junit'],'source_count':len(f['sources']),'sources_unchanged':True,'private':private,'polling':poll,'summary':summary,'cleanup_verified':True,'telegram':tg,'scope':'Real selected mobile browser/HTTP/bytes/headers; private eager and polling domain-controlled with dispatch stub explicit. No transport/generation/provider/OS-cold/LCP/p95 or universal137unit claim.'};(W/'reference-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['private','polling']}))
