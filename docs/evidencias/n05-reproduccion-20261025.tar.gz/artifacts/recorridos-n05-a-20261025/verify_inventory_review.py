import ast,hashlib,json,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n05-a-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:assert k not in d;d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
r=read(W/'inventory-review.json');assert r['STATUS']=='complete'
for k in ['FILES_CHANGED','TESTS_RUN','ASSUMPTIONS','RISKS','UNRESOLVED_ISSUES','RECOMMENDATIONS']:assert isinstance(r[k],list)
for k in ['IMPLEMENTATION_NOTES','TEST_RESULTS']:assert isinstance(r[k],str)
cites=[]
def walk(x):
 if isinstance(x,dict):
  if {'file','sha256','quote','line_start','line_end'}<=set(x):cites.append(x)
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(r)
snapshots=read(W/'review-snapshot-map.json')
for c in cites:
 assert sha(snapshots[c['file']]['snapshot'])==c['sha256'],c['file'];lines=Path(snapshots[c['file']]['snapshot']).read_text().splitlines();assert c['quote'] in '\n'.join(lines[c['line_start']-1:c['line_end']])
n00=read('docs/evidencias/n00-matriz-acciones-prioridades-20261025.json');expected={a['id'] for a in n00['actions'] if 'N05'in a['blocks']};assert expected=={a['id'] for a in r['action_dispositions']} and len(expected)==137
product=read('docs/evidencias/b16-final-candidate-reconciliation-20261025.json')['current_versioned_executable_sources'];gallery=read('artifacts/local-ci/20261024-064310-28e0f5bb/source-hashes.json')
for s in r['source_bridges']:
 p=s['file'];assert sha(p)==s['current_sha256']==s['B16_sha256']==product[p]
 assert sha(p)==s['gallery064310_sha256']==gallery[p]
original=[]
for row in r['original_JUnit']:
 p=Path(row['file']);assert sha(p)==row['sha256'];cs=list(E.parse(p).iter('testcase'));lookup={(x.attrib['classname'],x.attrib['name']):x for x in cs}
 for c in row['selected_cases']:
  x=lookup[(c['classname'],c['name'])];assert not any(x.find(k)is not None for k in ['failure','error','skipped'])
 original.append({'file':str(p),'selected_original_pass':len(row['selected_cases']),'original_other_failures':sum(x.find('failure')is not None for x in cs),'scope':'Original selected outcomes, not a new all137browserPASS or whole historical green run'})
def process(p):return next(n for n in ast.parse(Path(p).read_text()).body if isinstance(n,ast.FunctionDef)and n.name=='process')
def image_pipeline(p):
 t=next(n for n in process(p).body if isinstance(n,ast.Try));stop=next(i for i,n in enumerate(t.body) if isinstance(n,ast.With) and any(isinstance(i.context_expr,ast.Call) and isinstance(i.context_expr.func,ast.Attribute) and i.context_expr.func.attr=='atomic' for i in n.items));return ast.dump(ast.Module(body=t.body[:stop],type_ignores=[]),include_attributes=False)
old=Path('artifacts/recorridos-n03-b-20261025/services-before.py');assert sha(old)==gallery['apps/mediafiles/services.py'];assert image_pipeline(old)==image_pipeline('apps/mediafiles/services.py')
bs=read('artifacts/recorridos-n03-b-20261025/candidate-scope.json');assert sha('apps/mediafiles/similarity.py')==bs['apps/mediafiles/similarity.py']['after'];d=read('artifacts/recorridos-n03-d-20261025/candidate-scope.json');assert sha('apps/mediafiles/tasks.py')==d['apps/mediafiles/tasks.py']['after_sha256'];f=read('artifacts/recorridos-n03-f-20261025/candidate-scope.json');assert sha('apps/mediafiles/services.py')==f['apps/mediafiles/services.py']['after_sha256']
out={'result':'N05_ALL_CENSUS_CURRENT_SOURCES_AND_SELECTED_ORIGINAL_WITNESSES_VERIFIED_NOT_ACCEPTANCE','actions':137,'direct_sources':len(r['source_bridges']),'citations':len(cites),'selected_original_JUnit':original,'pixel_pipeline_AST_identical_to_gallery':True,'current_N03_source_scope_verified':True,'limits':'137support units not137independentfunctions. Gallery historical browser/bytes only; current private/poll references and final source/action reconciliation pending. Other documented fixture variants retained explicitly.','native_tokens':None}
(W/'review-verification.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
