import ast,hashlib,json,runpy,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n05-c-20261025');B=Path('artifacts/recorridos-n05-b-20261025');A=Path('artifacts/recorridos-n05-a-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:assert k not in d;d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
# Root verifies the original selected outcomes, all direct source identities and pixel pipeline again.
runpy.run_path(str(A/'verify_inventory_review.py'),run_name='__n05_inventory_verifier__')
r=read(B/'oracle-review-corrected.json');assert r['STATUS']=='complete' and not r['concrete_issues']
for k in ['FILES_CHANGED','TESTS_RUN','ASSUMPTIONS','RISKS','UNRESOLVED_ISSUES','RECOMMENDATIONS']:assert isinstance(r[k],list)
for k in ['IMPLEMENTATION_NOTES','TEST_RESULTS']:assert isinstance(r[k],str)
cites=[]
def walk(x):
 if isinstance(x,dict):
  if {'file','sha256','quote','line_start','line_end'}<=set(x):cites.append(x)
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(r);snap=read(B/'review-snapshot-map.json')
for c in cites:
 p=Path(snap[c['file']]['snapshot']);assert sha(p)==c['sha256'];assert c['quote']in '\n'.join(p.read_text().splitlines()[c['line_start']-1:c['line_end']])
reference=read(B/'reference-audit.json');compat=read(W/'compatibility-audit.json');assert reference['cleanup_verified'] and compat['cleanup_verified']
assert reference['result'].startswith('PASS_N05B') and compat['result'].startswith('PASS_N05C')
for run,count in [(reference['run'],4),(compat['run'],6)]:
 p=Path('artifacts/local-ci')/run;rr=read(p/'result.json');cs=list(E.parse(p/'pytest.xml').iter('testcase'));assert rr['result']=='PASS' and rr['sources_unchanged'] and len(cs)==count and not any(c.find(k)is not None for c in cs for k in ['failure','error','skipped']);assert read(p/'telegram-notification.json')['delivery']=='sent'
fB=read(B/'reference-freeze-corrected.json')['sources'];fC=read(W/'reference-freeze.json')['sources'];assert set(fB)==set(fC)
assert {p for p in fB if fB[p]!=fC[p]}=={'.ai/tasks/desarrollo.md'}
post={p:{'frozen':h,'current':sha(p)} for p,h in fC.items() if sha(p)!=h};assert set(post)=={'.ai/tasks/desarrollo.md'},post
for s in compat['summary']:
 assert all(s['body_dimension_parity_vs155'].values());assert (s['initial_images'],s['initial_decoded_bytes'],s['complete_images'],s['complete_decoded_bytes'],s['paused_status'])==(1,11110,8,135824,404)
assert compat['browser_versions']==['156.0.8078.47'] and compat['default_browser_same_before_after'] and len(compat['focus'])==4 and sum(x['observations'] for x in compat['focus'])==18
assert all(x['browser']=='156.0.8078.47' for x in reference['summary'])
first=read(B/'first-reference-audit.json');assert first['result'].startswith('PRESERVED_FIRST_REFERENCE_3PASS_1FAIL') and first['cleanup_verified']
sc=read(B/'corrected-reference-source-scope.json');assert sc['state']=='NO_APPLICATION_CHANGE_BETWEEN_BROWSER_REFERENCES'
mat=read(A/'inventory-review.json')['action_dispositions'];ids={x['id'] for x in mat};n00=read('docs/evidencias/n00-matriz-acciones-prioridades-20261025.json');assert ids=={x['id'] for x in n00['actions'] if 'N05'in x['blocks']} and len(ids)==137
ledger=read(W/'final-action-matrix.json');assert len(ledger['action_dispositions'])==137 and {x['id'] for x in ledger['action_dispositions']}==ids and ledger['mandatory_accepted']==6 and not ledger['remaining_N05_mandatory']
original={x['id']:x for x in mat}
for x in ledger['action_dispositions']:
 assert x['census_owners']==original[x['id']]['census_owners'] and x['sources']==original[x['id']]['sources'] and not x['per_unit_runtime_claim']
out={'result':'PASS_N05_FINITE_MEDIA_FRONTEND_ACTIONS_AND_NO_CHANGE_DISPOSITION_ROOT_VERIFIED','head_before_acta':'d6580c6','census_units':137,'routes':5,'templates':129,'custom_js':3,'direct_sources':138,'inventory_source_citations':read(A/'review-verification.json')['citations'],'corrected_oracle_review_citations':len(cites),'current_reference_run':reference['run'],'current_reference_cases':4,'compatibility_run':compat['run'],'compatibility_cases':6,'runs_are_separate_not_10_case_integrated_run':True,'current_browser':'156.0.8078.47','gallery_current_quality_exact_vs_historical':True,'original_3PASS_1FAIL_preserved_cause_not_confirmed':True,'application_change':False,'post_run_worklog_only':post,'decision':'No product candidate justified; accepted selected gallery/private/polling/keyboard scopes and source-based representative137unit dispositions, not137independent runtime guarantees.','next_mandatory_accepted_if_acta_integrated':6,'mandatory_total':13,'retained_owners':['N07','N09','N11'],'limits':'Local loopback Chromium/files/PG. Eager photo generation and controlled jobs.dispatch/claim/finish are explicit, not broker/worker/provider/generation credit. No LCP/p95/Internet/proxy/universalWCAG or opening.'}
(W/'final-acceptance-verification.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
