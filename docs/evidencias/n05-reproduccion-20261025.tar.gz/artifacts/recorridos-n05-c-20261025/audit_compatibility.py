import ast,hashlib,json,shutil,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n05-c-20261025');P=Path('artifacts/local-ci')/sys.argv[1];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:assert k not in d;d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
r=read(P/'result.json');f=read(W/'reference-freeze.json');assert r['result']=='PASS' and r['sources_unchanged'] and r['selection']==f['selection'] and r['workers']==1;assert all(sha(p)==h for p,h in f['sources'].items())
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==6 and not any(c.find(k)is not None for c in cs for k in ['failure','error','skipped'])
gallery=[];focus=[];versions=set()
for c in cs:
 props={x.attrib['name']:x.attrib['value'] for x in c.iter('property')}
 if 'gallery_delivery_diagnostic'in props:
  d=ast.literal_eval(props['gallery_delivery_diagnostic']);versions.add(d['browser_version']);gallery.extend(d['reports'])
 elif 'error_focus_observed'in props:
  rows=json.loads(props['error_focus_observed']);private='private_native'in c.attrib['name'];assert len(rows)==(3 if private else 6)
  assert {tuple(x['viewport']) for x in rows}=={(320,800),(390,844),(1280,900)};assert all(x['tag']=='UL' for x in rows)
  focus.append({'case':c.attrib['name'],'observations':len(rows),'viewports':sorted({tuple(x['viewport']) for x in rows}),'focused_tag':'UL','scope':'Original server-rejection focus/Enter/Tab/ARIA and private-state assertions passed, no universalWCAG'})
 else:raise AssertionError('Missing native gallery/focus properties')
assert len(gallery)==len(focus)==4 and versions=={'156.0.8078.47'}
assert {(x['language'],x['viewport']) for x in gallery}=={(lang,view) for lang in ['es','en'] for view in ['mobile','desktop']}
gallery=json.loads(json.dumps(gallery))
old=read('docs/evidencias/b09-gallery-corrected-audit-20261024.json')['reports'];oldmap={(x['language'],x['viewport']):x for x in old};summary=[]
for row in gallery:
 assert row['complete_photo_requests']==8 and row['paused_photo_status']==404 and len(row['photo_sha256'])==8 and row['loading'][0]!='lazy' and row['loading'][1:]==['lazy']*7
 for asset in row['assets']:
  p=Path('static')/Path(asset['path']).name;assert asset['sha256']==sha(p) and asset['bytes']==p.stat().st_size
 previous=oldmap[(row['language'],row['viewport'])]
 parity={k:row[k]==previous[k] for k in ['photo_sha256','dimensions','complete_photo_requests','complete_photo_body_bytes']}
 summary.append({'language':row['language'],'viewport':row['viewport'],'initial_images':row['initial_photo_requests'],'initial_decoded_bytes':row['initial_photo_body_bytes'],'complete_images':8,'complete_decoded_bytes':row['complete_photo_body_bytes'],'body_dimension_parity_vs155':parity,'paused_status':404})
before=read(W/'browser-context.json');actual=subprocess.check_output([shutil.which('chromium-browser'),'--version'],text=True).strip();assert actual==before['default_browser']['version'] and all(v in actual for v in versions)
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_N05C_CURRENT_CHROMIUM_SELECTED_GALLERY_KEYBOARD_NOT_N05_ACCEPTANCE','run':P.name,'junit':r['junit'],'source_count':len(f['sources']),'sources_unchanged':True,'selected_original_tests_unchanged':True,'browser_versions':sorted(versions),'default_browser_same_before_after':True,'gallery':gallery,'summary':summary,'focus':focus,'cleanup_verified':True,'telegram':tg,'scope':'Six selected unchanged native cases, four gallerylocale/viewports and18focus observations. CurrentChrome156, not global all137template/WCAG/p95/provider or imagecodec optimization.'};(W/'compatibility-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['gallery','focus']}))
