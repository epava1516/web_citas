# Grafo alfa — candidato de guard físico N02B

N00/N01aceptados2/13,N02/N06abiertos,alfa. Protocolo362: cambiar sólo guard de imágenes de sello válido a lote,cardinalidad estricta y todos los bytes/hash conservados. Etapa2imágenes7→4SQL previsto;12muestras pareadas y bloqueos reales/último archivo alterado previstos,14oráculos originales PASS del intento inicial y2casos nuevos por repetir;sin muestras aceptadas aún. Comparación361 no es ganancia integrada ni aceptaciónMOD09.2s/5s/FAIL/excepción conservados.

Refresco focal semántico362 más AST del instrumento y sustitución de llamada del guard por ASTPython/import local. Restante módulo ASTidéntico y base previa preservada;no reconstrucción global/semántica exhaustiva. 1957fuentes,18362nodos/80761relaciones,869comunidades.1505ejecutables originales intactos,1runnerinstrumental y1candidatodeapp explícito;100anotaciones ambiguas conservadas. JSONcompleto,HTMLcomunidades. Consumo nativo desconocido.

