from config.settings import *
MEDIA_ROOT = Path(os.environ["PUBLICATION_PROBE_OUTPUT"]) / "private"
CELERY_TASK_DEFAULT_QUEUE = os.environ["POSTGRES_DB"]
CELERY_TASK_ALWAYS_EAGER = False
CELERY_BEAT_SCHEDULE = {"refresh-publication-state": CELERY_BEAT_SCHEDULE["refresh-publication-state"]}
