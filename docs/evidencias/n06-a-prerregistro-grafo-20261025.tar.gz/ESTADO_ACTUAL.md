# Grafo alfa — prerregistro de atribución N06A

N00/N01aceptados2/13;N06abierto. Protocolo356:2casos/3POSTstart previstos,originales de revisión/rechazo sin modificar;atribución SQL entre autoridad/create_draft/tareas eager/otro. Eager no acredita cola real;no candidato de app ni resultado nuevo todavía.

Refresco focal semántico nativo de356 más ASTnuevo tests/test_listing_start_cost_baseline.py,4funciones,7nodos propios/23relaciones AST. 1948fuentes,18219nodos/80390relaciones,863comunidades. ASTprevio y base reconstruida preservados;no reconstrucción completa ni semántica exhaustiva.1506ejecutables originales intactos,runner instrumental variante explícita. Consumo nativo desconocido,JSONcompleto,HTMLcomunidades,100anotaciones ambiguas/exclusiones previas conservadas. Vista17líneas1–4. Semántica no prueba runtime.

