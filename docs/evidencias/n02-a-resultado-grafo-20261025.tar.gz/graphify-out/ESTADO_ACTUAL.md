# Grafo alfa — resultado pareado N02A

N00/N01aceptados2/13,N02/N06abiertos. Resultado361:5PASS/24observaciones de mecanismos existentes,medianas335,200→219,565ms y324,301→238,831ms;48→3SQL,16lecturas completas/hash por llamada,1500revisiones/~16MiBJSON/16WebP~64MiB por cohorte. Sin cambio integrado ni aceptaciónHTTP/p95MOD09;2s/5s/FAIL/excepción preservados. Fallo de calibración inicial conservado. Revisión del llamador aceptada como fuentes21SHA,no prueba de locks runtime.

Refresco semántico focal361/341/README/vista17líneas1–4,AST previo intacto;1955fuentes,18330nodos/80645relaciones,868comunidades. Base completa anterior preservada,no reconstrucción global ni semántica exhaustiva.1506ejecutables originales intactos y runner instrumental;100anotaciones ambiguas originales preservadas. JSONcompleto y HTMLproyección de comunidades. Consumo nativo desconocido,ceros técnicos no equivalen a coste cero.

