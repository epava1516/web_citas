import collections,hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
W=Path('artifacts/recorridos-n09-f-20261026');P=Path('artifacts/local-ci')/sys.argv[1]
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f,r,h=read(W/'candidate-freeze.json'),read(P/'result.json'),read(P/'source-hashes.json')
assert r['result']=='PASS' and r['sources_unchanged'] and r['selection']==f['selection']
assert all(sha(p)==v for p,v in f['sources'].items())
assert set(f['sources'])-set(h)==set(f['sources_verified_separately'])
assert all(h[p]==v for p,v in f['sources'].items() if p in h)
cases=list(ET.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==75
assert len({(c.get('classname'),c.get('name')) for c in cases})==75
assert not any(c.find(t) is not None for c in cases for t in ['failure','error','skipped'])
original=read(W/'baseline-audit.json');base={x['runtime']['label']:x for x in original['cases']}
waits={};variants={};originals=[]
for c in cases:
 props={p.get('name'):p.get('value') for p in c.iter('property')}
 if 'rectification_authority_wait' in props:
  d=json.loads(props['rectification_authority_wait']);assert d['label'] not in waits;waits[d['label']]=d
 elif 'rectification_authority_variant' in props:
  d=json.loads(props['rectification_authority_variant']);assert d['variant'] not in variants;variants[d['variant']]=d
 else:originals.append({'classname':c.get('classname'),'name':c.get('name'),'seconds':float(c.get('time'))})
families=['preview','propose','source_photo','upload','discard','inspect','review','notify','execute','recipients']
assert set(waits)=={a+':'+b for a in families for b in ['valid','permission']}
changed=lambda d:{k for k,v in d['domain_before']['tables'].items() if v!=d['domain_after']['tables'][k]}
comparison=[]
for label,d in waits.items():
 assert d['actual_wait'] and d['worker_pid']!=d['holder_pid'] and d['holder_pid'] in d['blocker_pids']
 assert d['thread_finished'] and d['connections_closed'] and d['holder_released']
 family,variant=label.split(':');b=base[label]['runtime']
 assert d['files_before']==d['files_after']
 if variant=='permission':
  assert d['permission_revoked'] and d['status']=='PermissionDenied'
  assert d['domain_before']==d['domain_after'] and d['minimal_before']==d['minimal_after']
  assert d['account_source_returns_after_revocation']==d['source_snapshot_returns_after_revocation']==0
  assert d['process_blob_delay_calls']==0 and d['private_stream_bytes']==0
  if family=='source_photo':assert d['http_status']==403 and d['response_closed'] and d['response_private']
 else:
  assert d['status']=='success' and not d['permission_revoked'] and changed(d)==changed(b)
  for table in changed(b):
   assert (d['domain_after']['tables'][table]['count']-d['domain_before']['tables'][table]['count'])==(b['domain_after']['tables'][table]['count']-b['domain_before']['tables'][table]['count'])
  if family=='source_photo':assert d['http_status']==200 and d['private_stream_bytes']==b['private_stream_bytes']>0 and d['response_closed']
 comparison.append({'family':family,'variant':variant,'baseline_status':b['status'],'candidate_status':d['status'],'baseline_case_seconds':b['elapsed_seconds_including_setup_wait_cleanup'],'candidate_case_seconds':d['elapsed_seconds_including_setup_wait_cleanup'],'baseline_changed_tables':sorted(changed(b)),'candidate_changed_tables':sorted(changed(d)),'baseline_http_status':b.get('http_status'),'candidate_http_status':d.get('http_status'),'baseline_private_bytes':b['private_stream_bytes'],'candidate_private_bytes':d['private_stream_bytes']})
expected_variants={'stale_actor:'+x for x in ['session','mfa','inactive','mfa_disabled']}|{'completed_replay:'+x for x in ['propose','upload','discard','review','notify','execute','recipients']}
assert set(variants)==expected_variants
for d in variants.values():
 assert not d['actual_wait_claimed'] and d['surface']=='native_service'
 assert d['domain_before']==d['domain_after'] and d['files_before']==d['files_after']
 assert d['metrics']['account_source_returns']==d['metrics']['source_snapshot_returns']==d['metrics']['process_blob_delay_calls']==0
assert len(originals)==44
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q']
 assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists()
tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_N09F75_SCOPED_CANDIDATE_AUDIT','run':P.name,'junit':r['junit'],'frozen_sources':len(f['sources']),'cases':75,'actual_waits':20,'valid_controls':10,'revoked_denials_without_effects':10,'stale_actor_cases':4,'revoked_replays':7,'originals':44,'comparisons':comparison,'wait_records':waits,'variant_records':variants,'original_cases':originals,'cleanup_verified':True,'telegram':tg,'limits':'Native services except photoHTTP;callbacks eager not worker;private helper-return oracle not all internal projections;firstwait upload/discard not final explicit lock. Timings whole cases incl setup/wait/snapshots,not normal app causal performance. No closure of N09full139 or remaining contract.'}
(W/'candidate-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['comparisons','wait_records','variant_records','original_cases']}))
