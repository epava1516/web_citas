import collections, hashlib, json, subprocess, sys, xml.etree.ElementTree as ET
from pathlib import Path
W = Path('artifacts/recorridos-n09-f-20261026')
P = Path('artifacts/local-ci') / sys.argv[1]
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
f, result, h = read(W/'baseline-freeze.json'), read(P/'result.json'), read(P/'source-hashes.json')
assert result['sources_unchanged'] and result['selection'] == f['selection']
assert all(sha(p) == value for p, value in f['sources'].items())
assert set(f['sources']) - set(h) == set(f['sources_verified_separately'])
assert all(h[p] == value for p, value in f['sources'].items() if p in h)
cases = list(ET.parse(P/'pytest.xml').iter('testcase'))
assert len(cases) == f['expected_cases'] == 20
records = {}
for c in cases:
    props = {p.get('name'):p.get('value') for p in c.iter('property')}
    d = json.loads(props['rectification_authority_wait'])
    assert d['label'] not in records
    records[d['label']] = {'runtime':d, 'failure':c.find('failure') is not None,
                           'error':c.find('error') is not None, 'skip':c.find('skipped') is not None}
families = ['preview','propose','source_photo','upload','discard','inspect','review','notify','execute','recipients']
assert set(records) == {a+':'+b for a in families for b in ['valid','permission']}
def wait_ok(row):
    d = row['runtime']
    return (d.get('actual_wait') and d.get('worker_pid') != d.get('holder_pid')
            and d.get('holder_pid') in d.get('blocker_pids', [])
            and d.get('thread_finished') and d.get('connections_closed')
            and d.get('holder_released') and not row['error'] and not row['skip'])
classified = []
for family in families:
    control = records[family+':valid']; d = control['runtime']
    valid = bool(wait_ok(control) and not control['failure'] and d.get('status') == 'success')
    classified.append({'family':family, 'variant':'valid',
        'verdict':'VALID_NATIVE_CONTROL' if valid else 'INVALID_CONTROL_DIAGNOSTIC', **control})
    row = records[family+':permission']; d = row['runtime']
    admissible = valid and wait_ok(row) and d.get('permission_revoked')
    unchanged = (d.get('domain_before') == d.get('domain_after')
                 and d.get('minimal_before') == d.get('minimal_after')
                 and d.get('files_before') == d.get('files_after'))
    private_returns = d.get('account_source_returns_after_revocation',0) + d.get('source_snapshot_returns_after_revocation',0)
    if not admissible:
        verdict = 'INVALID_PERMISSION_DIAGNOSTIC'
    elif d.get('status') == 'success':
        if family == 'source_photo' and d.get('http_status') == 200 and d.get('private_stream_bytes',0)>0:
            verdict = 'CONFIRMED_PRIVATE_HTTP_BYTES_AFTER_PERMISSION_REVOCATION'
        elif not unchanged:
            verdict = 'CONFIRMED_NATIVE_EFFECT_AFTER_PERMISSION_REVOCATION'
        else:
            verdict = 'NATIVE_SUCCESS_AFTER_REVOCATION_REQUIRES_RETURN_SCOPE_REVIEW'
    elif d.get('status') == 'PermissionDenied' and unchanged:
        if private_returns:
            verdict = 'CONFIRMED_PRIVATE_HELPER_RETURN_BEFORE_LATE_DENIAL'
        elif not row['failure'] and not d.get('process_blob_delay_calls',0) and not d.get('private_stream_bytes',0):
            verdict = 'DENIED_NO_REPRODUCTION_AT_DECLARED_BOUNDARY'
        else:
            verdict = 'DENIAL_WITH_UNCLASSIFIED_ORACLE_FAILURE'
    else:
        verdict = 'UNCLASSIFIED_REQUIRES_REVIEW'
    classified.append({'family':family, 'variant':'permission', 'verdict':verdict, **row})
for kind in ['container','volume','network']:
    cmd = ['docker','ps','-aq'] if kind == 'container' else ['docker',kind,'ls','-q']
    assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists()
tg = read(P/'telegram-notification.json'); assert tg['delivery'] == 'sent'
counts = dict(collections.Counter(x['verdict'] for x in classified))
out = {'result':'TWENTY_RECTIFICATION_DIAGNOSTICS_CLASSIFIED_NOT_CONTRACT_ACCEPTANCE',
       'run':P.name, 'original_result':result['result'], 'junit':result['junit'],
       'frozen_sources':len(f['sources']), 'verdict_counts':counts, 'cases':classified,
       'cleanup_verified':True, 'telegram':tg,
       'limits':'Controls must pass before attributing negative. Nine native services are not HTTP disclosure evidence. Helper-return counters do not exhaust internal projections; firstwait upload/discard inside source_snapshot, not final explicit locks. N09E38 retained,N09open139,8of13.'}
(W/'baseline-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='cases'}))
