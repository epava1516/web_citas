# Revisión diferencial N09F — resolución local

Ámbito: siete fuentes de rectificación, tests nuevos20+11 y44originales seleccionados; base6d4c288. Se revisaron DjangoReviewer, code-security, django-access-review y criterios de differential-review con adaptación a rutas autenticadas. Informe root, no aceptación delegada ni certificación global.

## Autoridad y superficie

Capture_authority cierra sobre pk/session/MFA originales antes de los locks. User fresco activo/no suprimido, MFA/epochs y permisos completos, ámbito permitted; ninguna fila de operador se bloquea. Base2, review extra y respond extra en notify/execute; current recibe el mismo callable, no rebaja roles. Fronteras canónicas y últimas filas explícitas revisadas antes de replay, proyección, descifrado o efectos.

Source_snapshot conserva User→Revision→Uploads→Blob→Rate/Photo y digest/orden. Identificadores bloqueados antes de materializar metadatos; callback entre ambas fases. PhoneClaim prelock justo antes de binding evita modificar consumidores ajenos. Account source/validate/apply guardan User y EmailConfirmation; execute revalida después de contacts.claim. Modelos, migraciones, templates, servicios, cifrado y guardas proof/audit/independence/version existentes preservados. Se retiró un check adyacente redundante sin nuevo recurso entre ambos.

## Evidencia que resuelve los hallazgos confirmados

Baseline20:10controlesPASS/10revocacionesFAIL236,664s,9efectosnativos+1GET200/9558bytessintéticos trasespera/revocación. Candidata75PASS1035,569s:20esperas reales10valid/10denied,snapshots íntegros/0retornosprivadosafterrevoke/0delay/0bytes;11staleactor/replays y44originales. 1776huellas/limpieza/Telegram auditados. Original20byteidéntico, sin debilitar negativos. Un informe complete del escritor no se usó como prueba.

## Conclusión acotada y pendientes

Los diez hallazgos reproducidos quedan corregidos en las fronteras observadas. No se afirma seguridad de todo el repositorio ni serialización universal después del último check. Contadores de retorno no agotan materialización interna; filas ORM User/Revision sí se obtienen al bloquear. CallbacksNone/rectification_final.evidence y ramas tardías no observadas retienen disposición propia. La regresión funcional de email/contactos/catálogos no equivale a revocación concurrente. Añaden consultas, sin mejora de rendimiento acreditada ni nuevo benchmark de carga. N09full139 y contrato siguen abiertos.
