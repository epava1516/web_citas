import hashlib,json
from pathlib import Path
w=Path('artifacts/recorridos-n01-b-20261025')
for folder,prefix in [(w,'/tmp/web-modelos-n01b-prereg-semantic/'),(w/'context','/tmp/web-modelos-n01-result-semantic/')]:
 r=json.loads((folder/'semantic-report.json').read_text());assert r['STATUS']=='complete' and not r['UNRESOLVED_ISSUES']
 expected=json.loads((folder/'semantic-inputs.json').read_text());view=prefix+'followup-current-view.md';expected[view]={'source':'docs/17-seguimiento-desarrollo.md','sha256':hashlib.sha256(Path(view).read_bytes()).hexdigest()}
 assert {f['source_file'] for f in r['READ_INPUTS']}==set(expected)
 for f in r['READ_INPUTS']:
  source=Path(f['source_file']);assert f['fully_read'] and hashlib.sha256(source.read_bytes()).hexdigest()==f['source_sha256']==expected[str(source)]['sha256']
  rel=str(source).split(prefix,1)[1];p=folder/'input-snapshots'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(source.read_bytes())
print('PASS_BOTH_REPORT_CONTRACTS_AND6SOURCE_INPUTS; original format errors preserved separately; no product/runtime acceptance')
