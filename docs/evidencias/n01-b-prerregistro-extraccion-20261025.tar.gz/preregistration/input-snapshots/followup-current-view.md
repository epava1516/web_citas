N01Bprerregistradoen [346](346-n01-b-prerregistro-segmentos-20261025.md):un caso,100perfiles,ES/EN,listado/página2/perfil/vacío/ficha,6peticionesporsegmento(60). Instrumentonuevosin cambioproducto;antesdeejecución,grafosemántico/ASTycongelaciónpendientes. N00aceptado1/13,N01encurso,alfa.

Siguiente:conciliar prerregistro e instrumento,congelar,ejecutarselecciónexacta y auditar;no p95/capacidadni comparacióncausal primera/posteriores. Tablasantes/despuésal cerrarbloque. Antecedentesinferioresconservancorte.

