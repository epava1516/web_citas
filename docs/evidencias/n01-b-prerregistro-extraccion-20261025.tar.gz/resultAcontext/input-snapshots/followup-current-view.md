N01Aterminalyauditado:2PASS/0FAIL/ERROR/SKIP,run20261025-081326-9844f827;listadoES10/100perfiles,0,624848/0,247264sinstrumentadosy52/29SQL. Sin mejoracausal,niTCP/p95/capacidad. [Resultado345](345-n01-a-diagnostico-descubrimiento-20261025.md). N00aceptado1/13;N01encurso,alfa.

Siguiente:incorporar semántica de345/este corte antesdelnuevohitoN01;prerregistrar misma poblaciónfrío/caliente ysegmentos restantesS01. Tablaantes/después obligatoria porbloque;N00en343. Antecedentes inferiores conservan corte.

