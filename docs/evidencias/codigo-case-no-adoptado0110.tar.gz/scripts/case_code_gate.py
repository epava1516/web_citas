"""Explicit test-only activation of optional CASE code, no callable replacement."""
import pytest


@pytest.fixture(autouse=True)
def optional_case_code(monkeypatch):
    from apps.listings import projected_publication as p
    from apps.listings import sql_publication as s
    monkeypatch.setitem(p.projected_page.__kwdefaults__, 'case_code', True)
    monkeypatch.setitem(s.SQLPublication.__init__.__kwdefaults__, 'case_code', True)
