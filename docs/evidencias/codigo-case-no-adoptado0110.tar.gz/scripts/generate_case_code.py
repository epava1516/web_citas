"""Development-only offline generation; run from repository root with its venv.

The exact compiler reference lives in the focal prototype test. This script
never connects to PostgreSQL and must not run in an application worker.
"""


def main():
    import os
    import re
    import sys
    from pathlib import Path

    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
    sys.path[:0] = [str(Path.cwd()), str(Path.cwd() / "tests")]
    import django

    django.setup()
    from django.apps import apps
    from django.db import connection
    from test_sql_expression_template_probe import prepare_template

    body, paths, params, instant, marker = prepare_template()
    tables = set(re.findall(r'\b(?:FROM|JOIN) "([^"]+)"', body))
    # Add the outer-model bindings reached through reference paths.
    from apps.listings.models import Listing

    for path in paths:
        model = Listing
        tables.add(model._meta.db_table)
        for part in path.split("__"):
            field = model._meta.get_field(part)
            if field.is_relation:
                model = field.related_model
                tables.add(model._meta.db_table)
    models = {
        m._meta.db_table: m for m in apps.get_models(include_auto_created=True) if not m._meta.proxy
    }
    assert tables <= models.keys(), tables - models.keys()
    labels = tuple(sorted(models[t]._meta.label_lower for t in tables))
    values = []
    for p in params:
        if p == instant:
            values.append("now")
        elif p == marker:
            values.append("document_version")
        else:
            values.append(repr(p))
    source = (
        '"""Reviewed V1 CASE program only; no database facts or eligibility cache."""\n'
        'from decimal import Decimal\nfrom psycopg.types.numeric import Int4\n\n\n'
        'def case_code_v1():\n    return ' + repr((body, paths)) + '\n\n\n'
        'def case_parameters_v1(document_version, now):\n    return (\n        '
        + ',\n        '.join(values) + ',\n    )\n\n\n'
        'def case_model_labels_v1():\n    return ' + repr(labels) + '\n'
    )
    compile(source, '<generated CASE code>', 'exec')
    assert connection.connection is None, 'Code generation must not read a database'
    Path('apps/listings/sql_case_code.py').write_text(source)
    print({'code_chars':len(body),'outer_columns':len(paths),'models':len(labels),'params':len(values)})


if __name__ == '__main__':
    main()
