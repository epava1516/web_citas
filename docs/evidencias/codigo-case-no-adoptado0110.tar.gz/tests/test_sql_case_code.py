"""Optional static program: current binding and fail-closed dependency boundary."""
from functools import wraps
from unittest.mock import patch

import pytest
from django.db import connection
from django.db.models import CharField
from django.db.models.lookups import Exact
from django.utils import timezone
from test_discovery import directory  # noqa: F401
from test_photos import photo_environment  # noqa: F401
from test_projected_publication import native_ids
from test_sql_expression_template_probe import prepare_template

from apps.listings import projected_publication as p
from apps.listings import sql_case_code as code
from apps.listings import sql_case_template as template
from apps.listings import sql_publication as proof
from apps.listings.discovery import candidates
from apps.listings.models import Listing
from scripts.synthetic_load_dataset import populate

pytestmark = pytest.mark.django_db(transaction=True)


def test_generated_program_is_exact_and_bindings_are_fresh(request, record_property):
    client = request.getfixturevalue('directory')
    body, paths, values, instant, marker = prepare_template()
    assert code.case_code_v1() == (body, paths)
    bound = code.case_parameters_v1(marker, instant)
    assert bound == values
    assert [type(v) for v in bound] == [type(v) for v in values]
    assert p.supported(case_code=True)
    response = client.get('/es/')
    assert response.wsgi_request._publication_route['candidate_stats']['case_code']
    # No SQL data in the program: changing current bindings affects each new
    # expression, while its column paths/program stay identical.
    first = template.CurrentCaseCode('v-a', instant)
    now = timezone.now()
    second = template.CurrentCaseCode('v-b', now)
    assert first.statement == second.statement
    assert 'v-a' in first.parameters and 'v-a' not in second.parameters
    assert 'v-b' in second.parameters and now in second.parameters and instant not in second.parameters
    query = candidates({})
    old = proof.SQLPublication(query, case_code=False)
    new = proof.SQLPublication(query, case_code=True)
    assert new.rows == old.rows
    assert new.visible_ids(query) == native_ids(query)
    assert new.stats['case_code'] and not old.stats['case_code']
    record_property('program', {'code_only':True,'current_binds':True,'exact_generated_types':True,
        'real_public_route':'projection','case_code':True})


def test_extended_dependencies_reject_changed_program_manager_lookup_and_column(request, monkeypatch):
    request.getfixturevalue('directory')
    assert p.supported(case_code=True)
    original = code.case_code_v1

    @wraps(original)
    def modified_program():
        body, paths = original()
        return body.replace(' THEN %s', ' THEN NOT %s'), paths

    with monkeypatch.context() as m:
        m.setattr(code, 'case_code_v1', modified_program)
        assert not p.supported(case_code=True)
        assert p.projected_page(candidates({}), 1, case_code=True) is None
    with monkeypatch.context() as m:
        m.setitem(vars(Listing.objects), 'get_queryset', lambda: Listing._base_manager.none())
        assert not p.supported(case_code=True)
    class ChangedExact(Exact):
        def as_sql(self, compiler, connection):
            return 'TRUE', []
    with monkeypatch.context() as m:
        lookups = dict(CharField.class_lookups)
        lookups['exact'] = ChangedExact
        m.setattr(CharField, 'class_lookups', lookups)
        CharField._clear_cached_class_lookups()
        try:
            assert not p.supported(case_code=True)
        finally:
            m.undo()
            CharField._clear_cached_class_lookups()
    with monkeypatch.context() as m:
        m.setattr(Listing._meta.get_field('expires_at'), 'column', 'different_expiry_column')
        assert not p.supported(case_code=True)
    assert p.supported(case_code=True)


def test_dependency_change_after_capture_recomputes_native_count_pages(request, monkeypatch, record_property):
    client = request.getfixturevalue('directory')
    populate(50)
    expected = native_ids(candidates({}))
    changes = []
    original = code.case_parameters_v1

    @wraps(original)
    def changed(version, now):
        return original(version, now)

    def after_execute(execute, sql, params, many, context):
        value = execute(sql, params, many, context)
        if 'AS "_sql_publication_positive"' in sql and not changes:
            monkeypatch.setattr(code, 'case_parameters_v1', changed)
            changes.append(True)
        return value

    with connection.execute_wrapper(after_execute):
        result = client.get('/es/', {'page':'2'})
    assert changes == [True]
    route = result.wsgi_request._publication_route
    assert route['route'] == 'fallback' and route['reason'] == 'definitions_changed_during_request'
    assert result.context['page'].paginator.count == 50
    assert [row.pk for row in result.context['page']] == expected[24:48]
    # Even transparent but unaudited wrappers conservatively fallback. wraps is
    # metadata, never a certificate of semantic transparency.
    with patch.object(p, 'supported', lambda **kwargs:False):
        native = client.get('/es/', {'page':'2'})
    assert result.content == native.content
    record_property('late_dependency_change', {'native_full_count':50,'page2_equal':True,'body_equal':True})


def test_actual_template_alias_change_outside_page_is_guarded(request, monkeypatch, record_property):
    from apps.listings.models import Revision
    client = request.getfixturevalue('directory')
    populate(50)
    expected = native_ids(candidates({}))
    target = Listing.objects.get(pk=expected[25])
    Revision.objects.filter(pk=target.approved_revision_id).update(description='www.example.invalid')
    native = native_ids(candidates({}))
    assert len(native)==49 and target.pk not in native
    original = template.case_code_v1
    @wraps(original)
    def semantic_alias():
        body, paths = original()
        return body.replace('CASE WHEN (', 'CASE WHEN (TRUE OR ', 1), paths
    monkeypatch.setattr(template, 'case_code_v1', semantic_alias)
    # Demonstrate that the changed alias really affects the SQL component:
    # an unguarded caller would get50 positives, including the invalid offpage row.
    unguarded = proof.SQLPublication(candidates({}),case_code=True)
    assert len(unguarded.visible_ids(candidates({})))==50
    assert unguarded.stats['positive']==50
    assert not p.supported(case_code=True)
    for page in [1,2,3]:
        result=client.get('/es/',{'page':str(page)})
        assert result.wsgi_request._publication_route['route']=='fallback'
        assert result.context['page'].paginator.count==49
        assert [row.pk for row in result.context['page']]==native[(page-1)*24:page*24]
    record_property('alias_boundary',{'unguarded_sql_count':50,'native_count':49,
        'public_fallback_pages_equal':True,'target_outside_first_page':True})


def test_unrelated_lazy_lookup_registration_does_not_disable_program(request):
    request.getfixturevalue('directory')
    assert p.supported(case_code=True)
    before = p.definitions_digest(case_code=True)
    import django.contrib.postgres.fields  # noqa: F401
    assert p.definitions_digest(case_code=True)==before
    assert p.supported(case_code=True)
