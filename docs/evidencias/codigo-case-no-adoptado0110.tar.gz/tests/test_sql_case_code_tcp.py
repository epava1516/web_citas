"""Owned serial TCP A/B of optional CASE program, no load gate."""
import hashlib
import json
import os
import re
import socket
import statistics
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import pytest
from django.conf import settings
from django.db import connection
from test_discovery import directory  # noqa: F401
from test_photos import photo_environment  # noqa: F401
from test_projection_cost_cycle import alpha
from test_projection_http_jit_context import stats_snapshot

from apps.listings import projected_publication as projection
from apps.listings.models import Revision
from scripts.query_pattern_redaction import query_pattern
from scripts.synthetic_load_dataset import populate

pytestmark = [pytest.mark.django_db(transaction=True), pytest.mark.skipif(
    not os.getenv('CASE_CODE_TCP_OUTPUT'), reason='Explicit isolated serial TCP comparison only')]


@pytest.mark.parametrize('variant', ['contractual', 'diverse'])
def test_case_code_tcp_comparison(request, tmp_path, monkeypatch, record_property, variant):
    request.getfixturevalue('directory')
    populate(10000)
    if variant == 'diverse':
        rows = list(Revision.objects.filter(status='approved').order_by('pk'))
        for index, row in enumerate(rows):
            suffix = alpha(index)
            row.description += ' ' + suffix
            if row.description_alternative:
                row.description_alternative += ' ' + suffix
            row.telegram = 'bench' + suffix
        Revision.objects.bulk_update(rows, ['description', 'description_alternative', 'telegram'], batch_size=250)
    db = connection.settings_dict
    assert connection.vendor == 'postgresql' and db['NAME'].startswith('test_promotion_gate_')
    assert projection.supported() and projection.supported(case_code=True)
    digest = projection.definitions_digest()
    with connection.cursor() as cursor:
        for table in connection.introspection.table_names():
            cursor.execute('ANALYZE ' + connection.ops.quote_name(table))
    (tmp_path/'case_code_tcp_settings.py').write_text(
        'from config.settings import *\nMEDIA_ROOT = ' + repr(str(settings.MEDIA_ROOT)) +
        '\nCELERY_TASK_ALWAYS_EAGER = True\nCELERY_BEAT_SCHEDULE = {}\n')
    config = tmp_path/'case_code_tcp_gunicorn.py'
    config.write_text('''import os
def post_worker_init(worker):
    from apps.listings import projected_publication as projection
    assert projection.supported() and projection.supported(case_code=True)
    get_response = worker.wsgi.get_response
    def selected_response(request):
        mode = request.META.get('HTTP_X_CASE_CODE_COMPARISON')
        if mode not in {'A', 'B'}:
            return get_response(request)
        original = projection.projected_page.__kwdefaults__['case_code']
        projection.projected_page.__kwdefaults__['case_code'] = mode == 'B'
        try:
            response = get_response(request)
        finally:
            projection.projected_page.__kwdefaults__['case_code'] = original
        route = getattr(request, '_publication_route', {})
        stats = route.get('candidate_stats', {})
        presentation = getattr(request, '_presentation_reads', {})
        response['X-Diagnostic-Route'] = route.get('route', 'missing')
        response['X-Diagnostic-Scalar'] = str(int(bool(stats.get('scalar_capture'))))
        response['X-Diagnostic-Index'] = str(int(bool(stats.get('text_membership'))))
        response['X-Diagnostic-Positive'] = str(stats.get('positive', -1))
        response['X-Diagnostic-Unknown'] = str(stats.get('native_fallback', -1))
        response['X-Diagnostic-Case-Code'] = str(int(bool(stats.get('case_code'))))
        response['X-Diagnostic-Grouped'] = str(int(bool(presentation.get('grouped'))))
        response['X-Diagnostic-Photo-Native'] = str(presentation.get('photo_native', -1))
        response['X-Diagnostic-Check-Native'] = str(presentation.get('check_native', -1))
        response['X-Diagnostic-Worker'] = str(os.getpid())
        return response
    worker.wsgi.get_response = selected_response
''')
    environment = os.environ.copy()
    environment.update(POSTGRES_DB=db['NAME'], POSTGRES_USER=db['USER'], POSTGRES_PASSWORD=db['PASSWORD'],
        DB_HOST=db['HOST'], DB_PORT=str(db['PORT']), APP_ENV='development', DJANGO_DEBUG='0',
        DJANGO_SETTINGS_MODULE='case_code_tcp_settings', PYTHONPATH=str(tmp_path)+os.pathsep+str(Path.cwd()),
        REDIS_URL='memory://')
    environment.pop('WEB_MODELOS_BENCHMARK_OBSERVER_DIR', None)
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
    origin = f'http://127.0.0.1:{port}'
    routes = [('listing-es', '/es/'), ('listing-en', '/en/'),
              ('search-es', '/es/?q=photography'), ('search-en', '/en/?q=synthetic')]
    bodies, samples, warmup = {}, [], []
    process = None
    report = {'variant': variant, 'source_fingerprint': digest, 'stage': 'prepared',
              'runtime_configuration_sha256': hashlib.sha256(config.read_bytes()).hexdigest()}
    output = Path(os.environ['CASE_CODE_TCP_OUTPUT'], variant+'.json')

    def persist():
        output.write_text(json.dumps(report, indent=2)+'\n')

    def fetch(label, path, mode):
        start = time.perf_counter()
        with urllib.request.urlopen(urllib.request.Request(origin+path,
                headers={'X-Case-Code-Comparison': mode}), timeout=65) as response:
            body = response.read()
            status = response.status
            headers = response.headers
        elapsed = time.perf_counter()-start
        assert status == 200 and re.search(rb'<p>10000 (?:results|resultados)</p>', body)
        assert headers['X-Diagnostic-Route'] == 'projection'
        assert headers['X-Diagnostic-Scalar'] == '1'
        assert headers['X-Diagnostic-Index'] == '1'
        assert headers['X-Diagnostic-Positive'] == '10000' and headers['X-Diagnostic-Unknown'] == '0'
        assert headers['X-Diagnostic-Case-Code'] == str(int(mode == 'B'))
        assert headers['X-Diagnostic-Grouped'] == '1'
        assert headers['X-Diagnostic-Photo-Native'] == '0'
        assert headers['X-Diagnostic-Check-Native'] == '0'
        bodies.setdefault(label, body)
        assert body == bodies[label]
        return {'family': label, 'mode': mode, 'seconds': elapsed,
                'worker_pid': int(headers['X-Diagnostic-Worker']), 'status': status,
                'body_sha256': hashlib.sha256(body).hexdigest(), 'route': 'projection',
                'scalar': True, 'indexed': True, 'case_code': mode == 'B', 'grouped':True, 'positive': 10000, 'unknown': 0}

    try:
        with (tmp_path/'gunicorn-private.log').open('w') as log:
            process = subprocess.Popen([sys.executable, '-m', 'gunicorn', '--config', str(config),
                'config.wsgi:application', '--bind', f'127.0.0.1:{port}', '--workers', '4',
                '--timeout', '65', '--worker-class', 'sync'], env=environment,
                stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic()+45
        while True:
            try:
                with urllib.request.urlopen(origin+'/health/', timeout=2) as response:
                    assert response.status == 200
                break
            except (OSError, urllib.error.URLError):
                assert process.poll() is None and time.monotonic() < deadline
                time.sleep(.1)
        # Warm every observed worker/mode before timing controls. Bound this
        # startup check; missing workers cannot silently become a four-worker run.
        seen = set()
        for index in range(96):
            label, path = routes[index % len(routes)]
            mode = 'AB'[(index // len(routes)) % 2]
            sample = fetch(label, path, mode)
            warmup.append(sample)
            seen.add((sample['worker_pid'], mode))
            if len(seen) == 8 and len({p for p, _ in seen}) == 4:
                break
        assert len(seen) == 8
        before = stats_snapshot()
        orders = [('A','B'), ('B','A')]*4
        for pair, order in enumerate(orders):
            for label, path in routes:
                for mode in order:
                    sample = fetch(label, path, mode)
                    assert (sample['worker_pid'], mode) in seen, 'Unexpected unprimed/restarted worker'
                    samples.append({'pair': pair, **sample})
            report.update(stage='controls', samples=samples, warmup=warmup)
            persist()
        after = stats_snapshot()
        medians = {f: {m: statistics.median(s['seconds'] for s in samples if s['family']==f and s['mode']==m)
                       for m in 'AB'} for f, _ in routes}

        def comparison(a, b, minimum, fraction):
            deltas = [statistics.mean(
                next(s['seconds'] for s in samples if s['pair']==pair and s['family']==f and s['mode']==a)
                - next(s['seconds'] for s in samples if s['pair']==pair and s['family']==f and s['mode']==b)
                for f, _ in routes) for pair in range(8)]
            reference = statistics.mean(v[a] for v in medians.values())
            no_regression = all(v[b]-v[a] <= max(.025, .05*v[a]) for v in medians.values())
            return {'paired_mean_family_deltas': deltas,
                    'effect': statistics.median(deltas) >= max(minimum, fraction*reference)
                              and sum(d > 0 for d in deltas) >= 6 and no_regression}

        report.update(stage='complete', medians=medians, samples=samples, warmup=warmup,
            material_effect=comparison('A','B',.05,.08), statistics_before=before,
            statistics_after=after, statistics_endpoints_equal=before==after,
            scope='Full serial loopback TCP, own Gunicorn4sync, same scalar/index/grouped-presentation backend/schema/data. Eight counterbalanced AB/BA pairs each ES/EN listing/search, max1outstanding. A builds current CASE and uses original dependency guard; B uses static program plus its extended dependency guard, fresh document/time and ordinary candidate Query column resolution. Test-only default selector does not replace protected callables. Actual route/flags/count/exact bodies asserted each request. Same headers/hook, no server profiler/SQL/render events. Allworkers/modes warmed, full response body timed. No capacity/uploads or normal runtime change. No database facts cached. Native equivalence/focal prototype plans reused.',
            not_measured=['validation/render per-rule events inside TCP controls','rows_affected/scanned',
                          'causal selector overhead','PG CPU/RSS/waits/locks/IO','capacity','uploads'])
    finally:
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
        report.update(own_server_stopped=process is None or process.poll() is not None,
                      server_returncode=process.returncode if process is not None else None)
        persist()
    assert projection.definitions_digest() == digest and projection.supported()
    # SQL observation separately AFTER controls/server termination; not HTTP
    # controls or CPU PostgreSQL. Existing equivalent main/read plans reused.
    client = request.getfixturevalue('directory')
    from django.db.models.sql.compiler import SQLCompiler
    from psycopg import Cursor
    from apps.listings import sql_publication as proof
    from apps.listings.sql_case_template import CurrentCaseCode
    from scripts.benchmark_local_monitor import LocalCallMonitor
    observations = []
    original = projection.projected_page.__kwdefaults__['case_code']
    try:
        for mode in ['A','B']:
            patterns = {}
            def sql_timer(execute, sql, params, many, context):
                start = time.perf_counter()
                try:
                    return execute(sql,params,many,context)
                finally:
                    bucket = patterns.setdefault(query_pattern(sql), {'calls':0,'total_time':0.})
                    bucket['calls'] += 1
                    bucket['total_time'] += time.perf_counter()-start
            projection.projected_page.__kwdefaults__['case_code'] = mode=='B'
            plain_start=time.perf_counter()
            plain=client.get('/es/')
            plain_elapsed=time.perf_counter()-plain_start
            assert plain.content==bodies['listing-es']
            targets=[proof.SQLPublication.__init__,proof.authority_proof,proof.content_proof,
                proof.read_ordered_scalar_population,proof.read_publication_values,
                SQLCompiler.as_sql,Cursor.fetchall,CurrentCaseCode.__init__,CurrentCaseCode.as_sql]
            observed_start=time.perf_counter()
            with LocalCallMonitor(targets) as monitor, connection.execute_wrapper(sql_timer):
                measured=client.get('/es/')
            observed_elapsed=time.perf_counter()-observed_start
            assert measured.content == bodies['listing-es']
            route=measured.wsgi_request._publication_route
            assert route['route']=='projection' and route['candidate_stats']['case_code']==(mode=='B')
            observations.append({'mode':mode, 'queries':sum(v['calls'] for v in patterns.values()),
                'sql_execute_seconds':sum(v['total_time'] for v in patterns.values()),
                'local_code_events':monitor.report(),'plain_client_seconds':plain_elapsed,
                'observed_client_seconds':observed_elapsed,
                'dominant_sql':[{'query_pattern':p,**v,'mean_time':v['total_time']/v['calls']}
                    for p,v in sorted(patterns.items(),key=lambda item:item[1]['total_time'],reverse=True)]})
    finally:
        projection.projected_page.__kwdefaults__['case_code']=original
    assert observations[0]['queries']==observations[1]['queries']
    report.update(separate_mechanism_observations=observations,
        observation_scope='Separate exploratory synchronous code-local events, no callable replacement. Constructor inclusive overlaps proof construction, Query compilation and full scalar read; directchildren only subtracted in exclusive. fetchall measures driver receipt/decoding scope, driverexecute may already buffer results; scalar read also builds dictionaries. execute is not PG CPU. All these observations add overhead, one adjacent plain/observed per mode only, no causal overhead or saving estimate; acceptance from64TCPcontrols alone.',
        plan_reuse='Expression prototype and common matrix primary/presentation reads, no SQL semantics/index/shape change intended; source and native boundary checked by N1.')
    persist()
    record_property('case_code_tcp_comparison', json.dumps(report))
