"""Current-request value projection; unknown proofs retain the native guard.

Nothing is persisted. Authority predicates are checked per candidate. Native
content validation may be shared only for equal complete content inputs under
the explicitly audited definitions; titles retain their independent rules.
"""

import hashlib
import inspect
import json
from collections import defaultdict
from datetime import date, datetime
from decimal import Decimal
from types import CodeType
from uuid import UUID

from django import forms
from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator
from django.db import connection
from django.db.migrations.serializer import serializer_factory
from django.db.models import prefetch_related_objects
from django.forms import models as model_forms
from django.utils import timezone
from django.utils.functional import SimpleLazyObject
from django.utils.translation import get_language

from apps.catalog.promotion_exposure import enabled as promotions_enabled
from apps.core import verification_services
from apps.core.models import LegalAcceptance
from apps.mediafiles.models import Photo

from . import forms as listing_forms
from . import history, moderation, public_validation, submissions
from .forms import ContactsForm, DetailsForm, RateForm
from .models import Rate, Revision
from .public_validation import (
    PublicationContext,
    SnapshotChoice,
    SnapshotDetails,
    SnapshotMultipleChoice,
    publication_query,
)
from .uuid_batches import CapturedUUIDBatch


def code_signature(code):
    """Executed bytecode/constants, without deployment path or source line numbers.

    Source lookup and inspect.unwrap can hide replacement runtime implementations.
    Every wrapper layer remains in the signature, including functools.wraps layers.
    Profiling therefore observes calls without changing the callable chain.
    This is a reviewed change detector, not a sandbox for arbitrary Python code.
    """
    def constant(value):
        if isinstance(value, CodeType):
            return code_signature(value)
        if isinstance(value, frozenset):
            return ("frozenset", sorted((constant(item) for item in value), key=repr))
        if isinstance(value, tuple):
            return ("tuple", [constant(item) for item in value])
        return (type(value).__name__, repr(value))
    return (code.co_code.hex(), [constant(value) for value in code.co_consts],
            code.co_names, code.co_varnames, code.co_freevars, code.co_cellvars,
            code.co_argcount, code.co_posonlyargcount, code.co_kwonlyargcount,
            code.co_flags, code.co_exceptiontable.hex())


def definitions(*, case_code=False):
    """Serializable audited code/metadata, independent of DB values and locale.

    Actual callable layers are fingerprinted; wraps is not evidence of transparency. A new
    validator, widget/configuration, constraint or instance rule is unsupported.
    The expected digest is reviewed source data, not learnt from a new request.
    """
    from . import sql_publication, text_proof

    classes = [DetailsForm, ContactsForm, RateForm, PublicationContext, SnapshotDetails, SnapshotChoice,
               SnapshotMultipleChoice, Revision, Rate, forms.Field, forms.CharField,
               forms.BooleanField, forms.ChoiceField, forms.MultipleChoiceField,
               forms.ModelChoiceField, forms.ModelMultipleChoiceField, forms.ModelForm,
               forms.TextInput, forms.Select, forms.CheckboxInput, forms.SelectMultiple]
    functions = [ProjectedPublication.page, ProjectedPublication.captured_revision,
                 sql_publication.read_ordered_scalar_population,
                 sql_publication.SQLPublication.visible_keys, sql_publication.SQLPublication.scalar_page,
                 sql_publication.SQLPublication.captured_revision, sql_publication.authority_proof, sql_publication.content_proof,
                 sql_publication.bulk_authority_membership, sql_publication.RowMembership.as_sql,
                 sql_publication.ordinary_matches, sql_publication.rectification_history_ids,
                 text_proof.IsNotTrueV1.as_sql, text_proof.PlainTextProofV1.__init__,
                 text_proof.PlainTextProofV1.as_sql, sql_publication.revision_text_unknown,
                 sql_publication.rate_text_unknown, sql_publication.PlainTextProof.__init__, sql_publication.PlainTextProof.as_sql,
                 sql_publication.JSONChoicesProof.__init__, sql_publication.JSONChoicesProof.as_sql,
                 sql_publication.SameNullable.as_sql, sql_publication.TelegramProof.as_sql,
                 sql_publication.SQLPublication.__init__, sql_publication.SQLPublication.visible_ids,
                 sql_publication.SQLPublication.certified_page, sql_publication.compact_order,
                 sql_publication.read_certified_page, sql_publication.CapturedSQLRead.__init__,
                 sql_publication.CapturedSQLRead.__iter__,
                 freeze, listing_forms.validate_details_values, listing_forms.validate_listing_text, listing_forms.normalize_telegram,
                 submissions.validate_submission, moderation.validate_submission,
                 moderation.publicly_visible, verification_services.publication_ready,
                 submissions.publication_ready, submissions.current_publishing_document,
                 publication_query, public_validation.publication_query,
                 history.ordinary_matches, history.rectification_history_ids,
                 model_forms.construct_instance, model_forms.model_to_dict,
                 public_validation.validate_publication_binding,
                 public_validation.validate_publication_value_fields,
                 public_validation.validate_publication_input_fields,
                 forms.BoundField.__init__, forms.BoundField.data.fget,
                 public_validation.memoize_publication_field_clean, SimpleLazyObject._setup,
                 public_validation.read_publication_values]
    for cls in classes:
        names = {"__init__", "clean", "full_clean", "clean_fields", "validate_unique",
                 "validate_constraints", "_get_unique_checks", "_perform_unique_checks",
                 "_perform_date_checks", "is_valid", "_clean_fields", "_clean_form",
                 "_post_clean", "_update_errors", "_get_validation_exclusions", "_bound_items",
                 "__getitem__", "get_bound_field", "_widget_data_value", "add_prefix", "_clean_bound_field", "to_python", "validate",
                 "run_validators", "postal_matches", "_check_values", "value_from_datadict",
                 "details", "details_valid", "contacts_valid", "rate_valid", "row",
                 "_bound_validation", "_memoize_field_clean", "fields_for_catalog"}
        names.update(name for name in dir(cls) if name.startswith("clean_"))
        functions.extend(getattr(cls, name) for name in sorted(names)
                         if callable(getattr(cls, name, None)))
    for model in [Revision, Rate]:
        for field in model._meta.concrete_fields:
            functions.extend(getattr(field, name) for name in
                             ["clean", "validate", "to_python", "run_validators", "save_form_data"])
            functions.extend(validator if inspect.isfunction(validator) else validator.__call__
                             for validator in field.validators)
    for cls in [DetailsForm, ContactsForm, RateForm]:
        for field in cls.base_fields.values():
            functions.extend(validator if inspect.isfunction(validator) else validator.__call__
                             for validator in field.validators)
    code = []
    for function in functions:
        layers = []
        seen = set()
        while True:
            function = getattr(function, "__func__", function)
            if id(function) in seen:
                raise ValueError("Cyclic callable wrapper")
            seen.add(id(function))
            layers.append(code_signature(function.__code__))
            if not hasattr(function, "__wrapped__"):
                break
            function = function.__wrapped__
        code.append(layers)
    field_options = []
    for cls in [DetailsForm, ContactsForm, RateForm]:
        field_options.append((cls.__name__, cls._meta.model._meta.label,
                              tuple(cls._meta.fields), cls._meta.exclude, cls.bound_field_class))
        for name, field in cls.base_fields.items():
            attrs = {key: value for key, value in vars(field).items()
                     if key not in {"label", "help_text", "error_messages", "widget",
                                    "creation_counter", "_choices", "_queryset"}}
            # Query predicates, not cached evaluation of the restricted queryset.
            if hasattr(field, "queryset"):
                attrs["queryset"] = field.queryset.query.sql_with_params()
            if hasattr(field, "choices") and not hasattr(field, "queryset"):
                attrs["choices"] = list(field.choices)
            attrs["widget"] = (type(field.widget).__module__, type(field.widget).__qualname__,
                               field.widget.attrs, getattr(field.widget, "allow_multiple_selected", None))
            # Migration serialization gives stable defaults, validators and types.
            field_options.append((cls.__name__, name, type(field).__module__,
                                  type(field).__qualname__, serializer_factory(attrs).serialize()[0]))
    models = []
    for model in [Revision, Rate]:
        models.append((model.__name__, [field.deconstruct() for field in model._meta.fields],
                       [field.deconstruct() for field in model._meta.many_to_many],
                       model._meta.unique_together,
                       [item.deconstruct() for item in model._meta.constraints]))
    result = code, field_options, serializer_factory(models).serialize()[0]
    if case_code:
        from . import sql_case_code, sql_case_template

        helpers = [sql_case_code.case_code_v1, sql_case_code.case_parameters_v1, sql_case_code.case_model_labels_v1,
                   sql_case_template.case_code_v1, sql_case_template.case_parameters_v1,
                   sql_case_template.case_model_labels_v1,
                   sql_case_template.CurrentCaseCode.__init__, sql_case_template.CurrentCaseCode.as_sql,
                   sql_case_template._literal_config, sql_case_template.dependency_record]
        extra = []
        for helper in helpers:
            layers, seen = [], set()
            while True:
                if id(helper) in seen:
                    raise ValueError("Cyclic CASE helper wrapper")
                seen.add(id(helper))
                layers.append(code_signature(helper.__code__))
                if not hasattr(helper, "__wrapped__"):
                    break
                helper = helper.__wrapped__
            extra.append(layers)
        return *result, extra, sql_case_template.dependency_record()
    return result


# Updated only with a reviewed native rule/metadata change and equivalence gates.
EXPECTED_DEFINITIONS = "7d424f63e60f8ae89e36172b05897165973a54e12f7e0dc9ad7adab9fe687575"


def definitions_digest(*, case_code=False):
    return hashlib.sha256(json.dumps(definitions(case_code=case_code), sort_keys=True, default=str).encode()).hexdigest()


EXPECTED_CASE_DEFINITIONS = "8506ac6a88989d5d8b12d4bd1cb71e1f94cf08a8bea1e2d8f5e96812d1d414d9"


def supported(*, checked=False, case_code=False):
    if connection.vendor != "postgresql" or settings.PRODUCTION or checked or promotions_enabled():
        return False
    try:
        return definitions_digest(case_code=case_code) == (EXPECTED_CASE_DEFINITIONS if case_code else EXPECTED_DEFINITIONS)
    except (TypeError, ValueError, AttributeError, OSError, LookupError):
        return False


def freeze(value):
    """Exact typed inputs; unsupported containers request native fallback."""
    if value is None or type(value) in (str, bool, int, float, Decimal, UUID, date, datetime):
        return (type(value), value)
    if type(value) in (list, tuple):
        return (type(value), tuple(freeze(item) for item in value))
    raise TypeError("Unknown publication input")


class ProjectedPublication:
    def __init__(self, query, *, sql=False, sql_setwise=False, sql_bulk=True, sql_json=True, sql_page=True, page_number=None, sql_legacy_text=True, sql_text_membership=True, sql_scalar_capture=True, sql_case_code=False):
        self.page_read = sql_page
        self.sql_projection = None
        if sql:
            from .sql_publication import SQLPublication

            self.sql_projection = SQLPublication(query, setwise=sql_setwise, bulk=sql_bulk, json_path=sql_json, page_number=page_number, legacy_text=sql_legacy_text, text_membership=sql_text_membership, scalar_capture=sql_scalar_capture, case_code=sql_case_code)
            self.rows = self.sql_projection.rows
            self.by_id = self.sql_projection.by_id
            self.stats = self.sql_projection.stats
            return
        self.document = submissions.current_publishing_document()
        self.validation_prototypes = {}
        self.field_clean_cache_stats = {}
        scalar_fields = [field for field in Revision._meta.concrete_fields]
        columns = ["pk", "status", "person_id", "expires_at", "approved_revision_id"]
        columns += ["approved_revision__" + field.attname for field in scalar_fields]
        columns += ["person__" + field.attname for field in
                    query.model._meta.get_field("person").related_model._meta.concrete_fields]
        columns += ["person__phone_claim__" + name for name in
                    ["phone", "verified_at", "individual_id", "agency_id"]]
        columns += ["person__agency__verification_status"]
        columns += ["_pv_" + name for name in ["history", "rectification_upload", "reintroduction",
                    "hold", "restriction", "grant", "conflict", "check_status",
                    "check_manager", "check_subject"]]
        self.rows = public_validation.read_publication_values(
            publication_query(query, self.document).values(*columns))
        self.by_id = {row["pk"]: row for row in self.rows}
        revision_ids = [row["approved_revision_id"] for row in self.rows]
        revision_batch = CapturedUUIDBatch(revision_ids, mode="array")
        self.memberships = {name: defaultdict(list) for name in
                            ["categories", "services", "travel_areas", "rates", "photos"]}
        for name in ["categories", "services", "travel_areas"]:
            field = Revision._meta.get_field(name)
            through = field.remote_field.through
            pairs = revision_batch.filter(through.objects.all(), "revision_id").values_list(
                "revision_id", field.m2m_reverse_field_name() + "_id"
            )
            for revision_id, target_id in pairs:
                self.memberships[name][revision_id].append(target_id)
        for values in revision_batch.filter(Rate.objects.all(), "revision_id").values_list(
            "revision_id", *RateForm.Meta.fields
        ):
            self.memberships["rates"][values[0]].append(values[1:])
        for revision_id, ready, complete in revision_batch.filter(Photo.objects.filter(
            removed_at__isnull=True
        ), "revision_id").values_list("revision_id", "blob__status", "comparison_complete"):
            self.memberships["photos"][revision_id].append((ready, complete))
        self.acceptances = {
            obj.pk: obj for obj in LegalAcceptance.objects.filter(
                pk__in={row["approved_revision__publisher_acceptance_id"] for row in self.rows}
            ).select_related("document")
        }
        self.catalog = {}
        for name in ["categories", "services", "travel_areas", "municipality",
                     "province", "region", "postal_code", "zone"]:
            if name in self.memberships:
                identifiers = {value for values in self.memberships[name].values() for value in values}
            elif name in ["region", "province"]:
                # Filled below from the current municipality hierarchy.
                continue
            else:
                identifiers = {row["approved_revision__" + name + "_id"] for row in self.rows}
            items = DetailsForm.base_fields[name].queryset.filter(pk__in=identifiers)
            if name == "municipality":
                items = items.select_related("province__region")
            self.catalog[name] = {str(obj.pk): obj for obj in items}
        for name, identifiers in [
            ("province", {city.province_id for city in self.catalog["municipality"].values()}),
            ("region", {city.province.region_id for city in self.catalog["municipality"].values()}),
        ]:
            self.catalog[name] = {str(obj.pk): obj for obj in
                                  DetailsForm.base_fields[name].queryset.filter(pk__in=identifiers)}
        postals = list(self.catalog["postal_code"].values())
        prefetch_related_objects(postals, "municipalities")
        for postal in postals:
            postal._publication_cities = {city.pk for city in postal.municipalities.all()}
        self.prepared_fields = SnapshotDetails.fields_for_catalog(self.catalog)
        self.title_field = DetailsForm().fields["title"]
        self.memo = {name: {} for name in ["details", "contacts", "rates"]}
        self.stats = {"candidates": len(self.rows), "positive": 0, "native_fallback": 0,
                      "details_native": 0, "contacts_native": 0, "rates_native": 0}

    def authority(self, row):
        """Per-row fresh inputs, never a memoized authority result."""
        def person(name):
            return row["person__" + name]

        def revision(name):
            return row["approved_revision__" + name]
        if (row["status"] != "published" or revision("status") != "approved"
                or revision("listing_id") != row["pk"] or not row["expires_at"]
                or row["expires_at"] <= timezone.now()):
            return False
        if any(row["_pv_" + name] for name in
               ["history", "rectification_upload", "reintroduction", "hold", "restriction", "conflict"]):
            return False
        if (person("publication_erased_at") or person("consent_revoked_at")
                or not person("subject_id") or person("age_status") != "passed"
                or person("manager_review_status") != "approved"
                or person("consent_version") != person("manager_version")
                or revision("manager_version") != person("manager_version")):
            return False
        if (not person("phone_claim_id") or not row["person__phone_claim__verified_at"]
                or row["person__phone_claim__individual_id"] != person("individual_id")
                or row["person__phone_claim__agency_id"] != person("agency_id")
                or revision("phone") != row["person__phone_claim__phone"]):
            return False
        if person("agency_id") and row["person__agency__verification_status"] != "passed":
            return False
        document = self.document
        acceptance = self.acceptances.get(revision("publisher_acceptance_id"))
        if (not document or not acceptance or not acceptance.document.active
                or acceptance.document.slug != "publishing"
                or acceptance.document.version != document.version
                or acceptance.action != "publish" or acceptance.agency_id != person("agency_id")
                or not row["_pv_grant"] or row["_pv_check_status"] != "passed"
                or row["_pv_check_manager"] != person("manager_version")
                or row["_pv_check_subject"] != person("subject_id")):
            return False
        return True

    def native_content(self, kind, data, instance, factory):
        key = (get_language(), id(self.catalog), freeze(data))
        if key not in self.memo[kind]:
            self.stats[kind + "_native"] += 1
            # Definitions depend on form kind, this request's catalog and locale;
            # binding data/model/errors never belong to a shared prototype.
            prototype_key = (kind, id(self.catalog), get_language())
            if prototype_key not in self.validation_prototypes:
                prototype = factory(data, instance)
                if kind in {"details", "contacts"}:
                    for name, field in prototype.fields.items():
                        if name != "title":
                            stats = self.field_clean_cache_stats.setdefault(
                                (prototype_key, name), {"calls": 0, "hits": 0, "misses": 0}
                            )
                            public_validation.memoize_publication_field_clean(field, stats)
                self.validation_prototypes[prototype_key] = prototype
            prototype = self.validation_prototypes[prototype_key]
            inputs = dict(zip(RateForm.Meta.fields, data, strict=True)) if kind == "rates" else dict(data)
            if not public_validation.validate_publication_binding(
                    prototype, inputs, instance, value_model=kind in {"details", "contacts"}):
                return False  # Errors are never reused; native fallback owns them.
            self.memo[kind][key] = True
        return True

    def positive(self, row):
        """Sufficient proof only; False means native fallback, never hidden."""
        if not self.authority(row):
            return False
        revision_id = row["approved_revision_id"]
        city = self.catalog["municipality"].get(str(row["approved_revision__municipality_id"]))
        if city is None:
            return False
        values = {field.attname: row["approved_revision__" + field.attname]
                  for field in Revision._meta.concrete_fields}
        # No database identity in the audited, instance-independent content rules.
        values["id"] = None
        def build_revision():
            revision = Revision(**values)
            revision.municipality = city
            return revision

        # Native title Field.clean does not inspect the model under the audited
        # definitions. Other rules force this proxy only on a real memo miss.
        # Unknown instance-dependent rules still disable the proof domain.
        instance = SimpleLazyObject(build_revision)
        data = {name: values[name] for name in DetailsForm.Meta.fields
                if not Revision._meta.get_field(name).many_to_many
                and name not in {"municipality", "postal_code", "zone"}}
        for name in ["categories", "services", "travel_areas"]:
            data[name] = self.memberships[name][revision_id]
        data.update(region=city.province.region_id, province=city.province_id,
                    municipality=city.pk, postal_code=values["postal_code_id"] or "",
                    zone=values["zone_id"] or "")
        try:
            # Only title-dependent native rules are independent in audited clean.
            title = self.title_field.clean(data["title"])
            listing_forms.validate_listing_text(title)
            Revision._meta.get_field("title").clean(title, instance)
            data["title"] = "Projected validation title"
            if not self.native_content("details", tuple(data.items()), instance,
                                       lambda pairs, obj: SnapshotDetails(
                                           self.catalog, dict(pairs), instance=obj,
                                           prepared_fields=self.prepared_fields)):
                return False
            contacts = {"whatsapp": values["whatsapp"], "telegram": values["telegram"],
                        "contact_exposure_accepted": values["contact_exposure_accepted"],
                        "accept_publishing": True, "legal_version": self.document.version}
            if not self.native_content("contacts", tuple(contacts.items()), instance,
                                       lambda pairs, obj: ContactsForm(dict(pairs), instance=obj)):
                return False
            rates = self.memberships["rates"][revision_id]
            if len(rates) > 10:
                return False
            for rate in rates:
                if not self.native_content("rates", rate, SimpleLazyObject(
                        lambda rate=rate: Rate(**dict(zip(RateForm.Meta.fields, rate, strict=True)))),
                                           lambda inputs, obj: RateForm(
                                               dict(zip(RateForm.Meta.fields, inputs, strict=True)),
                                               instance=obj)):
                    return False
            photos = self.memberships["photos"][revision_id]
            return 1 <= len(photos) <= 8 and all(status == "ready" and complete
                                                for status, complete in photos)
        except (ValidationError, TypeError):
            return False

    def page(self, query, number):
        if self.sql_projection is not None and self.sql_projection.compact:
            return self.sql_projection.certified_page(query, number)
        if self.sql_projection is not None and self.sql_projection.scalar_capture:
            return self.sql_projection.scalar_page(query, number)
        return Paginator(self.visible_ids(query), 24).page(number)

    def captured_revision(self, listing_id):
        if self.sql_projection is not None:
            return self.sql_projection.captured_revision(listing_id)
        return self.by_id[listing_id]["approved_revision_id"]

    def visible_ids(self, query):
        if self.sql_projection is not None:
            return self.sql_projection.visible_ids(query)
        if len({row["approved_revision_id"] for row in self.rows}) != len(self.rows):
            # A cross-listing approved pointer can collide in the native
            # context's by_revision map. Preserve native validation/errors for
            # that inconsistent population; a partial proof must not hide them.
            self.stats["native_fallback"] = len(self.rows)
            native = PublicationContext(query)
            return [row.pk for row in native.rows if moderation.publicly_visible(row, context=native)]
        positive = set()
        unknown = []
        for row in self.rows:
            if self.positive(row):
                positive.add(row["pk"])
                self.stats["positive"] += 1
            else:
                unknown.append(row["pk"])
        self.stats["native_fallback"] = len(unknown)
        if unknown:
            native = PublicationContext(query.filter(pk__in=unknown))
            positive.update(row.pk for row in native.rows if moderation.publicly_visible(row, context=native))
        return [row["pk"] for row in self.rows if row["pk"] in positive]


def projected_page(query, number, *, checked=False, observation=None, compact=False, case_code=False):
    """None asks the caller for the complete native path, including ranking."""
    if observation is not None:
        observation.update(route="fallback", reason="unsupported_definitions_or_mode")
    if not supported(checked=checked, case_code=case_code):
        return None
    # Reduced transfer remains an explicit experimental path: its isolated
    # comparison did not meet the prefixed material-effect threshold.
    projection = ProjectedPublication(query, sql=True, page_number=number if compact else None, sql_case_code=case_code)
    page = projection.page(query, number)
    if observation is not None:
        observation.update(candidate_stats=dict(projection.stats))
    if not supported(checked=checked, case_code=case_code):
        if observation is not None:
            observation["reason"] = "definitions_changed_during_request"
        return None  # A rule/configuration changed during this request.
    selected = list(page.object_list)
    native = PublicationContext(query.filter(pk__in=selected), page_read=projection.page_read)
    rows = {row.pk: row for row in native.rows}
    for listing_id in selected:
        row = rows.get(listing_id)
        if (row is None or row.approved_revision_id != projection.captured_revision(listing_id)
                or not moderation.publicly_visible(row, context=native)):
            # Confirmed change between projection and hydration: recompute native
            # population/count/order, rather than expose a stale/substituted row.
            if observation is not None:
                observation["reason"] = "native_page_guard_changed"
            return None
    if observation is not None:
        observation.update(route="projection", reason="audited_current_values",
                           hydrated_count=len(selected))
    page.object_list = [rows[listing_id] for listing_id in selected]
    return page
