"""Optional CASE code with fresh column resolution, bindings and dependency guard.

Only program text is precompiled. No database fact, validity result, document
version or time is retained between requests. The public caller checks the
extended reviewed fingerprint before capture and before the native page guard.
"""
import re

import django
from django.apps import apps
from django.db import connection
from django.db.models import BooleanField, F, Func
from django.db.models.query import QuerySet

from .sql_case_code import case_code_v1, case_model_labels_v1, case_parameters_v1


class CurrentCaseCode(Func):
    output_field = BooleanField()

    def __init__(self, document_version, now):
        self.statement, paths = case_code_v1()
        self.parameters = case_parameters_v1(document_version, now)
        super().__init__(*(F(path) for path in paths))

    def as_sql(self, compiler, connection, **kwargs):
        columns = []
        for expression in self.source_expressions:
            column, params = compiler.compile(expression)
            if params:
                raise ValueError('CASE code requires ordinary column references')
            columns.append(column)
        sql = re.sub(r'__CURRENT_COL_(\d+)__', lambda match: columns[int(match[1])], self.statement)
        return sql, self.parameters


def _literal_config(value):
    """Never repr/evaluate a QuerySet or serialize an arbitrary live object."""
    if value is None or type(value) in (bool, int, float, str):
        return (type(value).__name__, value)
    if isinstance(value, type):
        return ('class', tuple((base.__module__, base.__qualname__) for base in value.__mro__))
    if type(value) in (tuple, list):
        return (type(value).__name__, tuple(_literal_config(item) for item in value))
    if type(value) is dict and all(type(key) is str for key in value):
        return ('dict', tuple((key, _literal_config(item)) for key, item in sorted(value.items())))
    raise TypeError('Unknown CASE dependency configuration')


def dependency_record():
    """Fresh code/schema/query-manager metadata; never database row values.

    Literal template functions and native rules are included by definitions().
    This record additionally covers referenced table/column/FK bindings, field
    lookup registrations/implementations actually used by this program (exact,
    in, isnull, gt/gte/lt/lte), manager dispatch/configuration and
    the supported Django version. Unknown callable/configuration shapes reject
    the optional path. This remains a finite reviewed dependency boundary, not
    a sandbox against arbitrary mutation of Python or the database engine.
    """
    from .projected_publication import code_signature

    records, function_ids = [], {}

    def function_ref(function):
        function = getattr(function, '__func__', function)
        key = id(function)
        if key in function_ids:
            return function_ids[key]
        layers, seen = [], set()
        while True:
            if id(function) in seen:
                raise ValueError('Cyclic CASE dependency wrapper')
            seen.add(id(function))
            closure = tuple(_literal_config(cell.cell_contents) for cell in function.__closure__ or ())
            layers.append((code_signature(function.__code__), closure,
                           _literal_config(function.__defaults__), _literal_config(function.__kwdefaults__)))
            if not hasattr(function, '__wrapped__'):
                break
            function = function.__wrapped__
        reference = len(records)
        records.append(layers)
        function_ids[key] = reference
        return reference

    lookup_records, lookup_ids = [], {}

    def lookup_ref(lookup):
        if lookup in lookup_ids:
            return lookup_ids[lookup]
        methods = []
        for name in ['as_sql', 'as_postgresql', 'process_lhs', 'process_rhs',
                     'get_rhs_op', 'get_prep_lookup', 'get_db_prep_lookup']:
            method = getattr(lookup, name, None)
            if callable(method):
                methods.append((name, function_ref(method)))
        ref = len(lookup_records)
        lookup_records.append((lookup.__module__, lookup.__qualname__, methods))
        lookup_ids[lookup] = ref
        return ref

    models = []
    for label in case_model_labels_v1():
        model = apps.get_model(label)
        fields = []
        for field in model._meta.concrete_fields:
            target = getattr(field, 'target_field', None)
            fields.append((field.name, field.column, type(field).__module__, type(field).__qualname__,
                field.null, field.primary_key, getattr(field, 'db_collation', None),
                (target.model._meta.label_lower, target.column) if target is not None else None,
                [(name, lookup_ref(field.get_lookup(name))) for name in
                 ('exact', 'in', 'isnull', 'gt', 'gte', 'lt', 'lte')]))
        manager = model.objects
        if manager.model is not model or manager._queryset_class is not QuerySet:
            raise TypeError('Unreviewed CASE query manager')
        permitted = {'_constructor_args', 'creation_counter', 'model', 'name', '_db', '_hints', 'auto_created'}
        if set(vars(manager)) - permitted:
            raise TypeError('CASE manager has instance overrides')
        methods = [(name, function_ref(getattr(manager, name))) for name in
                   ['get_queryset', 'all', 'filter', 'exclude', 'order_by', 'values', 'annotate']]
        models.append((label, model._meta.db_table, fields,
            (type(manager).__module__, type(manager).__qualname__, manager.name, manager.auto_created,
             _literal_config(manager._constructor_args), _literal_config(manager._db),
             _literal_config(manager._hints), methods)))
    queryset_methods = [(name, function_ref(getattr(QuerySet, name))) for name in
        ['__init__', '_clone', '_chain', '_filter_or_exclude', '_filter_or_exclude_inplace',
         '_values', '_annotate', 'distinct']]
    return django.VERSION, models, records, lookup_records, queryset_methods, sorted(connection.operators.items())
