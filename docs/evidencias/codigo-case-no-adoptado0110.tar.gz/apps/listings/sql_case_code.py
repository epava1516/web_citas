"""Reviewed V1 CASE code, generated from the audited SQL proof.

This contains program text and static rule constants, never DB values or an
eligibility result. Regenerate/review when dependencies change; native guards
and fresh per-statement bindings are required. No runtime generation/cache.
"""

from decimal import Decimal

from psycopg.types.numeric import Int4


def case_code_v1():
    return ('CASE WHEN (__CURRENT_COL_0__ = (__CURRENT_COL_1__) AND __CURRENT_COL_2__ = (__CURRENT_COL_3__) AND __CURRENT_COL_4__ = (__CURRENT_COL_5__) AND __CURRENT_COL_6__ = %s AND __CURRENT_COL_7__ > %s AND __CURRENT_COL_8__ = %s AND __CURRENT_COL_9__ IS NULL AND __CURRENT_COL_10__ = (__CURRENT_COL_3__) AND __CURRENT_COL_11__ = %s AND __CURRENT_COL_12__ IS NOT NULL AND __CURRENT_COL_13__ IS NULL AND __CURRENT_COL_14__ IS NOT NULL AND __CURRENT_COL_15__ = %s AND NOT (__CURRENT_COL_16__ IN (SELECT V0."id" AS "pk" FROM "listings_revision" V0 INNER JOIN "listings_listing" V1 ON (V0."listing_id" = V1."id") WHERE EXISTS(SELECT %s AS "a" FROM "safety_rightsrectificationexecution" U0 INNER JOIN "safety_rightsrectificationnotification" U1 ON (U0."notification_id" = U1."id") INNER JOIN "safety_rightsrectificationreview" U2 ON (U1."review_id" = U2."id") INNER JOIN "safety_rightsrectificationproposal" U3 ON (U2."proposal_id" = U3."id") WHERE (U3."person_id" = (V1."person_id") AND NOT (U0."corrected_revision_id" = (V0."id") AND U0."corrected_revision_id" IS NOT NULL) AND (U3."source_revision_id" = (V0."id") OR U0."created_at" > (V0."created_at"))) LIMIT 1)) AND __CURRENT_COL_16__ IS NOT NULL) AND NOT (__CURRENT_COL_16__ IN (SELECT U0."revision_id" AS "revision_id" FROM "mediafiles_photo" U0 INNER JOIN "safety_rightsrectificationphotoupload" U1 ON (U0."id" = U1."photo_id") WHERE U1."id" IS NOT NULL) AND __CURRENT_COL_16__ IS NOT NULL) AND NOT (__CURRENT_COL_16__ IN (SELECT U1."revision_id" AS "photo__revision_id" FROM "safety_rightsphotoreintroduction" U0 INNER JOIN "mediafiles_photo" U1 ON (U0."photo_id" = U1."id")) AND __CURRENT_COL_16__ IS NOT NULL) AND NOT (__CURRENT_COL_17__ IN (SELECT U0."person_id" AS "person_id" FROM "safety_privacypublicationhold" U0 WHERE U0."active")) AND NOT (__CURRENT_COL_1__ IN (SELECT U0."listing_id" AS "listing_id" FROM "safety_restriction" U0 WHERE U0."active")) AND NOT (__CURRENT_COL_16__ IN (SELECT W2."revision_id" AS "photo__revision_id" FROM "mediafiles_match" W0 INNER JOIN "mediafiles_photo" W1 ON (W0."candidate_id" = W1."id") INNER JOIN "mediafiles_photo" W2 ON (W0."photo_id" = W2."id") INNER JOIN "listings_revision" W3 ON (W2."revision_id" = W3."id") INNER JOIN "listings_revision" W4 ON (W1."revision_id" = W4."id") LEFT OUTER JOIN "safety_rightsrectificationphotoupload" W5 ON (W2."id" = W5."photo_id") LEFT OUTER JOIN "safety_rightsrectificationphotoupload" W6 ON (W1."id" = W6."photo_id") WHERE ((W0."resolved_at" IS NULL OR W0."decision" = %s) AND W1."removed_at" IS NULL AND W0."decision" = %s AND W2."removed_at" IS NULL AND NOT (W2."revision_id" IN (SELECT V0."id" AS "pk" FROM "listings_revision" V0 INNER JOIN "listings_listing" V1 ON (V0."listing_id" = V1."id") WHERE EXISTS(SELECT %s AS "a" FROM "safety_rightsrectificationexecution" U0 INNER JOIN "safety_rightsrectificationnotification" U1 ON (U0."notification_id" = U1."id") INNER JOIN "safety_rightsrectificationreview" U2 ON (U1."review_id" = U2."id") INNER JOIN "safety_rightsrectificationproposal" U3 ON (U2."proposal_id" = U3."id") WHERE (U3."person_id" = (V1."person_id") AND NOT (U0."corrected_revision_id" = (V0."id") AND U0."corrected_revision_id" IS NOT NULL) AND (U3."source_revision_id" = (V0."id") OR U0."created_at" > (V0."created_at"))) LIMIT 1))) AND NOT (W1."revision_id" IN (SELECT V0."id" AS "pk" FROM "listings_revision" V0 INNER JOIN "listings_listing" V1 ON (V0."listing_id" = V1."id") WHERE EXISTS(SELECT %s AS "a" FROM "safety_rightsrectificationexecution" U0 INNER JOIN "safety_rightsrectificationnotification" U1 ON (U0."notification_id" = U1."id") INNER JOIN "safety_rightsrectificationreview" U2 ON (U1."review_id" = U2."id") INNER JOIN "safety_rightsrectificationproposal" U3 ON (U2."proposal_id" = U3."id") WHERE (U3."person_id" = (V1."person_id") AND NOT (U0."corrected_revision_id" = (V0."id") AND U0."corrected_revision_id" IS NOT NULL) AND (U3."source_revision_id" = (V0."id") OR U0."created_at" > (V0."created_at"))) LIMIT 1))) AND NOT (W3."status" = %s) AND NOT (W4."status" = %s) AND NOT (W5."id" IS NOT NULL) AND NOT (W6."id" IS NOT NULL))) AND __CURRENT_COL_16__ IS NOT NULL) AND NOT (__CURRENT_COL_16__ IN (SELECT W1."revision_id" AS "candidate__revision_id" FROM "mediafiles_match" W0 INNER JOIN "mediafiles_photo" W1 ON (W0."candidate_id" = W1."id") INNER JOIN "mediafiles_photo" W2 ON (W0."photo_id" = W2."id") INNER JOIN "listings_revision" W3 ON (W2."revision_id" = W3."id") INNER JOIN "listings_revision" W4 ON (W1."revision_id" = W4."id") LEFT OUTER JOIN "safety_rightsrectificationphotoupload" W5 ON (W2."id" = W5."photo_id") LEFT OUTER JOIN "safety_rightsrectificationphotoupload" W6 ON (W1."id" = W6."photo_id") WHERE ((W0."resolved_at" IS NULL OR W0."decision" = %s) AND W1."removed_at" IS NULL AND W0."decision" = %s AND W2."removed_at" IS NULL AND NOT (W2."revision_id" IN (SELECT V0."id" AS "pk" FROM "listings_revision" V0 INNER JOIN "listings_listing" V1 ON (V0."listing_id" = V1."id") WHERE EXISTS(SELECT %s AS "a" FROM "safety_rightsrectificationexecution" U0 INNER JOIN "safety_rightsrectificationnotification" U1 ON (U0."notification_id" = U1."id") INNER JOIN "safety_rightsrectificationreview" U2 ON (U1."review_id" = U2."id") INNER JOIN "safety_rightsrectificationproposal" U3 ON (U2."proposal_id" = U3."id") WHERE (U3."person_id" = (V1."person_id") AND NOT (U0."corrected_revision_id" = (V0."id") AND U0."corrected_revision_id" IS NOT NULL) AND (U3."source_revision_id" = (V0."id") OR U0."created_at" > (V0."created_at"))) LIMIT 1))) AND NOT (W1."revision_id" IN (SELECT V0."id" AS "pk" FROM "listings_revision" V0 INNER JOIN "listings_listing" V1 ON (V0."listing_id" = V1."id") WHERE EXISTS(SELECT %s AS "a" FROM "safety_rightsrectificationexecution" U0 INNER JOIN "safety_rightsrectificationnotification" U1 ON (U0."notification_id" = U1."id") INNER JOIN "safety_rightsrectificationreview" U2 ON (U1."review_id" = U2."id") INNER JOIN "safety_rightsrectificationproposal" U3 ON (U2."proposal_id" = U3."id") WHERE (U3."person_id" = (V1."person_id") AND NOT (U0."corrected_revision_id" = (V0."id") AND U0."corrected_revision_id" IS NOT NULL) AND (U3."source_revision_id" = (V0."id") OR U0."created_at" > (V0."created_at"))) LIMIT 1))) AND NOT (W3."status" = %s) AND NOT (W4."status" = %s) AND NOT (W5."id" IS NOT NULL) AND NOT (W6."id" IS NOT NULL))) AND __CURRENT_COL_16__ IS NOT NULL) AND ((__CURRENT_COL_17__, __CURRENT_COL_14__, __CURRENT_COL_3__, CASE WHEN (__CURRENT_COL_18__ IS NOT NULL) THEN %s ELSE %s END, CASE WHEN (__CURRENT_COL_18__ IS NOT NULL) THEN (__CURRENT_COL_18__)::varchar ELSE (__CURRENT_COL_19__)::varchar END) IN (SELECT U0."person_id" AS "person_id", U0."subject_id" AS "subject_id", U0."manager_version" AS "manager_version", U0."manager_kind" AS "manager_kind", U0."manager_id" AS "manager_id" FROM "core_representationaction" U0 INNER JOIN "core_legaldocument" U1 ON (U0."document_id" = U1."id") WHERE (U0."action" = %s AND U1."slug" = %s AND U1."version" = %s))) AND ((__CURRENT_COL_17__, __CURRENT_COL_14__, __CURRENT_COL_3__, %s) IN (SELECT "person_id", "subject_id", "manager_version", "status" FROM ( SELECT * FROM ( SELECT U0."person_id" AS "person_id", U0."subject_id" AS "subject_id", U0."manager_version" AS "manager_version", U0."status" AS "status", COUNT(U0."id") OVER (PARTITION BY U0."person_id", U0."created_at") AS "qual0", ROW_NUMBER() OVER (PARTITION BY U0."person_id" ORDER BY U0."created_at" DESC) AS "qual1" FROM "core_verificationcheck" U0 ) "qualify" WHERE ("qual1" = %s AND "qual0" = %s) ) "qualify_mask")) AND (__CURRENT_COL_20__ IS NOT DISTINCT FROM __CURRENT_COL_19__) AND (__CURRENT_COL_21__ IS NOT DISTINCT FROM __CURRENT_COL_18__) AND (__CURRENT_COL_18__ IS NULL OR __CURRENT_COL_22__ = %s) AND __CURRENT_COL_23__ = %s AND __CURRENT_COL_24__ AND __CURRENT_COL_25__ = %s AND __CURRENT_COL_26__ = %s AND (__CURRENT_COL_27__ IS NOT DISTINCT FROM __CURRENT_COL_18__) AND NOT (__CURRENT_COL_16__ IN (SELECT U0."id" AS "pk" FROM "listings_revision" U0 WHERE (((char_length(U0."title") <= %s AND (NOT %s OR btrim(U0."title", %s) <> \'\') AND (U0."title" COLLATE "C") ~ %s AND lower(U0."title" COLLATE "C") NOT LIKE %s AND (U0."title" COLLATE "C") !~ %s) AND (char_length(U0."description") <= %s AND (NOT %s OR btrim(U0."description", %s) <> \'\') AND (U0."description" COLLATE "C") ~ %s AND lower(U0."description" COLLATE "C") NOT LIKE %s AND (U0."description" COLLATE "C") !~ %s) AND (char_length(U0."description_alternative") <= %s AND (NOT %s OR btrim(U0."description_alternative", %s) <> \'\') AND (U0."description_alternative" COLLATE "C") ~ %s AND lower(U0."description_alternative" COLLATE "C") NOT LIKE %s AND (U0."description_alternative" COLLATE "C") !~ %s))) IS NOT TRUE) AND __CURRENT_COL_16__ IS NOT NULL) AND __CURRENT_COL_28__ IN (%s, %s) AND __CURRENT_COL_29__ IN (%s, %s, %s, %s) AND __CURRENT_COL_30__ IN (%s, %s, %s, %s) AND (jsonb_typeof(__CURRENT_COL_31__) = \'array\' AND __CURRENT_COL_31__ <@ %s::jsonb AND NOT jsonb_path_exists(CASE WHEN jsonb_typeof(__CURRENT_COL_31__) = \'array\' THEN __CURRENT_COL_31__ ELSE \'[]\'::jsonb END, %s::jsonpath)) AND (jsonb_typeof(__CURRENT_COL_32__) = \'array\' AND __CURRENT_COL_32__ <@ %s::jsonb AND NOT jsonb_path_exists(CASE WHEN jsonb_typeof(__CURRENT_COL_32__) = \'array\' THEN __CURRENT_COL_32__ ELSE \'[]\'::jsonb END, %s::jsonpath)) AND __CURRENT_COL_33__ AND (__CURRENT_COL_34__ = \'\' OR (char_length(__CURRENT_COL_34__) BETWEEN 5 AND 32 AND (__CURRENT_COL_34__ COLLATE "C") ~ %s AND (__CURRENT_COL_34__ COLLATE "C") !~ %s)) AND __CURRENT_COL_35__ IN (SELECT U0."id" AS "pk" FROM "catalog_municipality" U0 WHERE U0."active") AND (__CURRENT_COL_36__ IN (SELECT U0."id" AS "pk" FROM "catalog_postalcode" U0) OR __CURRENT_COL_36__ IS NULL) AND (__CURRENT_COL_37__ IN (SELECT U0."id" AS "pk" FROM "catalog_zone" U0 WHERE U0."active") OR __CURRENT_COL_37__ IS NULL) AND (__CURRENT_COL_36__ IS NULL OR (__CURRENT_COL_38__ AND EXISTS(SELECT %s AS "a" FROM "catalog_postalcode_municipalities" U0 WHERE (U0."municipality_id" = (__CURRENT_COL_35__) AND U0."postalcode_id" = (__CURRENT_COL_36__)) LIMIT 1))) AND (__CURRENT_COL_37__ IS NULL OR __CURRENT_COL_39__ = (__CURRENT_COL_35__)) AND NOT (__CURRENT_COL_16__ IN (SELECT V0."revision_id" AS "revision_id" FROM "listings_revision_categories" V0 WHERE NOT (V0."category_id" IN (SELECT U0."id" AS "pk" FROM "catalog_category" U0 WHERE U0."active"))) AND __CURRENT_COL_16__ IS NOT NULL) AND __CURRENT_COL_16__ IN (SELECT U0."revision_id" AS "revision_id" FROM "listings_revision_categories" U0) AND NOT (__CURRENT_COL_16__ IN (SELECT V0."revision_id" AS "revision_id" FROM "listings_revision_services" V0 WHERE NOT (V0."service_id" IN (SELECT U0."id" AS "pk" FROM "catalog_service" U0 WHERE U0."active"))) AND __CURRENT_COL_16__ IS NOT NULL) AND __CURRENT_COL_16__ IN (SELECT U0."revision_id" AS "revision_id" FROM "listings_revision_services" U0) AND NOT (__CURRENT_COL_16__ IN (SELECT V0."revision_id" AS "revision_id" FROM "listings_revision_travel_areas" V0 WHERE NOT (V0."municipality_id" IN (SELECT U0."id" AS "pk" FROM "catalog_municipality" U0))) AND __CURRENT_COL_16__ IS NOT NULL) AND NOT (__CURRENT_COL_16__ IN (SELECT V0."revision_id" AS "revision_id" FROM "listings_revision_services" V0 INNER JOIN "catalog_service" V2 ON (V0."service_id" = V2."id") WHERE NOT (V2."category_id" IN (SELECT U0."category_id" AS "category_id" FROM "listings_revision_categories" U0 WHERE U0."revision_id" = (V0."revision_id")))) AND __CURRENT_COL_16__ IS NOT NULL) AND NOT (__CURRENT_COL_16__ IN (SELECT V0."revision_id" AS "revision_id" FROM "listings_rate" V0 WHERE NOT (NOT (V0."id" IN (SELECT U0."id" AS "pk" FROM "listings_rate" U0 WHERE ((char_length(U0."concept") <= %s AND (NOT %s OR btrim(U0."concept", %s) <> \'\') AND (U0."concept" COLLATE "C") ~ %s AND lower(U0."concept" COLLATE "C") NOT LIKE %s AND (U0."concept" COLLATE "C") !~ %s)) IS NOT TRUE)) AND (V0."duration_minutes" IS NULL OR (V0."duration_minutes" >= %s AND V0."duration_minutes" IS NOT NULL AND V0."duration_minutes" <= %s AND V0."duration_minutes" IS NOT NULL)) AND ((V0."amount" IS NULL AND V0."mode" = %s) OR (V0."amount" > %s AND V0."amount" IS NOT NULL AND V0."amount" <= %s AND V0."amount" IS NOT NULL AND V0."mode" IN (%s, %s))))) AND __CURRENT_COL_16__ IS NOT NULL) AND NOT (__CURRENT_COL_16__ IN (SELECT U0."revision_id" AS "revision_id" FROM "listings_rate" U0 GROUP BY 1 HAVING COUNT(U0."id") > %s) AND __CURRENT_COL_16__ IS NOT NULL) AND __CURRENT_COL_16__ IN (SELECT U0."revision_id" AS "revision_id" FROM "mediafiles_photo" U0 INNER JOIN "mediafiles_blob" U2 ON (U0."blob_id" = U2."id") WHERE U0."removed_at" IS NULL GROUP BY 1 HAVING (COUNT(U0."id") FILTER (WHERE NOT (U2."status" = %s AND U0."comparison_complete")) = %s AND COUNT(U0."id") >= %s AND COUNT(U0."id") <= %s))) THEN %s ELSE %s END', ('approved_revision__listing', 'id', 'approved_revision__manager_version', 'person__manager_version', 'approved_revision__phone', 'person__phone_claim__phone', 'approved_revision__status', 'expires_at', 'person__age_status', 'person__consent_revoked_at', 'person__consent_version', 'person__manager_review_status', 'person__phone_claim__verified_at', 'person__publication_erased_at', 'person__subject', 'status', 'approved_revision', 'person', 'person__agency', 'person__individual', 'person__phone_claim__individual', 'person__phone_claim__agency', 'person__agency__verification_status', 'approved_revision__publisher_acceptance__action', 'approved_revision__publisher_acceptance__document__active', 'approved_revision__publisher_acceptance__document__slug', 'approved_revision__publisher_acceptance__document__version', 'approved_revision__publisher_acceptance__agency', 'approved_revision__content_language', 'approved_revision__profile_type', 'approved_revision__time_slot', 'approved_revision__spoken_languages', 'approved_revision__days', 'approved_revision__contact_exposure_accepted', 'approved_revision__telegram', 'approved_revision__municipality', 'approved_revision__postal_code', 'approved_revision__zone', 'approved_revision__postal_code__public_safe', 'approved_revision__zone__municipality'))


def case_parameters_v1(document_version, now):
    return (
        'approved',
        now,
        'passed',
        'approved',
        'published',
        Int4(1),
        'conflict',
        'conflict',
        Int4(1),
        Int4(1),
        'rights-stage',
        'rights-stage',
        'conflict',
        'conflict',
        Int4(1),
        Int4(1),
        'rights-stage',
        'rights-stage',
        'agency',
        'individual',
        'grant',
        'publishing',
        document_version,
        'passed',
        Int4(1),
        Int4(1),
        'passed',
        'publish',
        'publishing',
        document_version,
        Int4(120),
        True,
        ' \t\r\n',
        '^[A-Za-z0-9 áéíóúüñÁÉÍÓÚÜÑ.,;!?()\'"\n\r\t-]*$',
        '%www.%',
        '[0-9][0-9 ()-]{7}',
        Int4(6000),
        True,
        ' \t\r\n',
        '^[A-Za-z0-9 áéíóúüñÁÉÍÓÚÜÑ.,;!?()\'"\n\r\t-]*$',
        '%www.%',
        '[0-9][0-9 ()-]{7}',
        Int4(6000),
        False,
        ' \t\r\n',
        '^[A-Za-z0-9 áéíóúüñÁÉÍÓÚÜÑ.,;!?()\'"\n\r\t-]*$',
        '%www.%',
        '[0-9][0-9 ()-]{7}',
        'es',
        'en',
        'woman',
        'man',
        'trans',
        'other',
        '',
        'morning',
        'afternoon',
        'evening',
        '["es", "en", "fr", "de", "it", "pt"]',
        'strict $[*] ? (@.type() != "string")',
        '["1", "2", "3", "4", "5", "6", "7"]',
        'strict $[*] ? (@.type() != "string")',
        '^[A-Za-z]',
        '[^A-Za-z0-9_]',
        Int4(1),
        Int4(80),
        True,
        ' \t\r\n',
        '^[A-Za-z0-9 áéíóúüñÁÉÍÓÚÜÑ.,;!?()\'"\n\r\t-]*$',
        '%www.%',
        '[0-9][0-9 ()-]{7}',
        Int4(1),
        Int4(10080),
        'consult',
        Decimal('0'),
        Decimal('999999.99'),
        'fixed',
        'from',
        Int4(10),
        'ready',
        Int4(0),
        Int4(1),
        Int4(8),
        True,
        False,
    )


def case_model_labels_v1():
    return ('catalog.category', 'catalog.municipality', 'catalog.postalcode', 'catalog.postalcode_municipalities', 'catalog.service', 'catalog.zone', 'core.agency', 'core.legalacceptance', 'core.legaldocument', 'core.person', 'core.phoneclaim', 'core.representationaction', 'core.user', 'core.verificationcheck', 'listings.listing', 'listings.rate', 'listings.revision', 'listings.revision_categories', 'listings.revision_services', 'listings.revision_travel_areas', 'mediafiles.blob', 'mediafiles.match', 'mediafiles.photo', 'safety.privacypublicationhold', 'safety.restriction', 'safety.rightsphotoreintroduction', 'safety.rightsrectificationexecution', 'safety.rightsrectificationnotification', 'safety.rightsrectificationphotoupload', 'safety.rightsrectificationproposal', 'safety.rightsrectificationreview')
