"""Audit a completed N01B run; never substitute properties for source oracles."""
import hashlib,json,statistics,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
W=Path('artifacts/recorridos-n01-b-20261025');RUN=Path(sys.argv[1]);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=json.loads((W/'freeze.json').read_text());r=json.loads((RUN/'result.json').read_text());runner=json.loads((RUN/'runner.json').read_text())
assert r['result']=='PASS' and r['sources_unchanged'] and r['workers']==1
assert all(s['exit']==0 for s in r['steps'])
for p,h in f['product_sha256'].items():assert sha(p)==h,p
for p,h in f['instrument_documents_graph_sha256'].items():assert sha(p)==h,p
cases=list(ET.parse(RUN/'pytest.xml').getroot().iter('testcase'));assert len(cases)==1
c=cases[0];node=c.get('file')+'::'+c.get('name');assert [node]==f['selected']
assert all(c.find(k) is None for k in ('failure','error','skipped'))
props={p.get('name'):p.get('value') for p in c.findall('./properties/property')}
obs=json.loads(props['n01b_observations']);assert len(obs)==10 and int(props['measured_requests'])==60
assert [(o['language'],o['scenario']) for o in obs]==[(lang,case) for lang in ('es','en') for case in ('listing','page2','profile','empty','detail')]
summary=[]
for o in obs:
 assert o['population']==100 and len(o['samples'])==6
 assert [s['index'] for s in o['samples']]==list(range(6))
 assert len({s['ordered_ids_sha256'] for s in o['samples']})==1
 for s in o['samples']:
  assert s['seconds_instrumented']>0 and s['queries']>0 and s['execute_seconds']>=0
  assert s['position']==('first_after_preparation' if s['index']==0 else 'subsequent')
  if o['scenario'] in ('listing','page2'):assert s['returned_count']==24 and o['expected_total']==100
  if o['scenario']=='empty':assert s['returned_count']==0 and o['expected_total']==0
  if o['scenario']=='detail':assert s['returned_count']==1 and o['expected_total'] is None
 subsequent=[s['seconds_instrumented'] for s in o['samples'][1:]]
 assert o['subsequent_median_seconds']==statistics.median(subsequent)
 summary.append({'language':o['language'],'scenario':o['scenario'],'first_seconds':o['samples'][0]['seconds_instrumented'],'subsequent_median_seconds':o['subsequent_median_seconds'],'subsequent_min_seconds':min(subsequent),'subsequent_max_seconds':max(subsequent),'first_sql':o['samples'][0]['queries'],'subsequent_sql':[s['queries'] for s in o['samples'][1:]],'publication_routes':[s['route'] for s in o['samples']]})
journal=[json.loads(line) for line in (RUN/'pytest-reports.jsonl').read_text().splitlines()];assert len(journal)==3 and {row['when'] for row in journal}=={'setup','call','teardown'}
assert all(row['outcome']=='passed' and row['nodeid']==node for row in journal)
for name,state in r['cleanup'].items():
 assert state['absent'];q=subprocess.run(['docker','container','inspect','--format','{{.Id}}',name],capture_output=True,text=True);assert q.returncode and 'no such' in (q.stdout+q.stderr).lower()
assert not Path(runner['temporary']).exists()
assert json.loads((RUN/'telegram-notification.json').read_text())['delivery']=='sent'
result={'result':'PASS_N01B_AUDIT','run':str(RUN),'pass':1,'fail':0,'error':0,'skip':0,'measured_requests':60,'segments':10,'samples_per_segment':6,'summary':summary,'observations':obs,'pytest_step_seconds':next(s['seconds'] for s in r['steps'] if s['name']=='pytest'),'frozen_product_sources_unchanged':1507,'new_instrument_frozen':True,'frozen_documents_graph_unchanged_until_audit':True,'containers_temporary_absent':True,'telegram_delivery':'sent','N01_complete':False,'N04_complete':False,'product_changes':0,'limits':['No causal optimization/beforeafter claim: first/subsequent conditions differ and order is fixed','Not coldOS, TCP, concurrency, p95/capacity or all filters/promotions/cardinalities','Native test source contains all response200/no-store/language/privacy/ID/order/count oracles; audit verifies same frozen source and complete success'],'original_sha256':{p.name:sha(p) for p in RUN.iterdir() if p.is_file() and p.suffix in ('.json','.jsonl','.xml','.log')},'freeze_sha256':sha(W/'freeze.json')}
Path('docs/evidencias/n01-b-diagnostico-auditoria-20261025.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('observations','original_sha256')}))
