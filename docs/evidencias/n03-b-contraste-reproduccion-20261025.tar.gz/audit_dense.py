import hashlib,json,math,statistics,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n03-b-20261025');variant,run=sys.argv[1:];P=Path('artifacts/local-ci')/run
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
f=read(W/(variant+'-freeze.json'));r=read(P/'result.json')
assert r['result']=='PASS' and r['sources_unchanged'] and r['workers']==1
assert r['selection']==['tests/test_similarity_prepared_reference.py']
assert len(r['junit'])==1 and r['junit'][0]['tests']=='1' and all(r['junit'][0][k]=='0' for k in ['errors','failures','skipped'])
assert all(Path(p).is_file() and sha(p)==h for p,h in f['sources'].items())
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==1 and not any(cs[0].findall(k) for k in ['failure','error','skipped'])
props={x.attrib['name']:x.attrib['value'] for x in cs[0].iter('property')};d=json.loads(props['n03b_dense_reference'])
assert d['candidates']==d['expected_matches']==100 and len(d['samples'])==6 and d['corpus_bytes']<128*1024*1024
for i,s in enumerate(d['samples']):
 assert s['ordinal']==i and s['confirm_calls']==s['match_count']==100
 assert s['feature_calls']==(200 if variant=='baseline' else 101)
 assert s['process_maxrss_kib']<1024*1024
 for k in ['wall_seconds','thread_cpu_seconds','operation_python_peak_bytes','process_maxrss_kib','sql_queries','sql_execute_seconds']:
  assert math.isfinite(s[k]) and s[k]>=0
for k in ['complete_result_sha256','persisted_method_score_sha256']:
 assert len({s[k] for s in d['samples']})==1
inventory={}
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q']
 q=subprocess.run(cmd+['--filter',f'label=web-modelos-local-ci-run={run}'],capture_output=True,text=True,check=True);inventory[kind]=q.stdout.split();assert not inventory[kind]
assert not Path(read(P/'runner.json')['temporary']).exists()
tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
summary={k:{'first':d['samples'][0][k],'later_median':statistics.median(s[k] for s in d['samples'][1:]),'later_min':min(s[k] for s in d['samples'][1:]),'later_max':max(s[k] for s in d['samples'][1:])} for k in ['wall_seconds','thread_cpu_seconds','operation_python_peak_bytes','process_maxrss_kib','sql_queries','sql_execute_seconds','feature_calls']}
out={'result':'PASS_FINITE_DENSE_REFERENCE' if variant=='baseline' else 'PASS_FINITE_DENSE_CANDIDATE_NOT_ADOPTION','run':run,'variant':variant,'junit':r['junit'],'source_count':len(f['sources']),'measurement':d,'summary':summary,'inventory':inventory,'temporary_absent':True,'telegram':tg}
(W/(variant+'-audit.json')).write_text(json.dumps(out,indent=2))
print(json.dumps({'result':out['result'],'summary':summary}))
