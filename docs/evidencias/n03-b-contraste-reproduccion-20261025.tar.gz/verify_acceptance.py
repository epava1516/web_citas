import ast,hashlib,json,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n03-b-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
a,b=read(W/'baseline-audit.json'),read(W/'candidate-audit.json')
for k in ['corpus_sha256','corpus_bytes','candidates','expected_matches','scope']:assert a['measurement'][k]==b['measurement'][k]
for k in ['complete_result_sha256','persisted_method_score_sha256','confirm_calls','match_count','sql_queries']:
 assert [s[k] for s in a['measurement']['samples']]==[s[k] for s in b['measurement']['samples']]
for k in ['wall_seconds','thread_cpu_seconds']:assert b['summary'][k]['later_max']<a['summary'][k]['later_min']
for s in b['measurement']['samples']:assert s['feature_calls']==101 and s['confirm_calls']==s['match_count']==100
f=read(W/'functional-audit.json');P=Path('artifacts/local-ci')/f['run'];r=read(P/'result.json');assert r['result']=='PASS' and r['sources_unchanged']
assert r['selection']==['tests/test_similarity_prepared_features.py','tests/test_image_similarity.py','tests/test_photos.py']
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==f['testcases']==46 and not any(c.find(k)is not None for c in cs for k in ['failure','error','skipped'])
freeze=read(W/'candidate-freeze.json');assert all(sha(p)==h for p,h in freeze['sources'].items() if p!='.ai/tasks/desarrollo.md')
scope=read(W/'candidate-scope.json');assert all(sha(p)==v['after'] for p,v in scope.items())
for name in ['services','similarity']:
 old=ast.parse((W/(name+'-before.py')).read_text());new=ast.parse(Path('apps/mediafiles/'+name+'.py').read_text())
 if name=='similarity':
  before=next(n for n in old.body if isinstance(n,ast.FunctionDef) and n.name=='confirm_match').body[4:]
  after=next(n for n in new.body if isinstance(n,ast.FunctionDef) and n.name=='_confirm_features').body
  assert ast.dump(ast.Module(body=before,type_ignores=[]),include_attributes=False)==ast.dump(ast.Module(body=after,type_ignores=[]),include_attributes=False)
 excluded={'detect_matches'} if name=='services' else {'confirm_match','prepare_query','_confirm_features','_PreparedQuery'}
 olddefs={n.name:ast.dump(n,include_attributes=False) for n in old.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name not in excluded}
 newdefs={n.name:ast.dump(n,include_attributes=False) for n in new.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name not in excluded}
 assert olddefs==newdefs
for audit in [a,b,f]:
 run=audit['run'];P=Path('artifacts/local-ci')/run
 assert read(P/'telegram-notification.json')['delivery']=='sent'
 assert not Path(read(P/'runner.json')['temporary']).exists()
 for kind in ['container','volume','network']:
  cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q']
  q=subprocess.run(cmd+['--filter',f'label=web-modelos-local-ci-run={run}'],capture_output=True,text=True,check=True);assert not q.stdout.strip()
out={'result':'PASS_LOCAL_N03B_NOT_N03_BLOCK_ACCEPTANCE','exact_parity':True,'functional_cases':46,'timing_ranges_separate':True,'feature_calls_before_after':[200,101],'unchanged_geometric_algorithm':True,'unrelated_definitions_unchanged':True,'all_three_runs_cleaned_and_telegram_sent':True,'app_hashes_verified':True,'worklog_delta_after_tests_explicit':True}
(W/'acceptance-verification.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
