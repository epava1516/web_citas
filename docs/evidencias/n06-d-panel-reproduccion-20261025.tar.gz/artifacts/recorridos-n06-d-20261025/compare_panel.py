import json,statistics
from pathlib import Path
W=Path('artifacts/recorridos-n06-d-20261025');read=lambda p:json.loads(Path(p).read_text())
a=read(W/'baseline-audit.json');b=read(W/'candidate-audit.json');identity=lambda x:(x['size'],x['language'],x['actor']);before={identity(x):x for x in a['rows']};rows=[]
for post in b['rows']:
 pre=before[identity(post)]
 assert all(x['response_bytes']==y['response_bytes'] and x['people_order']==y['people_order'] and x['member_order']==y['member_order'] for x,y in zip(pre['samples'],post['samples']))
 assert all(y['sql_queries']<=x['sql_queries'] for x,y in zip(pre['samples'],post['samples']))
 if post['actor']=='owner' and post['size']>1:assert post['sql_queries']['median_later']<pre['sql_queries']['median_later']
 row={'size':post['size'],'language':post['language'],'actor':post['actor']}
 for k in ['wall_seconds','cpu_seconds','sql_execute_seconds','sql_queries','response_bytes']:
  old=pre[k]['median_later'];new=post[k]['median_later'];row[k]={'before':old,'after':new,'delta_after_minus_before':new-old,'reduction_percent':100*(old-new)/old if old else None,'before_range':pre[k]['range_later'],'after_range':post[k]['range_later']}
 rows.append(row)
assert len(rows)==12
bf=read(W/'baseline-freeze.json');cf=read(W/'candidate-freeze.json');changed=[p for p,h in bf['sources'].items() if cf['sources'].get(p)!=h];assert changed==['apps/core/agencies.py'],changed;assert bf['images']==cf['images'] and bf['native_commit']==cf['native_commit'] and bf['affinity']==cf['affinity']
out={'state':'PAIRED_SCENARIO_COMPARISON','baseline_run':a['run'],'candidate_run':b['run'],'changed_runtime_sources':changed,'same_images_native_affinity':True,'samples_per_actor_cohort_language':6,'principal_samples':5,'first_separate':True,'ordered_people_members_and_response_bytes_equal':True,'rows':rows,'timing_nonworse_rows':sum(r['wall_seconds']['after']<=r['wall_seconds']['before'] for r in rows),'scope':'Instrumented local Client panel, two sequential runs; five subsequent samples per actor/cohort/language, not p95 or universal causal evidence.'}
(W/'comparison.json').write_text(json.dumps(out,indent=2)+'\n');print('COMPARISON',out['timing_nonworse_rows'],'of',len(rows))
for r in rows:print(r['size'],r['language'],r['actor'],r['sql_queries']['before'],r['sql_queries']['after'],round(1000*r['wall_seconds']['before'],3),round(1000*r['wall_seconds']['after'],3),round(r['wall_seconds']['reduction_percent'],2))
