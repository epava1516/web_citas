import hashlib,json,os,platform,subprocess,sys
from pathlib import Path
sys.path.insert(0,'scripts')
from run_local_ci import hashes
phase=sys.argv[1];W=Path('artifacts/recorridos-n06-d-20261025');M=json.loads(Path('graphify-out/SOURCE_MANIFEST.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(p)==r['sha256'] for p,r in M.items())
images={i:subprocess.check_output(['docker','image','inspect','--format','{{.Id}}',i],text=True).strip() for i in ['postgres:17-alpine','redis:7.4-alpine']}
d={'phase':phase,'sources':hashes(),'graph_sha256':sha('graphify-out/graph.json'),'corpus_sha256':{p:r['sha256'] for p,r in M.items()},'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'images':images,'platform':platform.platform(),'affinity':sorted(os.sched_getaffinity(0)),'native_commit':subprocess.check_output(['git','-C','/tmp/web-modelos-librdb-v2.4.0','rev-parse','HEAD'],text=True).strip()}
p=W/(phase+'-freeze.json');assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n');print('FROZEN',phase,len(d['sources']))
