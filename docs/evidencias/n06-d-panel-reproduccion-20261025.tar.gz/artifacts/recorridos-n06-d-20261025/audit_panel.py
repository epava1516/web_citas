"""Audit frozen panel reference/candidate without rerunning workload."""
import hashlib,json,math,statistics,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n06-d-20261025');phase,run=sys.argv[1:3];P=Path('artifacts/local-ci')/run

def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda v:(_ for _ in ()).throw(ValueError(v)))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=read(W/(phase+'-freeze.json'));mismatch=[p for p,h in f['sources'].items() if not Path(p).is_file() or sha(p)!=h];assert not mismatch,mismatch
r=read(P/'result.json');assert r['result']=='PASS' and r['sources_unchanged'];assert r['selection']==['tests/test_agency_panel_growth_reference.py'] and r['workers']==1
assert len(r['junit'])==1 and r['junit'][0]['tests']=='6' and all(r['junit'][0][k]=='0' for k in ['failures','errors','skipped'])
rows=[]
for c in E.parse(P/'pytest.xml').iter('testcase'):
 assert not any(c.findall(k) for k in ['failure','error','skipped'])
 props={p.attrib['name']:p.attrib['value'] for p in c.iter('property')};d=json.loads(props['agency_panel_samples']);assert len(d['samples'])==12
 for actor in ['owner','editor']:
  samples=[s for s in d['samples'] if s['actor']==actor];assert [s['ordinal'] for s in samples]==list(range(6))
  for s in samples:
   assert all(math.isfinite(s[k]) and s[k]>=0 for k in ['wall_seconds','cpu_seconds','sql_execute_seconds','sql_queries','response_bytes'])
  later=samples[1:];row={'size':d['size'],'language':d['language'],'actor':actor,'samples':samples}
  for k in ['wall_seconds','cpu_seconds','sql_execute_seconds','sql_queries','response_bytes']:
   vals=[s[k] for s in later];row[k]={'first':samples[0][k],'median_later':statistics.median(vals),'range_later':[min(vals),max(vals)]}
  rows.append(row)
assert len(rows)==12 and len({(r['size'],r['language'],r['actor']) for r in rows})==12
inventory={}
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q']
 q=subprocess.run(cmd+['--filter',f'label=web-modelos-local-ci-run={run}'],capture_output=True,text=True,check=True);inventory[kind]=q.stdout.split();assert not inventory[kind]
runner=read(P/'runner.json');assert not Path(runner['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'state':'PRIMARY_AUDITED','phase':phase,'run':run,'head':f['head'],'source_count':len(f['sources']),'source_mismatches':mismatch,'junit':r['junit'],'junit_sha256':sha(P/'pytest.xml'),'rows':rows,'inventory':inventory,'temporary_absent':True,'telegram':tg,'steps':[{k:v for k,v in x.items() if k!='command'} for x in r['steps']],'scope':'Six synthetic panel cases/72 measured requests, first separate and five subsequent per actor/cohort/language; no p95 or production capacity.'}
(W/(phase+'-audit.json')).write_text(json.dumps(out,indent=2)+'\n')
print('AUDITED',phase,run)
for x in rows:print(x['size'],x['language'],x['actor'],'queries',x['sql_queries']['median_later'],'wall_ms',round(x['wall_seconds']['median_later']*1000,3))
