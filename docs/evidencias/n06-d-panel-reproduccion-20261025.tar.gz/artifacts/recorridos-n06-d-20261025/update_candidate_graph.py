"""Refresh one code source identity; extractor AST shape is unchanged, not full semantics."""
import ast,hashlib,json,shutil
from pathlib import Path
W=Path('artifacts/recorridos-n06-d-20261025');B=W/'candidate-graph-base';S=W/'candidate-graph';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not B.exists() and not S.exists();shutil.copytree('graphify-out',B);shutil.copytree(B,S)
source='apps/core/agencies.py';old=json.loads((W/'agencies-before-ast.json').read_text());new=json.loads((W/'agencies-candidate-ast.json').read_text());assert not new['failed_sources'];assert old['nodes']==new['nodes'] and old['edges']==new['edges']
scope=json.loads((W/'candidate-scope.json').read_text());assert sha(source)==scope['after_sha256'];m=json.loads((S/'SOURCE_MANIFEST.json').read_text());assert m[source]['sha256']==scope['before_sha256'];m[source].update(sha256=sha(source),bytes=Path(source).stat().st_size,input_sha256=sha(source));(S/'SOURCE_MANIFEST.json').write_text(json.dumps(m,indent=2))
assert all(sha(p)==r['sha256'] for p,r in m.items())
g=json.loads((S/'graph.json').read_text());g['graph']['latest_code_refresh']={'source':source,'sha256':sha(source),'scope':'Fresh graphify AST same25nodes64edges; chained select_related strategy not represented by extractor. Exact one-line candidate diff independently audited. No complete semantic/runtime claim.'};(S/'graph.json').write_text(json.dumps(g,ensure_ascii=False,indent=2))
proof={'result':'PASS_N06D_CANDIDATE_SOURCE_AST_REFRESH','source':source,**scope,'graph_nodes_edges_unchanged':True,'ast_nodes':len(new['nodes']),'ast_edges':len(new['edges']),'source_files':len(m),'graph_sha256':sha(S/'graph.json'),'scope':g['graph']['latest_code_refresh']['scope']}
(S/'GRAPH_VERIFICATION.json').write_text(json.dumps(proof,indent=2)+'\n');(W/'candidate-graph-verification.json').write_text(json.dumps(proof,indent=2)+'\n')
for name in ['GRAPH_REPORT.md','ESTADO_ACTUAL.md']:
 p=S/name;p.write_text('# N06D — candidata local aplicada, todavía sin medir\n\nReferencia panel6PASS: propietario9/18/108SQL por1/10/100editores, editor7SQL. Candidata sólo añade select_related("user") a miembros activos para propietario. AST de fuente reextraído con forma idéntica; no detecta esta cadena de método. Identidad y diff exactos verificados por separado; no se afirma semántica exhaustiva ni mejora aún.\n\n'+p.read_text())
p=S/'CORPUS_POLICY.json';d=json.loads(p.read_text());d['latest_code_refresh']=proof;p.write_text(json.dumps(d,indent=2))
p=S/'CURRENT_OUTPUTS.json';d=json.loads(p.read_text());d['sha256']={p.name:sha(p) for p in S.iterdir() if p.is_file() and p.name not in ('CURRENT_OUTPUTS.json','GRAPH_VERIFICATION.json')};p.write_text(json.dumps(d,indent=2))
for p in S.iterdir():
 if p.is_file():shutil.copy2(p,Path('graphify-out')/p.name)
print(json.dumps(proof))
