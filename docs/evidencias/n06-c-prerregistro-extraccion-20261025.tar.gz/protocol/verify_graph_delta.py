"""Independent scoped graph integrity and unchanged-product audit."""
import collections,hashlib,json,tarfile
from pathlib import Path
W=Path('artifacts/recorridos-n06-c-20261025/protocol');S=W/'graph-integrated';B=W/'graph-base';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=json.loads((W/'semantic-integration.json').read_text());changed=set(proof['changed_sources'])
m=json.loads((S/'SOURCE_MANIFEST.json').read_text())
for p,r in m.items():assert sha(p)==r['sha256'],p
old=json.loads((B/'graph.json').read_text());new=json.loads((S/'graph.json').read_text());nodes={n['id']:n for n in new['nodes']}
assert len(nodes)==len(new['nodes']) and len(m)==1965
assert new['directed'] and new['multigraph']
assert all(e[k] in nodes for e in new['links'] for k in ('source','target'))
def canonical(row):return json.dumps({k:v for k,v in row.items() if k not in ('community','community_name','key')},sort_keys=True)
resolved=set(proof.get('resolved_legacy_reference_ids',[]))
for identity in resolved:
 previous=next(n for n in old['nodes'] if n['id']==identity)
 assert previous.get('external') and previous.get('resolution_status')=='prior_semantic_entity_replaced_reference_only'
 assert nodes[identity].get('source_file') in changed and nodes[identity].get('extraction_origin')=='native_semantic_n06c_protocol'
oldnodes={n['id']:canonical(n) for n in old['nodes'] if n.get('source_file') not in changed and n['id'] not in resolved}
assert all(canonical(nodes[i])==v for i,v in oldnodes.items())
oldedges=collections.Counter(canonical(e) for e in old['links'] if e.get('source_file') not in changed)
newedges=collections.Counter(canonical(e) for e in new['links'] if e.get('source_file') not in changed)
assert oldedges==newedges,'Unchanged-source relationship mutation'
for p in proof['semantic_changed_sources']:
 assert any(n.get('source_file')==p and n.get('extraction_origin')=='native_semantic_n06c_protocol' for n in nodes.values()),p
assert set(m)<={n.get('source_file') for n in nodes.values()}
assert all(not n.get('source_file') or n['source_file'] in m for n in nodes.values())
a=json.loads((S/'.graphify_analysis.json').read_text());flat=[i for v in a['communities'].values() for i in v]
assert len(flat)==len(set(flat))==len(nodes) and set(flat)==set(nodes)
assert len([e for e in new['links'] if e.get('relation') in ('unresolved_call_annotation','unresolved_base_annotation')])==100
assert not any(e['source']==e['target'] and e.get('relation')=='inherits' for e in new['links'])
product=json.loads(Path('docs/evidencias/b16-final-candidate-reconciliation-20261025.json').read_text())['current_versioned_executable_sources'];assert len(product)==1507
for p,h in product.items():
 if p not in ('scripts/run_local_ci.py','apps/safety/rights_portability_export.py'):assert sha(p)==h,p
assert sha('artifacts/recorridos-n01-d-20261025/runner-before.py')==product['scripts/run_local_ci.py']
assert sha('scripts/run_local_ci.py')==m['scripts/run_local_ci.py']['sha256']
candidate=json.loads(Path('artifacts/recorridos-n02-b-20261025/candidate-scope.json').read_text())
assert candidate['before_sha256']==product['apps/safety/rights_portability_export.py']
assert sha('apps/safety/rights_portability_export.py')==candidate['after_sha256']
assert sha('artifacts/recorridos-n02-b-20261025/rights-portability-export-before.py')==candidate['before_sha256']
import ast
def rest(text):
 t=ast.parse(text);t.body=[n for n in t.body if not isinstance(n,ast.FunctionDef) or n.name!='_verify_current_images'];return ast.dump(t,include_attributes=False)
assert rest(Path('apps/safety/rights_portability_export.py').read_text())==rest(Path('artifacts/recorridos-n02-b-20261025/rights-portability-export-before.py').read_text())
outputs=json.loads((S/'CURRENT_OUTPUTS.json').read_text())['sha256']
for p,h in outputs.items():assert sha(S/p)==h,p
assert '<html' in (S/'graph.html').read_text().lower()
assert sha('docs/111-inventario-rendimiento-recorridos-beta-20261020.md')=='380b026c51b5e9647052838bb77a0712e9efff4ccdd857b5df3d4b545d921a95'
result={'result':'PASS_SCOPED_GRAPH_N06C_PROTOCOL_AND_INSTRUMENT','source_files':len(m),'nodes':len(nodes),'relations':len(new['links']),'communities':len(a['communities']),'source_sha_mismatches':0,'dangling_or_missing_endpoints':0,'unchanged_source_nodes_preserved':len(oldnodes),'unchanged_source_relations_preserved':sum(oldedges.values()),'accepted_executable_sources_unchanged':1505,'application_guard_locally_adopted_variant':1,'runner_measurement_variant':1,'resolved_legacy_reference_ids':sorted(resolved),'original111_unchanged':True,'graph_sha256':sha(S/'graph.json'),'scope':proof['scope'],'native_token_usage':None}
(S/'GRAPH_VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n');(W/'graph-delta-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
