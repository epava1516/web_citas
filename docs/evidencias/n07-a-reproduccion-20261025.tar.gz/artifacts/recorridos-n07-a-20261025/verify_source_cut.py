import hashlib,json,shutil
from pathlib import Path
W=Path('artifacts/recorridos-n07-a-20261025');G=Path('graphify-out');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((G/'SOURCE_MANIFEST.json').read_text());bad=[p for p,r in m.items() if sha(p)!=r['sha256']];assert not bad,bad
x=json.loads((G/'ESTADO_ACTUAL.json').read_text());assert x['next_mandatory_accepted']==6
for n in ['SOURCE_MANIFEST.json','ESTADO_ACTUAL.json','GRAPH_VERIFICATION.json']:shutil.copy2(G/n,W/n)
a=json.loads(Path('docs/evidencias/n00-matriz-acciones-prioridades-20261025.json').read_text())['actions'];rows=[r for r in a if 'N07' in r['blocks']];assert len(rows)==39
(W/'census.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
out={'result':'PASS_CURRENT_PRE_N07_SOURCE_CUT','source_files':len(m),'graph_sha256':sha(G/'graph.json'),'source_mismatches':bad,'census_units':len(rows),'scope':'N05 final focal AST plus native semantics preserved, no new content changes before N07 analysis; not a global semantic rebuild.'}
(W/'source-cut-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
