import json,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n07-a-20261025');P=Path('artifacts/local-ci/20261025-222614-c4dfdaad');read=lambda p:json.loads(Path(p).read_text())
r=read(P/'result.json');assert r['result']=='ERROR' and r['sources_unchanged'] and r['workers']==1
f=read(W/'first-reference-freeze.json');hashes=read(P/'source-hashes.json');assert all(hashes[p]==h for p,h in f['sources'].items()),[p for p,h in f['sources'].items() if hashes.get(p)!=h]
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==2 and all(c.find('failure') is not None and '500 == 404' in c.find('failure').get('message','') for c in cs);assert not any(c.find(k)is not None for c in cs for k in ['error','skipped']);log=(P/'09-pytest.log').read_text();assert log.count('StopIteration')==2 and log.count('index = next(i for i, photo in enumerate(photos) if photo.pk == initial.pk)')==2
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PRESERVED_ORIGINAL_2FAIL_CONFIRMED_REORDER_REMOVE_RACE','run':P.name,'cases':2,'status_actual':500,'status_expected':404,'cause':'StopIteration after actualPGblocked reorder and committed remove, both languages','original_sources_unchanged':True,'freeze_sources_checked':len(f['sources']),'junit':r['junit'],'cleanup_verified':True,'telegram':tg,'scope':'Original product defect confirmed; no exposure/data-loss claim; candidate not yet verified.'};(W/'original-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
