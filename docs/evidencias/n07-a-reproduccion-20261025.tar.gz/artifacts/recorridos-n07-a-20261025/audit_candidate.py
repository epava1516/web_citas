import ast,hashlib,json,shutil,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n07-a-20261025');P=Path('artifacts/local-ci')/sys.argv[1];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
r=read(P/'result.json');f=read(W/'candidate-freeze.json');assert r['result']=='PASS' and r['sources_unchanged'] and r['workers']==1 and r['selection']==f['selection'];assert all(sha(p)==h for p,h in f['sources'].items())
h=read(P/'source-hashes.json');missing=set(f['sources'])-set(h);assert missing=={'docs/400-n07-a-prerregistro-medios-publicacion-20261025.md','docs/401-n07-a-carrera-reordenacion-retirada-20261025.md'},missing;assert all(h[p]==v for p,v in f['sources'].items() if p in h)
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==4 and not any(c.find(k)is not None for c in cs for k in ['failure','error','skipped']);assert {c.get('name') for c in cs}=={'test_reorder_rechecks_photo_removed_while_waiting[es]','test_reorder_rechecks_photo_removed_while_waiting[en]','test_photo_edit_rejects_localized_and_effects_preserved[es]','test_photo_edit_rejects_localized_and_effects_preserved[en]'}
props=[]
for c in cs:
 for p in c.iter('property'):
  if p.get('name')=='n07_reorder_remove_race':
   x=ast.literal_eval(p.get('value'));assert x['actual_postgresql_blocking'] and x['removed_after_initial_lookup'] and x['reorder_status']==404 and x['removal_only_version_increment'] and x['positions_preserved'];props.append(x)
assert len(props)==2 and {x['language'] for x in props}=={'es','en'}
scope=read(W/'candidate-scope.json');assert sha('apps/mediafiles/views.py')==scope['after_sha256'] and sha(W/'views-before.py')==scope['before_sha256']
def rest(text):
 t=ast.parse(text);t.body=[n for n in t.body if not isinstance(n,ast.FunctionDef) or n.name!='reorder'];return ast.dump(t,include_attributes=False)
assert rest(Path('apps/mediafiles/views.py').read_text())==rest((W/'views-before.py').read_text())
first=read(W/'original-audit.json');assert first['result'].startswith('PRESERVED_ORIGINAL_2FAIL') and first['cleanup_verified']
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
browser=read(W/'candidate-browser-before.json');p=shutil.which('chromium-browser');assert p==browser['executable'] and sha(p)==browser['launcher_sha256'] and subprocess.check_output([p,'--version'],text=True).strip()==browser['version']
out={'result':'PASS_N07A_REORDER_REMOVE_RACE_CORRECTION_AND_LOCALIZED_REGRESSION','run':P.name,'cases':4,'race':props,'regression_scope':'Existing unchanged ESEN actualChromium localized invalid400/noneditable409/foreign404/valid302/remove/versions/order','browser':browser['version'],'original_2FAIL_preserved':True,'original_status':500,'corrected_status':404,'only_reorder_changed':True,'source_freeze_count':len(f['sources']),'untracked_documents_checked_separately':sorted(missing),'junit':r['junit'],'cleanup_verified':True,'telegram':tg,'limits':'Functional correction, no isolated application timing gain claimed. N07 remains open; not full39unit or contract acceptance.'};(W/'candidate-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
