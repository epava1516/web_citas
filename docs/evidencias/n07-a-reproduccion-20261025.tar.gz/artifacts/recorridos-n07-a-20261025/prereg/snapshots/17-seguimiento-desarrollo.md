N07A/400en curso:39IDs/corte2009verificado;hipótesisrace reorder/remove pendiente de reproducciónPGESEN.6/13aceptados,sinoptimizaciónmarginal.

Siguiente:semántica/AST400+instrumento,congelación y primer run de carrera;noaplicarcandidatoantes de preservar original.N07Bworker/Beat30/60en preparaciónaislada,N06ya377.

