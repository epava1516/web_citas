# N03C — recuperación y aislamiento entre generaciones

25/10/2026. Alfa, N03 abierto, N00/N01/N06 aceptados3/13. Primera candidata32PASS verificada; aceptación final pendiente de caso propio de comparación añadido antes de nueva validación conforme ampliación382. Los tiempos actuales aceptables y el diferimiento de optimizaciones marginales no eliminan esta corrección de concurrencia.

## Fallo reproducido y corrección

Referencia20261025-181549-690b123b: runnerERROR con2FAIL/0ERROR/0SKIP de pytest,42,686sJUnit,fuentes intactas. Dos conexiones PostgreSQL y barreras deterministas: worker antiguo adquiere lease; se induce caducidad del timestamp en DB; otro genera ready; al salir el antiguo reemplaza el derivado o cambia ready→failed. Los dos FAIL permanecen como evidencia; no se etiquetan PASS por ser esperados. No se esperaron tres minutos ni se simularon la base o los locks; se controlaron decode y el fallo OSError deliberado.

process conserva attempts y started_at de su lease. Al readquirir el lock sólo escribe si statusprocessing e intento/timestamp siguen siendo suyos. El UPDATE de fallo exige intento/timestamp propios y statusprocessing/ready, para conservar el fallo propio después de generar el derivado. Trabajador tardío no reemplaza archivos ni deshace ready, borrado u otro intento. No cambia elección de candidatos, detector, presupuesto de generación, cola ni configuración. Diff restringido a process; resto del AST de services idéntico, incluido ORB aceptado381. No se repite el benchmark del detector por un cambio ajeno a su implementación.

| Intercalación | Antes, referencia | Después, candidata |
| --- | --- | --- |
| Antiguo termina tras nueva generación | Reemplaza derivado nuevo: FAIL | Conserva derivado nuevo y ready: PASS |
| Antiguo falla tras nueva generación | ready→failed: FAIL | Conserva ready/errorvacío: PASS |
| Identidad de generación nueva | Intento2 existe pero no protege escrituras | Intento2/started_at/derivado preservados |

Candidata20261025-181844-c30b0964:32PASS/0FAIL/ERROR/SKIP,188,641sJUnit:15nuevos+11preparation_cleanup+6photos. Original intacto ante fallo de lectura, failed/attempt1 recuperable y restauración a ready/attempt2/WebPsinEXIF/firmas; replayready no regenera. Lease fresco omite/caducado recupera. Erasing/erased/purging/purged no abren storage ni resucitan. Cohorte mixta conserva fallidos0/3 y descarta agotados4/frescos;readyincomplete repetido por2Photo sólo se envía una vez,retirados/completados fuera. Lote101 continúa al resolver primer100;no promesa de orden/fairness. Once originales conservan retención de evidencia/referencias,pathscompartidos,fallo parcial,interrupción de limpieza,carrera con nuevo referente y procesado que no recrea purga. Seis flujos originales conservan privacidad/EXIF/duplicado/recorte/límites/alta tardía.

## Tabla de tiempos del selector

Milisegundos de recover_media_jobs.run, PostgreSQL real y delay capturado en memoria. Primera+5posteriores por cohorte, mediana/rango. No mide entrega al broker, worker, Beat, latencia del usuario ni espera de caducidad. tasks.py no cambia: no hay ganancia temporal afirmada ni anterior comparable. La referencia de carreras mide corrección, no este tiempo;188,641sQA tampoco es latencia de aplicación.

| Queued | Antes | Primera después, ms | Mediana después, ms (rango) | SQL | Envíos capturados |
| --- | --- | ---: | ---: | ---: | ---: |
| 0 | Sin referencia comparable | 6.745 | 1.821 (1.751–2.001) | 1 | 0 |
| 1 | Sin referencia comparable | 3.449 | 2.072 (1.757–2.169) | 1 | 1 |
| 10 | Sin referencia comparable | 3.311 | 1.778 (1.760–1.973) | 1 | 10 |
| 100 | Sin referencia comparable | 4.790 | 3.191 (2.885–3.680) | 1 | 100 |
| 101 | Sin referencia comparable | 3.660 | 3.514 (2.274–4.077) | 1 | 100 |

## Auditoría y pendientes

1741huellas intactas en cada ejecución; entre referencia y candidata sólo cambia services.py. Grafo actualizado antes de cada congelación: protocolo semántico focal y AST real, sin tratar AST como semántica completa. Revisión nativa sólo lectura n06e_coverage_review ayudó a localizar la carrera; Codex reprodujo y verificó. PostgreSQL/Redis propios, namespaces aislados, contenedores/volúmenes/redes/temp retirados por inventario independiente y ambos avisos terminales Telegram sent. Prerregistro y referencia preservados; sin datos reales ni proveedores.

Lint inicial del instrumento falló por fixture/import y se corrigió antes de ejecutar; recibos conservados. El auditor posterior esperaba31casos por conteo manual erróneo: JUnit contiene32 (11retención, no10). Se corrigió el auditor y verificó32sin repetir pruebas funcionales; error y recibo retenidos. Esto no fue un fallo de aplicación.

N03/N07 siguen abiertos: reproducir por separado el posible no progreso de readyincomplete cuando sus fotos ya no son elegibles o carece de firma; una lectura de fuente no es un fallo runtime verificado. Conciliar reintentos/backoff y recuperación por broker/worker/Beat reales: envío capturado/direct process no los acredita. Reutilizar testigos sólo con identidad y ámbito comprobados; no cerrar por conteo. No abrir otra hipótesis marginal del detector. MOD09 restante diferido al final del desarrollo por usuario. Sin apertura de beta/producción.
