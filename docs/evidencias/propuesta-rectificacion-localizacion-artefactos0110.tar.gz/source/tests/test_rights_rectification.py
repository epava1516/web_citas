import pytest
from django.test import Client
from test_reports import directory, photo_environment  # noqa: F401
from test_rights_responses import ready

from apps.safety.crypto import unseal
from apps.safety.models import RightsRectificationProposal

pytestmark = pytest.mark.django_db(transaction=True)
REASON = "Private correction justification after scoped evidence review"


def test_encrypted_rectification_proposal_is_idempotent_without_source_change(
    request, settings, monkeypatch
):
    case, _, staff, _, _, person = ready(request, settings, monkeypatch, "rectify")
    revision = person.listing.approved_revision
    before = person.alias, revision.title, person.listing.status, person.listing.lifecycle_version
    dates = case.received_at, case.initial_due_at
    path = f"/en/moderation/rights/{case.pk}/rectification/"
    page = staff.get(path)
    assert page.status_code == 200 and page["Cache-Control"] == "private, no-store"
    changes = {"alias": "Synthetic corrected alias", "title": "Synthetic corrected title"}
    assert (
        staff.post(
            path,
            page.context["form"].initial
            | {
                "operation": "preview",
                "purpose": "Inspect current profile fields before correction",
            },
        ).status_code
        == 200
    )
    data = page.context["form"].initial | {
        "operation": "propose",
        "fields": list(changes),
        **changes,
        "reason": REASON,
    }
    assert staff.post(path, data).status_code == 302
    assert staff.post(path, data).status_code == 302
    assert staff.post(path, data | {"reason": REASON + " changed"}).status_code == 409
    item = RightsRectificationProposal.objects.get()
    assert unseal(item.encrypted_changes) == changes
    assert changes["alias"] not in item.encrypted_changes
    assert changes["alias"].encode() not in staff.get(path).content
    person.refresh_from_db()
    revision.refresh_from_db()
    case.refresh_from_db()
    person.listing.refresh_from_db()
    assert (
        person.alias,
        revision.title,
        person.listing.status,
        person.listing.lifecycle_version,
    ) == before
    assert (case.received_at, case.initial_due_at) == dates
    assert case.status == "reviewing" and case.scope_status == "unverified"
    assert Client(enforce_csrf_checks=True).post(path, data).status_code == 403


def test_shared_identity_fields_cannot_be_proposed_as_profile_text(request, settings, monkeypatch):
    case, _, staff, _, _, _ = ready(request, settings, monkeypatch, "rectify")
    path = f"/en/moderation/rights/{case.pk}/rectification/"
    initial = staff.get(path).context["form"].initial
    assert (
        staff.post(
            path,
            initial
            | {
                "operation": "propose",
                "reason": REASON,
                "fields": ["phone"],
                "phone": "unverified contact",
            },
        ).status_code
        == 400
    )
    assert not RightsRectificationProposal.objects.exists()


def test_source_read_is_required_and_text_change_invalidates_it(request, settings, monkeypatch):
    case, _, staff, _, _, person = ready(request, settings, monkeypatch, "rectify")
    path = f"/en/moderation/rights/{case.pk}/rectification/"
    initial = staff.get(path).context["form"].initial
    data = initial | {
        "operation": "propose",
        "fields": ["title"],
        "title": "Corrected synthetic title",
        "reason": REASON,
    }
    assert staff.post(path, data).status_code == 409
    response = staff.post(
        path,
        initial
        | {
            "operation": "preview",
            "purpose": "Audit current revision fields for requested correction",
        },
    )
    assert (
        response.status_code == 200
        and response.context["source_fields"]["title"] == person.listing.approved_revision.title
    )
    assert staff.get(path).context["source_fields"] is None
    revision = person.listing.approved_revision
    revision.title = "Interleaved synthetic source correction"
    revision.save(update_fields=["title"])
    assert staff.post(path, data).status_code == 409
    assert not RightsRectificationProposal.objects.exists()
    assert (
        staff.post(
            path,
            initial
            | {
                "operation": "preview",
                "purpose": "Reinspect changed revision fields before correction",
            },
        ).status_code
        == 200
    )
    assert staff.post(path, data).status_code == 302


def test_mobile_source_review_and_field_proposal(
    live_server, request, settings, monkeypatch, tmp_path
):
    import json
    import shutil

    import pyotp
    from playwright.sync_api import expect, sync_playwright
    from test_rectification_proposal_localization import assert_if_present, check_missing_selection

    settings.DEBUG = True
    case, _, _, _, _, person = ready(request, settings, monkeypatch, "rectify")
    credentials = json.loads((tmp_path / "credentials.json").read_text())
    account = credentials["accounts"]["moderator"]
    alias_before = person.alias
    from test_rectification_photos import add_source_photo

    from apps.safety.rectification_photos import source as photo_source

    add_source_photo(person.listing.approved_revision)
    photo_ids = photo_source(person.listing.approved_revision)
    from apps.catalog.models import Municipality

    new_city = (
        Municipality.objects.filter(active=True)
        .exclude(pk=person.listing.approved_revision.municipality_id)
        .first()
    )
    assert new_city
    from django.utils import timezone

    from apps.core.models import PhoneClaim

    replacement_phone = PhoneClaim.objects.create(
        phone="+34600000992",
        agency_id=person.agency_id,
        individual_id=person.individual_id,
        verified_at=timezone.now(),
        verification_procedure="simulator-v1",
    )
    from apps.catalog.models import Category, Service

    new_category = Category.objects.create(
        slug="synthetic-browser-corrected-category",
        name_es="Synthetic browser category",
        name_en="Synthetic browser category",
    )
    new_service = Service.objects.create(
        slug="synthetic-browser-corrected-service",
        category=new_category,
        name_es="Synthetic browser service",
        name_en="Synthetic browser service",
    )
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            executable_path=shutil.which("chromium-browser"), args=["--no-sandbox"]
        )
        try:
            page = browser.new_page(viewport={"width": 390, "height": 844})
            page.goto(live_server.url + "/en/account/login/")
            page.locator("[name=email]").fill(account["email"])
            page.locator("[name=password]").fill(credentials["password"])
            page.locator("button[type=submit]").click()
            page.locator("[name=code]").fill(pyotp.TOTP(account["totp_secret"]).now())
            page.locator("button[type=submit]").click()
            page.goto(live_server.url + f"/en/moderation/rights/{case.pk}/")
            page.get_by_role("link", name="Propose data correction", exact=True).click()
            assert_if_present(page, "en")
            check_missing_selection(page, "en", case.pk)
            page.locator("[name=operation]").select_option("preview")
            page.locator("[name=purpose]").fill(
                "Inspect current scoped source before proposing correction"
            )
            page.get_by_role("button", name="Record correction action", exact=True).click()
            assert_if_present(page, "en")
            expect(
                page.get_by_role("heading", name="Audited current fields", exact=True)
            ).to_be_visible()
            from test_photos import raw_image

            page.get_by_role("link", name="Prepare replacement images", exact=True).click()
            page.locator("[name=image]").set_input_files(
                {
                    "name": "synthetic-replacement.jpg",
                    "mimeType": "image/jpeg",
                    "buffer": raw_image(946),
                }
            )
            page.locator("[name=reason]").fill(
                "Synthetic browser replacement image scoped for independent review"
            )
            page.get_by_role("button", name="Record image preparation", exact=True).click()
            expect(
                page.get_by_role("heading", name="Propose data correction", exact=True)
            ).to_be_visible()
            page.locator("[name=operation]").select_option("preview")
            page.locator("[name=purpose]").fill(
                "Inspect processed replacement and original source before selection"
            )
            page.get_by_role("button", name="Record correction action", exact=True).click()
            assert_if_present(page, "en")
            page.get_by_role("link", name="Discard prepared image", exact=True).click()
            expect(
                page.get_by_role("heading", name="Discard prepared image", exact=True)
            ).to_be_visible()
            page.locator("[name=reason]").fill(
                "Discard synthetic prepared image before a fresh scoped replacement"
            )
            page.get_by_role("button", name="Record image preparation", exact=True).click()
            expect(
                page.get_by_role("heading", name="Propose data correction", exact=True)
            ).to_be_visible()
            page.locator("[name=operation]").select_option("preview")
            page.locator("[name=purpose]").fill(
                "Inspect source after discarded preparation before new upload"
            )
            page.get_by_role("button", name="Record correction action", exact=True).click()
            assert_if_present(page, "en")
            expect(page.locator('[name^="photos-"][name$="-photo_id"]')).to_have_count(2)
            page.get_by_role("link", name="Prepare replacement images", exact=True).click()
            page.locator("[name=image]").set_input_files(
                {
                    "name": "synthetic-replacement.jpg",
                    "mimeType": "image/jpeg",
                    "buffer": raw_image(946),
                }
            )
            page.locator("[name=reason]").fill(
                "Synthetic browser replacement image scoped for independent review"
            )
            page.get_by_role("button", name="Record image preparation", exact=True).click()
            expect(
                page.get_by_role("heading", name="Propose data correction", exact=True)
            ).to_be_visible()
            page.locator("[name=operation]").select_option("preview")
            page.locator("[name=purpose]").fill(
                "Inspect processed replacement and original source before selection"
            )
            page.get_by_role("button", name="Record correction action", exact=True).click()
            assert_if_present(page, "en")
            staged_id = page.locator("[name=photos-2-photo_id]").input_value()
            expect(page.locator("[name=alias]")).to_have_value(alias_before)
            page.locator('[name=fields][value="alias"]').check()
            page.locator("[name=alias]").fill("Synthetic browser correction")
            page.locator('[name=fields][value="location"]').check()
            page.locator("[name=municipality]").select_option(str(new_city.pk))
            page.locator("[name=postal_code]").select_option("")
            page.locator("[name=zone]").select_option("")
            page.locator('[name=fields][value="catalog"]').check()
            for field in ["categories", "services"]:
                for checkbox in page.locator(f"[name={field}]").all():
                    checkbox.uncheck()
            page.locator(f'[name=categories][value="{new_category.pk}"]').check()
            page.locator(f'[name=services][value="{new_service.pk}"]').check()
            page.locator('[name=fields][value="rates"]').check()
            for checkbox in page.locator('[name^="rates-"][name$="-DELETE"]').all():
                checkbox.check()
            expect(page.locator('[name$="-concept"]')).to_have_count(10)
            page.locator("[name=rates-0-DELETE]").uncheck()
            page.locator("[name=rates-0-concept]").fill("Synthetic browser rate")
            page.locator("[name=rates-0-mode]").select_option("consult")
            page.locator("[name=rates-0-amount]").fill("")
            page.locator("[name=rates-0-duration_minutes]").fill("")
            page.locator("[name=rates-9-DELETE]").uncheck()
            page.locator("[name=rates-9-concept]").fill("Synthetic tenth browser rate")
            page.locator("[name=rates-9-mode]").select_option("consult")
            page.locator("[name=rates-9-amount]").fill("")
            page.locator("[name=rates-9-duration_minutes]").fill("")
            page.locator('[name=fields][value="photos"]').check()
            expect(page.get_by_alt_text("Source photo 1", exact=True)).to_be_visible()
            assert page.get_by_alt_text("Source photo 1", exact=True).evaluate(
                "image => image.decode().then(() => image.naturalWidth > 0)"
            )
            page.locator("[name=photos-0-position]").fill("1")
            page.locator("[name=photos-1-position]").fill("0")
            page.locator("[name=photos-2-DELETE]").uncheck()
            page.locator("[name=photos-2-position]").fill("2")
            expect(page.get_by_alt_text("Source photo 3", exact=True)).to_be_visible()
            assert page.get_by_alt_text("Source photo 3", exact=True).evaluate(
                "image => image.decode().then(() => image.naturalWidth > 0)"
            )
            page.locator('[name=fields][value="contacts"]').check()
            page.locator("[name=phone]").fill(replacement_phone.phone)
            page.locator("[name=whatsapp]").check()
            page.locator("[name=telegram]").fill("synthetic_browser")
            page.locator('[name=fields][value="details"]').check()
            page.locator("[name=content_language]").select_option("en")
            page.locator("[name=profile_type]").select_option("other")
            for field in ["spoken_languages", "days", "travel_areas"]:
                for checkbox in page.locator(f"[name={field}]").all():
                    checkbox.uncheck()
            page.locator('[name=spoken_languages][value="en"]').check()
            page.locator('[name=days][value="3"]').check()
            page.locator("[name=time_slot]").select_option("morning")
            page.locator("[name=reception]").check()
            page.locator("[name=travel]").check()
            page.locator(f'[name=travel_areas][value="{new_city.pk}"]').check()
            page.locator("[name=reason]").fill(REASON)
            page.get_by_role("button", name="Record correction action", exact=True).click()
            assert_if_present(page, "en")
            expect(
                page.get_by_role("heading", name="Private rights inspection", exact=True)
            ).to_be_visible()
            page.goto(live_server.url + f"/en/moderation/rights/{case.pk}/rectification/")
            assert_if_present(page, "en")
            expect(page.locator("[name=alias]")).to_have_value("")
            assert page.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
        finally:
            browser.close()
    proposal = RightsRectificationProposal.objects.get()
    assert unseal(proposal.encrypted_changes) == {
        "alias": "Synthetic browser correction",
        "details": {
            "content_language": "en",
            "profile_type": "other",
            "spoken_languages": ["en"],
            "days": ["3"],
            "time_slot": "morning",
            "reception": True,
            "travel": True,
            "travel_areas": [new_city.pk],
        },
        "contacts": {
            "phone": replacement_phone.phone,
            "whatsapp": True,
            "telegram": "synthetic_browser",
        },
        "rates": [
            {
                "concept": "Synthetic browser rate",
                "mode": "consult",
                "amount": None,
                "currency": "EUR",
                "duration_minutes": None,
            },
            {
                "concept": "Synthetic tenth browser rate",
                "mode": "consult",
                "amount": None,
                "currency": "EUR",
                "duration_minutes": None,
            },
        ],
        "photos": [*reversed(photo_ids), staged_id],
        "catalog": {"categories": [new_category.pk], "services": [new_service.pk]},
        "location": {"municipality": new_city.pk, "postal_code": None, "zone": None},
    }
    person.refresh_from_db()
    assert person.alias == alias_before


def test_location_form_requires_coherent_public_safe_city_postal_and_zone(
    request, settings, monkeypatch
):
    from apps.catalog.models import Municipality, PostalCode, Zone
    from apps.safety.rectification_location import source as location_source

    case, _, staff, _, _, person = ready(request, settings, monkeypatch, "rectify")
    revision = person.listing.approved_revision
    city = revision.municipality
    other = Municipality.objects.filter(active=True).exclude(pk=city.pk).first()
    assert other
    postal = PostalCode.objects.create(code="99982", source=city.source, public_safe=False)
    postal.municipalities.add(city)
    zone = Zone.objects.create(
        code="synthetic-location-test",
        name="Synthetic location test",
        municipality=city,
        source=city.source,
    )
    path = f"/en/moderation/rights/{case.pk}/rectification/"
    initial = staff.get(path).context["form"].initial
    page = staff.post(
        path,
        initial
        | {"operation": "preview", "purpose": "Inspect current location before scoped correction"},
    )
    assert page.status_code == 200
    assert page.context["source_fields"]["location"] == location_source(revision)
    assert staff.get(path).context["source_fields"] is None
    data = initial | {
        "operation": "propose",
        "fields": ["location"],
        "municipality": other.pk,
        "postal_code": postal.pk,
        "zone": zone.pk,
        "reason": REASON,
    }
    assert staff.post(path, data).status_code == 400  # Restricted precision cannot be selected.
    postal.public_safe = True
    postal.save(update_fields=["public_safe"])
    assert staff.post(path, data).status_code == 400  # CP and area belong to the old city.
    assert staff.post(path, data | {"postal_code": ""}).status_code == 400
    assert (
        staff.post(path, data | {"municipality": "", "postal_code": "", "zone": ""}).status_code
        == 400
    )
    assert not RightsRectificationProposal.objects.exists()
    assert staff.post(path, data | {"postal_code": "", "zone": ""}).status_code == 302
    proposal = RightsRectificationProposal.objects.get()
    assert unseal(proposal.encrypted_changes) == {
        "location": {"municipality": other.pk, "postal_code": None, "zone": None}
    }
    revision.refresh_from_db()
    assert revision.municipality_id == city.pk
    assert staff.get(path).context["source_fields"] is None


def test_catalog_form_requires_active_compatible_categories_and_services(
    request, settings, monkeypatch
):
    from django.core.exceptions import ValidationError

    from apps.catalog.models import Category, Service
    from apps.safety.rectification_catalog import source as catalog_source
    from apps.safety.rectification_catalog import validate

    case, _, staff, _, _, person = ready(request, settings, monkeypatch, "rectify")
    revision = person.listing.approved_revision
    original = catalog_source(revision)
    category = Category.objects.create(
        slug="synthetic-catalog-proposal",
        name_es="Synthetic proposal category",
        name_en="Synthetic proposal category",
    )
    service = Service.objects.create(
        slug="synthetic-catalog-proposal",
        category=category,
        name_es="Synthetic proposal service",
        name_en="Synthetic proposal service",
        active=False,
    )
    path = f"/en/moderation/rights/{case.pk}/rectification/"
    initial = staff.get(path).context["form"].initial
    page = staff.post(
        path,
        initial
        | {"operation": "preview", "purpose": "Inspect current catalog before scoped correction"},
    )
    assert page.status_code == 200 and page.context["source_fields"]["catalog"] == original
    assert staff.get(path).context["source_fields"] is None
    data = initial | {
        "operation": "propose",
        "fields": ["catalog"],
        "categories": [category.pk],
        "services": [service.pk],
        "reason": REASON,
    }
    assert staff.post(path, data).status_code == 400
    service.active = True
    service.save(update_fields=["active"])
    assert staff.post(path, data | {"categories": original["categories"]}).status_code == 400
    assert staff.post(path, data | {"categories": []}).status_code == 400
    assert staff.post(path, data | {"services": []}).status_code == 400
    with pytest.raises(ValidationError):
        validate({"categories": [category.pk, category.pk], "services": [service.pk]})
    with pytest.raises(ValidationError):
        validate({"categories": [True], "services": [service.pk]})
    assert not RightsRectificationProposal.objects.exists()
    assert staff.post(path, data).status_code == 302
    assert unseal(RightsRectificationProposal.objects.get().encrypted_changes) == {
        "catalog": {"categories": [category.pk], "services": [service.pk]}
    }
    assert catalog_source(revision) == original


@pytest.mark.parametrize("table_mode", ["fixed", "clear", "maximum"])
def test_rate_table_form_validates_management_amount_duration_and_deletion(
    request, settings, monkeypatch, table_mode
):
    from django.core.exceptions import ValidationError

    from apps.safety.rectification_rates import source as rates_source
    from apps.safety.rectification_rates import validate

    case, _, staff, _, _, person = ready(request, settings, monkeypatch, "rectify")
    revision = person.listing.approved_revision
    before = rates_source(revision)
    assert before
    path = f"/en/moderation/rights/{case.pk}/rectification/"
    initial = staff.get(path).context["form"].initial
    page = staff.post(
        path,
        initial
        | {"operation": "preview", "purpose": "Inspect tariff source before complete replacement"},
    )
    assert page.status_code == 200 and page.context["source_fields"]["rates"] == before
    assert staff.get(path).context["source_fields"] is None
    data = initial | {
        "operation": "propose",
        "fields": ["rates"],
        "reason": REASON,
        "rates-TOTAL_FORMS": "1",
        "rates-INITIAL_FORMS": "0",
        "rates-0-concept": "Synthetic corrected tariff",
        "rates-0-mode": "consult",
        "rates-0-amount": "50",
        "rates-0-duration_minutes": "60",
    }
    assert staff.post(path, data).status_code == 409
    assert (
        staff.post(path, data | {"rates-0-mode": "fixed", "rates-0-amount": "0"}).status_code == 409
    )
    assert (
        staff.post(
            path, data | {"rates-0-mode": "fixed", "rates-0-duration_minutes": "10081"}
        ).status_code
        == 409
    )
    assert (
        staff.post(
            path, {key: value for key, value in data.items() if key != "rates-TOTAL_FORMS"}
        ).status_code
        == 409
    )
    assert staff.post(path, data | {"rates-TOTAL_FORMS": "1000000"}).status_code == 409
    assert not RightsRectificationProposal.objects.exists()
    row = {
        "concept": "Synthetic corrected tariff",
        "mode": "fixed",
        "amount": "50.00",
        "currency": "EUR",
        "duration_minutes": 60,
    }
    for invalid in [
        {**row, "currency": "USD"},
        {**row, "amount": 50.0},
        {**row, "duration_minutes": True},
        {**row, "amount": "NaN"},
    ]:
        with pytest.raises(ValidationError):
            validate([invalid])
    for concept in [
        "https://external.invalid",
        "www.external.invalid",
        "@synthetic_contact",
        "+34999999999",
    ]:
        assert (
            staff.post(
                path, data | {"rates-0-mode": "fixed", "rates-0-concept": concept}
            ).status_code
            == 409
        )
        with pytest.raises(ValidationError):
            validate([{**row, "concept": concept}])
    assert not RightsRectificationProposal.objects.exists()
    valid = data | {"rates-0-mode": "fixed"}
    expected = [row]
    if table_mode == "clear":
        valid["rates-0-DELETE"] = "on"
        expected = []
    elif table_mode == "maximum":
        valid["rates-TOTAL_FORMS"] = "10"
        expected = []
        for index in range(10):
            current = {**row, "concept": f"Synthetic corrected tariff {index}"}
            expected.append(current)
            valid.update(
                {
                    f"rates-{index}-{field}": value
                    for field, value in current.items()
                    if field != "currency"
                }
            )
    assert staff.post(path, valid).status_code == 302
    assert unseal(RightsRectificationProposal.objects.get().encrypted_changes) == {
        "rates": expected
    }
    assert rates_source(revision) == before


def test_contact_proposal_requires_verified_owner_and_audited_binding(
    request, settings, monkeypatch
):
    from django.utils import timezone

    from apps.core.models import PhoneClaim, User
    from apps.safety.rectification_contacts import source as contacts_source

    case, _, staff, _, _, person = ready(request, settings, monkeypatch, "rectify")
    revision = person.listing.approved_revision
    old = contacts_source(revision)
    old_claim = person.phone_claim
    path = f"/en/moderation/rights/{case.pk}/rectification/"
    initial = staff.get(path).context["form"].initial
    page = staff.post(
        path,
        initial
        | {"operation": "preview", "purpose": "Inspect current contact and verification binding"},
    )
    assert page.status_code == 200 and page.context["source_fields"]["contacts"] == old
    assert old["phone"].encode() not in staff.get(path).content
    data = initial | {
        "operation": "propose",
        "fields": ["contacts"],
        "phone": "+34600000993",
        "whatsapp": "on",
        "telegram": "synthetic_contact",
        "reason": REASON,
    }
    assert staff.post(path, data).status_code == 409  # No verified claim is invented.
    foreign = PhoneClaim.objects.create(
        phone=data["phone"],
        individual=User.objects.get(username="fixture-v1-visitor"),
        verified_at=timezone.now(),
        verification_procedure="simulator-v1",
    )
    assert staff.post(path, data).status_code == 409
    foreign.delete()  # Synthetic unused record, no user content.
    target = PhoneClaim.objects.create(
        phone=data["phone"],
        agency_id=person.agency_id,
        individual_id=person.individual_id,
        verification_procedure="simulator-v1",
    )
    assert staff.post(path, data).status_code == 409
    target.verified_at = timezone.now()
    target.save(update_fields=["verified_at"])
    assert staff.post(path, data | {"telegram": "invalid/path"}).status_code == 400
    assert staff.post(path, data | {"phone": ""}).status_code == 400
    original_verified = old_claim.verified_at
    old_claim.verified_at = None
    old_claim.save(update_fields=["verified_at"])
    assert staff.post(path, data).status_code == 409  # Source binding changed without case version.
    old_claim.verified_at = original_verified
    old_claim.save(update_fields=["verified_at"])
    assert not RightsRectificationProposal.objects.exists()
    assert staff.post(path, data).status_code == 302
    assert unseal(RightsRectificationProposal.objects.get().encrypted_changes) == {
        "contacts": {"phone": target.phone, "whatsapp": True, "telegram": "synthetic_contact"}
    }
    person.refresh_from_db()
    assert person.phone_claim_id == old_claim.pk and contacts_source(revision) == old


def test_details_form_validates_choices_lists_and_active_travel_cities(
    request, settings, monkeypatch
):
    from django.core.exceptions import ValidationError

    from apps.catalog.models import Municipality
    from apps.safety.rectification_details import source, validate

    case, _, staff, _, _, person = ready(request, settings, monkeypatch, "rectify")
    revision = person.listing.approved_revision
    original = source(revision)
    city = Municipality.objects.filter(active=True).exclude(pk=revision.municipality_id).first()
    assert city
    path = f"/en/moderation/rights/{case.pk}/rectification/"
    initial = staff.get(path).context["form"].initial
    page = staff.post(
        path,
        initial
        | {"operation": "preview", "purpose": "Inspect profile attributes before correction"},
    )
    assert page.status_code == 200 and page.context["source_fields"]["details"] == original
    data = initial | {
        "operation": "propose",
        "fields": ["details"],
        "reason": REASON,
        "content_language": "en",
        "profile_type": "other",
        "spoken_languages": ["en", "fr"],
        "days": ["2"],
        "time_slot": "evening",
        "reception": "on",
        "travel": "on",
        "travel_areas": [city.pk],
    }
    for field, value in [
        ("profile_type", "unknown"),
        ("content_language", "xx"),
        ("days", ["9"]),
        ("spoken_languages", ["xx"]),
        ("time_slot", "unknown"),
    ]:
        assert staff.post(path, data | {field: value}).status_code == 400
    city.active = False
    city.save(update_fields=["active"])
    assert staff.post(path, data).status_code == 400
    city.active = True
    city.save(update_fields=["active"])
    valid = {
        "content_language": "en",
        "profile_type": "other",
        "spoken_languages": ["en", "fr"],
        "days": ["2"],
        "time_slot": "evening",
        "reception": True,
        "travel": True,
        "travel_areas": [city.pk],
    }
    for invalid in [
        {**valid, "days": [2]},
        {**valid, "days": ["2", "2"]},
        {**valid, "travel_areas": [True]},
        {**valid, "travel": 1},
    ]:
        with pytest.raises(ValidationError):
            validate(invalid)
    assert not RightsRectificationProposal.objects.exists()
    assert staff.post(path, data).status_code == 302
    assert unseal(RightsRectificationProposal.objects.get().encrypted_changes) == {"details": valid}
    assert source(revision) == original
    assert staff.get(path).context["source_fields"] is None


@pytest.mark.parametrize("field", ["title", "description", "description_alternative"])
def test_correction_text_obeys_listing_editor_limits_and_contact_rules(
    request, settings, monkeypatch, field
):
    import uuid

    from django.core.exceptions import ValidationError

    from apps.listings.forms import DetailsForm
    from apps.safety.rights_rectification import propose, validated_changes

    case, moderator, staff, _, _, person = ready(request, settings, monkeypatch, "rectify")
    path = f"/en/moderation/rights/{case.pk}/rectification/"
    initial = staff.get(path).context["form"].initial
    maximum = DetailsForm.base_fields[field].max_length
    page = staff.post(
        path,
        initial
        | {"operation": "preview", "purpose": "Inspect current text source before correction"},
    )
    assert page.status_code == 200
    assert page.context["form"].fields[field].max_length == maximum
    data = initial | {
        "operation": "propose",
        "fields": [field],
        "reason": REASON,
        field: "x" * (maximum + 1),
    }
    assert staff.post(path, data).status_code == 400
    with pytest.raises(ValidationError):
        propose(
            moderator, case.pk, uuid.uuid4(), case.version, {field: "x" * (maximum + 1)}, REASON
        )
    for unsafe in [
        "Synthetic text https://example.invalid",
        "Synthetic text www.example.invalid",
        "Synthetic contact @example_name",
        "Synthetic phone +34 600 000 991",
    ]:
        with pytest.raises(ValidationError):
            validated_changes({field: unsafe})
        assert staff.post(path, data | {field: unsafe}).status_code == 409
    assert not RightsRectificationProposal.objects.exists()
    revision = person.listing.approved_revision
    before = getattr(revision, field)
    valid = "x" * maximum
    assert staff.post(path, data | {field: valid}).status_code == 302
    assert unseal(RightsRectificationProposal.objects.get().encrypted_changes) == {field: valid}
    revision.refresh_from_db()
    assert getattr(revision, field) == before
    if field == "description_alternative":
        assert validated_changes({field: ""}) == {field: ""}


def test_public_names_do_not_bypass_contact_fields_and_correction_preserves_exact_text(
    request, settings, monkeypatch
):
    from django.core.exceptions import ValidationError

    from apps.core.agencies import AgencyForm, PersonForm
    from apps.safety.rights_rectification import validated_changes

    for unsafe in [
        "Synthetic https://example.invalid",
        "Synthetic @public_contact",
        "Synthetic +34 600 000 991",
    ]:
        assert not AgencyForm({"name": unsafe}).is_valid()
        assert not PersonForm({"alias": unsafe}).is_valid()
        with pytest.raises(ValidationError):
            validated_changes({"alias": unsafe})
    assert AgencyForm({"name": "Synthetic public agency"}).is_valid()
    assert PersonForm({"alias": "Synthetic public profile"}).is_valid()
    case, _, staff, _, _, person = ready(request, settings, monkeypatch, "rectify")
    revision = person.listing.approved_revision
    before = revision.description
    path = f"/en/moderation/rights/{case.pk}/rectification/"
    initial = staff.get(path).context["form"].initial
    assert (
        staff.post(
            path,
            initial
            | {"operation": "preview", "purpose": "Inspect exact text before reviewed correction"},
        ).status_code
        == 200
    )
    data = initial | {
        "operation": "propose",
        "fields": ["alias"],
        "alias": "Synthetic @public_contact",
        "reason": REASON,
    }
    assert staff.post(path, data).status_code == 409
    assert not RightsRectificationProposal.objects.exists()
    exact = "  Synthetic corrected paragraph.\n\nSecond paragraph.  "
    assert validated_changes({"description": exact}) == {"description": exact}
    assert (
        staff.post(path, data | {"fields": ["description"], "description": exact}).status_code
        == 302
    )
    assert unseal(RightsRectificationProposal.objects.get().encrypted_changes) == {
        "description": exact
    }
    revision.refresh_from_db()
    assert revision.description == before


@pytest.mark.parametrize(
    "field,value",
    [
        ("status", "erased"),
        ("derivative", "derivatives/synthetic-replacement.webp"),
        ("sha256", "f" * 64),
    ],
)
def test_media_source_change_invalidates_audited_correction(
    request, settings, monkeypatch, field, value
):
    case, _, staff, _, _, person = ready(request, settings, monkeypatch, "rectify")
    revision = person.listing.approved_revision
    photo = revision.photos.filter(removed_at__isnull=True).first()
    assert photo is not None
    blob = photo.blob
    previous = getattr(blob, field)
    path = f"/en/moderation/rights/{case.pk}/rectification/"
    initial = staff.get(path).context["form"].initial
    response = staff.post(
        path,
        initial
        | {"operation": "preview", "purpose": "Inspect media bound to correction before proposal"},
    )
    assert response.status_code == 200
    data = initial | {
        "operation": "propose",
        "fields": ["title"],
        "title": "Corrected synthetic title",
        "reason": REASON,
    }
    setattr(blob, field, value)
    blob.save(update_fields=[field])
    assert staff.post(path, data).status_code == 409
    assert not RightsRectificationProposal.objects.exists()
    # Restore synthetic metadata without changing file contents; a fresh read
    # of the same complete source authorizes the still-current proposal.
    setattr(blob, field, previous)
    blob.save(update_fields=[field])
    assert staff.post(path, data).status_code == 302
    assert blob.sha256.encode() not in staff.get(path).content
    assert str(blob.pk).encode() not in staff.get(path).content


def test_media_snapshot_serializes_blob_mutation(request, settings, monkeypatch):
    from concurrent.futures import ThreadPoolExecutor
    from queue import Queue
    from threading import Event
    from time import monotonic

    from django.db import connection, connections, transaction

    from apps.mediafiles.models import Blob
    from apps.safety.rights_rectification import source_snapshot

    case, _, _, _, _, person = ready(request, settings, monkeypatch, "rectify")
    listing = person.listing
    blob = listing.approved_revision.photos.filter(removed_at__isnull=True).first().blob
    original = blob.derivative.name
    writer_pid = Queue()
    pause = Event()

    def mutate():
        connections.close_all()
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT pg_backend_pid()")
                writer_pid.put(cursor.fetchone()[0])
            Blob.objects.filter(pk=blob.pk).update(
                derivative="derivatives/concurrent-synthetic.webp"
            )
        finally:
            connections.close_all()

    with ThreadPoolExecutor(max_workers=1) as pool:
        with transaction.atomic():
            _, snapshot = source_snapshot(case, person, listing)
            assert any(
                row["id"] == str(blob.pk) and row["derivative"] == original
                for row in snapshot["copied_source"]["blobs"]
            )
            with connection.cursor() as cursor:
                cursor.execute("SELECT pg_backend_pid()")
                holder_pid = cursor.fetchone()[0]
            pending = pool.submit(mutate)
            pid = writer_pid.get(timeout=5)
            deadline = monotonic() + 5
            blockers = []
            while monotonic() < deadline:
                with connection.cursor() as cursor:
                    cursor.execute("SELECT pg_blocking_pids(%s)", [pid])
                    blockers = cursor.fetchone()[0]
                if holder_pid in blockers:
                    break
                pause.wait(0.01)
            assert holder_pid in blockers
            assert not pending.done()
        pending.result(timeout=5)
    blob.refresh_from_db()
    assert blob.derivative.name == "derivatives/concurrent-synthetic.webp"
    # Test-only metadata update; no synthetic storage bytes were changed.
    Blob.objects.filter(pk=blob.pk).update(derivative=original)
