"""Current N11 requirement audit; never accepts the whole contract or deferred debt."""
import collections,copy,hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
sys.path.insert(0,'scripts')
from run_local_ci import hashes
W=Path('artifacts/recorridos-n11-20261026/n11d');load=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
path=Path('docs/evidencias/n11-d-matriz-integrada-acciones-20261027.json');before=path.read_bytes();m=json.loads(before);f=load(W/'freeze.json');a=load(W/'common-audit.json');c=load('artifacts/recorridos-n11-20261026/n11c/candidate-audit.json');cf=load('artifacts/recorridos-n11-20261026/n11c/freeze.json');reuse=load(W/'reuse-audit.json');bridge=load(W/'integrated-source-bridge.json');requirements={}
assert not m['N11_accepted']and m['state']=='DRAFT_N11_INTEGRATED_MATRIX_NOT_ACCEPTED'
assert hashes()==f['sources']and subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==m['candidate_commit']==a['candidate_commit']=='48dfad61f71ccd378d5e6ccd979c91d4b7908cc7'
for group in ['extra_sources','docs']:
 for p,h in f[group].items():assert sha(p)==h,p
assert not subprocess.check_output(['git','diff','HEAD','--','apps','config','templates','tests','scripts','uv.lock','pyproject.toml'],text=True).strip()
requirements['R01_integrated_candidate_sources_dependencies_migrations_instruments_frozen']=True
canonical={r['id']:r for r in load(m['original_census'])['actions']};assert set(m['rows'])==set(canonical)and len(canonical)==443
families=set();N02only=[];sharedN02=[]
for ident,row in m['rows'].items():
 original=canonical[ident];assert row['families']==original['families']and row['original_blocks']==original['blocks']and not row['whole_functionality_PASS_claimed'];families.update(row['families'])
 assert set(row['prior_dispositions'])==set(original['blocks'])
 for p,h in row['candidate_source_sha256'].items():assert sha(p)==h,p
 if set(row['original_blocks'])=={'N02'}:N02only.append(ident)
 elif 'N02'in row['original_blocks']:sharedN02.append(ident)
assert len(families)==28 and len(N02only)==23 and len(sharedN02)==16
assert sha(m['original_census'])==m['original_census_sha256']
requirements['R02_all443_original_actions28families_ownership_and_declared_debt_reconciled']=True
assert reuse['result']=='PASS_N11_PRIOR_REFERENCE_CUSTODY_WITH_DECLARED_SOURCE_BRIDGES'and len(reuse['actual_referenced_runs'])==45
assert reuse['original_whole_ERROR_not_rewritten']['original_result']=='ERROR'and reuse['original_whole_ERROR_not_rewritten']['actual_case_counts_separate']=={'PASS':3697,'FAIL':3,'SKIP':129}
assert reuse['CLI_corrective_separate']['actual_case_counts_separate']=={'PASS':23}
assert bridge['full_non_doc_source_reconciliation']['same_sources']==1791 and len(bridge['changed_product_files'])==4 and len(bridge['full_non_doc_source_reconciliation']['added_instruments'])==3
for row in bridge['current_moderation_source_bridges']['records']:
 assert sha(row['file'])==row['current_candidate_sha256']==cf['sources'][row['file']]==f['sources'][row['file']]
for block,root in m['blocks'].items():
 assert sha(root['path'])==root['sha256']and sha(root['root_acceptance_gate']['path'])==root['root_acceptance_gate']['sha256']
for record in reuse['actual_referenced_runs']:
 p=Path('artifacts/capacity-environment'if record['kind'].startswith('capacity')else'artifacts/local-ci')/record['run']/'pytest.xml';assert sha(p)==record['actual_XML_sha256']
requirements['R03_scoped_prior_witnesses_actual_custody_and_explicit_current_source_bridges']=True
assert a['counts']=={'PASS':44,'FAIL':0,'ERROR':0,'SKIP':0}and a['ordinary_cases']==21 and a['unit_guard_cases']==23 and a['sources_stable']
P=Path('artifacts/local-ci')/a['run'];assert load(P/'result.json')['result']=='PASS'and sha(P/'pytest.xml')==a['actual_JUnit_sha256']
assert len(list(ET.parse(P/'pytest.xml').iter('testcase')))==44
assert c['counts']=={'PASS':30,'FAIL':0,'ERROR':0,'SKIP':0}and c['run']!=a['run']
requirements['R04_pertinent_common44_actually_executed_separately_from_focal30']=True
known=[]
for row in c['observations']['POST']:
 d=row['observed']
 if d['revoke']:
  assert d['actual_wait']and d['http_status']==403 and d['full_snapshot_no_effect']and not d['effective_permission_after']
  known.append({'issue':'N11_'+d['surface']+'_POST_after_wait','case':row['case'],'status':'closed_in_selected_actual_wait_scenario'})
for row in c['observations']['image']:
 d=row['observed']
 if d['revoke']:
  assert d['actual_wait']and d['http_status']==403 and d['all_rows_unchanged']and not d['streaming']and not d['image_bytes_match']and d['derivative_bytes_returned']==0
  known.append({'issue':'N11_'+d['surface']+'_private_read_after_wait','case':row['case'],'status':'closed_in_selected_actual_wait_scenario'})
assert len(known)==5 and c['actual_PG_waits']==23 and c['denied_after_wait']==18 and c['valid_wait_controls']==5
assert all(row['observed']['all_rows_unchanged']and row['observed']['http_status']==403 for row in c['observations']['variants'])
assert len(c['ordinary_cases'])==7 and c['all_models_and_files_scoped_oracles']and c['original_POST_negative_expectations_preserved']and c['image_instrument_byteidentical_to_original']
requirements['R05_authority_privacy_versions_replay_and_domain_invariants_in_selected_cases']=True
assert all(k['status']=='closed_in_selected_actual_wait_scenario'for k in known)
assert load('artifacts/recorridos-n11-20261026/n11a/original-audit.json')['counts']=={'PASS':1,'FAIL':3,'ERROR':0,'SKIP':0}
assert load('artifacts/recorridos-n11-20261026/n11b/invalid-audit.json')['runner_result']=='INVALID'
requirements['R06_known_demonstrated_critical_access_exposure_issues_closed_in_accepted_scope']=True
assert reuse['omissions']['original_SKIPs']==129 and reuse['omissions']['opt_in_not_PASS']==121 and reuse['omissions']['supplemental_scoped_records']==8 and not reuse['omissions']['all_counted_as_PASS']
assert a['HTTP_samples']==len(a['samples'])==253 and a['resolved_route_names']==31 and len(a['unresolved'])==1 and a['unresolved'][0]['status']==404
assert all(s['exception_class']is None and s['observer_error_class']is None for s in a['samples'])
requirements['R07_PASS_FAIL_ERROR_SKIP_negatives_and_unresolved_metadata_kept_separate']=True
assert a['cleanup_verified']and c['cleanup_verified']and a['telegram']['delivery']==c['telegram']['delivery']=='sent'
assert a['run']!=c['run']and a['junit_seconds']==196.539 and c['junit_seconds']==205.811
assert all('request_seconds_instrumented'in s and 'sql_queries'in s for s in a['samples'])
requirements['R08_own_cleanup_notifications_and_QA_vs_instrumented_app_timings_separate']=True
for p,v in load('artifacts/recorridos-n11-20261026/n11c/lateral-before-candidate.json')['paths'].items():assert not Path(p).exists()if v.get('absent')else sha(p)==v['sha256'],p
assert Path('docs/deuda-pendiente-viva.md').exists()and m['alpha_noindex']
assert all(m['rows'][ident]['prior_dispositions']['N02']['state']=='residual_performance_user_deferred_not_PASS'for ident in N02only+sharedN02)
requirements['R09_live_debt_conditions_alpha_noindex_and_lateral_scope_preserved']=True
assert len(requirements)==9 and all(requirements.values())
# Preserve the exact preregistration matrix; acceptance changes only reconciliation metadata.
(W/'matrix-prerun.json').write_bytes(before)
by_action=collections.defaultdict(list)
for s in a['samples']:
 if s['route_name']=='unresolved':continue
 ident='route:R_'+s['route_name'];assert ident in m['rows'],ident
 by_action[ident].append({'case':s['case'],'sample_index':s['sample_index'],'method':s['method'],'status':s['status']})
for ident,row in m['rows'].items():
 row['N11_reconciliation']='deferred_N02_residual_disposition_preserved'if ident in N02only else'scoped_prior_dispositions_reconciled_with_current_source_bridges'
 row['N11_current_common_HTTP_samples']=by_action.get(ident,[])
 if row['new_moderation_direct_source_overlap']:row['N11_current_authority_fix']='C30_actual_current_23PGwaits18denials_and_ordinary_controls; scope in495, unchanged bodies and changed shared authority explicitly bridged'
 row['N11_limit']='Disposition/identity/scoped witness reconciliation, not a new independent PASS for every action/method/role/population. Direct service calls and unmeasured branches retain their declared original scopes.'
m.update(state='N11_ACCEPTED_LOCAL_SCOPED_INTEGRATED_CONCILIATION443',N11_accepted=True,mandatory_accepted=11,mandatory_total=13,acceptance_doc='docs/498-n11-aceptacion-local-integracion-20261027.md',reconciled_dispositions=443,N02_only_deferred_dispositions=23,scoped_non_N02_only_dispositions=420,common_regression={'state':'PASS_SCOPED','run':a['run'],'actual_cases':44,'ordinary_cases':21,'unit_guard_cases':23,'actual_JUnit_sha256':a['actual_JUnit_sha256'],'selection':f['selection'],'junit_QA_seconds':a['junit_seconds'],'HTTP_samples':253,'resolved_route_names':31,'unresolved_expected404':1,'scope':'Clientcallphase/descriptive only; separate from C30 and old runs, no74PASSfiction'},known_issues_closed_in_selected_scope=known,requirements=requirements,remaining=['N15','N02_residual_user_deferred_to_development_end'],conditioned_not_PASS=['N12','N13','N14'],proof_archive='docs/evidencias/n11-d-regresion-conciliacion-20261027.tar.gz',whole_goal_complete=False)
path.write_text(json.dumps(m,ensure_ascii=False,indent=2))
proof={'result':'PASS_N11_LOCAL_REQUIREMENTS_ACCEPTED_NOT_WHOLE_CONTRACT','requirements':requirements,'matrix':str(path),'matrix_sha256_before':hashlib.sha256(before).hexdigest(),'matrix_sha256_after':sha(path),'actions':443,'families':28,'direct_source_files':295,'scoped_non_N02_only_dispositions':420,'N02_only_deferred_dispositions':23,'N02_shared_deferred_owners':16,'known_issue_closures':known,'common_actual_run':a['run'],'common_actual_cases':44,'focal_actual_run':c['run'],'focal_actual_cases':30,'runs_are_separate_not_one74PASS':True,'prior_actual_reference_cuts':45,'original_negatives_INVALID_and_129SKIP_preserved':True,'mandatory_accepted':11,'mandatory_total':13,'remaining':['N15','N02_residual_user_deferred_to_development_end'],'conditioned_not_PASS':['N12','N13','N14'],'alpha_noindex':True,'whole_goal_complete':False,'limits':['Local selected scenarios/source bridges, not every path or a global security certificate','N02 budgetFAIL2s5s and residual optimization deferred, not silently accepted','No production/opening/provider/new capacity acceptance','N15 full graph and differential/frontend inventory plus purge remain mandatory']}
(W/'acceptance-audit.json').write_text(json.dumps(proof,indent=2));print(json.dumps(proof))
