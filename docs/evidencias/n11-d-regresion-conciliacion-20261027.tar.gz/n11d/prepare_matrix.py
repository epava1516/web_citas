import ast,hashlib,json,subprocess
from pathlib import Path
W=Path('artifacts/recorridos-n11-20261026/n11d');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
census='docs/evidencias/n00-matriz-acciones-prioridades-20261025.json';original=load(census)
roots={
'N03':('docs/evidencias/n03-aceptacion-verificacion-20261025.json','actions'),
'N04':('docs/evidencias/n04-final-acceptance-verification-20261025.json','actions'),
'N05':('docs/evidencias/n05-final-action-matrix-20261025.json','action_dispositions'),
'N06':('docs/evidencias/n06-aceptacion-matriz-final-20261025.json','actions'),
'N07':('docs/evidencias/n07-disposiciones-finales-20261026.json','actions'),
'N08':('docs/evidencias/n08-disposiciones-finales-20261026.json','actions'),
'N09':('docs/evidencias/n09-s-censo139-aceptacion-local-20261026.json','rows'),
'N10':('docs/evidencias/n10-e-matriz77-disposiciones-20261026.json','rows')}
proofs={};maps={}
for block,(path,key)in roots.items():
 data=load(path);rows=data[key];index={k:'#/'+key+'/'+k.replace('~','~0').replace('/','~1')for k in rows}if isinstance(rows,dict)else{(r if isinstance(r,str)else r['id']):'#/'+key+'/'+str(i)for i,r in enumerate(rows)}
 proofs[block]={'path':path,'sha256':sha(path),'declared_actions':len(index),'state':'prior_local_scoped_acceptance_reference_not_new_runtime'};maps[block]=index
selection=[
'tests/test_accounts.py::test_signup_verified_login_replay_and_no_privilege_escalation',
'tests/test_accounts.py::test_reset_one_use_expiry_and_existing_sessions_invalidated',
'tests/test_drafts.py::test_wizard_persists_profile_and_contact_without_service_rates',
'tests/test_photos.py::test_valid_photo_private_derivative_retries_exif_and_remove',
'tests/test_discovery.py::test_search_approved_text_language_and_hidden_revisions',
'tests/test_discovery.py::test_language_any_geo_and_private_postal_filters',
'tests/test_discovery.py::test_pagination_invalid_and_out_of_range_preserve_filter_semantics',
'tests/test_favorites.py::test_favorites_private_idempotent_permissions_and_hidden_content',
'tests/test_lifecycle.py::test_availability_pause_resume_withdraw_and_old_retry',
'tests/test_lifecycle.py::test_withdraw_pending_revision_prevents_late_moderation',
'tests/test_promotion_orders.py::test_order_snapshot_replay_pending_failed_success_and_event_conflicts',
'tests/test_promotion_orders.py::test_invalid_events_foreign_actor_and_revoked_session_never_grant',
'tests/test_rights_verification.py::test_scoped_simulation_needs_independent_permission_and_current_evidence',
'tests/test_rectification_review.py::test_independent_audited_review_needs_fresh_source_and_preserves_publication[approved]',
'tests/test_reports.py::test_anonymous_receipt_private_encryption_replay_and_formal_rules',
'tests/test_notice_delivery.py::test_due_outbox_exactly_once_private_receipt_and_production_disabled',
'tests/test_notice_operations.py::test_recovery_preserves_history_replays_and_case_decision',
'tests/test_operational_events.py::test_actual_http_state_and_fallback_emit_without_changing_population',
'tests/test_publication_state.py::test_state_route_matches_native_before_and_after_refresh',
'tests/test_publication_state.py::test_rules_version_hashes_source_and_configuration',
'tests/test_benchmark_owned_redis.py']
count=0
for selector in selection:
 parts=selector.split('::');nodes=[n for n in ast.parse(Path(parts[0]).read_text()).body if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')]
 if len(parts)>1:
  name=parts[1].split('[',1)[0];nodes=[n for n in nodes if n.name==name];assert len(nodes)==1,selector
 if '['in selector:count+=1;continue
 for fn in nodes:
  n=1
  for d in fn.decorator_list:
   if isinstance(d,ast.Call)and isinstance(d.func,ast.Attribute)and d.func.attr=='parametrize':n*=len(ast.literal_eval(d.args[1]))
  count+=n
assert count==44,count
(W/'selection.json').write_text(json.dumps({'selection':selection,'expected_cases':count,'ordinary_cases':21,'unit_guard_cases':23,'observer':'existing scripts.http_operation_metrics, Client.request callphase only','limits':'No whole regression, capacity, browser, load or new external worker/provider claim; pure unit Redis fixtures do not prove real Redis by23cases'},indent=2))
rows={}
newapp={'apps/listings/moderation.py','apps/listings/match_review.py','apps/listings/moderation_views.py','apps/listings/match_views.py'}
for record in original['actions']:
 ident=record['id'];owners={}
 for block in record['blocks']:
  if block=='N02':owners[block]={'state':'residual_performance_user_deferred_not_PASS','decision_doc':'docs/367-n02-d-resultado-y-diferimiento-mod09-20261025.md','decision_sha256':sha('docs/367-n02-d-resultado-y-diferimiento-mod09-20261025.md'),'scope':'Retain actual evaluation/corrections and2s/5sFAIL; residual optimization deferred by user. Functional/security requirements are not waived.'}
  else:
   assert ident in maps[block],(block,ident)
   owners[block]={'state':'prior_local_scoped_disposition','reference':block,'json_pointer':maps[block][ident]}
 sources={p:sha(p)for p in record['sources']};assert sources
 rows[ident]={'families':record['families'],'kind':record['kind'],'original_blocks':record['blocks'],'prior_dispositions':owners,'candidate_source_sha256':sources,'source_drift_since_N00':[p for p,h in record.get('source_sha256',{}).items()if sha(p)!=h],'new_moderation_direct_source_overlap':sorted(newapp&set(sources)),'N11_reconciliation':'PENDING_COMMON_AND_ROOT_REQUIREMENT_AUDIT','whole_functionality_PASS_claimed':False,'limits':record.get('risk_if_regressed',[]),'evidence_level':'Original scoped block evidence with its own result/version/limits; current direct-source identity does not alone prove runtime or transitive equivalence.'}
assert len(rows)==443 and len({f for r in rows.values()for f in r['families']})==28
out={'state':'DRAFT_N11_INTEGRATED_MATRIX_NOT_ACCEPTED','candidate_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'original_census':census,'original_census_sha256':sha(census),'actions':443,'family_count':28,'blocks':proofs,'rows':rows,'current_moderation_fix':{'doc':'docs/495-n11-c-moderacion-autoridad-verificada-20261027.md','archive':'docs/evidencias/n11-abc-moderacion-autoridad-20261027.tar.gz','archive_sha256':sha('docs/evidencias/n11-abc-moderacion-autoridad-20261027.tar.gz'),'cases':30,'run':'20261026-235930-b380126e','scoped_only':True},'common_regression':{'state':'PENDING','selection':selection,'expected_cases':44},'historical_results':{'whole_20261024':'ERROR3697PASS3FAIL129SKIP/3829actual','CLI_corrective':'Separate23PASS run20261024-140904-a428539f,doc315; not rewritten wholePASS','omissions':'129originalSKIP retain individual dispositions;121optindiagnostics and8supplemental paths from prior contract; never129PASS'},'live_debt_register':'docs/deuda-pendiente-viva.md','alpha_noindex':True,'N11_accepted':False,'whole_goal_complete':False}
path=Path('docs/evidencias/n11-d-matriz-integrada-acciones-20261027.json');assert not path.exists();path.write_text(json.dumps(out,ensure_ascii=False,indent=2))
(W/'matrix-build-summary.json').write_text(json.dumps({'state':'DRAFT_NOT_ACCEPTED','path':str(path),'sha256':sha(path),'actions':443,'families':28,'direct_source_files':len({p for r in rows.values()for p in r['candidate_source_sha256']}),'selected_common_cases':44},indent=2));print('DRAFT443actions28families295sources;common44pending')
