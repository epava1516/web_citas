import collections,hashlib,json,math,statistics,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
sys.path.insert(0,'scripts')
from run_local_ci import hashes
W=Path('artifacts/recorridos-n11-20261026/n11d');load=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=load(W/'freeze.json');im=load(W/'runtime-images.json');P=Path('artifacts/local-ci')/im['run'];r=load(P/'result.json')
assert r['result']=='PASS'and r['sources_unchanged']and r['selection']==f['selection']and r['workers']==1 and r['observe_http_operations']
assert hashes()==load(P/'source-hashes.json')==f['sources']
for group in ['extra_sources','docs']:
 for p,h in f[group].items():assert sha(p)==h,p
assert sha('graphify-out/graph.json')==f['graph_sha256']
assert all(im[k]for k in ['matched_actual_runner_pid_and_start_ticks','all_observed','match_prelaunch_freeze'])
for name,row in r['cleanup'].items():
 assert row['absent']and row['removal_exit']==0
 assert subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0
assert not Path(load(P/'runner.json')['temporary']).exists()
tg=load(P/'telegram-notification.json');assert tg['delivery']=='sent'and tg['result']=='PASS'
cases=list(ET.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==44
rows=[];ordinary=[];unit=[];case_records=[]
for c in cases:
 assert all(c.find(k)is None for k in ['failure','error','skipped'])
 node=c.get('classname')+'::'+c.get('name');props={x.get('name'):x.get('value')for x in c.iter('property')}
 assert 'http_operation_samples'in props and 'http_operation_count'in props
 samples=json.loads(props['http_operation_samples']);assert len(samples)==int(props['http_operation_count'])
 isunit=c.get('classname')=='tests.test_benchmark_owned_redis';(unit if isunit else ordinary).append(node)
 if isunit:assert not samples
 for index,s in enumerate(samples):
  assert set(s)=={'method','route_name','status','request_seconds_instrumented','sql_queries','sql_execute_seconds','exception_class','observer_error_class'}
  assert s['observer_error_class']is None and s['exception_class']is None
  assert s['method']in ['GET','POST'] and isinstance(s['status'],int)
  assert isinstance(s['sql_queries'],int)and s['sql_queries']>=0
  assert math.isfinite(s['request_seconds_instrumented'])and s['request_seconds_instrumented']>=0
  assert math.isfinite(s['sql_execute_seconds'])and s['sql_execute_seconds']>=0
  rows.append({'case':node,'sample_index':index,**s})
 case_records.append({'case':node,'result':'PASS','http_samples':len(samples),'scope':props['http_operation_scope']})
assert len(unit)==23 and len(ordinary)==21 and len(rows)==253
assert sum(s['route_name']=='unresolved'for s in rows)==1
assert next(s for s in rows if s['route_name']=='unresolved')['status']==404
unresolved=[{'case':s['case'],'sample_index':s['sample_index'],'status':s['status'],'disposition':'Expected404 in original photo-private-boundary scenario; keep unresolved metadata, not a resolvedroute or omittedsample'}for s in rows if s['route_name']=='unresolved']
byroute=collections.defaultdict(list)
for s in rows:byroute[(s['route_name'],s['method'],s['status'])].append(s)
summary=[{'route':k[0],'method':k[1],'status':k[2],'samples':len(v),'first_ms':v[0]['request_seconds_instrumented']*1000,'median_ms_mixed_samples':statistics.median(s['request_seconds_instrumented']*1000for s in v),'sql_range':[min(s['sql_queries']for s in v),max(s['sql_queries']for s in v)],'limit':'Mixed original contexts/cohorts, including dynamicfixtures and eager synchronous work where applicable; descriptive only, not performancebenchmark'}for k,v in sorted(byroute.items())]
for p,v in load('artifacts/recorridos-n11-20261026/n11c/lateral-before-candidate.json')['paths'].items():assert not Path(p).exists()if v.get('absent')else sha(p)==v['sha256'],p
proof={'result':'PASS_SCOPED_N11D_COMMON44_CURRENT_CANDIDATE_NOT_YET_N11_ACCEPTANCE','run':P.name,'candidate_commit':f['head'],'counts':{'PASS':44,'FAIL':0,'ERROR':0,'SKIP':0},'ordinary_cases':21,'unit_guard_cases':23,'source_count':len(f['sources']),'extra_sources':len(f['extra_sources']),'sources_stable':True,'actual_JUnit_sha256':sha(P/'pytest.xml'),'junit_seconds':sum(float(s['time'])for s in r['junit']),'HTTP_samples':253,'resolved_route_names':len({s['route_name']for s in rows if s['route_name']!='unresolved'}),'unresolved':unresolved,'status_counts':dict(collections.Counter(s['status']for s in rows)),'case_records':case_records,'samples':rows,'route_summary':summary,'cleanup_verified':True,'telegram':tg,'limits':['Separate run from C30, never one74PASS battery','No capacity/browser/load/new worker or realprovider proof','Unit23usesmocks, not Redis functionalintegration','InstrumentedClientcallphase only; dynamicfixtures and synchronous eager work may be included, no production/queue timing claim','Root443/28source/evidence/requirements audit still required for N11 acceptance']}
(W/'common-audit.json').write_text(json.dumps(proof,indent=2));print(json.dumps({k:v for k,v in proof.items()if k not in ['case_records','samples','route_summary']}))
