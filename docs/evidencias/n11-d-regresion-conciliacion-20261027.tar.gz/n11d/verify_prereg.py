import ast,hashlib,json,subprocess
from pathlib import Path
W=Path('artifacts/recorridos-n11-20261026/n11d');load=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=load('docs/evidencias/n11-d-matriz-integrada-acciones-20261027.json');o=load(m['original_census']);canonical={r['id']:r for r in o['actions']};assert len(m['rows'])==len(canonical)==443 and set(m['rows'])==set(canonical) and not m['N11_accepted'] and not m['whole_goal_complete']
assert sha(m['original_census'])==m['original_census_sha256'] and m['candidate_commit']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
families=set();direct=set()
for ident,row in m['rows'].items():
 old=canonical[ident];assert row['families']==old['families']and row['original_blocks']==old['blocks']and not row['whole_functionality_PASS_claimed'];families.update(row['families'])
 assert set(row['candidate_source_sha256'])==set(old['sources'])
 for p,h in row['candidate_source_sha256'].items():assert sha(p)==h,p;direct.add(p)
 assert set(row['prior_dispositions'])==set(old['blocks'])
 for block,entry in row['prior_dispositions'].items():
  if block=='N02':assert entry['state']=='residual_performance_user_deferred_not_PASS'and sha(entry['decision_doc'])==entry['decision_sha256'];continue
  proof=m['blocks'][block];assert sha(proof['path'])==proof['sha256'];node=load(proof['path'])
  for part in entry['json_pointer'][2:].split('/'):
   part=part.replace('~1','/').replace('~0','~');node=node[int(part)]if isinstance(node,list)else node[part]
  assert node==ident if isinstance(node,str)else (node.get('id',ident)==ident)
assert len(families)==28 and len(direct)==295
for row in m['blocks'].values():
 gate=row['root_acceptance_gate'];assert sha(gate['path'])==gate['sha256']
for p,h in load(W/'instrument-review.json')['sources'].items():assert sha(p)==h,p
sel=load(W/'selection.json');assert sel['selection']==m['common_regression']['selection']and sel['expected_cases']==44 and sel['ordinary_cases']==21 and sel['unit_guard_cases']==23
assert not subprocess.check_output(['git','diff','HEAD','--','apps','config','templates','tests','scripts','uv.lock','pyproject.toml'],text=True).strip()
proof={'result':'PASS_N11D_PREREG443_ACTIONS28_FAMILIES_SOURCE_AND_SELECTOR_ONLY','actions':443,'families':28,'direct_sources':295,'common_expected_cases':44,'new_application_changes':False,'N11_accepted':False,'whole_goal_complete':False,'limit':'JSON pointers, direct sources and prior gate identities verified; no new runtime or transitive-source acceptance from static checks'}
(W/'prereg-verification.json').write_text(json.dumps(proof,indent=2));print(json.dumps(proof))
