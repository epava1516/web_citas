import collections,hashlib,json,re,xml.etree.ElementTree as ET
from pathlib import Path
W=Path('artifacts/recorridos-n11-20261026/n11d');load=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=load('docs/evidencias/n11-d-matriz-integrada-acciones-20261027.json');paths={p for row in m['blocks'].values()for p in [row['path'],row['root_acceptance_gate']['path']]}
refs=set()
for p in paths:refs.update(re.findall(r'\b20\d{6}-\d{6}-[a-f0-9]{8}\b',Path(p).read_text()))
tri_path='docs/evidencias/b16-actual-omission-triage-20261024.json';tri=load(tri_path);assert tri['total']==len(tri['cases'])==129 and all(not c['counted_as_pass']for c in tri['cases'])
assert sum(c['category']=='explicit_diagnostic_or_prototype'for c in tri['cases'])==121
supp=[c for c in tri['cases']if c['category']!='explicit_diagnostic_or_prototype'];assert len(supp)==8 and all(c['disposition']=='SUPPLEMENTARY_CURRENT_SCENARIO_PASS'for c in supp)
for c in supp:refs.update(re.findall(r'\b20\d{6}-\d{6}-[a-f0-9]{8}\b',c['evidence']))
correct_path='docs/evidencias/b16-functional-terminal-corrective-20261024.json';correct=load(correct_path);assert correct['original_run']=='20261024-094540-3a6ec8ac'and correct['corrective_run']=='20261024-140904-a428539f'and correct['corrective_outcomes']=={'passed':23}and correct['changed_sources']==['tests/test_benchmark_owned_redis.py']and correct['original_file_reconstructed_byte_exact']and correct['corrective_cases_subset_original']
refs.update([correct['original_run'],correct['corrective_run']]);records=[]
for run in sorted(refs):
 p=Path('artifacts/local-ci')/run
 if (p/'result.json').exists():
  r=load(p/'result.json');assert r['sources_unchanged'],run
  assert r['result']in ['PASS','ERROR'],(run,r['result'])
  xml=p/'pytest.xml';assert xml.exists(),run
  tg=load(p/'telegram-notification.json');assert tg['delivery']=='sent',run
  special=False
 else:
  assert run=='20261024-235904-c98b179b',run
  p=Path('artifacts/capacity-environment')/run;r=load(p/'report.json');assert r['result']=='BETA_HTTP_CONTRACTUAL_PASS_NOT_GLOBAL'and r['sources_unchanged']
  xml=p/'pytest.xml';assert sha(xml)==r['artifacts']['pytest.xml']['sha256']
  assert hashlib.sha256(json.dumps(load(p/'source-hashes.json'),sort_keys=True).encode()).hexdigest()==r['source_manifest_sha256'];special=True
 counts=collections.Counter();names=[]
 for event,c in ET.iterparse(xml,events=['end']):
  if c.tag!='testcase':continue
  outcome='ERROR'if c.find('error')is not None else'FAIL'if c.find('failure')is not None else'SKIP'if c.find('skipped')is not None else'PASS'
  counts[outcome]+=1;names.append(c.get('classname')+'::'+c.get('name'));c.clear()
 if r['result']=='PASS':assert counts['FAIL']==counts['ERROR']==0,run
 if special:assert counts=={'PASS':1}
 records.append({'run':run,'kind':'capacity_actual_xml_and_report'if special else'local_actual_xml_and_result','original_result':r['result'],'actual_XML_sha256':sha(xml),'actual_case_counts_separate':dict(counts),'actual_cases':sum(counts.values()),'sources_stable_in_own_cut':True,'limits':'Original scoped reference, not a new execution or automatically current transitive identity. Never sum these runs as one battery.'})
old=next(r for r in records if r['run']==correct['original_run']);assert old['actual_case_counts_separate']=={'PASS':3697,'FAIL':3,'SKIP':129}
fix=next(r for r in records if r['run']==correct['corrective_run']);assert fix['actual_case_counts_separate']=={'PASS':23}
assert sha('tests/test_benchmark_owned_redis.py')==load(Path('artifacts/local-ci')/correct['corrective_run']/'source-hashes.json')['tests/test_benchmark_owned_redis.py']
bridge=load(W/'integrated-source-bridge.json');assert len(bridge['changed_product_files'])==4 and bridge['full_non_doc_source_reconciliation']['same_sources']==1791 and not bridge['full_non_doc_source_reconciliation']['removed']
proof={'result':'PASS_N11_PRIOR_REFERENCE_CUSTODY_WITH_DECLARED_SOURCE_BRIDGES','prior_reference_files':{p:sha(p)for p in sorted(paths)},'actual_referenced_runs':records,'original_results_preserved_separately':True,'original_whole_ERROR_not_rewritten':old,'CLI_corrective_separate':fix,'omissions':{'source':tri_path,'sha256':sha(tri_path),'original_SKIPs':129,'opt_in_not_PASS':121,'supplemental_scoped_records':8,'all_counted_as_PASS':False,'limit':'Original129SKIP remain; eight supplementary historical scenario records are separate, with later domain corrections/current source bridges declared, not a new single run.'},'corrective_manifest':{'path':correct_path,'sha256':sha(correct_path)},'current_source_bridge':bridge,'N11_acceptance_pending':True,'limits':['Revalidates actual referenced XML/results and preserved negatives; does not execute tests again','Literal primary-gate/disposition run references plus supplementary omission cuts, not an exhaustive transitive test catalogue','Whole-file identity or old run label alone does not credit a new code path; C30/D44 and definition bridges are separate','No new SLA, capacity, provider, allbranch or whole-regression claim']}
(W/'reuse-audit.json').write_text(json.dumps(proof,indent=2));print(json.dumps({'result':proof['result'],'referenced_actual_runs':len(records),'original_results':dict(collections.Counter(r['original_result']for r in records)),'original_whole':old['actual_case_counts_separate'],'corrective':fix['actual_case_counts_separate'],'original_SKIPs':129,'supplemental_records':8,'no_new_tests_executed':True}))
