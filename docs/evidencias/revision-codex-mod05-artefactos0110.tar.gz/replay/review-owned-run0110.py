import ast,hashlib,json,sys,xml.etree.ElementTree as ET
from pathlib import Path
import psycopg
root=Path('/home/felidae/proyectos/web_modelos');out=Path(sys.argv[1]);dest=root/sys.argv[2]
r=json.loads((out/'result.json').read_text());m=json.loads((out/'frozen-manifest.json').read_text())
assert r['sources_unchanged'] and r['cleanup_verified'] and r['media_removed']
for p,h in r['artifact_sha256'].items():assert hashlib.sha256((out/p).read_bytes()).hexdigest()==h,p
for p,h in m['source_sha256'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
cases=[]
for c in ET.parse(out/'pytest.xml').getroot().findall('.//testcase'):
 props={p.attrib['name']:p.attrib['value'] for p in c.findall('./properties/property')}
 for k,v in list(props.items()):
  try:props[k]=json.loads(v)
  except (ValueError,TypeError):
   try:props[k]=ast.literal_eval(v)
   except (ValueError,SyntaxError):pass
 cases.append({'name':c.attrib['name'],'seconds':float(c.attrib['time']),
               'status':'FAIL' if c.find('failure') is not None else 'ERROR' if c.find('error') is not None else 'SKIP' if c.find('skipped') is not None else 'PASS','properties':props})
env={}
for line in (root/'.env').read_text().splitlines():
 k,sep,v=line.partition('=')
 if sep and k in {'POSTGRES_DB','POSTGRES_USER','POSTGRES_PASSWORD'}:env[k]=v.strip().strip('\"\'')
names=json.loads((out/'owned-databases.json').read_text())
with psycopg.connect(dbname=env.get('POSTGRES_DB','clasificados'),user=env.get('POSTGRES_USER','clasificados'),password=env['POSTGRES_PASSWORD'],host='127.0.0.1',port=55432,autocommit=True) as conn:
 assert not conn.execute('SELECT datname FROM pg_database WHERE datname=ANY(%s)',[names]).fetchall()
assert not (out/'pytest-temp').exists()
dest.write_text(json.dumps({**r,'frozen_manifest':m,'cases':cases,'review':{
 'source_and_artifact_hashes_verified':True,'independent_database_absence_verified':True,
 'independent_media_absence_verified':True,'note':sys.argv[3]}},ensure_ascii=False,indent=2)+'\n')
print({s:sum(c['status']==s for c in cases) for s in ['PASS','FAIL','ERROR','SKIP']})
