"""Independent reproduction of conditional invalidation; synthetic persisted ledger."""
import json
from uuid import uuid4
import pytest
from django.contrib.auth.models import Permission
from test_discovery import directory, multipage_directory
from test_photos import photo_environment
from test_photo_disposition_authority import ledger
from apps.core.models import User
from apps.listings import publication_state, moderation
from apps.listings.discovery import candidates
from apps.listings.models import Listing, PublicationDirty
from apps.safety.models import RightsRectificationPhotoDisposition, RightsPhotoReintroduction, RightsPhotoReintroductionDecision
from apps.safety.photo_reintroduction_review import inspect, decide

pytestmark=pytest.mark.django_db(transaction=True)

def test_conditional_decision_write_preserves_exact_count(multipage_directory, monkeypatch, record_property):
    client=multipage_directory
    while publication_state.refresh(500):pass
    before=client.get('/en/', {'q':'pagination'})
    assert before.status_code==200 and before.context['page'].paginator.count==25
    second=client.get('/en/', {'q':'pagination','page':'2'})
    target=second.context['page'].object_list[0]
    execution=ledger(target.person)
    execution.corrected_revision=target.approved_revision
    execution.save(update_fields=['corrected_revision'])
    execution.proof.status='passed'
    execution.proof.save(update_fields=['status'])
    photo=target.approved_revision.photos.first()
    disposition=RightsRectificationPhotoDisposition.objects.create(execution=execution,source_photo=photo,blob=photo.blob,outcome='withdrawn')
    candidate=RightsPhotoReintroduction.objects.create(photo=photo,uploaded_blob=photo.blob,disposition=disposition,method='sha256')
    reviewer=User.objects.create_user(username='synthetic-independent-mod05-review',mfa_enabled=True)
    reviewer.user_permissions.add(Permission.objects.get(codename='review_photo_reintroduction'))
    read=inspect(reviewer,candidate.pk,uuid4(),1,'Inspect synthetic current photo reuse permission')
    decision=decide(reviewer,candidate.pk,read.pk,uuid4(),1,'authorize','Synthetic independent current image permission assessment','synthetic-reviewed-ref')
    assert moderation.publicly_visible(Listing.objects.get(pk=target.pk))
    while publication_state.refresh(500):pass
    assert not PublicationDirty.objects.filter(listing_id=target.pk).exists()
    # A write on a table actually read by the rule. QuerySet.update deliberately
    # bypasses signals, as MOD05 database invalidation promises to support.
    reports=[]
    for dependency in ['decision','proof']:
        RightsPhotoReintroductionDecision.objects.filter(pk=decision.pk).update(outcome='maintain' if dependency=='decision' else 'authorize')
        if dependency=='proof':
            type(execution.proof).objects.filter(pk=execution.proof_id).update(status='failed')
        target=Listing.objects.get(pk=target.pk)
        assert not moderation.publicly_visible(target)
        stored=client.get('/en/', {'q':'pagination'})
        with monkeypatch.context() as patch:
            patch.setattr(publication_state,'state_page',lambda *args,**kwargs:None)
            native=client.get('/en/', {'q':'pagination'})
        observed={'dependency':dependency,'stored_count':stored.context['page'].paginator.count,'native_count':native.context['page'].paginator.count,'route':stored.wsgi_request._publication_route,'target_dirty':PublicationDirty.objects.filter(listing_id=target.pk).exists(),'target_off_first_page':target.pk not in [r.pk for r in stored.context['page'].object_list],'native_target_visible':False}
        reports.append(observed)
    record_property('conditional_dependency',json.dumps(reports))
    assert all(r['stored_count']==r['native_count'] for r in reports),reports
