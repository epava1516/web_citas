import ast,hashlib,json,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n06-g-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
ledger=read('docs/evidencias/n06-aceptacion-matriz-final-20261025.json');original=read('artifacts/recorridos-n06-e-20261025/actions-original.json');assert len(ledger['actions'])==46 and {a['id'] for a in ledger['actions']}=={a['id'] for a in original}
assert len(ledger['root_requirements'])==17 and {r['id'] for r in ledger['root_requirements']}=={f'E{i:02}' for i in range(1,18)}
assert sum(a['kind']=='route' for a in ledger['actions'])==41 and sum(a['kind']!='route' for a in ledger['actions'])==5
for a in ledger['actions']:
 assert a['N06_disposition']
 if a['kind']=='route':assert a['performance_references'] or a['F_reference'] or a['G_reference']
 else:assert a['shared_obligations']
 for p,h in a['source_fingerprints'].items():assert sha(p)==h,p
review=ledger['independent_readiness_review'];assert review['STATUS']=='complete' and review['TESTS_RUN']==[]
for p,h in review['source_sha256'].items():
 if sha(p)==h:continue
 old=subprocess.check_output(['git','show','e4343f5:'+p]);assert hashlib.sha256(old).hexdigest()==h,p
product=read('docs/evidencias/b16-final-candidate-reconciliation-20261025.json')['current_versioned_executable_sources'];allowed={'scripts/run_local_ci.py','apps/core/agencies.py','apps/safety/rights_portability_export.py'};assert len(product)==1507
assert all(sha(p)==h for p,h in product.items() if p not in allowed)
assert sha('apps/core/agencies.py')==read('artifacts/recorridos-n06-d-20261025/candidate-scope.json')['after_sha256']
assert sha('apps/safety/rights_portability_export.py')==read('artifacts/recorridos-n06-b-20261025/candidate-scope.json')['after_sha256']
assert product['apps/listings/publication_signals.py']==sha('apps/listings/publication_signals.py')
G=read(W/'queues-audit.json');assert G['measured_requests']==240 and G['authority_controls']==128 and len(G['rows'])==40 and all(r['constant_median_nonempty'] for r in G['query_growth'])
assert all(r['sql_queries']['median_later']==7 for r in G['rows']);assert G['terminal_telegram']['delivery']=='sent' and G['temporary_absent'] and all(not x for x in G['independent_inventory'].values())
D=read('docs/evidencias/n06-d-panel-auditoria-comparacion-20261025.json');assert D['comparison']['ordered_people_members_and_response_bytes_equal'] and D['comparison']['timing_nonworse_rows']==12
assert len(D['comparison']['rows'])==12 and D['functional']['junit'][0]['tests']=='3'
for row in D['comparison']['rows']:
 if row['actor']=='owner':assert row['sql_queries']['after']==8 and row['sql_queries']['before']==row['size']+8
 else:assert row['sql_queries']['before']==row['sql_queries']['after']==7
F=read('docs/evidencias/n06-f-referencias-auditoria-20261025.json');assert F['counts']['observed_requests']==120 and F['counts']['newly_referenced_routes']==17 and F['junit'][0]['tests']=='12'
# Every old functional selector citation remains byte/line-identical; old overall error is retained.
Eproof=read('docs/evidencias/n06-e-conciliacion-acciones-20261025.json');assert Eproof['historical_overall_result']=='ERROR' and Eproof['witness_citations_checked']==76
for a in Eproof['actions']:
 for v in a['functional_review']['witnesses']:
  p,name=v['selector'].split('::',1);name=name.split('[',1)[0];assert sha(p)==v['source_sha256'];nodes=[n for n in ast.walk(ast.parse(Path(p).read_text())) if isinstance(n,ast.FunctionDef) and n.name==name];assert len(nodes)==1 and nodes[0].lineno==v['line_start'] and nodes[0].end_lineno==v['line_end']
# Final focal graph must match actual final documentary corpus, counts and unchanged application.
S=W/'acceptance/graph-integrated';proof=read(S/'GRAPH_VERIFICATION.json');assert proof['result']=='PASS_SCOPED_GRAPH_N06_ACCEPTANCE';state=read(S/'ESTADO_ACTUAL.json');assert state['next_mandatory_accepted']==3 and state['next_mandatory_total']==13 and state['phase']=='alpha'
manifest=read(S/'SOURCE_MANIFEST.json');assert all(sha(p)==r['sha256'] for p,r in manifest.items())
assert sha('docs/111-inventario-rendimiento-recorridos-beta-20261020.md')=='380b026c51b5e9647052838bb77a0712e9efff4ccdd857b5df3d4b545d921a95'
result={'result':'PASS_N06_LOCAL_ACCEPTANCE_WITH_DECLARED_LIMITS','action_count':46,'HTTP_routes_with_scoped_reference':41,'shared_actions_retained':5,'requirements':17,'accepted_mandatory':3,'total_mandatory':13,'original_executable_sources_unchanged':1504,'named_original_variants':sorted(allowed),'panel_comparison_rows':12,'G_cases':8,'G_samples':240,'G_authority_controls':128,'G_constant_queries':7,'F_cases':12,'F_HTTP_samples':120,'historical_overall_ERROR_preserved':True,'graph_sha256':sha(S/'graph.json'),'graph_sources':len(manifest),'phase':'alpha','scope':'N06 selected local scenarios, not every branch, whole current regression, provider, production capacity or whole contract completion. N03/N07/N10 shared obligations and N11/N15 retained.'}
(W/'acceptance-primary-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
