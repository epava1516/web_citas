# Grafo alfa — referencia real N06B y atribución N02

N00/N01aceptados2/13,N06abierto.359auditado2PASS3POSTencolados109.875/114.054/131.019ms27SQL;workerprefork2restringido real,identidades/roles/credenciales temporales retirados. Disponibilidadobservadaposterior460.337/514.251/471.346ms es cota de arnés. No Beat/TCP/capacidad ni optimización atribuible entre modalidades. N02investigación2hipótesisporfuente,16referencias comprobadas,sinmedir/adoptar. Objetivos2s/5syFAIL/excepción preservados.

Refresco semántico focal359/341/README/vista17líneas1–4;ASTprevio preservado:1952fuentes,18280nodos/80538relaciones,866comunidades. No reconstrucción completa ni semántica exhaustiva.1506ejecutables originales intactos,runner variante instrumental;consumo nativo desconocido. JSONcompleto/HTMLcomunidades;100anotaciones ambiguas y exclusiones previas conservadas. Relaciones documentales no prueban runtime.

