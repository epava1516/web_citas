import hashlib,json,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n04-b-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:assert k not in d;d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
r=read(W/'oracle-review.json');assert r['STATUS']=='complete'
for k in ['FILES_CHANGED','TESTS_RUN','ASSUMPTIONS','RISKS','UNRESOLVED_ISSUES','RECOMMENDATIONS']:assert isinstance(r[k],list)
for k in ['IMPLEMENTATION_NOTES','TEST_RESULTS']:assert isinstance(r[k],str)
cites=[]
def walk(x):
 if isinstance(x,dict):
  if {'file','sha256','quote','line_start','line_end'}<=set(x):cites.append(x)
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(r)
for c in cites:
 assert sha(c['file'])==c['sha256'],c['file'];lines=Path(c['file']).read_text().splitlines();assert c['quote'] in '\n'.join(lines[c['line_start']-1:c['line_end']])
assert not r['concrete_issues']
a=read('artifacts/recorridos-n04-a-20261025/inventory-review.json');sources={}
for s in a['source_bridges']:
 p=s['file'];assert sha(p)==s['current_sha256']==s['B16_sha256'];assert all(sha(p)==x['frozen_sha256'] for x in s['N01_bridges']);sources[p]=sha(p)
# Inspect original selected outcomes, preserving the fact that a broad original run had unrelated failures.
original=[]
for row in a['existing_JUnit']:
 p=Path(row['file']);assert sha(p)==row['sha256'];cs=list(E.parse(p).iter('testcase'));lookup={(x.attrib['classname'],x.attrib['name']):x for x in cs}
 for c in row['selected_cases']:
  x=lookup[(c['classname'],c['name'])];assert not any(x.find(k)is not None for k in ['failure','error','skipped'])
 original.append({'file':str(p),'selected_original_pass':len(row['selected_cases']),'total_original_failures':sum(x.find('failure')is not None for x in cs),'scope':'Original outcome verification only; per-action reuse keeps source/scenario limits, not all tests imported as N04.'})
# Clean load is a historical witness, not a newly executed per-variant SLO.
p=Path('artifacts/local-ci/20261024-235904-c98b179b');cs=list(E.parse(p/'pytest.xml').iter('testcase'));assert len(cs)==1 and not any(c.find(k)is not None for c in cs for k in ['failure','error','skipped']);assert read(p/'result.json')['result']=='PASS'
current=read(W/'reference-audit.json');assert current['result']=='PASS_N04B_MAINTAINED_STAGES_REFERENCE_NOT_N04_ACCEPTANCE' and current['cleanup_verified'];assert current['measurement']['measured_requests']==144 and len(current['summary'])==24
freeze=read(W/'reference-freeze-corrected.json')['sources'];assert all(sha(p)==h for p,h in freeze.items())
first=read(W/'first-reference-failure-audit.json');assert first['result'].startswith('PRESERVED_FIRST_REFERENCE_1FAIL') and first['cleanup_verified']
for key in ['apps/catalog/promotion_orders.py','tests/test_promotion_paged_equivalence.py']:assert sha(key)==first['primary_sources'][key]
assert read(W/'corrected-reference-source-scope.json')['state']=='NO_APPLICATION_CHANGE_BETWEEN_REFERENCES'
out={'result':'PASS_N04_FINITE_SCENARIOS_ACTIONS_AND_NO_CHANGE_DISPOSITION_ROOT_VERIFIED','actions':['route:R_home','route:R_listing_detail'],'families':['I01','I02','I03','I04','I05'],'current_source_identity':sources,'source_bridges':len(sources),'oracle_review_citations':len(cites),'original_selected_witnesses':original,'clean_load_original_run':p.name,'clean_load_scope':'Historical original mixed protocol334, no fresh public p95 or per-variant800ms claim; public source identity preserved, final candidate integration remains N11.','current_reference':current['run'],'instrumented_requests':144,'outside_clock_page_requests':36,'first_reference_1FAIL_preserved':True,'application_change':False,'decision':'No app candidate selected: finite stages measured, exact parity/authority retained, times acceptable in alpha; no forced marginal optimization. No causal before/after percentage.','next_mandatory_accepted_if_acta_integrated':5,'mandatory_total':13,'limits':'Selected finite120cohort with24synthetic rights, ES/EN/pages1&5/combined1&3/empty/detail; first after oracles not OS cold; nested observers not clean load. No new provider or opening.'}
(W/'acceptance-verification.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['current_source_identity','original_selected_witnesses']}))
