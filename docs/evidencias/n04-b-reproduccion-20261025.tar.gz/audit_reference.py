import hashlib,json,math,statistics,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n04-b-20261025');P=Path('artifacts/local-ci/20261025-205210-f0b7e1ab');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:assert k not in d;d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
r=read(P/'result.json');f=read(W/'reference-freeze.json');assert r['result']=='PASS' and r['sources_unchanged'] and r['selection']==f['selection'] and r['workers']==1
assert all(sha(p)==h for p,h in f['sources'].items())
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==1 and not any(c.find(k)is not None for c in cs for k in ['failure','error','skipped'])
props={x.attrib['name']:x.attrib['value'] for x in cs[0].iter('property')};d=json.loads(props['n04b_maintained_stages']);assert d['measured_requests']==144 and len(d['observations'])==24
assert d['published']==120 and d['women_en']==d['men_fr']==60 and (d['promoted'],d['premium'],d['top'])==(24,8,16)
assert d['reference_sha256']==sha('docs/evidencias/b08-promociones-referencia-20261020.py')
expected={(phase,language,segment) for phase in ['organic','synthetic_promoted'] for language in ['es','en'] for segment in ['page1','last_page5','combined_page1','combined_last_page3','empty_combined','detail']}
assert {(x['phase'],x['language'],x['segment']) for x in d['observations']}==expected
summary=[]
for x in d['observations']:
 samples=x['samples'];assert len(samples)==6 and [s['ordinal'] for s in samples]==list(range(1,7))
 assert [s['position'] for s in samples]==['first_instrumented']+['later']*5
 assert len({s['ordered_ids_sha256'] for s in samples})==len({s['sponsor_labels_sha256'] for s in samples})==1
 detail=x['segment']=='detail';count={'page1':24,'last_page5':24,'combined_page1':24,'combined_last_page3':12,'empty_combined':0,'detail':1}[x['segment']]
 for s in samples:
  assert s['returned_count']==count and s['sql']['calls']>0 and s['process_maxrss_kib']<1024*1024
  assert (s['route']=='detail_native_snapshot_guard') if detail else s['route']['route']=='state'
  assert s['stages']['detail_render' if detail else 'discovery_render']['calls']==1
  assert s['stages']['detail_guard_alias' if detail else 'presentation_init']['calls']==1
  for stage in s['stages'].values():assert all(math.isfinite(v) and v>=0 for v in stage.values())
 later=samples[1:]
 row={'phase':x['phase'],'language':x['language'],'segment':x['segment'],'first_seconds':samples[0]['request_wall_seconds'],'wall_median':statistics.median(s['request_wall_seconds'] for s in later),'wall_min':min(s['request_wall_seconds'] for s in later),'wall_max':max(s['request_wall_seconds'] for s in later),'cpu_median':statistics.median(s['request_thread_cpu_seconds'] for s in later),'sql_calls':sorted({s['sql']['calls'] for s in samples}),'sql_execute_median':statistics.median(s['sql']['execute_seconds'] for s in later),'stage_wall_medians':{key:statistics.median(s['stages'][key]['wall_seconds'] for s in later) for key in samples[0]['stages']},'maxrss_kib':max(s['process_maxrss_kib'] for s in samples)}
 summary.append(row)
assert len(d['coverage'])==12 and {(x['phase'],x['language'],x['segment']) for x in d['coverage']}=={(phase,lang,seg) for phase in ['organic','synthetic_promoted'] for lang in ['es','en'] for seg in ['all','combined','empty']}
for x in d['coverage']:assert x['count']=={'all':120,'combined':60,'empty':0}[x['segment']]
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];q=subprocess.run(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],capture_output=True,text=True,check=True);assert not q.stdout.strip()
assert not Path(read(P/'runner.json')['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_N04B_MAINTAINED_STAGES_REFERENCE_NOT_N04_ACCEPTANCE','run':P.name,'junit':r['junit'],'source_count':len(f['sources']),'sources_unchanged':True,'measurement':d,'summary':summary,'cleanup_verified':True,'telegram':tg,'limits':'No app change or causal speedup. Fixed finite cohort, inclusive instrumented stages and full-page native/frozen oracle; not OS cold, clean load, provider, capacity or N04 acceptance.'}
(W/'reference-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['measurement','summary']}));print(json.dumps(summary))
