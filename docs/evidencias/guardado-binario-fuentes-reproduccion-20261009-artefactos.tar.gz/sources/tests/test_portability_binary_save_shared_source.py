"""Native scoped binary save keeps fresh source checks without repeated snapshots."""

from uuid import uuid4

import pytest
from test_reports import directory, photo_environment  # noqa: F401
from test_rights_portability_export_races import prepared_selection

from apps.safety import rights_inspection_source as shared
from apps.safety import rights_portability_image_selection as image_selection
from apps.safety import rights_portability_selection_store as store
from apps.safety import rights_portability_use as use
from apps.safety.crypto import unseal

pytestmark = pytest.mark.django_db(transaction=True)
REASON = "Validate complete scoped binary page with fresh source and preserved fields"
FACTS = {"status": "eligible", "basis": "contract", "origin": "provided",
         "automated": True, "subject_related": True, "third_party_reviewed": True,
         "reason": REASON, "evidence": "Synthetic reviewed image; no production legal claim"}


def test_binary_page_save_keeps_two_fresh_sources_and_preserves_native_choices(
    request, settings, monkeypatch, record_property
):
    case, author, baseline, _, _, _, _ = prepared_selection(request, settings, monkeypatch, False)
    original = unseal(baseline.encrypted_selection)
    page = image_selection.prepare(author, case.pk, case.version, baseline.assessment_review_id,
                                   uuid4(), REASON, 0, 0)
    calls = []
    for module in [shared, image_selection, store, use]:
        native = module.source_copy

        def counted(*args, _native=native, **kwargs):
            calls.append(True)
            return _native(*args, **kwargs)

        monkeypatch.setattr(module, "source_copy", counted)
    key = uuid4()
    row = image_selection.save(author, key, page["token"], REASON, True, FACTS)
    body = unseal(row.encrypted_selection)
    assert body["selection"] == original["selection"]
    assert body["field_evidence"] == original["field_evidence"]
    assert body["images"] == [{**page["declaration"], "conditions": FACTS}]
    record_property("full_source_reads_per_save", len(calls))
    assert len(calls) == 2
    calls.clear()
    assert image_selection.save(author, key, page["token"], REASON, True, FACTS).pk == row.pk
    assert len(calls) == 2
