"""Finite real TCP selection-page probe; not full capacity acceptance."""

import cProfile
import http.cookiejar
import io
import pstats
import json
import math
import time
import urllib.parse
import urllib.request
from uuid import uuid4

import pytest
import test_rights_portability_export_races as fixtures
from capacity_target_fixture import PATHS, populate
from django.db import connection, transaction
from django.test import Client
from test_reports import directory, photo_environment  # noqa: F401

from apps.core.models import User
from apps.safety.crypto import unseal
from apps.safety.rights_exports import reviewer_case, source_copy
from apps.safety.rights_portability_selection import row_reference
from apps.safety.rights_portability_selection_store import save_selection

pytestmark = pytest.mark.django_db(transaction=True)
REASON = "Measure independently inspected synthetic target page over actual TCP"


@pytest.mark.usefixtures("photo_environment")
def test_target_selection_page_tcp(request, settings, monkeypatch, live_server, record_property):
    assert connection.vendor == "postgresql"
    request.getfixturevalue("directory")
    started = time.perf_counter()
    _, _, _, manifest = populate("capacity-subject-a")
    build_seconds = time.perf_counter() - started
    original = fixtures.ready

    def target_ready(*args, **kwargs):
        return original(*args, **(kwargs | {"subject_username": "capacity-subject-a"}))

    monkeypatch.setattr(fixtures, "ready", target_ready)
    started = time.perf_counter()
    case, author, baseline, previous, _, _, _ = fixtures.prepared_selection(
        request, settings, monkeypatch, False
    )
    with transaction.atomic():
        locked, profile, listing = reviewer_case(author, case.pk)
        source = source_copy(profile, listing, locked)
    assert len(source["revisions"]) == 1500
    body = unseal(baseline.encrypted_selection)
    body["selection"]["revisions"] = [
        {"row": row_reference("revisions", index, row), "fields": PATHS}
        for index, row in enumerate(source["revisions"])
    ]
    row = save_selection(author, case.pk, case.version, baseline.assessment_review_id,
                         uuid4(), baseline.version, REASON, body["selection"],
                         field_evidence=body["field_evidence"])
    preparation_seconds = time.perf_counter() - started
    reviewer = User.objects.get(pk=previous.action.actor_id)
    browser = Client()
    browser.force_login(reviewer)
    session = browser.session
    session["mfa_version"] = reviewer.mfa_version
    session.save()
    cookies = http.cookiejar.CookieJar()
    host = urllib.parse.urlparse(live_server.url).hostname
    cookie_host = host if "." in host else host + ".local"
    cookies.set_cookie(http.cookiejar.Cookie(
        0, settings.SESSION_COOKIE_NAME, browser.cookies[settings.SESSION_COOKIE_NAME].value,
        None, False, cookie_host, False, False, "/", True, False, None, True, None, None, {}
    ))
    client = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookies))
    path = f"/en/moderation/rights/{case.pk}/portability/selection/{row.pk}/review/"
    endpoint = live_server.url + path
    opened = time.perf_counter()
    with client.open(endpoint, timeout=60) as response:
        assert response.status == 200 and "no-store" in response.headers["Cache-Control"]
        response.read()
    first_open = time.perf_counter() - opened
    csrf = next(cookie.value for cookie in cookies if cookie.name == settings.CSRF_COOKIE_NAME)
    samples, sizes = [], []
    try:
        for _ in range(20):
            payload = urllib.parse.urlencode({"key": str(uuid4()), "version": case.version,
                                             "operation": "inspect", "reason": REASON, "page": 1}).encode()
            query = urllib.request.Request(endpoint, data=payload, headers={
                "Content-Type": "application/x-www-form-urlencoded", "Referer": endpoint,
                "X-CSRFToken": csrf,
            })
            opened = time.perf_counter()
            with client.open(query, timeout=60) as response:
                content = response.read()
                elapsed = time.perf_counter() - opened
                assert response.status == 200 and "no-store" in response.headers["Cache-Control"]
            samples.append(elapsed)
            sizes.append(len(content))
            from apps.safety.models import RightsPortabilitySelectionRead
            latest = RightsPortabilitySelectionRead.objects.filter(selection=row).latest("pk")
            assert latest.page_metadata["page"] == 1 and latest.page_metadata["size"] == 50
            assert latest.page_metadata["total"] == 1501
    finally:
        p95 = sorted(samples)[math.ceil(len(samples) * .95) - 1] if samples else None
        record_property("selection_tcp_measurements", json.dumps({
            "samples": samples, "response_bytes": sizes, "p95_seconds": p95,
            "first_open_seconds": first_open, "build_seconds": build_seconds,
            "preparation_seconds": preparation_seconds, "fixture": manifest,
            "scope": "One case, repeated page 1, real Django live_server TCP; no concurrency, page completion, approval, image selection or full capacity",
        }))
    from apps.safety import rights_portability_selection_views as selection_views

    profile = cProfile.Profile()
    original_record = selection_views.record

    def profiled_record(*args, **kwargs):
        profile.enable()
        try:
            return original_record(*args, **kwargs)
        finally:
            profile.disable()

    monkeypatch.setattr(selection_views, "record", profiled_record)
    diagnostic_payload = urllib.parse.urlencode({"key": str(uuid4()), "version": case.version,
                                                "operation": "inspect", "reason": REASON, "page": 1}).encode()
    diagnostic_query = urllib.request.Request(endpoint, data=diagnostic_payload, headers={
        "Content-Type": "application/x-www-form-urlencoded", "Referer": endpoint,
        "X-CSRFToken": csrf,
    })
    with client.open(diagnostic_query, timeout=60) as response:
        assert response.status == 200
        response.read()
    summary = io.StringIO()
    pstats.Stats(profile, stream=summary).sort_stats("cumulative").print_stats(35)
    record_property("selection_service_profile", summary.getvalue())
    assert len(samples) == 20
    assert p95 <= 2, f"Target page TCP p95 {p95:.3f}s exceeds 2s"
