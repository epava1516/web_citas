"""Small real case validates stage/TCP instrumentation; not large-case capacity."""

import pytest
from test_portability_large_closed_json_transport import (
    test_native_closed_selected_json_over_local_tcp as run_transport,
)
from test_reports import directory, photo_environment  # noqa: F401

pytestmark = pytest.mark.django_db(transaction=True)


def test_owned_small_case_instrumentation(
    request, settings, monkeypatch, live_server, tmp_path, record_property
):
    run_transport(request, settings, monkeypatch, live_server, tmp_path, record_property,
                  large=False, control=True)
