# Grafo alfa — N03F2 crecimiento histórico verificado; N03 abierto

3/13 bloques aceptados, N03 abierto.392real3PASS/18calls/1746huellas/limpieza/TGsent. Cohortes0/10/100history con2Blob2actuales fijos,corpus/Matchidénticos,22SQL/1confirmación/1Match. Medianas156,429/175,145/202,129ms: coste observado,noappchange/speedup/SLO. Sinoptimizaciónmarginal;acta6acciones/puentes/tablafinalpendiente. F1aceptado390/49PASS,MOD09restantediferidoalfinaldel desarrollo,alfa.

Semántica focal392/341/README/vista17primeras4líneas; ASTinstrumento vigente. 2000fuentes,18905nodos/81966relaciones,903comunidades. Base preservada,no reconstrucción global ni semántica exhaustiva. Tokens nativos desconocidos.

