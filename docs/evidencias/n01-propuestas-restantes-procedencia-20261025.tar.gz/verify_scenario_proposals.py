"""Check native research provenance and selector existence, not scenario acceptance."""
import ast,hashlib,json,sys
from pathlib import Path
W=Path('artifacts/recorridos-n01-c-20261025');known={r['id'] for r in json.loads(Path('docs/evidencias/n00-matriz-acciones-prioridades-20261025.json').read_text())['actions']};errors=[];counts={};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for letter,groups in [('a',{'S02','S03','S04','S05'}),('b',{'S06','S07','S08','S09'})]:
 folder=W/('scenario-research-'+letter);r=json.loads((folder/'report.json').read_text());data=json.loads((folder/'scenario-proposals.json').read_text());proposals=data.get('proposals',data.get('scenarios',[]));evidence=data['source_evidence'];ids={e['id'] for e in evidence}
 if r['STATUS']!='complete' or r['TESTS_RUN'] or r['UNRESOLVED_ISSUES']:errors.append([letter,'report scope incomplete'])
 if data['status']!='proposed' or set(data['groups'])!=groups:errors.append([letter,'wrong group/status'])
 for e in evidence:
  path=e.get('path',e.get('file'));quote=e.get('literal_quote',e.get('literal'));p=Path(path)
  if not p.is_file() or sha(p)!=e['sha256']:errors.append([letter,e['id'],'source missing/drift']);continue
  lines=p.read_text().splitlines(keepends=True);lo=e['line_start'];hi=e['line_end']
  if not 1<=lo<=hi<=len(lines) or not quote or quote not in ''.join(lines[lo-1:hi]):errors.append([letter,e['id'],'literal/location mismatch'])
 for s in proposals:
  if s['status']!='proposed' or s['group'] not in groups or not s['metrics'] or not s['oracles'] or not s['hypothesis'] or not s['budget'] or not s['limits']:errors.append([letter,s['id'],'incomplete scope'])
  for ident in s['action_ids']:
   if ident not in known:errors.append([letter,s['id'],'unknown action '+ident])
  refs=s.get('source_evidence_refs',s.get('source_evidence',[]))
  if not refs or not set(refs)<=ids:errors.append([letter,s['id'],'unknown evidence reference'])
  for selector in s['existing_test_selectors']:
   pieces=selector.split('::');p=Path(pieces[0])
   if not p.is_file():errors.append([letter,s['id'],'missing selector file '+selector]);continue
   names={n.name for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
   if any(piece.split('[',1)[0] not in names for piece in pieces[1:]):errors.append([letter,s['id'],'missing selector symbol '+selector])
 if {s['group'] for s in proposals}!=groups:errors.append([letter,'missing group proposal'])
 counts[letter]={'groups':sorted(groups),'proposals':len(proposals),'literal_sources':len(evidence),'test_selectors':sum(len(s['existing_test_selectors']) for s in proposals)}
result={'result':'PASS_N01_PROPOSAL_SOURCE_SCOPE' if not errors else 'ERROR_N01_PROPOSAL_SOURCE_SCOPE','counts':counts,'errors':errors,'proposal_status':'research_only_not_final_preregistration_or_acceptance','tests_executed_by_research':0,'limits':['Literal hashes/locations and AST selector symbols checked; not adequate timing samples, full oracles or historicalresult equivalence proof.','Parent must review proposedcohorts/roles/budgets/coverage before integrating N01 plan.']}
(W/'scenario-proposals-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));sys.exit(bool(errors))
