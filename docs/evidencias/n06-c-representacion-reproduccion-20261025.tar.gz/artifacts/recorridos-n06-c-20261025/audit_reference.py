"""Read-only terminal audit; never writes source or reruns workload."""
import hashlib,json,math,subprocess,xml.etree.ElementTree as E
from pathlib import Path
ROOT=Path.cwd();W=ROOT/'artifacts/recorridos-n06-c-20261025';RUN='20261025-154544-5fcdc190';P=ROOT/'artifacts/local-ci'/RUN

def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=read(P/'result.json');freeze=read(W/'freeze.json');mismatch=[p for p,h in freeze['sources'].items() if not (ROOT/p).is_file() or sha(ROOT/p)!=h];assert not mismatch,mismatch
xml=E.parse(P/'pytest.xml');cases=[]
for c in xml.iter('testcase'):
 props={e.attrib['name']:e.attrib['value'] for e in c.iter('property')};samples=json.loads(props['http_operation_samples']);assert len(samples)==int(props['http_operation_count']) and samples
 for ordinal,s in enumerate(samples,1):
  assert s['exception_class'] is None and s['observer_error_class'] is None
  assert isinstance(s['sql_queries'],int) and s['sql_queries']>=0
  assert all(math.isfinite(s[k]) and s[k]>=0 for k in ['request_seconds_instrumented','sql_execute_seconds'])
  s['ordinal']=ordinal
 cases.append({'name':c.attrib['name'],'seconds_qa':c.attrib['time'],'samples':samples,'failures':len(c.findall('failure')),'errors':len(c.findall('error')),'skips':len(c.findall('skipped'))})
assert len(cases)==2
inventory={}
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q']
 q=subprocess.run(cmd+['--filter',f'label=web-modelos-local-ci-run={RUN}'],capture_output=True,text=True,check=True);inventory[kind]=q.stdout.split();assert not inventory[kind]
receipts=[]
for p in Path('artifacts/test-notifications').glob('*.json'):
 d=read(p)
 if RUN in str(d):receipts.append(d)
out={'run':RUN,'runner_result':r,'source_count':len(freeze['sources']),'source_mismatches':mismatch,'junit_sha256':sha(P/'pytest.xml'),'cases':cases,'independent_inventory':inventory,'receipts':receipts,'scope':'Two original functional oracles plus dynamically observed fixture HTTP. Per-operation baseline only; no candidate improvement, provider, browser, load, p95 or N06 closure.'}
(W/'reference-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('AUDITED',[(c['name'],len(c['samples'])) for c in cases]);print('RESULT',r)
