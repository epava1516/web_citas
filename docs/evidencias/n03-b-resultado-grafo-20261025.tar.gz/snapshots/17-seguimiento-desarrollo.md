N03B381 aceptado localmente:detector denso100/6muestras con paridad exacta,ORB200→101,mediana14,954→12,729s(−14,9%),CPU−15,5%,SQL1012igual;46PASSfuncionales/limpieza/TGsent. N03abierto,3/13obligatorios,alfa.

Siguiente:conciliar recuperación/reintentos/retención/concurrencia N03/N07, sin otra optimización marginal del detector. Si no hay mejora clara, diferir al final del desarrollo según decisión del usuario;MOD09restante ya diferido.

