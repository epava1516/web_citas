# N09E433 — revisión diferencial del candidato, pendiente de38casos

Base a5cd18d. Riesgo ALTO por autorización y descifrado privado; recomendación CONDICIONAL, no aceptación hasta la selección completa y auditoría. Revisión quirúrgica de cuatro módulos completos, siete líneas nuevas y dos instrumentos; ningún autorizador compartido, modelo, migración, rol, crypto o servicio de infraestructura modificado.

## Evidencia y amenaza

Tres defectos originales confirmados por run075104-d7159725: controles nativos3PASS, revocaciones3FAIL,129,909sJUnit,1770huellas estables, cleanup/Telegram. El operador inicialmente autorizado queda esperando fila de decisión/información/borrador; otro actor retira el permiso y confirma antes de liberar. Se observa descifrado nativo satisfactorio del ciphertext objetivo(2campo/1información/1borrador) antes de PermissionDenied final. Dominio revertido intacto, sin devolución de plaintext por HTTP atribuida. No es un fallo de preparación ni un simulador de conexión PG.

## Diferencia por archivo

- rights_access_field_decision.py: propose reautoriza tras inventario y última fila de decisión; context tras fila de decisión antes de inspección/revisión; consume tras decisión aprobada antes de ejecutar evidencia bajo autoridad del revisor. Evita que autoridad vigente de un revisor distinto autorice indirectamente el consumo por un operador ya revocado. Parámetro user/epochs original conservado; helpers de autoridad no cambiados.
- rights_information_review.py: record reautoriza tras la fila Information, antes de proof/firma/replay/audit/unseal para inspect/review. Mantiene guardas finales y validadores de policy/proof/source/versiones.
- rights_access_response_review.py: inspect reautoriza tras el borrador; record reutiliza esa inspección. No cambia authorize_reviewer ni los validadores/cuerpos permitidos.
- rights_access_field_read.py: reautoriza tras el inventario propio antes de su motivo/proyección. No modifica FIELDS, resolución de referencias, proof/source ni autorización final.

correction-source-review.json prueba que sólo seis funciones existentes cambian, con exactamente las siete comprobaciones previstas; restantes AST idénticos. No se retira ninguna guarda, por lo que no hay línea de seguridad eliminada que restaurar. Historia y callees relevantes son los helpers actuales ya usados en admisión: se conservan y se invocan otra vez después del bloqueo, no se sustituyen ni relajan.

## Callers y aislamiento

Context de field sirve inspect_decision y review; propose se invoca también al reproducir la evidencia desde inspect_decision; consume por la entrega complementaria. Info record sirve dos operaciones del controlador y consumidores de evidencia; draft inspect sirve su controlador y record; field_read sirve scope y reconstrucción de propuesta. Se revisaron estos encadenamientos en fuente: las llamadas de reconstrucción permanecen sujetas a autor/revisor independientes y epochs guardados, sin adoptar el User del otro actor como autorización del solicitante.

No cambia la resolución anidada de ID de decisión/inventario/expediente, ni la independencia row.actor/action.actor, el origen de la fuente, la lectura previa ni la condición de decisión aprobada. Las rutas autenticadas se incluyeron en la revisión de IDOR, escalada, revocación y permisos actuales. No se presume seguridad por exigir login.

## Pruebas elegidas y límites

Los seis diagnósticos originales432 permanecen byte a byte idénticos. Ocho variantes nuevas cubren propose/inventory, replay/decision, consume/approveddecision y read/inventory, por válido/revocado. Sólo callables forward para contar el ciphertext exacto, nunca cuerpo/ciphertext en metadatos. Comparaciones privadas calculadas en booleanos antes de assert. Control replay conserva dominio idéntico; nuevo propose añade Action+Decision y consume/read Action. Los24originales comprueban perfil/cuenta, ambos idiomas y cuatro recorridos móviles básicos además de carreras de caso y evidencia/versión/proof/CSRF.

Los ocho móviles auxiliares de metadatos físicos/logs conservan sus testigos: no se modifican parsers ni payloads, y la nueva guarda es anterior a sus ramas. No se declaran ochoPASSnuevos por ese razonamiento. No se repite el original de coverage ni N09D117.

No se bloquea al operador ni se garantiza serialización universal después de la última lectura. Los locks/proyecciones adicionales de source_snapshot/subjectUser conservan revisión independiente en N09; las regresiones actuales cubren las filas declaradas y el ciphertext objetivo, no toda fase previa al último lock. Un replay puede haber procesado contenido legítimo mientras aún tenía permiso antes de esperar su última decisión.

## Disposición

Pendiente38=6+8+24, con PG/Redis propios, sourcefreeze, cleanup/Telegram y audit root. No afirmar mejora de rendimiento: es coste de seguridad y los tiempos completos del caso incluyen preparación. Conservar3FAIL originales y clasificar cualquier nuevo fallo de producto/instrumento sin recortar selección. No certificar todo N09 ni el proyecto por ausencia de hallazgos nuevos; quedan139disposiciones y otros bloques.

## Referencias estáticas e historia cuantificadas

- apps.safety.rights_access_field_decision.consume: 1 sitios de llamada explícitos no ambiguos en apps/safety.
- apps.safety.rights_access_field_decision.context: 2 sitios de llamada explícitos no ambiguos en apps/safety.
- apps.safety.rights_access_field_decision.propose: 2 sitios de llamada explícitos no ambiguos en apps/safety.
- apps.safety.rights_access_field_read.read: 3 sitios de llamada explícitos no ambiguos en apps/safety.
- apps.safety.rights_access_response_review.inspect: 2 sitios de llamada explícitos no ambiguos en apps/safety.
- apps.safety.rights_information_review.record: 1 sitios de llamada explícitos no ambiguos en apps/safety.

Son referencias estáticas, no consumidores dinámicos exhaustivos. Los seis guards de admisión adyacentes originales y sus commits figuran en candidate-source-selection-review.json; no se elimina código de seguridad. Comprobación AST/selección24originales/38total PASS, separada de runtime pendiente.
