import json,subprocess,hashlib,collections
from pathlib import Path
work=Path(__file__).resolve().parent;root=Path('/home/felidae/proyectos/web_modelos_mod08_vps');out=root/'graphify-out';out.mkdir()
from graphify.detect import detect
raw=detect(root)
(work/'raw-detection.json').write_text(json.dumps(raw))
tracked=subprocess.check_output(['git','-C',str(root),'ls-files','-z']).decode().split('\0');tracked=[p for p in tracked if p and (root/p).is_file()]
code=[];templates=[];configs=[];docs=[];excluded=[]
source_prefixes=('apps/','config/','scripts/','static/','tests/')
code_exts={'.py','.js','.c','.h','.pyx','.sql','.sh'}
core_docs=['README.md','docs/01-producto.md','docs/02-arquitectura.md','docs/03-seguridad-privacidad.md','docs/04-seo.md','docs/06-marco-legal.md','docs/08-fichas-categorias.md','docs/09-taxonomia-ubicacion-busqueda.md','docs/10-unicidad-antiduplicados.md','docs/11-plan-seguridad-validacion.md','docs/12-operacion-seguridad.md','docs/14-contrato-funcional-v1.md','docs/15-apartado-legal-publico.md','docs/16-contrato-ejecucion-desarrollo.md','docs/84-restauracion-sin-reintroduccion.md','docs/85-operacion-registro-recuperacion.md','docs/87-recursos-locales-recuperacion.md','docs/94-sello-entrega-portabilidad.md','docs/96-mod08-objetos-cifrados-entrega-proxy.md','docs/mod08-canonical-v2.md','docs/mod08-generacion-asincrona.md','docs/mod08-portability-evidence-chain.md','docs/mod08-portability-runtime-role.md','docs/ci-local.md','docs/adr/001-base-tecnica.md','docs/actas/10-entrega-tecnica-local-alpha-20261020.md','docs/actas/11-preparacion-produccion-pendiente-20261019.md']
config_names={'pyproject.toml','uv.lock','Dockerfile','Caddyfile','compose.yaml','compose.runtime-role.yaml','compose.production.example.yaml','.dockerignore','.gitignore','.gitattributes'}
for rel in tracked:
 p=Path(rel)
 if rel in core_docs or rel.startswith('docs/contratos/') and p.suffix=='.md':docs.append(rel)
 elif rel.startswith('templates/') and p.suffix=='.html':templates.append(rel)
 elif rel in config_names or rel.startswith('.github/workflows/') or rel.startswith('static/') and p.suffix in {'.css','.svg'}:configs.append(rel)
 elif rel.startswith(source_prefixes) and p.suffix in code_exts and not rel.startswith('static/vendor/'):code.append(rel)
 elif rel.startswith(('apps/','tests/')) and p.suffix=='.json':configs.append(rel)
 else:excluded.append({'path':rel,'reason':'historical, evidence, coordination, proposal, generated or outside current source scope'})
for p in core_docs:
 if p not in docs:raise RuntimeError('missing current selected doc '+p)
selected=sorted(code+templates+configs+docs)
manifest={rel:{'sha256':hashlib.sha256((root/rel).read_bytes()).hexdigest(),'bytes':(root/rel).stat().st_size,'layer':'tests' if rel.startswith('tests/') else 'tooling' if rel.startswith('scripts/') else 'documentation' if rel in docs else 'interface' if rel in templates or rel.startswith('static/') else 'configuration' if rel in configs else 'application'} for rel in selected}
detection={'scan_root':str(root),'total_files':len(selected),'total_words':sum(len((root/p).read_text(errors='replace').split()) for p in selected),'files':{'code':[str(root/p) for p in code], 'document':[str(root/p) for p in docs],'paper':[],'image':[],'video':[]},'templates':[str(root/p) for p in templates],'configuration':[str(root/p) for p in configs],'skipped_sensitive':[], 'warning':'Large code corpus; explicit current-source scope requested by user; no historic expansion','raw_sensitive_heuristic_overrides':['templates/core/token.html','templates/core/token_invalid.html'],'unclassified':[]}
# Both skipped paths are tracked template code, reviewed as code: no credential values are ingested.
for name,data in [('corpus.json',detection),('source-manifest.json',manifest),('excluded-sources.json',excluded)]:
 (work/name).write_text(json.dumps(data,indent=2,ensure_ascii=False))
# Three bounded actual semantic readings, not regex/heading extraction.
groups=[[] for _ in range(3)];sizes=[0]*3
for p in sorted(docs,key=lambda p:manifest[p]['bytes'],reverse=True):
 i=min(range(3),key=lambda i:sizes[i]);groups[i].append(str(root/p));sizes[i]+=manifest[p]['bytes']
for i,fs in enumerate(groups):
 folder=work/f'semantic-{i+1}';folder.mkdir(exist_ok=True)
 (folder/'assignment.json').write_text(json.dumps({'root':str(root),'files':sorted(fs)},indent=2))
print('Corpus',len(selected),'files',detection['total_words'],'words','code',len(code),'templates',len(templates),'config',len(configs),'docs',len(docs))
print('Top',collections.Counter(p.split('/')[0] if '/' in p else '(root)' for p in selected).most_common(5))
print('Semantic groups',[(i+1,len(fs),sizes[i]) for i,fs in enumerate(groups)])
print('Gemini configured: not used; native semantic agents as explicitly authorized by skill')
