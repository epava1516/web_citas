import json,hashlib,subprocess
from pathlib import Path
root=Path('/home/felidae/proyectos/web_modelos_mod08_vps');out=root/'graphify-out';work=Path('/tmp/web-modelos-graph-clean-20261020')
g=json.loads((out/'graph.json').read_text());h=json.loads((out/'GRAPH_HEALTH.json').read_text());manifest=json.loads((out/'SOURCE_MANIFEST.json').read_text());policy=json.loads((out/'CORPUS_POLICY.json').read_text());errors=[]
ids=[n['id'] for n in g['nodes']];idset=set(ids);edges=g.get('links',g.get('edges',[]))
if len(ids)!=len(idset):errors.append('duplicate IDs')
if not g.get('directed') or not g.get('multigraph'):errors.append('directed multigraph not preserved')
if len(edges)!=h['relations']:errors.append('relation count mismatch')
for e in edges:
 if e['source'] not in idset or e['target'] not in idset:errors.append('dangling endpoint')
 if e.get('confidence')=='EXTRACTED' and e.get('confidence_score')!=1.0:errors.append('invalid EXTRACTED confidence')
for n in g['nodes']:
 p=n.get('source_file')
 if p and p not in manifest:errors.append('out-of-corpus node source '+p)
 if p and p.startswith(('.ai/','docs/evidencias/','docs/17-historial/','graphify-out/')):errors.append('historical contamination '+p)
for rel,record in manifest.items():
 if hashlib.sha256((root/rel).read_bytes()).hexdigest()!=record['sha256']:errors.append('source changed '+rel)
 if not any(n.get('source_file')==rel for n in g['nodes']):errors.append('missing file '+rel)
if len(policy['selected_files'])!=len(manifest):errors.append('policy manifest mismatch')
for key in ['prior_graph_nodes_used','prior_graph_edges_used','prior_cache_entries_used']:
 if g['graph'].get(key)!=0:errors.append('prior data reused '+key)
if json.loads((work/'policy-detection.json').read_text())['historical_entries']:errors.append('default ignore policy admits history')
if h['routing_audit']['unresolved_template_urls']:errors.append('unresolved explicit template route')
if not (out/'graph.html').is_file():errors.append('missing HTML')
for p in out.rglob('*'):
 if p.name in {'snapshots','previous-initial','previous-alpha','memory'}:errors.append('stale graph history '+str(p))
if subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()!=h['source_commit']:errors.append('source commit changed')
for base in [Path('/home/felidae/proyectos/web_modelos'),root]:
 subprocess.run(['git','-C',str(base),'diff','--check'],check=True)
 if (base/'docs/evidencias/traslado-maquina-graphify0110.tar.gz').exists():errors.append('prior graph archive survived')
# Source code is untouched; graph-only deletion and maintenance metadata are the only Alpha worktree edits.
status=subprocess.check_output(['git','-C',str(root),'status','--porcelain'],text=True).splitlines()
allowed={'.graphifyignore','docs/19-graphify-analisis-local.md','docs/evidencias/traslado-maquina-graphify0110.tar.gz','docs/evidencias/graphify-grafo-limpio-20261020.json'}
for line in status:
 if line[3:] not in allowed:errors.append('unexpected Alpha worktree modification '+line[3:])
view=Path('/home/felidae/proyectos/web_modelos/graphify-out')
for name in ['graph.json','graph.html','GRAPH_REPORT.md']:
 if not (view/name).is_symlink() or (view/name).resolve()!=(out/name).resolve():errors.append('canonical output alias invalid '+name)
for base in [out,view]:
 if (base/'cache').exists():errors.append('retained generated cache')
actual_without_source=sum(not n.get('source_file') for n in g['nodes'])
if actual_without_source!=h['external_unresolved_nodes']+h['ast_external_symbol_occurrences_without_source_file']:errors.append('external reference accounting mismatch')
result={'result':'PASS' if not errors else 'FAIL','errors':errors,'nodes':len(ids),'relations':len(edges),'source_files_sha256_verified':len(manifest),'historical_source_nodes':0,'prior_nodes_edges_cache_reused':0,'unresolved_external_references':h['external_unresolved_nodes'],'self_loops':h['self_loops'],'template_routes':h['routing_audit']['routes'],'template_url_names_unresolved':0,'scope':'Graph artifact integrity, fresh corpus isolation and source consistency. No application tests or new acceptance.'}
(out/'GRAPH_VERIFICATION.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(result,ensure_ascii=False))
raise SystemExit(bool(errors))
