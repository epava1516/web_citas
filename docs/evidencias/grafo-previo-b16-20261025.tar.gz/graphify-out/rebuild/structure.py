import ast,json,re,hashlib,tomllib,posixpath
from pathlib import Path
work=Path(__file__).resolve().parent;r=json.loads((work/'corpus.json').read_text());root=Path(r['scan_root']);manifest=json.loads((work/'source-manifest.json').read_text())
def ident(s):return re.sub('[^a-z0-9]','_',s.lower())
def fid(rel):return 'file_'+ident(rel)
# Environment names only, never secret values; bundled third-party code is a single asset node.
for rel in ['.env.example','static/vendor/htmx.min.js']:
 p=root/rel
 if p.is_file() and rel not in manifest:
  r['configuration'].append(str(p));r['total_files']+=1
  manifest[rel]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'layer':'configuration' if rel.startswith('.') else 'third_party_asset'}
(work/'source-manifest.json').write_text(json.dumps(manifest,indent=2));(work/'corpus.json').write_text(json.dumps(r,indent=2))
nodes={};edges=[];routes={};unresolved_urls=[]
def node(i,label,rel,ft='concept',line=None,**kw):
 nodes.setdefault(i,{'id':i,'label':label,'file_type':ft,'source_file':str(root/rel),'source_location':line,**kw});return i
def edge(s,t,relation,rel,line=None,evidence=None,**kw):
 edges.append({'source':s,'target':t,'relation':relation,'confidence':'EXTRACTED','confidence_score':1.0,'source_file':str(root/rel),'source_location':line,'weight':1.0,**({'evidence':evidence} if evidence else {}),**kw})
for rel,d in manifest.items():
 node(fid(rel),rel,rel,'document' if d['layer']=='documentation' else 'code',1,layer=d['layer'],sha256=d['sha256'])
# Resolve actual path(name=...) declarations without executing Django.
for rel in manifest:
 if not Path(rel).name.endswith('urls.py'):continue
 text=(root/rel).read_text();tree=ast.parse(text);imports={};namespace='';package='.'.join(Path(rel).parent.parts)
 for n in tree.body:
  if isinstance(n,ast.Import):
   for a in n.names:imports[a.asname or a.name]=a.name
  if isinstance(n,ast.ImportFrom):
   if n.level:
    parts=package.split('.');base='.'.join(parts[:len(parts)-n.level+1]);base+='.'+n.module if n.module else ''
   else:base=n.module or ''
   for a in n.names:imports[a.asname or a.name]=base+'.'+a.name
  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='app_name' for t in n.targets) and isinstance(n.value,ast.Constant):namespace=n.value.value
 for n in ast.walk(tree):
  if not isinstance(n,ast.Call) or not isinstance(n.func,ast.Name) or n.func.id not in {'path','re_path'}:continue
  names=[k.value.value for k in n.keywords if k.arg=='name' and isinstance(k.value,ast.Constant) and isinstance(k.value.value,str)]
  if not names:continue
  name=names[0];full=(namespace+':' if namespace else '')+name
  route=n.args[0].value if n.args and isinstance(n.args[0],ast.Constant) else ''
  i=node('route_'+ident(full),'Ruta '+full,rel,line=n.lineno,route_name=full,route_pattern=route,layer='routing');edge(fid(rel),i,'declares_route',rel,n.lineno)
  routes[full]=i
  if len(n.args)<2:continue
  view=n.args[1]
  if isinstance(view,ast.Attribute) and isinstance(view.value,ast.Name) and view.value.id in imports:
   ref=imports[view.value.id]+'.'+view.attr
  elif isinstance(view,ast.Name) and view.id in imports:ref=imports[view.id]
  else:continue
  module,_,symbol=ref.rpartition('.');path=module.replace('.','/')+'.py'
  if path in manifest:
   target=node(ident(module.replace('.','_'))+'_'+ident(symbol),symbol+'()',path,'code',None,layer='application',binding_origin='url_import')
   edge(i,target,'dispatches_to',rel,n.lineno,evidence=ast.get_source_segment(text,n))
# Template inheritance, explicit named routes, static assets and HTMX bindings.
for absolute in r['templates']:
 p=Path(absolute);rel=str(p.relative_to(root));text=p.read_text();lines=text.splitlines()
 nodes[fid(rel)].update(has_csrf_token='{% csrf_token %}' in text,has_htmx='hx-' in text)
 for lineno,line in enumerate(lines,1):
  for m in re.finditer(r"{%\s*(extends|include)\s+['\"]([^'\"]+)['\"]",line):
   target='templates/'+m.group(2)
   if target in manifest:edge(fid(rel),fid(target),m.group(1),rel,lineno,m.group(0))
  for m in re.finditer(r"{%\s*url\s+['\"]([^'\"]+)['\"]",line):
   name=m.group(1)
   if name in routes:edge(fid(rel),routes[name],'references_route',rel,lineno,m.group(0))
   else:unresolved_urls.append({'source_file':rel,'line':lineno,'route_name':name})
  for m in re.finditer(r"{%\s*static\s+['\"]([^'\"]+)['\"]",line):
   target='static/'+m.group(1)
   if target in manifest:edge(fid(rel),fid(target),'loads_asset',rel,lineno,m.group(0))
# Current-source citations ONLY: excluded/history links stay plain metadata, never recursively expanded.
pat=re.compile(r'(?<![A-Za-z0-9_./@+-])[A-Za-z0-9_./@+-]{1,240}\.(?:py|pyx|js|md|json|ya?ml|toml|html|css)\b')
for rel in manifest:
 if rel=='static/vendor/htmx.min.js':continue
 text=(root/rel).read_text(errors='replace');references=set();outside=[]
 for raw in {m.group() for m in pat.finditer(text)}:
  target=next((s for s in (raw,posixpath.normpath(str(Path(rel).parent/raw))) if s in manifest),None)
  if target and target!=rel:references.add(target)
  elif raw.startswith(('docs/evidencias/','evidencias/','17-historial/','.ai/')):outside.append(raw)
 for target in sorted(references):edge(fid(rel),fid(target),'references_source',rel)
 if outside:nodes[fid(rel)]['excluded_citations']=sorted(set(outside))
# Native Cython declarations are indexed without pretending CPython AST handled them.
for absolute in r['files']['code']:
 p=Path(absolute)
 if p.suffix!='.pyx':continue
 rel=str(p.relative_to(root))
 for lineno,line in enumerate(p.read_text().splitlines(),1):
  m=re.match(r'^(?:def\s+|cdef\s+(?:[A-Za-z_]\w*\s+)+|cpdef\s+(?:[A-Za-z_]\w*\s+)*)([A-Za-z_]\w*)\s*\(',line)
  if m:
   name=m.group(1);i=node(ident(str(p.relative_to(root).with_suffix('')))+'_'+ident(name),name+'()',rel,'code',lineno,layer='application',extractor='cython_declaration')
   edge(fid(rel),i,'contains',rel,lineno,line)
# Direct dependency declarations and exact uv.lock versions; no transitive lock graph noise.
project=tomllib.loads((root/'pyproject.toml').read_text());lock=tomllib.loads((root/'uv.lock').read_text());versions={p['name'].lower():p['version'] for p in lock.get('package',[]) if 'version' in p}
for kind,values in [('runtime',project['project']['dependencies']),('development',project.get('dependency-groups',{}).get('dev',[]))]:
 for value in values:
  m=re.match(r'[A-Za-z0-9_.-]+',value);name=m.group();i=node('dependency_'+ident(name),name,'pyproject.toml',dependency_kind=kind,declared_spec=value,locked_version=versions.get(name.lower()),layer='dependencies')
  edge(fid('pyproject.toml'),i,'depends_on','pyproject.toml',evidence=value)
  if name.lower() in versions:edge(fid('uv.lock'),i,'pins_version','uv.lock')
(work/'structure.json').write_text(json.dumps({'nodes':list(nodes.values()),'edges':edges,'hyperedges':[]},ensure_ascii=False))
(work/'routing-audit.json').write_text(json.dumps({'routes':len(routes),'unresolved_template_urls':unresolved_urls,'sensitive_template_override':'Both token templates reviewed as tracked HTML/Django source; contain no credential values; included as interface code.','no_historical_link_expansion':True},indent=2))
print('Current source structure',len(nodes),'nodes',len(edges),'relations','routes',len(routes),'unresolved template routes',len(unresolved_urls),'input files',r['total_files'])
