import json,time
from pathlib import Path
from graphify.extract import extract
work=Path(__file__).resolve().parent;r=json.loads((work/'corpus.json').read_text());root=Path(r['scan_root'])
files=[Path(f) for f in r['files']['code'] if Path(f).suffix!='.pyx']
t=time.monotonic();d=extract(files,cache_root=None,root=root,max_workers=2)
(work/'ast.json').write_text(json.dumps(d,ensure_ascii=False))
print('Fresh AST',len(files),'files',len(d['nodes']),'nodes',len(d['edges']),'relations',round(time.monotonic()-t,1),'s',flush=True)
