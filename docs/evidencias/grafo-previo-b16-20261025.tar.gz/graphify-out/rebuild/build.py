import json,re,hashlib,collections,copy
from pathlib import Path
from datetime import datetime,timezone
import networkx as nx
from graphify.cluster import cluster,score_all
from graphify.analyze import god_nodes,surprising_connections
from graphify.export import to_json
from graphify.report import generate
work=Path(__file__).resolve().parent
read=lambda name:json.loads((work/name).read_text())
r=read('corpus.json');root=Path(r['scan_root']);manifest=read('source-manifest.json');out=root/'graphify-out';out.mkdir(exist_ok=True)
normalize=lambda s:re.sub('[^a-z0-9]','_',s.lower())
fid=lambda p:'file_'+normalize(p)
def relative(p):
 if not p:return None
 p=Path(p)
 return str(p.relative_to(root)) if p.is_absolute() and p.is_relative_to(root) else str(p)
nodes={};edges=[];hyper=[];semantic_audit=[];excluded_semantic=[]
def ingest(d,origin):
 allowed_ids=set()
 for raw in d.get('nodes',[]):
  n=copy.deepcopy(raw);p=relative(n.get('source_file'));n['source_file']=p
  if p and p not in manifest:
   excluded_semantic.append({'id':n['id'],'source_file':p,'reason':'outside clean corpus'});continue
  if p:n['layer']=manifest[p]['layer']
  else:n.setdefault('layer','external_reference')
  n['extraction_origin']=origin;existing=nodes.get(n['id'])
  if existing:
   sources=sorted(set(existing.get('source_files',[])+n.get('source_files',[])+[x for x in [existing.get('source_file'),p] if x]))
   merged={**existing,**n}
   if existing.get('_origin')=='ast':
    merged={**n,**existing}
   merged['source_files']=sources
   nodes[n['id']]=merged
  else:nodes[n['id']]=n
  allowed_ids.add(n['id'])
 for raw in d.get('edges',[]):
  e=copy.deepcopy(raw);p=relative(e.get('source_file'));e['source_file']=p
  if p and p not in manifest:continue
  e['extraction_origin']=origin;e.setdefault('confidence','EXTRACTED')
  e.setdefault('confidence_score',{'EXTRACTED':1.0,'INFERRED':0.75,'AMBIGUOUS':0.2}[e['confidence']]);e.setdefault('weight',1.0)
  edges.append(e)
 for h in d.get('hyperedges',[]):
  h=copy.deepcopy(h);h['source_file']=relative(h.get('source_file'));hyper.append(h)
ingest(read('ast.json'),'fresh_ast')
ingest(read('structure.json'),'fresh_template_route_config_structure')
for i in [1,2,3]:
 fragment=read(f'semantic-{i}/fragment.json');assigned=set(read(f'semantic-{i}/assignment.json')['files']);covered=fragment['covered_files']
 records={x['source_file']:x for x in covered}
 if set(records)!=assigned:raise RuntimeError('semantic coverage mismatch '+str(i))
 for p,record in records.items():
  if record['sha256']!=manifest[relative(p)]['sha256'] or not record.get('complete_read'):raise RuntimeError('semantic SHA/read mismatch '+p)
 checked=0;bad=[]
 for e in fragment['edges']:
  quote=e.get('evidence');p=e.get('source_file')
  if quote:
   norm=lambda x:' '.join(str(x).split())
   text=Path(p).read_text()
   if norm(quote) not in norm(text):bad.append({'source_file':p,'evidence':quote})
   checked+=1
 if bad:
  (work/f'semantic-{i}/unmatched-evidence.json').write_text(json.dumps(bad,indent=2));raise RuntimeError('unmatched evidence '+str(i))
 semantic_audit.append({'agent':i,'documents':len(records),'nodes':len(fragment['nodes']),'edges':len(fragment['edges']),'quotations_verified':checked})
 ingest(fragment,'fresh_reasoned_semantics_'+str(i))
# Do not create references to excluded historical documents, even if agents cited them.
excluded_ids={x['id'] for x in excluded_semantic};edges=[e for e in edges if not any(e[k] in excluded_ids and e[k] not in nodes for k in ['source','target'])]
# Physical module/file anchoring; preserve original module names as provenance.
module_files=collections.defaultdict(list)
for p in manifest:
 if p.endswith('.py'):module_files[normalize(str(Path(p).with_suffix('')))].append(p)
missing=set();resolved={}
for e in edges:
 for key in ['source','target']:
  x=e[key]
  if x in nodes:continue
  candidates=module_files.get(x,[])
  if len(candidates)==1:
   e['original_'+key]=x;e[key]=fid(candidates[0]);resolved[x]=e[key]
  else:missing.add(x)
for x in sorted(missing):nodes[x]={'id':x,'label':'Referencia externa/sin resolver: '+x,'file_type':'concept','source_file':None,'source_location':None,'layer':'external_reference','resolution_status':'external_or_unresolved'}
for e in edges:
 if e['source'] in missing or e['target'] in missing:e['resolution_status']='external_or_unresolved'
# Containment connects definitions and reasoned concepts to current source files.
for n in list(nodes.values()):
 p=n.get('source_file')
 if p and fid(p) in nodes and n['id']!=fid(p):edges.append({'source':fid(p),'target':n['id'],'relation':'contains','confidence':'EXTRACTED','confidence_score':1.0,'source_file':p,'source_location':n.get('source_location'),'weight':1.0,'extraction_origin':'source_membership'})
unique=[];seen=set();removed=0
for e in edges:
 key=json.dumps({k:v for k,v in e.items() if k!='extraction_origin'},sort_keys=True,ensure_ascii=False)
 if key in seen:removed+=1;continue
 seen.add(key);unique.append(e)
edges=unique
valid_hyper=[h for h in hyper if set(h.get('nodes',[]))<=set(nodes)]
G=nx.MultiDiGraph()
for n in nodes.values():G.add_node(n['id'],**{k:v for k,v in n.items() if k!='id'})
for e in edges:G.add_edge(e['source'],e['target'],**{k:v for k,v in e.items() if k not in {'source','target'}})
commit='920ea36b6f4d0e8c0a60d030730de5aed1cf1781'
G.graph.update(hyperedges=valid_hyper,source_root=str(root),source_commit=commit,stage='Alpha técnico local aceptado; G01–08 producción pendientes',rebuilt_from_zero=True,prior_graph_nodes_used=0,prior_graph_edges_used=0,prior_cache_entries_used=0,historical_source_expansion=False,generated_at=datetime.now(timezone.utc).isoformat())
H=nx.Graph();H.add_nodes_from(G.nodes(data=True))
for u,v,d in G.edges(data=True):
 if u==v:continue
 if H.has_edge(u,v):H[u][v]['weight']+=1
 else:H.add_edge(u,v,**{**d,'weight':1})
print('Fresh clean graph',G.number_of_nodes(),'nodes',G.number_of_edges(),'relations; clustering',flush=True)
communities=cluster(H);cohesion=score_all(H,communities)
labels={}
features=[('portability','Portabilidad'),('publication','Publicación'),('rectification','Rectificación'),('rights','Derechos'),('promotion','Promociones'),('recovery','Recuperación'),('retention','Retención'),('erasure','Supresión'),('account','Cuentas'),('agency','Agencias'),('geograph','Geografía'),('media','Imágenes'),('crypto','Cifrado'),('capacity','Capacidad'),('safety','Privacidad')]
for cid,ids in communities.items():
 layers=collections.Counter(H.nodes[x].get('layer') for x in ids);layer=layers.most_common(1)[0][0]
 text=' '.join(str(H.nodes[x].get('source_file') or '')+' '+str(H.nodes[x].get('label','')) for x in ids).lower()
 score,feature=max((text.count(key),label) for key,label in features)
 prefix={'tests':'Pruebas','tooling':'Herramientas','documentation':'Contrato','interface':'Interfaz','application':'Aplicación','configuration':'Configuración','external_reference':'Referencias externas'}.get(layer,'Proyecto')
 labels[cid]=prefix+(' · '+feature if score else '')
gods=god_nodes(H);surprises=surprising_connections(H,communities)
questions=[{'question':'¿Cómo se propaga una revocación desde la cuenta hasta publicación y entrega privada?','why':'Autoridad vigente y elegibilidad conectan varios módulos actuales.'},{'question':'¿Qué conecta las plantillas con sus rutas y las comprobaciones del servidor?','why':'Las rutas nombradas y dispatches se extraen del código vigente.'},{'question':'¿Qué separa el alfa aceptado de los requisitos productivos G01–08?','why':'Las actas10/11 constituyen la frontera de aceptación vigente.'}]
assert to_json(G,communities,str(out/'graph.json'),built_at_commit=commit,community_labels=labels)
report=generate(H,communities,cohesion,labels,gods,surprises,r,{'input':0,'output':0},str(root),suggested_questions=questions,built_at_commit=commit)
header=f'''# Imagen limpia del alfa — reconstrucción absoluta 2026-10-20

Fuente única: `{root}`, commit `{commit}`. Los grafos, cachés, memorias, snapshots y archivo de traslado anteriores fueron eliminados por instrucción expresa del usuario. **Cero nodos, relaciones o entradas de caché heredados.** Se conserva únicamente el registro numérico de consumo en documentación, fuera del corpus.

Corpus seleccionado: **{r['total_files']} archivos**, código de aplicación/configuración, pruebas y herramientas actuales, 129 plantillas y 41 documentos explícitamente seleccionados. No se ingiere `.ai`, seguimiento cronológico, historial documental, evidencias antiguas, archivos comprimidos, propuestas, fuentes descartadas, medios, datos privados, secretos ni dependencias instaladas. Las citas a fuentes excluidas se conservan como metadatos y no se expanden. Listas completas en SOURCE_MANIFEST.json y CORPUS_POLICY.json.

Grafo autoritativo dirigido y múltiple: **{G.number_of_nodes():,} nodos, {G.number_of_edges():,} relaciones**; conserva paralelas. Comunidades y centralidad usan una proyección simple de {H.number_of_edges():,} pares. Capas explícitas: aplicación, interfaz, documentación, configuración, pruebas, herramientas y referencias externas. La pertenencia de una prueba al grafo no demuestra que haya pasado ni representa una funcionalidad productiva.

Estado vigente: Alpha técnico local aceptado según acta10; producción G01–08 pendiente según acta11. MOD09 conserva deuda de rendimiento. Los documentos vigentes pueden contener contexto histórico acotado: no se transforma en una cola actual ni se reabren bloqueos cerrados. Los conceptos documentales proceden de lecturas y razonamiento nuevos; AST, rutas/plantillas y dependencias son extracciones estructurales, no pruebas funcionales.

Limitaciones: {len(missing)} referencias externas/sin resolver explícitas, {nx.number_of_selfloops(G)} autorrelaciones conservadas (incluidos posibles `super()`; no prueban recursión), semántica documental seleccionada sin prometer cada proposición. No se ejecutó ninguna prueba de aplicación, carga, nueva aceptación o despliegue.

**Consumo nuevo: no medible por las herramientas de agentes nativos. Los ceros técnicos de la plantilla inferior son placeholders, no consumo cero. Historial numérico conservado fuera del grafo.** Sin Claude ni API LLM externa.

'''
(out/'GRAPH_REPORT.md').write_text(header+report)
(out/'.graphify_labels.json').write_text(json.dumps(labels,ensure_ascii=False))
(out/'.graphify_analysis.json').write_text(json.dumps({'communities':communities,'cohesion':cohesion,'gods':gods,'surprises':surprises,'questions':questions},ensure_ascii=False))
health={'nodes':G.number_of_nodes(),'relations':G.number_of_edges(),'communities':len(communities),'source_files':len(manifest),'code_files':len(r['files']['code']),'document_files':len(r['files']['document']),'template_files':len(r['templates']),'configuration_files':len(r['configuration']),'missing_endpoints':0,'dangling_endpoints':0,'external_unresolved_nodes':len(missing),'internal_module_paths_resolved':len(resolved),'self_loops':nx.number_of_selfloops(G),'parallel_edges_preserved':G.number_of_edges()-len(set(G.edges())),'exact_duplicates_removed':removed,'old_graph_entities_used':0,'old_cache_entries_used':0,'source_commit':commit,'semantic_audits':semantic_audit,'routing_audit':read('routing-audit.json')}
(out/'GRAPH_HEALTH.json').write_text(json.dumps(health,indent=2,ensure_ascii=False))
(out/'SOURCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
(out/'CORPUS_POLICY.json').write_text(json.dumps({'source_root':str(root),'source_commit':commit,'selected_files':sorted(manifest),'excluded_sources':read('excluded-sources.json'),'historical_link_expansion':False,'cache_reuse':False,'old_graph_reuse':False,'secret_values_ingested':False,'template_filter_overrides':read('routing-audit.json')['sensitive_template_override']},indent=2,ensure_ascii=False))
(out/'RESET_RECEIPT.json').write_text(json.dumps(read('reset-receipt.json'),indent=2))
(work/'extraction.json').write_text(json.dumps({'nodes':list(nodes.values()),'edges':edges,'hyperedges':valid_hyper},ensure_ascii=False))
(work/'semantic-audit.json').write_text(json.dumps(semantic_audit,indent=2))
print(json.dumps({k:v for k,v in health.items() if k not in {'semantic_audits','routing_audit'}},ensure_ascii=False),flush=True)
