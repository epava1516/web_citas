# Estado del grafo — consolidación beta

Grafo actual: 14370 nodos, 60812 relaciones dirigidas, 559 comunidades y 1801 fuentes. Refresco AST/templates dirigido más semántica de 2 documentos completos y encabezado vigente de seguimiento17. No actualización semántica exhaustiva. B00–B13 aceptados técnicos locales, catorce de18puntos; B14–B17 pendientes; alfa aceptado sólo en su corte; G01–G08 pendientes.
