# Corpus limpio y mantenimiento

Fuente única: worktree alfa `/home/felidae/proyectos/web_modelos_mod08_vps`. `CORPUS_POLICY.json` define la lista exacta y `.graphifyignore` impide que una detección ordinaria vuelva a ingerir historial o evidencia masiva. Las citas excluidas permanecen como metadatos; nunca expandirlas recursivamente.

La extracción de esta generación no usó cachés ni grafos previos. `rebuild/` contiene sólo fragmentos y receta NUEVOS para trazabilidad, sin snapshots históricos. Los scripts son el acta de esta ejecución, con ruta temporal de trabajo fijada; no constituyen un servicio automático ni una interfaz de mantenimiento general. Para reconstruir sobre nuevas fuentes hay que revalidar el corpus, rehacer AST y lectura semántica y comprobar huellas/citas antes de exportar. No usar una actualización AST aislada para afirmar nueva cobertura semántica.

`graph.json` es un MultiDiGraph: conserva relaciones paralelas. La proyección simple existe únicamente para agrupación y métricas; no sustituye la extracción. `graph.html` agrega comunidades para navegar. Capas separan aplicación, interfaz, documentación, configuración, pruebas, herramientas y referencias externas. Una arista de prueba no acredita PASS.

Se conservó únicamente consumo histórico numérico fuera del grafo. Tokens nativos nuevos no medibles por la herramienta; no se presentan como cero. Alpha local y producción se separan según las actas10/11. Ninguna prueba de aplicación ni aceptación nueva se ejecutó para construir el grafo.
