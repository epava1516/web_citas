# Grafo actual — adaptación del perfil hacia beta

Grafo actual: 14370 nodos, 60812 relaciones dirigidas, 559 comunidades y 1801 fuentes. Refresco AST/templates dirigido más semántica de 2 documentos completos y encabezado vigente de seguimiento17. No actualización semántica exhaustiva. B00–B13 aceptados técnicos locales, catorce de18puntos; B14–B17 pendientes; alfa aceptado sólo en su corte; G01–G08 pendientes. Las métricas de conectividad del informe usan proyección simple; graph.json conserva todas las relaciones paralelas.

Actualización semántica dirigida B07–B08: exposure. Se conserva el AST actual y su refresco dirigido; sin expansión a historial. Conceptos nuevos de lectura y razonamiento nativos, con citas literales comprobadas. La implementación y las pruebas se acreditan por sus evidencias, no por el grafo; sin aceptación beta. Comunidades anteriores conservadas y nueva comunidad documental Beta; no se ha recalculado su detección. Consumo nativo no disponible; los ceros técnicos inferiores no significan coste cero.

# Graph Report - web_modelos_mod08_vps  (2026-10-25)

## Corpus Check
- 1801 files · ~0 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 14370 nodes · 58816 edges · 559 communities (313 shown, 246 thin omitted)
- Extraction: 91% EXTRACTED · 9% INFERRED · 0% AMBIGUOUS · INFERRED: 5070 edges (avg confidence: 0.92)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `920ea36b`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- Pruebas · Portabilidad
- Aplicación · Privacidad
- Aplicación · Derechos
- Pruebas · Publicación
- Pruebas
- Herramientas · Imágenes
- Aplicación · Privacidad
- Pruebas · Recuperación
- Pruebas · Capacidad
- Pruebas
- Pruebas · Capacidad
- Aplicación · Rectificación
- Aplicación · Rectificación
- Pruebas · Derechos
- Aplicación · Derechos
- Herramientas · Capacidad
- Pruebas · Capacidad
- Pruebas · Capacidad
- Aplicación · Privacidad
- Pruebas · Privacidad
- Aplicación · Privacidad
- Pruebas · Capacidad
- Aplicación · Privacidad
- Herramientas · Capacidad
- Aplicación · Promociones
- Herramientas
- Aplicación · Promociones
- Pruebas · Supresión
- Aplicación · Imágenes
- Aplicación · Derechos
- Aplicación · Publicación
- Aplicación · Privacidad
- Aplicación · Privacidad
- Pruebas · Capacidad
- Aplicación · Privacidad
- Pruebas · Capacidad
- Aplicación · Promociones
- Aplicación · Privacidad
- Aplicación · Derechos
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Pruebas · Portabilidad
- Pruebas · Capacidad
- Aplicación · Recuperación
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Pruebas · Derechos
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Portabilidad
- Pruebas · Capacidad
- Pruebas · Derechos
- Herramientas
- Aplicación · Privacidad
- Aplicación · Derechos
- Pruebas
- Aplicación · Rectificación
- Aplicación · Privacidad
- Pruebas · Capacidad
- Pruebas · Recuperación
- Aplicación · Privacidad
- Herramientas
- Pruebas · Privacidad
- Aplicación · Privacidad
- Pruebas · Derechos
- Pruebas · Retención
- Aplicación · Supresión
- Aplicación · Publicación
- Herramientas · Publicación
- Pruebas · Capacidad
- Aplicación · Privacidad
- Pruebas · Publicación
- Pruebas · Derechos
- Pruebas · Supresión
- Aplicación · Publicación
- Aplicación · Geografía
- Aplicación
- Aplicación · Publicación
- Aplicación · Publicación
- Pruebas · Capacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Promociones
- Aplicación · Promociones
- Pruebas · Derechos
- Aplicación · Promociones
- Aplicación · Promociones
- Aplicación · Cuentas
- Aplicación
- Aplicación
- Aplicación
- Aplicación · Agencias
- Aplicación
- Aplicación
- Pruebas · Derechos
- Aplicación
- Aplicación · Agencias
- Aplicación
- Aplicación · Derechos
- Aplicación · Publicación
- Aplicación · Derechos
- Aplicación · Cuentas
- Aplicación
- Aplicación
- Aplicación
- Aplicación
- Aplicación
- Aplicación
- Aplicación
- Aplicación
- Aplicación
- Aplicación
- Aplicación
- Aplicación
- Aplicación
- Pruebas · Publicación
- Aplicación · Publicación
- Aplicación
- Aplicación · Publicación
- Aplicación · Imágenes
- Aplicación · Imágenes
- Aplicación · Imágenes
- Aplicación · Imágenes
- Aplicación · Imágenes
- Aplicación · Imágenes
- Aplicación · Imágenes
- Aplicación · Imágenes
- Aplicación · Privacidad
- Aplicación · Agencias
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Agencias
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Recuperación
- Aplicación · Derechos
- Aplicación · Derechos
- Pruebas · Publicación
- Aplicación · Privacidad
- Aplicación · Derechos
- Aplicación · Publicación
- Aplicación · Supresión
- Aplicación · Supresión
- Aplicación · Supresión
- Aplicación · Derechos
- Aplicación · Privacidad
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Privacidad
- Pruebas · Derechos
- Aplicación · Privacidad
- Aplicación · Derechos
- Aplicación · Rectificación
- Aplicación · Rectificación
- Aplicación · Derechos
- Aplicación · Rectificación
- Aplicación · Rectificación
- Aplicación · Rectificación
- Aplicación · Rectificación
- Aplicación · Rectificación
- Pruebas · Privacidad
- Aplicación · Rectificación
- Aplicación · Rectificación
- Aplicación · Rectificación
- Aplicación · Rectificación
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Cuentas
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Rectificación
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Supresión
- Aplicación · Supresión
- Aplicación · Retención
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Pruebas · Derechos
- Aplicación · Publicación
- Aplicación · Privacidad
- Aplicación · Publicación
- Aplicación · Publicación
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Derechos
- Aplicación · Derechos
- Pruebas · Capacidad
- Aplicación · Portabilidad
- Aplicación · Portabilidad
- Aplicación · Portabilidad
- Aplicación · Portabilidad
- Aplicación · Portabilidad
- Aplicación · Portabilidad
- Aplicación · Portabilidad
- Aplicación · Portabilidad
- Aplicación · Portabilidad
- Aplicación · Portabilidad
- Pruebas · Derechos
- Aplicación · Portabilidad
- Aplicación · Portabilidad
- Aplicación · Portabilidad
- Aplicación · Recuperación
- Aplicación · Recuperación
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Cuentas
- Pruebas · Promociones
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Retención
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Derechos
- Aplicación · Privacidad
- Herramientas · Capacidad
- Pruebas · Publicación
- Pruebas · Imágenes
- Pruebas · Privacidad
- Aplicación · Privacidad
- Pruebas · Rectificación
- Pruebas · Privacidad
- Pruebas · Privacidad
- Pruebas · Derechos
- Pruebas · Privacidad
- Pruebas · Privacidad
- Pruebas · Publicación
- Pruebas · Derechos
- Aplicación · Agencias
- Aplicación · Privacidad
- Pruebas · Supresión
- Pruebas · Publicación
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Pruebas · Cuentas
- Aplicación · Privacidad
- Aplicación · Perfil beta
- Pruebas · Publicación
- Aplicación · Perfil beta
- Pruebas · Rectificación
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Pruebas · Promociones
- Aplicación · Perfil beta
- Aplicación · Supresión
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Cuentas
- Pruebas · Cuentas
- Aplicación · Privacidad
- Pruebas · Derechos
- Pruebas · Capacidad
- Pruebas · Derechos
- Pruebas · Privacidad
- Aplicación · Derechos
- Aplicación · Publicación
- Pruebas · Agencias
- Aplicación · Rectificación
- Aplicación · Portabilidad
- Pruebas · Capacidad
- Pruebas · Derechos
- Pruebas · Rectificación
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Derechos
- Aplicación
- Aplicación · Privacidad
- Pruebas · Derechos
- Pruebas · Publicación
- Pruebas · Capacidad
- Pruebas
- Pruebas · Capacidad
- Pruebas
- Aplicación · Promociones
- Pruebas · Portabilidad
- Pruebas · Portabilidad
- Pruebas · Cuentas
- Pruebas · Recuperación
- Pruebas · Derechos
- Aplicación · Recuperación
- Pruebas · Capacidad
- Pruebas · Capacidad
- Pruebas · Supresión
- Herramientas · Cuentas
- Pruebas · Cuentas
- Pruebas
- Pruebas · Privacidad
- Herramientas
- Pruebas
- Pruebas · Derechos
- Aplicación · Derechos
- Herramientas
- Pruebas · Derechos
- Pruebas · Cifrado
- Aplicación · Rectificación
- Herramientas · Cifrado
- Pruebas · Capacidad
- Pruebas · Capacidad
- Pruebas · Capacidad
- Pruebas · Derechos
- Herramientas
- Pruebas · Imágenes
- Aplicación · Derechos
- Pruebas · Imágenes
- Pruebas · Privacidad
- Contrato · Promociones
- Pruebas · Capacidad
- Pruebas · Publicación
- Pruebas · Publicación
- Pruebas · Derechos
- Herramientas
- Pruebas · Portabilidad
- Pruebas
- Pruebas · Derechos
- Herramientas
- Pruebas · Capacidad
- Pruebas
- Pruebas · Derechos
- Pruebas · Privacidad
- Pruebas · Privacidad
- Herramientas
- Pruebas · Cuentas
- Pruebas
- Pruebas · Derechos
- Pruebas · Derechos
- Pruebas
- Pruebas · Portabilidad
- Pruebas
- Pruebas · Capacidad
- Pruebas · Capacidad
- Pruebas · Capacidad
- Pruebas · Portabilidad
- Pruebas
- Pruebas
- Pruebas · Retención
- Pruebas · Publicación
- Pruebas · Capacidad
- Pruebas · Portabilidad
- Pruebas
- Herramientas · Capacidad
- Herramientas · Cuentas
- Herramientas · Retención
- Pruebas · Capacidad
- Pruebas
- Pruebas · Portabilidad
- Pruebas · Publicación
- Aplicación · Privacidad
- Aplicación · Privacidad
- Herramientas
- Herramientas · Cuentas
- Herramientas · Retención
- Pruebas · Capacidad
- Pruebas · Capacidad
- Pruebas
- Pruebas
- Pruebas
- Pruebas · Publicación
- Pruebas · Derechos
- Herramientas
- Pruebas · Cuentas
- Pruebas · Cuentas
- Pruebas · Capacidad
- Pruebas
- Pruebas
- Pruebas
- Pruebas · Portabilidad
- Herramientas
- Pruebas
- Pruebas · Capacidad
- Pruebas · Capacidad
- Pruebas · Capacidad
- Pruebas · Publicación
- Pruebas · Derechos
- Pruebas · Derechos
- Herramientas
- Herramientas
- Pruebas
- Pruebas · Cuentas
- Pruebas · Capacidad
- Pruebas · Cuentas
- Pruebas
- Pruebas
- Pruebas · Publicación
- Pruebas · Publicación
- Pruebas · Publicación
- Pruebas · Publicación
- Pruebas
- Pruebas · Portabilidad
- Pruebas · Derechos
- Pruebas
- Herramientas · Publicación
- Pruebas · Cuentas
- Pruebas · Publicación
- Pruebas
- Pruebas · Portabilidad
- Pruebas · Portabilidad
- Pruebas · Derechos
- Pruebas
- Pruebas · Derechos
- Pruebas · Portabilidad
- Pruebas · Portabilidad
- Aplicación · Privacidad
- Herramientas
- Interfaz · Geografía
- Interfaz · Geografía
- Pruebas · Capacidad
- Pruebas · Capacidad
- Aplicación
- Pruebas · Derechos
- Pruebas
- Aplicación · Derechos
- Aplicación · Imágenes
- Herramientas · Privacidad
- Pruebas · Derechos
- Herramientas
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Cuentas
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Pruebas · Derechos
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Pruebas · Promociones
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Pruebas · Derechos
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Pruebas · Publicación
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Perfil beta
- Aplicación · Privacidad
- Pruebas · Derechos
- Pruebas · Derechos
- Aplicación · Privacidad
- Aplicación · Privacidad
- Aplicación · Recuperación
- Pruebas · Derechos
- Pruebas · Agencias
- Aplicación · Privacidad
- Interfaz · Privacidad
- Herramientas
- Contrato · Portabilidad
- Contrato · Publicación
- Contrato · Imágenes
- Contrato
- Configuración · Cifrado
- Contrato · Portabilidad
- Pruebas
- Aplicación · Promociones
- Aplicación · Agencias
- Contrato · Imágenes
- Contrato
- Contrato · Beta
- Contrato

## God Nodes (most connected - your core abstractions)
1. `User` - 693 edges
2. `unseal()` - 505 edges
3. `RightsAction` - 428 edges
4. `Listing` - 382 edges
5. `fingerprint()` - 343 edges
6. `Revision` - 328 edges
7. `seal()` - 298 edges
8. `RightsRequest` - 270 edges
9. `Person` - 265 edges
10. `Client` - 254 edges

## Surprising Connections (you probably didn't know these)
- `RightsPortabilityCoverage` --uses--> `test_private_guided_coverage_http_get_clean_save_replay_csrf()`  [INFERRED]
  apps/safety/models.py → tests/test_rights_portability_coverage_http.py
- `RightsPortabilityCoverage` --uses--> `test_covered_export_rechecks_after_observed_wait()`  [INFERRED]
  apps/safety/models.py → tests/test_rights_portability_covered_export_races.py
- `RightsPortabilityCoverage` --uses--> `test_mobile_guided_coverage_save_and_clean_get()`  [INFERRED]
  apps/safety/models.py → tests/test_rights_portability_coverage_mobile.py
- `RightsPortabilityCoverage` --uses--> `base()`  [INFERRED]
  apps/safety/models.py → tests/test_rights_evidence_chain.py
- `RightsPortabilityCoverageRead` --uses--> `test_failure_restores_aliases_and_batch_rollback()`  [INFERRED]
  apps/safety/models.py → tests/test_capacity_unseal_diagnostic.py

## Import Cycles
- None detected.

## Communities (559 total, 246 thin omitted)

### Community 0 - "Pruebas · Portabilidad"
Cohesion: 0.02
Nodes (189): RightsPortabilityCoverage, RightsPortabilityCoverageRead, RightsPortabilityCoverageReview, RightsPortabilityReview, RightsPortabilitySelection, RightsPortabilitySelectionReview, validated_kernel(), shared_source() (+181 more)

### Community 1 - "Aplicación · Privacidad"
Cohesion: 0.03
Nodes (113): PrivacyHoldReleaseProposal, PrivacyPublicationHold, PublicationCalendarEvent, PurposeExceptionProposal, RightsAccessCoverage, RightsMessage, RightsRectificationProposalRead, RightsRectificationRecipientAssessment (+105 more)

### Community 101 - "Aplicación · Derechos"
Cohesion: 0.12
Nodes (10): NoticeForm, CommunicationForm, inbox(), visible(), assert_screen(), test_operation_requirements_and_legacy(), test_agency_own_account_notice_does_not_include_owned_models(), test_mobile_recipient_assessment_source_is_audited_in_both_languages() (+2 more)

### Community 102 - "Pruebas · Publicación"
Cohesion: 0.13
Nodes (13): OrderVariantMiddleware, server_topology(), compatible_order_reference(), call(), test_default_preserves_four_sync_workers(), test_frozen_order_reference_keeps_original_arguments_with_snapshot_keyword(), reference(), test_threaded_candidate_rejects_other_modes_or_normal_resources() (+5 more)

### Community 103 - "Pruebas"
Cohesion: 0.19
Nodes (10): RoomControls, append(), ask(), execute(), load_events(), locked(), main(), now() (+2 more)

### Community 106 - "Herramientas · Imágenes"
Cohesion: 0.24
Nodes (15): RightsExportImage, RightsExportPart, purge_export_objects(), command(), fixture(), launch(), main(), state() (+7 more)

### Community 11 - "Pruebas · Recuperación"
Cohesion: 0.07
Nodes (35): Command, Command, RecoveryLedgerState, Checkpoint, LedgerIntegrityError, RecoveryLedger, RecoveryStore, export_batch() (+27 more)

### Community 111 - "Pruebas · Capacidad"
Cohesion: 0.16
Nodes (8): Collector, Cursor, observed(), wrapper(), scope(), wrapped_cursor(), test_observer_scope_restores_aliases_and_pipeline_after_failure(), test_alias_counts_root_consumption_without_patching_recursion()

### Community 115 - "Pruebas"
Cohesion: 0.18
Nodes (15): SyntheticProcessorError, render_owned_context(), assert_owned_links_released(), observe_contexts(), capture(), render_engine(), synthetic_processor(), test_invalid_context_keeps_native_type_error() (+7 more)

### Community 116 - "Pruebas · Capacidad"
Cohesion: 0.19
Nodes (17): Response, application(), observation(), outputs(), write(), test_domain_failure_remains_identical_and_hook_is_restored(), original(), test_listing_phase_marker_bypasses_both_profilers_and_drains() (+9 more)

### Community 119 - "Aplicación · Rectificación"
Cohesion: 0.21
Nodes (5): PhotoForm, available(), changes(), initial(), validate()

### Community 12 - "Pruebas · Derechos"
Cohesion: 0.06
Nodes (78): RightsAccess, RightsExtension, test_own_account_copy_review_download_and_changed_authority(), link_account(), account(), test_account_link_is_audited_idempotent_and_creates_no_profile(), test_account_link_rejects_conflict_mixed_reference_erased_and_representation(), action() (+70 more)

### Community 13 - "Aplicación · Derechos"
Cohesion: 0.05
Nodes (40): RightsAccessClosure, RightsAccessCoverageReview, RightsExportInformationBinding, RightsExportPortabilityBinding, close_response(), close_response(), prepare_response(), review_response() (+32 more)

### Community 132 - "Herramientas · Capacidad"
Cohesion: 0.17
Nodes (9): OwnedCPUObserver, cpu_counters(), cpu_delta(), read_group(), fixture(), test_cpu_delta_uses_elapsed_and_cumulative_counters_without_counting_wait_as_cpu(), test_missing_optional_controller_interfaces_stay_explicit(), test_rejects_unowned_or_nonlive_postgres() (+1 more)

### Community 134 - "Pruebas · Capacidad"
Cohesion: 0.23
Nodes (12): Snapshot, SnapshotBusy, _admin(), cache_key(), context(), _empty_fixture_database(), _quiescent(), seed_or_restore() (+4 more)

### Community 135 - "Pruebas · Capacidad"
Cohesion: 0.26
Nodes (19): WorkerObserver, collect_events(), test_opt_in_gc_records_real_collection_and_removes_callback(), native(), test_prelude_is_bounded_private_and_does_not_modify_request(), native(), test_sql_attribution_is_bounded_private_and_keeps_failed_calls(), native() (+11 more)

### Community 137 - "Aplicación · Privacidad"
Cohesion: 0.20
Nodes (9): Migration, CalendarPage, install(), uninstall(), backwards(), forwards(), calendar_page(), cursor() (+1 more)

### Community 138 - "Pruebas · Privacidad"
Cohesion: 0.23
Nodes (15): Frame, _check(), install(), getframe(), kernel(), try_check(), validated_kernel(), test_eligible_loader_integrity_error_preserved_and_frames_released() (+7 more)

### Community 139 - "Aplicación · Privacidad"
Cohesion: 0.15
Nodes (5): PublicationReleaseForm, QueueForm, ReleaseForm, release(), test_inherited_operations_and_required_errors_preserved()

### Community 143 - "Pruebas · Capacidad"
Cohesion: 0.19
Nodes (11): Collector, scope(), observed(), _timed(), test_failure_restores_aliases_and_batch_rollback(), fail_second(), test_fresh_crypto_result_is_never_shared_and_invalid_token_is_rechecked(), test_real_runtime_batch_unseal_breakdown() (+3 more)

### Community 147 - "Aplicación · Privacidad"
Cohesion: 0.17
Nodes (6): Catalog, Decision, DecisionsBase, ImageCatalog, prepare(), prepare_image_omissions()

### Community 148 - "Herramientas · Capacidad"
Cohesion: 0.19
Nodes (9): ResourceProbe, TrialLimits, cgroup_chain(), optional_text(), process_snapshot(), test_limits_require_five_sustained_execution_samples_and_detect_new_oom(), sample(), test_resource_stop_preserves_partial_ledger() (+1 more)

### Community 152 - "Aplicación · Promociones"
Cohesion: 0.21
Nodes (7): ListingChoice, OrderForm, ProductChoice, SimulationForm, detail(), orders(), credentials()

### Community 155 - "Herramientas"
Cohesion: 0.18
Nodes (6): ObservedResponse, post_worker_init(), route_response(), call(), application(), status()

### Community 159 - "Aplicación · Promociones"
Cohesion: 0.15
Nodes (7): PromotionProductVersion, PromotionCatalogueAudit.Meta, PromotionProduct.Meta, PromotionProductVersion.Meta, test_operator_audit_is_scoped_and_changes_invalidate_inventory(), capture(), test_localized_mobile_catalogue_navigation_save_release_reload()

### Community 16 - "Pruebas · Supresión"
Cohesion: 0.05
Nodes (69): AccountToken, Person, RecoveryCode, DecisionForm, PlanForm, ErasureInventory, ErasurePlan, AgencyMember.Meta (+61 more)

### Community 160 - "Aplicación · Imágenes"
Cohesion: 0.14
Nodes (5): Migration, Migration, Migration, Migration, Migration

### Community 161 - "Aplicación · Derechos"
Cohesion: 0.38
Nodes (12): Policy, _actor(), _context(), _digest(), _draft(), inspect(), issue(), _material() (+4 more)

### Community 164 - "Aplicación · Publicación"
Cohesion: 0.22
Nodes (6): SafeAccessLogger, PrivateRequestFilter, test_development_http_log_hides_report_capability(), test_django_http_warning_hides_report_receipt_secret(), test_photo_and_draft_access_logs_hide_private_identifiers(), test_publication_queue_early_responses_receive_private_headers()

### Community 166 - "Aplicación · Privacidad"
Cohesion: 0.27
Nodes (7): ExecutionForm, LocalizedProcessingForm, PreparationForm, ReviewForm, execution(), preparation(), review()

### Community 168 - "Aplicación · Privacidad"
Cohesion: 0.19
Nodes (6): ImageCatalogForm, ImageSaveForm, prepare_images(), image_catalog_captions(), image_save_captions(), test_image_forms_schema_defaults_and_literal()

### Community 169 - "Pruebas · Capacidad"
Cohesion: 0.28
Nodes (7): AdaptationProxy, adapted_fetch(), wrapped(), scope(), test_proxy_preserves_adaptation_result_and_restores_on_throw(), fetch(), test_scope_restores_full_phases_and_driver_generator_on_exception()

### Community 17 - "Aplicación · Privacidad"
Cohesion: 0.06
Nodes (63): CandidateResult, MatchResult, Signature, SimilarityResult, RightsPhotoReintroduction, RightsPhotoReintroductionDecision, RightsPhotoReintroductionRead, AuditForm (+55 more)

### Community 170 - "Pruebas · Capacidad"
Cohesion: 0.27
Nodes (7): Opener, Response, run(), test_explicit_profile_only_marker_reaches_private_get_with_full_timing(), test_missing_or_invalid_profile_keeps_original_string_get(), test_profile_does_not_relax_original_redirect_scope(), test_profile_does_not_relax_private_cache_control()

### Community 172 - "Aplicación · Promociones"
Cohesion: 0.31
Nodes (9): ProductForm, VersionForm, ProductForm.Meta, VersionForm.Meta, edit(), preview(), products(), versions() (+1 more)

### Community 174 - "Aplicación · Derechos"
Cohesion: 0.40
Nodes (6): LegalDocument, document(), index(), policy(), test_policy_rejects_unpublished_or_mismatched_reference(), test_policy_requires_transaction_and_detects_content_change()

### Community 175 - "Aplicación · Privacidad"
Cohesion: 0.24
Nodes (8): Migration, Migration, backfill(), install(), uninstall(), install(), uninstall(), runtime_functions()

### Community 176 - "Aplicación · Privacidad"
Cohesion: 0.24
Nodes (5): AccessForm, DecisionForm, ReviewForm, assert_screen(), test_native_form_values_and_generic_denial()

### Community 178 - "Aplicación · Privacidad"
Cohesion: 0.25
Nodes (5): ApprovedChoice, CatalogForm, FieldDecisionForm, FieldDecisionSet, field_label()

### Community 18 - "Pruebas · Portabilidad"
Cohesion: 0.03
Nodes (93): ProcessingPlanRead, ProcessingPlanReview, ProcessingPurposePlan, RightsAccessResponseReview, RightsPortabilityAssessment, Complaint.Meta, ErasureExecution.Meta, ErasureInventory.Meta (+85 more)

### Community 181 - "Pruebas · Capacidad"
Cohesion: 0.33
Nodes (6): Collector, _active(), _counter(), _plan(), _wrapper(), observed()

### Community 182 - "Aplicación · Recuperación"
Cohesion: 0.27
Nodes (3): AccountGateMiddleware, RecoveryGateMiddleware, SecurityHeadersMiddleware

### Community 185 - "Aplicación · Privacidad"
Cohesion: 0.21
Nodes (4): FinalForm, ProcessingForm, final(), final()

### Community 186 - "Aplicación · Privacidad"
Cohesion: 0.21
Nodes (3): Command, Command, configure_role()

### Community 188 - "Aplicación · Privacidad"
Cohesion: 0.18
Nodes (4): CalendarFilterForm, CalendarFilterForm, FollowUpForm, detail()

### Community 19 - "Pruebas · Derechos"
Cohesion: 0.06
Nodes (40): RightsAction, RightsPortabilitySelectionRead, _InspectionSource, review(), _fresh_source(), inspection_source(), scope(), shared_row_reference() (+32 more)

### Community 195 - "Aplicación · Privacidad"
Cohesion: 0.25
Nodes (10): KernelIntegrityError, _after_fork(), _after_fork_parent(), _before_fork(), _load(), _memfd(), _read(), _sha() (+2 more)

### Community 197 - "Aplicación · Privacidad"
Cohesion: 0.27
Nodes (5): DecisionForm, PageForm, condition_captions(), captions(), test_forms_defaults_raw_bounds_and_tristate()

### Community 198 - "Aplicación · Privacidad"
Cohesion: 0.21
Nodes (5): ApprovedCoverage, ApprovedSelection, ExportForm, job_status(), prepare()

### Community 199 - "Aplicación · Portabilidad"
Cohesion: 0.29
Nodes (6): CloseForm, DecisionForm, ReviewForm, draft_captions(), review_captions(), test_optional_language_query_defaults_and_private_literal()

### Community 2 - "Pruebas · Capacidad"
Cohesion: 0.02
Nodes (98): GCObserver, PublicationSampler, NoRedirect, kernel_identity(), generator_gc_overlap(), prepare_generator_gc(), backend_delta(), backend_snapshot() (+90 more)

### Community 20 - "Pruebas · Derechos"
Cohesion: 0.07
Nodes (25): Documents, part_tables(), _parts(), source_fingerprint(), source_rows(), _union(), materialize_physical(), physical_stamp() (+17 more)

### Community 202 - "Herramientas"
Cohesion: 0.26
Nodes (3): PGStatementSampler, test_sampler_rejects_unowned_database_before_connect(), forbidden_connect()

### Community 207 - "Aplicación · Privacidad"
Cohesion: 0.21
Nodes (4): Migration, Migration, Migration, Migration

### Community 21 - "Aplicación · Derechos"
Cohesion: 0.07
Nodes (29): RightsAccessFieldDecision, RightsAccessResponseDraft, RightsAccessScopeInventory, prepare_response(), review_response(), preview(), consume(), context() (+21 more)

### Community 211 - "Pruebas"
Cohesion: 0.36
Nodes (4): ObservedLoop, SelectorProbe, difference(), snapshot()

### Community 217 - "Aplicación · Rectificación"
Cohesion: 0.38
Nodes (6): RightsRectificationManagerNotice, acknowledge(), inbox(), allowed(), create(), visible()

### Community 218 - "Aplicación · Privacidad"
Cohesion: 0.30
Nodes (4): ProposalForm, ReviewForm, prepare(), review()

### Community 219 - "Pruebas · Capacidad"
Cohesion: 0.27
Nodes (6): Save, SaveForm, queries(), wrapper(), catalog_captions(), test_optional_language_lazy_shared_and_literal_data()

### Community 23 - "Pruebas · Recuperación"
Cohesion: 0.11
Nodes (32): RepresentationAction, RecoveryApplication, RecoveryMediaJob, RecoveryOutbox, payload(), stored_receipt(), test_foreign_scope_rolls_back_whole_application(), test_media_recovery_requeues_even_if_old_job_claims_completed() (+24 more)

### Community 230 - "Aplicación · Privacidad"
Cohesion: 0.33
Nodes (3): ImageInspectionForm, ReviewForm, test_review_defaults_bounds_and_photo_ids()

### Community 24 - "Pruebas · Privacidad"
Cohesion: 0.08
Nodes (51): ComplaintNotice, NoticeRecovery, ReportNotice, SimulatedComplaintNoticeDelivery, SimulatedNoticeDelivery, SimulatedRightsNoticeDelivery, RecoveryForm, queue() (+43 more)

### Community 247 - "Aplicación · Privacidad"
Cohesion: 0.36
Nodes (4): ConfirmationForm, confirm(), exchange(), cookie_name()

### Community 248 - "Pruebas · Derechos"
Cohesion: 0.61
Nodes (7): RightsResponseAcknowledgement, prepared(), test_explicit_receipt_is_private_idempotent_and_changes_no_authorization(), test_invalid_or_expired_receipt_and_foreign_response_cannot_acknowledge(), test_mobile_receipt_confirmation_persists_without_account(), test_two_postgresql_connections_keep_one_receipt_record(), submit()

### Community 25 - "Pruebas · Retención"
Cohesion: 0.07
Nodes (38): RetentionReview, RetentionReviewEvent, ReviewForm, inspect(), queue(), locked(), plan_decisions(), reconcile() (+30 more)

### Community 268 - "Herramientas · Publicación"
Cohesion: 0.46
Nodes (3): RouteMiddleware, post_worker_init(), observed()

### Community 27 - "Pruebas · Capacidad"
Cohesion: 0.05
Nodes (36): PageSeed, original_compiler(), variant(), build_counted_page_prototype(), build_dirty_projection_prototype(), build_page_template(), resolved(), template() (+28 more)

### Community 285 - "Aplicación · Privacidad"
Cohesion: 0.60
Nodes (3): Meta, RightsEvidenceEvent, RightsEvidenceHead

### Community 29 - "Pruebas · Publicación"
Cohesion: 0.13
Nodes (48): ReportAction, Restriction, coordinator(), test_coordinator_recovers_assignment_after_reviewer_loses_permission(), test_report_author_cannot_coordinate_own_case(), test_unassignment_cannot_reopen_resolved_case(), test_unassignment_racing_restriction_cannot_erase_resolved_restriction(), perform() (+40 more)

### Community 3 - "Pruebas · Derechos"
Cohesion: 0.02
Nodes (124): RightsCopyInformation, RightsCopyInformationRead, RightsCopyInformationReview, RightsCopyPageReview, RightsExport, RightsExportPreview, RightsImageAccess, source() (+116 more)

### Community 30 - "Pruebas · Supresión"
Cohesion: 0.07
Nodes (30): PurposeExceptionRead, PurposeExceptionReview, test_localized_audited_independent_review_preserves_active_restriction(), labels(), approved(), test_mobile_consume_reload_and_active_measure(), payload(), test_waiting_consumers_revalidate_and_consume_once() (+22 more)

### Community 302 - "Aplicación · Publicación"
Cohesion: 0.70
Nodes (3): Migration, trigger_sql(), collect()

### Community 31 - "Aplicación · Geografía"
Cohesion: 0.12
Nodes (24): Command, Category, GeographicSource, Municipality, PostalCode, Province, Region, Service (+16 more)

### Community 32 - "Pruebas · Capacidad"
Cohesion: 0.09
Nodes (48): Response, collect(), compact(), matrix(), _matrix_valid(), observe(), _open(), sample_id() (+40 more)

### Community 33 - "Pruebas · Derechos"
Cohesion: 0.09
Nodes (47): Body, legacy_read(), observe(), get_object(), tombstone(), test_mock_read_cancellation_closes_body_and_private_scratch(), read(), temporary() (+39 more)

### Community 34 - "Pruebas · Derechos"
Cohesion: 0.09
Nodes (31): RightsProof, RightsProofEvent, VerificationForm, verification(), account_source_digest(), check_actor(), compatible(), current_read() (+23 more)

### Community 36 - "Pruebas · Publicación"
Cohesion: 0.07
Nodes (24): VerificationCheck, PagePresentation, stripped(), test_owned_directory_count_and_page_plans(), capture(), test_discovery_full_visibility_query_growth(), counter(), test_owned_cold_mix_pyspy() (+16 more)

### Community 38 - "Aplicación · Agencias"
Cohesion: 0.10
Nodes (29): AgencyForm, AssignmentForm, InvitationForm, PersonForm, Agency, AgencyInvitation, AgencyMember, accept_invitation() (+21 more)

### Community 4 - "Pruebas · Publicación"
Cohesion: 0.03
Nodes (46): Migration, Migration, RuleProfile, revision_search_vector(), measured(), test_direct_child_discount_does_not_double_count_grandchildren(), test_exception_closes_event_and_restores_parent_stack(), fail() (+38 more)

### Community 40 - "Aplicación · Privacidad"
Cohesion: 0.12
Nodes (37): InvalidObject, Keyring, _aad(), _authenticate_frames(), authenticated_plaintext(), _b64(), _canonical(), decrypt() (+29 more)

### Community 41 - "Pruebas · Derechos"
Cohesion: 0.12
Nodes (36): RightsPortabilityExportJob, ids(), scope(), claim(), dispatch(), failure_location(), finish_attempt(), original_actor() (+28 more)

### Community 42 - "Pruebas · Privacidad"
Cohesion: 0.11
Nodes (34): MessageForm, ComplaintMessage, ComplaintResolution, submit(), append(), complete_read(), resolve(), ready() (+26 more)

### Community 44 - "Pruebas · Derechos"
Cohesion: 0.12
Nodes (29): ChainTicket, RightsPortabilityRead, backfill_missing(), record_tombstone(), require_runtime_chain(), _runtime_is_trusted(), validate_chain(), specs() (+21 more)

### Community 45 - "Pruebas · Capacidad"
Cohesion: 0.12
Nodes (35): Collector, _phase(), scope(), functions(), run(), test_callback_failure_preserves_domain_failure_and_teardown(), broken_clock(), test_disabled_scope_never_installs_hook() (+27 more)

### Community 46 - "Pruebas · Derechos"
Cohesion: 0.12
Nodes (35): RightsExportValidationSeal, recording(), observe(), full(), holds(), recording(), replay(), test_complete_enforced_login_validation_creates_and_replays_seal() (+27 more)

### Community 47 - "Pruebas · Promociones"
Cohesion: 0.12
Nodes (21): PromotionBumpExecution, PromotionEntitlement, PromotionOrder, PromotionOrderAudit, PromotionPaymentAttempt, PromotionPaymentEvent, PromotionBumpExecution.Meta, PromotionEntitlement.Meta (+13 more)

### Community 49 - "Herramientas · Capacidad"
Cohesion: 0.15
Nodes (16): ArchiveSink, _check(), parse_mountinfo(), tmpfs_bytes(), writable_storage(), write_artifact(), test_archive_ceiling_is_enforced_by_kernel_rlimit(), test_archive_explicit_ceiling_survives_default_changes() (+8 more)

### Community 5 - "Pruebas · Publicación"
Cohesion: 0.03
Nodes (98): AppealForm, ReviewForm, ResolutionForm, Match, MatchResolution, Photo, PhotoAppeal, PhotoRestriction (+90 more)

### Community 50 - "Pruebas · Imágenes"
Cohesion: 0.16
Nodes (20): Blob, MediaErasure, MediaErasureRecovery, RecoveryForm, queue(), recover(), erase_due_media(), erase_one() (+12 more)

### Community 51 - "Pruebas · Privacidad"
Cohesion: 0.13
Nodes (23): PurposeCalendarEvent, record(), test_mobile_calendar_follow_up_reload_and_audit(), test_actual_release_and_calendar_follow_up_observe_each_other_after_wait(), attempt(), operation(), test_changed_case_reference_after_scope_wait_is_denied(), attempt() (+15 more)

### Community 52 - "Aplicación · Privacidad"
Cohesion: 0.09
Nodes (14): CloseForm, ProposalForm, DecisionForm, ReviewForm, ScopeForm, SupplementForm, independent(), prepare() (+6 more)

### Community 53 - "Pruebas · Rectificación"
Cohesion: 0.34
Nodes (8): MediaPreparationCleanup, RightsRectificationPhotoDisposition, RightsRectificationPhotoUpload, cleanup_due_preparations(), cleanup_one(), delete_prepared(), prepare_cleanup(), retention_reason()

### Community 55 - "Pruebas · Privacidad"
Cohesion: 0.13
Nodes (24): ProcessingExecution, PurposeRestriction, execute(), test_mobile_apply_and_subject_favorites_block(), prepared(), account(), test_execution_replay_after_wait_is_unique(), attempt() (+16 more)

### Community 56 - "Pruebas · Privacidad"
Cohesion: 0.13
Nodes (30): Report, UrgentReportAlert, reconcile_urgent_report_alerts(), command(), launch(), main(), wait(), test_report_presentation_and_formal_exception_preserve_private_intake() (+22 more)

### Community 57 - "Pruebas · Derechos"
Cohesion: 0.19
Nodes (13): RightsExportDownload, Meta, RightsObjectDelivery, authorize_token(), closed_grants(), observe(), actual_read(), checked() (+5 more)

### Community 58 - "Pruebas · Privacidad"
Cohesion: 0.21
Nodes (29): ComplaintAction, act(), action(), coordinator(), prepared(), test_assignment_recovery_replay_and_private_receipt_without_clock_reset(), test_mobile_claim_recovery_reload_and_no_private_reason_in_receipt(), test_own_case_stale_version_wrong_key_and_closed_case_cannot_be_reassigned() (+21 more)

### Community 59 - "Pruebas · Privacidad"
Cohesion: 0.17
Nodes (24): PurposeReleaseProposal, PurposeRestrictionRead, current(), execute(), inspect(), locked(), permission(), propose() (+16 more)

### Community 6 - "Pruebas · Publicación"
Cohesion: 0.02
Nodes (64): Command, real_checks(), build_first_page_batch_prototype(), build_native_reference(), test_final_material_marks_restored_publication_projection_pending(), test_owned_counted_page_parity(), test_owned_dirty_population_plans(), capture() (+56 more)

### Community 60 - "Pruebas · Derechos"
Cohesion: 0.09
Nodes (39): Data, Dict, Float, Int, List, Number, Str, Tuple (+31 more)

### Community 62 - "Aplicación · Agencias"
Cohesion: 0.13
Nodes (23): AgencyAppeal, AgencyReview, ReviewForm, queue(), review(), submit(), queue(), review() (+15 more)

### Community 63 - "Aplicación · Privacidad"
Cohesion: 0.18
Nodes (9): ReportAccess, resolve_listing(), resolve_report(), act(), fresh_authority(), enqueue_outcome(), test_history_is_only_revealed_by_audited_post_and_remains_escaped(), test_keyset_history_has_no_omission_or_other_case_data() (+1 more)

### Community 64 - "Pruebas · Supresión"
Cohesion: 0.14
Nodes (29): ErasureExecution, data(), test_account_erasure_requires_related_scope_decisions(), test_account_erasure_revokes_access_preserves_audit_and_replays(), test_inflight_account_token_cannot_reactivate_erased_account(), callback(), waiting_lock(), test_new_other_responsibility_invalidates_account_plan() (+21 more)

### Community 65 - "Pruebas · Publicación"
Cohesion: 0.16
Nodes (33): Rollback, assert_equivalent(), assert_marks(), assert_state_current(), dirty_ids(), drain(), native(), published() (+25 more)

### Community 652 - "Aplicación · Perfil beta"
Cohesion: 0.00
Nodes (1033): Command, AcceptanceForm, EmailForm, LoginForm, ResetForm, SignupForm, InventoryUnavailable, Command (+1025 more)

### Community 654 - "Aplicación · Perfil beta"
Cohesion: 0.30
Nodes (6): CapacityPhaseWriter, decode_phase(), validate_phase(), test_atomic_signal_retains_all_boundaries(), test_existing_signal_never_overwritten(), test_invalid_signal_rejected()

### Community 66 - "Pruebas · Cuentas"
Cohesion: 0.22
Nodes (15): RightsAccountEmailConfirmation, RightsRectificationExecution, purge_expired_delivery(), inspect(), test_localized_destination_confirmation_preserves_token_and_account(), execution_ready(), test_email_and_listing_correction_share_atomic_execution(), test_email_reserved_during_unique_index_wait_rolls_back_entire_execution() (+7 more)

### Community 68 - "Aplicación · Privacidad"
Cohesion: 0.16
Nodes (18): AccessForm, ActionForm, ComplaintForm, ResolutionForm, action(), inspect(), photo(), queue() (+10 more)

### Community 694 - "Aplicación · Perfil beta"
Cohesion: 0.11
Nodes (24): CapacityContainerPending, CapacityResourceObserver, CapacityResourceReader, check(), verify_capacity_identity(), inspection(), test_cgroup_must_match_full_container_id(), test_created_container_is_pending_only_with_exact_owned_metadata() (+16 more)

### Community 7 - "Pruebas · Publicación"
Cohesion: 0.04
Nodes (21): LegalAcceptance, prepare_static_structures(), rejected(), test_mobile_submission_declaration_and_pending_reload(), test_periodic_expiry_preserves_unexpired_and_paused_and_is_idempotent(), decision(), pending(), test_approval_exposes_exact_revision_and_only_derivative() (+13 more)

### Community 706 - "Aplicación · Perfil beta"
Cohesion: 0.35
Nodes (6): NoRedirect, test_policy_checked_real_http100(), capture(), http_get(), observe_handler(), observed()

### Community 71 - "Pruebas · Rectificación"
Cohesion: 0.18
Nodes (12): PhoneClaim, RightsRectificationNotification, RightsRectificationRecipientReview, normalize_phone(), binding(), claim(), display(), source() (+4 more)

### Community 717 - "Aplicación · Perfil beta"
Cohesion: 0.49
Nodes (8): UploadForm, baseline(), check_actor(), check_current(), discard(), eligible(), prepare(), upload()

### Community 725 - "Aplicación · Perfil beta"
Cohesion: 0.67
Nodes (4): ExecutionForm, apply(), current_erasure_actor(), execute()

### Community 73 - "Pruebas · Promociones"
Cohesion: 0.24
Nodes (26): PromotionCatalogueAudit, PromotionProduct, audit(), authority(), create_product(), create_version(), draft(), fresh_actor() (+18 more)

### Community 733 - "Aplicación · Perfil beta"
Cohesion: 0.23
Nodes (11): AccessForm, DecisionForm, ReportForm, queue_reports(), decision(), inspect(), permitted(), private() (+3 more)

### Community 74 - "Aplicación · Supresión"
Cohesion: 0.28
Nodes (7): PhoneChallenge, RepresentationInvitation, capture(), finalized(), ids(), validate_empty_replacement(), validate_ownership()

### Community 743 - "Aplicación · Perfil beta"
Cohesion: 0.29
Nodes (4): CopyPresentationForm, ExportForm, PageReviewForm, ReviewedCopyField

### Community 747 - "Aplicación · Perfil beta"
Cohesion: 0.20
Nodes (17): CodeForm, ConsentForm, ConsentInviteForm, PhoneForm, SimulationForm, TransferForm, accept_consent(), age() (+9 more)

### Community 78 - "Pruebas · Cuentas"
Cohesion: 0.28
Nodes (6): VerificationEvent, publication_ready(), receive_event(), simulate_event(), start_age_check(), test_localized_age_simulator_preserves_explicit_scope_and_current_events()

### Community 79 - "Aplicación · Privacidad"
Cohesion: 0.18
Nodes (18): RightsRecipientNotice, acknowledge(), approved(), authorized_targets(), checked_ack(), checked_delivery(), deliver(), delivery_evidence() (+10 more)

### Community 8 - "Pruebas · Derechos"
Cohesion: 0.04
Nodes (83): User, RightsNotice, RightsPortabilityClosure, RightsPortabilityResponseDraft, RightsPortabilityResponseReview, RightsResponse, RightsWithdrawal, prepare() (+75 more)

### Community 83 - "Pruebas · Capacidad"
Cohesion: 0.18
Nodes (23): BaselineCleanupError, _admin(), _adopt(), capture(), codec(), _create_database(), _create_login(), _drop_login() (+15 more)

### Community 84 - "Pruebas · Derechos"
Cohesion: 0.15
Nodes (26): Discard, test_discovery_gc_profile_10000(), active_rules(), get(), initialized(), encoded(), outcome(), test_codec_exact_negative_class_message_order_and_atomic_read_output() (+18 more)

### Community 85 - "Pruebas · Privacidad"
Cohesion: 0.16
Nodes (21): Complaint, ComplaintAccess, Client, test_audited_access_localization_preserves_private_post_read(), test_private_clarification_localized_without_changing_capability_contract(), moderator(), payload(), test_actor_replay_foreign_receipt_and_escaped_reference_do_not_confer_access() (+13 more)

### Community 87 - "Aplicación · Derechos"
Cohesion: 0.16
Nodes (18): _ResultCursor, _sealed_or_full(), _annotated(), caller_digest(), _caller_values(), value(), _code_version(), create() (+10 more)

### Community 89 - "Aplicación · Publicación"
Cohesion: 0.24
Nodes (11): ReviewForm, ReviewForm, ManagerAppeal, ManagerReview, queue(), review(), submit(), queue() (+3 more)

### Community 9 - "Pruebas · Agencias"
Cohesion: 0.05
Nodes (53): DetailSeed, build_detail_context_prototype(), patch_detail_view(), visit(), build_generic_reader(), read(), build_scoped_generic_context(), context() (+45 more)

### Community 91 - "Aplicación · Rectificación"
Cohesion: 0.17
Nodes (11): ProposalForm, prepare(), changes(), display(), source(), validate(), preview(), propose() (+3 more)

### Community 92 - "Aplicación · Portabilidad"
Cohesion: 0.11
Nodes (12): LocalizedForm, ResetForm, ReviewForm, DatasetForm, DraftForm, ReadForm, review(), fact() (+4 more)

### Community 93 - "Pruebas · Capacidad"
Cohesion: 0.14
Nodes (12): PrivateDeliveryRedirect, PrivateProxyTransport, SourceHTTPHandler, _grant_digest(), _signed_url(), open_client(), operator(), post() (+4 more)

### Community 95 - "Pruebas · Derechos"
Cohesion: 0.16
Nodes (23): RightsPortabilityImageRead, required_reads(), duplicate(), prepared(), test_bulk_exact_scope_and_ids_are_not_widened(), test_bulk_lookup_one_query_preserves_decision_order_and_all_signatures(), observe(), test_bulk_newest_corrupt_read_never_falls_back_but_exact_ids_keep_original() (+15 more)

### Community 96 - "Pruebas · Rectificación"
Cohesion: 0.37
Nodes (10): RightsRectificationProposal, source(), source(), add_source_photo(), test_eight_source_photos_are_editable_and_valid(), test_photo_bytes_require_current_private_audit_and_scope(), test_photo_selection_form_rejects_other_sources_and_persists_order(), test_photo_selection_rejects_removed_unavailable_and_historical_rows() (+2 more)

### Community 98 - "Aplicación · Privacidad"
Cohesion: 0.11
Nodes (11): FieldForm, InformationForm, ReadForm, ReviewForm, prepare(), review(), initial_fields(), prepare_captions() (+3 more)

### Community 183 - "Aplicación · Privacidad"
Cohesion: 0.31
Nodes (6): add(), index(), remove(), blocked_response(), require_unrestricted(), restricted()

### Community 54 - "Aplicación"
Cohesion: 0.11
Nodes (16): directory(), index(), listings(), robots(), health(), home(), add_urls(), candidates() (+8 more)

### Community 94 - "Aplicación · Privacidad"
Cohesion: 0.18
Nodes (16): communications(), notice_payload(), manager_evidence(), backend(), current(), final_material(), inspect(), inspect_source() (+8 more)

### Community 10 - "Pruebas · Derechos"
Cohesion: 0.05
Nodes (72): build_census(), capture_census(), producer_records(), reviewed_content_census(), scope_dependencies(), associated_content_records(), await_external_review(), capture_content() (+64 more)

### Community 104 - "Pruebas · Capacidad"
Cohesion: 0.15
Nodes (9): capture(), bind_backend(), sample(), statements(), test_owned_complete_target_delivery(), worker(), test_observed_exit_rejects_live_process_and_unreaped_zombie(), test_observed_exit_waits_for_reaper() (+1 more)

### Community 105 - "Pruebas"
Cohesion: 0.20
Nodes (23): artifact(), child(), rejected(), test_absent_build_uses_reference(), test_changed_binary_at_same_path_is_rejected(), test_concurrent_load_is_single_and_sealed(), test_duplicate_manifest_fields_are_rejected(), test_failed_initialization_never_retries_or_reuses_an_old_mapping() (+15 more)

### Community 108 - "Pruebas · Capacidad"
Cohesion: 0.19
Nodes (17): pointer_value(), benchmark(), counted_leaves(), wrapper(), observed(), wrapper(), scope(), source_census() (+9 more)

### Community 112 - "Pruebas"
Cohesion: 0.15
Nodes (19): require_diagnostic(), baseline_modules(), test_aead_roundtrip_preserves_original_expiry_and_authenticated_end(), test_baseline_index_stream_is_bounded_and_ordered(), test_baseline_rejects_acceptance_before_resources(), test_capture_archive_expanded_count_remains_finite_and_normal_default(), test_controller_error_scrubs_timeout_command_secrets(), test_dependency_identity_binds_lock_versions_and_python() (+11 more)

### Community 113 - "Aplicación · Promociones"
Cohesion: 0.19
Nodes (10): bump_promotions(), can_manage_person(), test_observed_person_wait_prevents_bump_after_eligibility_revocation(), execute(), test_two_concurrent_bumps_grant_one_window_only(), execute(), purchased(), test_bump_window_quota_replay_and_editorial_state_preserved() (+2 more)

### Community 120 - "Pruebas · Portabilidad"
Cohesion: 0.15
Nodes (15): integer(), main(), reconstruct(), test_owned_small_case_instrumentation(), diagnosed(), sql_observed(), test_native_closed_selected_json_over_local_tcp(), counted() (+7 more)

### Community 121 - "Pruebas · Portabilidad"
Cohesion: 0.29
Nodes (18): message(), test_audited_subject_snapshot_includes_only_profile_history_and_cannot_claim_complete(), test_encrypted_history_reader_binds_source_cutoff_and_preserves_partial(), test_exact_owned_historical_messages_exclude_foreign_database_queue_and_capabilities(), test_unknown_or_large_scoped_messages_stay_blocked(), inspect(), periodic_message(), result() (+10 more)

### Community 122 - "Pruebas · Cuentas"
Cohesion: 0.26
Nodes (18): email_path(), legal_docs(), registration(), test_concurrent_signup_email_unicity(), signup_thread(), test_concurrent_token_consumption(), consume(), test_csrf_throttle_and_token_headers() (+10 more)

### Community 123 - "Pruebas · Recuperación"
Cohesion: 0.22
Nodes (14): catalog(), enroll(), test_agency_quota_counts_unapproved_current_manager_and_owner_scope(), test_agency_requires_mfa_and_cannot_assign_outside_member(), test_concurrent_recovery_code_one_use(), consume(), test_mfa_enrollment_replay_and_recovery(), test_two_models_editor_scope_and_revocation() (+6 more)

### Community 124 - "Pruebas · Derechos"
Cohesion: 0.22
Nodes (12): canonical(), canonical_bytes(), content_reference(), reference_check(), test_action_fingerprint_still_keyed_and_distinct_from_content(), test_canonical_utf8_bytes_keep_the_keyed_fingerprint(), test_content_reference_binds_dataset_position_and_entire_row(), test_non_json_types_require_explicit_conversion() (+4 more)

### Community 125 - "Aplicación · Recuperación"
Cohesion: 0.12
Nodes (8): database_probe(), main(), beat_probe_queue(), test_actual_beat_removes_prior_schedule_during_recovery(), published(), test_actual_worker_ignores_recovery_and_executes_normal_probe(), wait_for(), config.celery.app.task

### Community 126 - "Pruebas · Capacidad"
Cohesion: 0.21
Nodes (11): binding(), prepare(), read(), calibrated_rows(), candidate(), revision_values(), test_materialized_manifest_existing_consumer_cost_gate(), test_page_manifest_full_physical_content_cost_gate() (+3 more)

### Community 127 - "Pruebas · Capacidad"
Cohesion: 0.21
Nodes (16): context_observed(), measured(), iterated(), measured(), observe(), measured(), profile_report(), scope() (+8 more)

### Community 128 - "Pruebas · Supresión"
Cohesion: 0.19
Nodes (15): material(), test_final_account_erasure_uses_original_proof_after_execution(), test_final_draft_requires_independent_read_and_current_execution(), test_final_http_issues_partial_response_once_with_private_receipt(), concurrent_issue(), test_final_material_preserves_pending_and_detects_reintroduced_credentials(), test_final_material_rejects_foreign_receipt_and_modified_plan(), test_final_media_requires_actual_file_absence_even_after_completed_job() (+7 more)

### Community 130 - "Herramientas · Cuentas"
Cohesion: 0.31
Nodes (10): counts(), distribution(), review(), run_open_loop(), worker(), population(), test_error_latency_and_pending_are_not_hidden_by_success_population(), test_fixed_drain_classifies_pending_and_late_response_cannot_rewrite_snapshot() (+2 more)

### Community 131 - "Pruebas · Cuentas"
Cohesion: 0.20
Nodes (15): observed_transport(), factory(), pytest_collection_modifyitems(), pytest_runtest_setup(), observed(), pytest_runtest_teardown(), execute(), scenario() (+7 more)

### Community 133 - "Pruebas"
Cohesion: 0.16
Nodes (14): query_pattern(), test_discovery_cost_checkpoint(), context_init(), from_db(), initialized(), instrument_form_method(), measured(), iterator() (+6 more)

### Community 136 - "Pruebas · Privacidad"
Cohesion: 0.30
Nodes (14): load_json(), periodic_tasks(), project_message(), unique_object(), validate_envelope(), message(), test_duplicate_json_keys_are_not_silently_discarded(), test_excessive_json_nesting_becomes_typed_rejection() (+6 more)

### Community 140 - "Herramientas"
Cohesion: 0.19
Nodes (10): main(), notify(), pytest_sessionfinish(), pytest_sessionstart(), test_failed_delivery_keeps_test_result_and_redacts_provider_diagnostics(), fail(), test_notification_uses_openclaw_without_exposing_credentials(), run() (+2 more)

### Community 144 - "Pruebas"
Cohesion: 0.20
Nodes (8): assert_execution(), assert_preparation(), assert_review(), choices(), labels(), test_execution_scope_choices_preserved(), test_mobile_processing_preparation(), test_mobile_independent_plan_review()

### Community 145 - "Pruebas · Derechos"
Cohesion: 0.25
Nodes (16): _source_rows(), _source_rows_pipeline(), _source_rows_serial(), _source_statements(), test_alternating_source_transport_measurement(), test_autocommit_validation_keeps_head_lock_until_source_validation(), inspect_locked_source(), test_committed_change_between_queries_visible_in_later_snapshot() (+8 more)

### Community 146 - "Aplicación · Derechos"
Cohesion: 0.26
Nodes (10): scope_matches(), source(), agency_relationships(), contact_data(), date(), image_inventory(), legal_acceptances(), personal_contacts() (+2 more)

### Community 149 - "Herramientas"
Cohesion: 0.24
Nodes (12): inspect_origin(), identity(), inventory_log_captures(), log_capture_references(), visit(), main(), capture_declaration(), test_capture_metadata_does_not_admit_content_or_ambiguous_declarations() (+4 more)

### Community 150 - "Pruebas · Derechos"
Cohesion: 0.21
Nodes (12): run(), explain(), scrub(), shape(), statements(), test_bulk_all_families_events_and_tombstone_equal_producers(), test_bulk_detects_owner_changes_and_missing_rows_with_same_head(), test_bulk_invoker_properties_and_foreign_case_exclusion() (+4 more)

### Community 151 - "Pruebas · Cifrado"
Cohesion: 0.23
Nodes (16): configured(), test_native_fallback_always_constructs_fresh_session(), client(), close(), __init__(), test_original_settings_key_and_config_errors_precede_session_construction(), failed_config(), __getattr__() (+8 more)

### Community 153 - "Aplicación · Rectificación"
Cohesion: 0.50
Nodes (4): assert_form(), test_display_preserves_data_native_validation_and_unknown_raw_values(), test_review_error_audit_raw_value_and_revoked_permission(), snapshot()

### Community 154 - "Herramientas · Cifrado"
Cohesion: 0.20
Nodes (11): decode(), encode(), record(), importable_header(), _json(), key(), metadata(), records() (+3 more)

### Community 157 - "Pruebas · Capacidad"
Cohesion: 0.20
Nodes (10): candidate_functions(), __init__(), source_statements(), visit_Name(), scope(), application(), start(), test_all_families_and_tombstone_equal_producer() (+2 more)

### Community 158 - "Pruebas · Capacidad"
Cohesion: 0.18
Nodes (10): coverage_batches(), error_html(), handle_data(), handle_endtag(), handle_starttag(), __init__(), queued_generation(), remaining_timeout() (+2 more)

### Community 162 - "Pruebas · Derechos"
Cohesion: 0.33
Nodes (14): _pipeline_connection(), _replay(), _replay_serial(), native_pipeline(), test_existing_native_pipeline_is_not_nested_and_remains_operational(), test_native_pipeline_matches_ordered_typed_and_empty_hashes(), test_pipeline_keeps_read_committed_statement_snapshots_after_real_lock_wait(), reader() (+6 more)

### Community 163 - "Herramientas"
Cohesion: 0.22
Nodes (8): post_worker_init(), parse_service_samples(), worker_exit(), test_ingress_composes_product_startup_before_observer(), prepare(), test_ingress_hook_avoids_eager_handlers_and_restores_callback_resources(), guarded(), test_service_ledger_preserves_ids_and_rejects_duplicates_nonfinite_without_paths()

### Community 165 - "Pruebas · Imágenes"
Cohesion: 0.24
Nodes (12): test_occupied_database_falls_back_to_real_seed_without_terminating(), seed(), test_preexisting_test_setup_is_preserved_instead_of_restoring(), test_seed_password_changes_cache_identity_without_exposing_password(), test_snapshot_container_identity_is_cached_only_for_same_worker_and_port(), inspect(), test_snapshot_falls_back_without_ci_optin(), test_snapshot_refuses_container_label_or_port_mismatch() (+4 more)

### Community 167 - "Aplicación · Derechos"
Cohesion: 0.29
Nodes (8): _binding(), _directory(), invalidate_restored_deliveries(), _path(), proxy_or_direct(), purge_export_deliveries(), purge_object_deliveries(), stage_delivery()

### Community 171 - "Pruebas · Imágenes"
Cohesion: 0.21
Nodes (13): test_actual_original_approval_roundtrip_and_config_rejection(), ambiguous_create(), ambiguous_login(), checked_login(), disk_full(), expired_proof(), fail_copy(), refused_cleanup() (+5 more)

### Community 177 - "Pruebas · Privacidad"
Cohesion: 0.29
Nodes (10): inspect_aof(), line(), test_argument_limits_reject_before_reading_body(), test_deleted_values_remain_historical_without_parameter_disclosure(), test_large_retained_arguments_are_drained_without_materializing_values(), read(), test_short_reads_and_missing_crlf_are_handled_safely(), read() (+2 more)

### Community 179 - "Contrato · Promociones"
Cohesion: 0.29
Nodes (4): main(), unrelated_task_log(), test_any_other_tracked_change_blocks_even_with_ledger(), test_independent_task_ledger_is_hashed_without_mutating_it()

### Community 180 - "Pruebas · Capacidad"
Cohesion: 0.31
Nodes (8): aggregate(), fingerprint_profile(), private_credentials(), scrub(), test_fingerprint_diagnostic_flags_and_secret_scrubbing(), test_fingerprint_private_config_guards(), test_normal_or_acceptance_mode_is_rejected_before_credentials_or_connect(), forbidden()

### Community 184 - "Pruebas · Publicación"
Cohesion: 0.33
Nodes (5): independent_legacy_flag(), test_nested_committed_writes_schedule_one_refresh(), test_rollback_does_not_suppress_later_committed_refresh(), rolled_back(), test_rolled_back_savepoint_preserves_outer_refresh()

### Community 187 - "Pruebas · Publicación"
Cohesion: 0.46
Nodes (11): execute(), confirm(), fresh(), plan(), prepared(), test_concurrent_release_replay_executes_one_action(), run(), test_fresh_check_started_before_acknowledgement_is_insufficient() (+3 more)

### Community 189 - "Pruebas · Derechos"
Cohesion: 0.30
Nodes (11): images(), test_bulk_fresh_metadata_is_three_queries_and_preserves_single_bytes(), test_bulk_rejects_mapping_changed_during_actual_blob_lock_wait(), reader(), test_physical_bytes_changed_between_children_roll_back_all_batch_audits(), page(), read(), test_reverse_bulk_and_single_readers_complete_with_real_pg_locks() (+3 more)

### Community 190 - "Herramientas"
Cohesion: 0.32
Nodes (7): file_costs(), order_items(), pytest_addoption(), pytest_collection_modifyitems(), test_direct_cli_validates_history_before_creating_resources(), test_invalid_duration_cannot_silently_change_scheduling(), test_long_single_case_file_precedes_many_short_cases_without_losing_local_order()

### Community 192 - "Pruebas · Portabilidad"
Cohesion: 0.22
Nodes (12): test_binary_page_save_keeps_one_copy_and_fresh_versions_preserving_native_choices(), checked_versions(), counted(), unshared(), test_binary_save_rechecks_late_changes_after_final_snapshot_and_rolls_back(), changed(), test_binary_save_rejects_audit_removed_during_real_byte_read_and_rolls_back(), removed_during_read() (+4 more)

### Community 194 - "Pruebas"
Cohesion: 0.18
Nodes (8): authenticated_context(), test_localized_appeal_and_independent_review_preserve_authority_and_state(), test_shared_appeal_consumers_receive_request_language(), test_appeal_private_idempotent_and_independent_review(), test_concurrent_appeal_resolutions_keep_one_result(), resolve(), test_invalid_appeal_and_obsolete_manager_cannot_reopen(), test_reconsideration_respects_current_rejection_and_pending_quota()

### Community 196 - "Pruebas · Derechos"
Cohesion: 0.34
Nodes (7): archive(), packages(), test_archive_consumes_single_pass_images_without_changing_zip_bytes(), test_default_grouping_targets_eight_mib_and_preserves_larger_individual_images(), test_packages_fit_actual_zip_size_without_losing_or_duplicating_content(), test_single_attachment_over_limit_and_duplicate_rejected(), test_unsafe_or_oversized_snapshot_is_rejected()

### Community 201 - "Herramientas"
Cohesion: 0.29
Nodes (8): install_admission_hooks(), enqueue(), handle(), init(), write(), post_worker_init(), post_worker_init(), response()

### Community 204 - "Pruebas · Capacidad"
Cohesion: 0.29
Nodes (9): modules(), test_invalid_launcher_flags_stop_before_output_or_docker(), test_native_profiler_cannot_enter_acceptance_or_preflight(), test_normal_and_recovery_inventory_names_all_own_resources(), test_preflight_and_object_writer_cannot_bypass_owned_mode(), test_preflight_is_explicit_same_whole_budget_and_has_no_workload(), test_preflight_rejects_every_load_and_instrumentation_flag(), test_recovery_removes_proxy_objects_and_shared_volume_and_detects_leftover() (+1 more)

### Community 205 - "Pruebas"
Cohesion: 0.41
Nodes (10): backdrop(), collect(), luminance(), measured(), over(), ratio(), rgba(), test_contrast_reference_pairs_and_alpha() (+2 more)

### Community 206 - "Pruebas · Derechos"
Cohesion: 0.34
Nodes (9): create_image_copy(), selection(), test_expired_export_purges_image_snapshots_and_mismatch_attachment_is_rejected(), test_mobile_review_select_generate_and_private_image_download(), test_reviewed_image_snapshot_is_encrypted_private_and_download_audited(), test_selected_image_needs_current_audited_bytes_and_foreign_photos_are_inaccessible(), test_generation_over_64mib_delivers_every_reviewed_image_in_bounded_parts(), test_mobile_anonymous_reviewed_package_download() (+1 more)

### Community 208 - "Pruebas · Privacidad"
Cohesion: 0.40
Nodes (8): targets(), validate_decisions(), test_previous_manager_is_reviewed_candidate_but_not_authorized_delivery(), with_retained_history(), decisions(), fixture_data(), test_communication_requires_matching_recorded_receipt_not_free_text(), test_every_candidate_and_gap_needs_reason_and_evidence()

### Community 209 - "Pruebas · Privacidad"
Cohesion: 0.27
Nodes (5): broker_records(), test_refresh_accumulation_blocks_bounded_inventory(), test_next_case_isolated_without_deleting_previous_backlog(), test_previous_case_can_leave_a_real_backlog(), test_subprocess_inherits_current_case_generation()

### Community 210 - "Herramientas"
Cohesion: 0.37
Nodes (7): anchors(), check(), retired_source(), destination(), links(), main(), markdown_text()

### Community 212 - "Pruebas · Cuentas"
Cohesion: 0.28
Nodes (5): replace_terms(), test_localized_acceptance_preserves_stale_version_and_missing_document_gates(), test_signup_localized_document_gates_email_token_and_account_limits(), fill(), submit()

### Community 213 - "Pruebas"
Cohesion: 0.21
Nodes (7): test_mobile_photo_appeal_submission_and_independent_reopening(), independent_reviewer(), photo_case(), test_concurrent_photo_appeal_resolution_reopens_once(), resolve(), test_photo_appeal_cannot_reopen_superseded_decision(), test_qualified_moderator_with_own_person_cannot_resolve_photo_appeal()

### Community 214 - "Pruebas · Derechos"
Cohesion: 0.27
Nodes (8): state(), rows_fingerprint(), test_changed_versions_with_identical_content_fall_back_to_full_comparison(), test_drift_or_projection_mutation_rejected_and_context_reset(), test_exception_resets_context_without_turning_failure_into_success(), test_no_transaction_or_forged_context_rejected(), test_reuse_fresh_exit_and_expired_context(), test_wrong_scope_and_cross_thread_context_denied()

### Community 215 - "Pruebas · Derechos"
Cohesion: 0.45
Nodes (9): login(), test_actual_login_checks_nine_queries_each_time_without_cached_trust(), test_direct_owner_or_missing_table_is_not_trusted(), test_extra_trigger_is_accepted_and_id_only_update_remains_allowed(), test_grant_between_actual_login_checks_is_rejected(), test_owner_membership_is_observed_after_column_phase_in_the_same_call(), grant_after_columns(), test_trigger_change_between_actual_login_checks_is_rejected() (+1 more)

### Community 216 - "Pruebas"
Cohesion: 0.33
Nodes (7): documents(), public_client(), test_browser_follows_sitemap_to_public_page_and_observes_retirement(), retire(), test_robots_policy_branches_and_empty_sitemap(), test_sitemap_languages_privacy_page_boundaries_and_withdrawal(), urls()

### Community 22 - "Pruebas · Portabilidad"
Cohesion: 0.06
Nodes (54): compile_coverage(), exclusion(), checked_images(), _scalar_paths(), _validate_decision(), pure_benchmark(), original(), paths() (+46 more)

### Community 221 - "Pruebas"
Cohesion: 0.26
Nodes (5): post_worker_init(), test_default_gunicorn_hook_runs_preparation_and_propagates_failure(), failure(), test_static_preparation_has_no_network_database_or_language_side_effects(), forbidden()

### Community 222 - "Pruebas · Capacidad"
Cohesion: 0.27
Nodes (3): test_owned_professional_probe(), test_owned_context_rejects_unverified_alias_before_provision(), test_owned_runtime_child_login_acl_optin_and_private_cleanup()

### Community 223 - "Pruebas · Capacidad"
Cohesion: 0.44
Nodes (6): gate(), quantile(), samples(), test_drift_and_spread_rejected(), test_exact_sample_budget(), test_linear_quantiles_and_stable_control()

### Community 224 - "Pruebas · Capacidad"
Cohesion: 0.39
Nodes (8): measured(), wrapped(), scope(), test_preserves_return_and_exception_without_scope(), fail(), test_records_only_counts_and_exclusive_nested_spans(), test_scope_restores_driver_pipeline_and_phase_after_exception(), fail()

### Community 225 - "Pruebas · Portabilidad"
Cohesion: 0.32
Nodes (4): catalog_captions(), declaration_captions(), test_coverage_defaults_lazy_paths_and_exclusion(), test_mobile_guided_coverage_save_and_clean_get()

### Community 226 - "Pruebas"
Cohesion: 0.30
Nodes (10): test_owned_wsgi_close_release(), call(), start_response(), inspect_cycles(), render_with_release(), release(), residual_path(), label() (+2 more)

### Community 227 - "Pruebas"
Cohesion: 0.30
Nodes (10): test_owned_wsgi_context_release(), call(), start_response(), inspect_cycles(), render_with_release(), release(), residual_path(), label() (+2 more)

### Community 228 - "Pruebas · Retención"
Cohesion: 0.30
Nodes (10): test_owned_wsgi_incoming_retention(), call(), start_response(), inspect_cycles(), render_with_release(), release(), residual_path(), label() (+2 more)

### Community 229 - "Pruebas · Publicación"
Cohesion: 0.32
Nodes (10): owner_client(), pending_update(), test_approval_race_cannot_republish_held_profile(), apply_hold(), approve(), test_ground_and_proof_scope_are_checked_and_case_stays_open(), test_hold_removes_exposure_and_blocks_forced_status_and_manager_lifecycle(), test_mobile_hold_persists_after_reload_without_closing_request() (+2 more)

### Community 233 - "Pruebas · Capacidad"
Cohesion: 0.44
Nodes (7): sampled(), response(), test_native_controller_timing_does_not_install_cprofile(), operation(), test_post_validation_profile_is_exclusively_legacy_diagnostic(), test_private_download_requires_redirect_eof_and_privacy(), test_proxy_client_allows_ordinary_save_without_delivery_redirect()

### Community 235 - "Pruebas · Portabilidad"
Cohesion: 0.35
Nodes (8): test_native_closed_binary_delivery_over_local_tcp(), counted(), measured(), call(), post(), ready_with_binary(), rss(), sample()

### Community 236 - "Pruebas"
Cohesion: 0.36
Nodes (7): test_report_decision_rechecks_revocation_after_scoped_locks(), after_outbox(), revoke(), test_urgent_owner_revocation_escalates_to_authorized_substitute(), followed(), mark(), operate()

### Community 238 - "Herramientas · Capacidad"
Cohesion: 0.27
Nodes (9): _dirty_snapshot(), _postrun(), _prerun(), _published(), _write(), connect(), celery.signals.task_postrun.connect, celery.signals.task_prerun.connect (+1 more)

### Community 240 - "Herramientas · Cuentas"
Cohesion: 0.51
Nodes (7): command(), fixture(), action(), launch(), main(), state(), wait()

### Community 241 - "Herramientas · Retención"
Cohesion: 0.49
Nodes (7): command(), fixture(), action(), launch(), wait(), main(), state()

### Community 242 - "Pruebas · Capacidad"
Cohesion: 0.38
Nodes (7): test_admission_hooks_preserve_native_results_and_isolate_thread_contexts(), handle(), __init__(), invoke(), write(), test_native_handler_exception_resets_admission_context(), native()

### Community 243 - "Pruebas"
Cohesion: 0.31
Nodes (6): test_owned_request_aa_attribution(), observed(), gc_event(), sql(), test_owned_request_aa_stability(), counted()

### Community 244 - "Pruebas · Portabilidad"
Cohesion: 0.42
Nodes (8): test_large_history_native_approval_closure_and_binary_delivery(), measured(), run(), counter(), ready(), rss(), sample(), save_progress()

### Community 245 - "Pruebas · Publicación"
Cohesion: 0.42
Nodes (6): localized_release_labels(), test_localized_mobile_execute_received_proposal(), mobile(), test_localized_mobile_proposal_and_public_receipt(), confirm(), propose()

### Community 249 - "Aplicación · Privacidad"
Cohesion: 0.43
Nodes (3): current_case_paths(), source(), capture()

### Community 251 - "Herramientas"
Cohesion: 0.39
Nodes (5): pytest_addoption(), pytest_collection_finish(), pytest_collectreport(), pytest_configure(), pytest_sessionfinish()

### Community 252 - "Herramientas · Cuentas"
Cohesion: 0.58
Nodes (6): command(), fixture(), launch(), main(), state(), wait()

### Community 253 - "Herramientas · Retención"
Cohesion: 0.56
Nodes (6): command(), fixture(), launch(), wait(), main(), state()

### Community 255 - "Pruebas · Capacidad"
Cohesion: 0.36
Nodes (7): test_cursor_forwards_and_reports_only_numeric_event_rows(), __enter__(), execute(), __exit__(), fetchall(), test_wrapper_preserves_return_and_exception_without_scope(), failure()

### Community 256 - "Pruebas · Capacidad"
Cohesion: 0.33
Nodes (6): test_professional_argv_keeps_measure_clean(), test_professional_flow_excludes_legacy_profiles(), forbidden(), test_professional_parser_rejects_mixed_native(), test_professional_sampling_stops_after_invalid_capture(), post()

### Community 257 - "Pruebas"
Cohesion: 0.36
Nodes (6): test_discovery_materialization_and_explicit_stage_times(), context_init(), initialized(), render(), sql_timer(), validate()

### Community 258 - "Pruebas"
Cohesion: 0.53
Nodes (5): browser(), check_error_focus(), test_private_native_conflict_focus(), counts(), test_public_field_and_nonfield_error_focus()

### Community 259 - "Pruebas"
Cohesion: 0.39
Nodes (7): canonical_body(), test_prepared_detail_guard_parity_freshness_and_callsite_scope(), binding(), compare(), direct(), guard(), observe()

### Community 260 - "Pruebas · Publicación"
Cohesion: 0.42
Nodes (5): test_mobile_execute_received_proposal(), mobile(), test_mobile_proposal_and_public_receipt(), confirm(), propose()

### Community 261 - "Pruebas · Derechos"
Cohesion: 0.53
Nodes (6): fixture(), test_every_field_and_unprojected_boundary_is_accounted_without_authorizing(), test_incomplete_or_conflicting_accounting_is_rejected(), test_injected_empty_container_cannot_escape_scalar_accounting(), test_old_delivery_digest_rejected_even_when_new_rows_could_be_accounted(), test_redaction_requires_motivated_exact_field_decision()

### Community 267 - "Herramientas"
Cohesion: 0.50
Nodes (3): build(), git(), main()

### Community 269 - "Pruebas · Cuentas"
Cohesion: 0.46
Nodes (5): test_account_final_rectification_concurrent_close(), test_account_final_rectification_review_and_atomic_close(), test_account_recipient_flow_does_not_require_or_modify_owned_agency_profiles(), test_account_without_profile_review_receive_and_execute(), concurrently_close()

### Community 270 - "Pruebas · Cuentas"
Cohesion: 0.46
Nodes (4): delivered_account(), test_account_recipient_rechecks_after_observed_account_wait(), attempt(), forbidden_decrypt()

### Community 271 - "Pruebas · Capacidad"
Cohesion: 0.50
Nodes (6): test_constructor_original_vs_deferred_postgres_rows(), captured(), record(), consume(), experiment(), no_sql()

### Community 272 - "Pruebas"
Cohesion: 0.43
Nodes (6): test_owned_wsgi_object_lifetime(), call(), start_response(), inspect_cycles(), tracked(), typename()

### Community 273 - "Pruebas"
Cohesion: 0.43
Nodes (6): test_owned_wsgi_release_roi(), call(), start_response(), candidate_render(), release(), counted()

### Community 274 - "Pruebas"
Cohesion: 0.54
Nodes (4): snapshot(), test_private_reflow_content_controls_and_native_conflict(), counts(), test_public_reflow_and_keyboard_errors()

### Community 275 - "Pruebas · Portabilidad"
Cohesion: 0.57
Nodes (5): inputs(), test_implicit_containers_invalid_paths_and_duplicates_are_rejected(), test_mixed_fields_require_exact_eligible_evidence_and_never_export_it(), test_pending_dataset_cannot_be_selected(), test_selected_fields_omit_all_other_values_and_reject_changed_source()

### Community 277 - "Herramientas"
Cohesion: 0.62
Nodes (3): alive(), main(), process_start_ticks()

### Community 279 - "Pruebas · Capacidad"
Cohesion: 0.48
Nodes (3): test_original_response_is_closed_once(), close(), __iter__()

### Community 28 - "Pruebas · Capacidad"
Cohesion: 0.07
Nodes (61): scope(), modules(), test_default_missing_modules_report_missing_required_phases(), test_detail_generator_is_omitted_without_wrapping_image_contents(), image_contents(), test_disabled_no_install_or_sql_provider(), forbidden(), original() (+53 more)

### Community 280 - "Pruebas · Capacidad"
Cohesion: 0.48
Nodes (3): test_original_response_is_closed_once(), close(), __iter__()

### Community 281 - "Pruebas · Publicación"
Cohesion: 0.48
Nodes (4): test_mobile_queue_and_publication_inspection(), inspection_count(), count(), with_mobile()

### Community 282 - "Pruebas · Derechos"
Cohesion: 0.52
Nodes (3): database_value(), run(), test_mobile_generate_pages_with_approved_information()

### Community 283 - "Pruebas · Derechos"
Cohesion: 0.52
Nodes (6): approved(), test_concurrent_exact_withdrawal_only_mutates_once(), withdraw(), test_execution_permission_current_read_and_proof_required(), test_mobile_reviewer_withdraws_scoped_anonymous_representation(), test_no_account_withdrawal_hides_only_scoped_profile_and_revokes_representation()

### Community 286 - "Herramientas"
Cohesion: 0.60
Nodes (3): pytest_addoption(), pytest_runtest_logreport(), pytest_terminal_summary()

### Community 287 - "Herramientas"
Cohesion: 0.60
Nodes (3): pytest_addoption(), pytest_configure(), pytest_runtest_logreport()

### Community 289 - "Pruebas · Cuentas"
Cohesion: 0.47
Nodes (3): test_browser_individual_verification(), test_browser_mfa_agency_two_people(), test_real_browser_account_flow()

### Community 290 - "Pruebas · Capacidad"
Cohesion: 0.60
Nodes (3): test_freeze_and_reindex_preserve_observed_heap_versions_but_schema_can_change(), read(), test_restored_hash_function_does_not_repair_stored_generated_digest()

### Community 292 - "Pruebas"
Cohesion: 0.60
Nodes (4): test_owned_detail_template_threads(), read(), begin(), worker()

### Community 296 - "Pruebas · Publicación"
Cohesion: 0.60
Nodes (3): test_calendar_permission_revoked_during_query(), with_query(), revoke()

### Community 297 - "Pruebas · Publicación"
Cohesion: 0.47
Nodes (3): test_release_refreshes_permission_after_proposal_wait(), with_wait(), attempt()

### Community 299 - "Pruebas · Portabilidad"
Cohesion: 0.47
Nodes (3): test_binary_export_rechecks_after_observed_wait(), binary_selection(), binary_url()

### Community 300 - "Pruebas · Derechos"
Cohesion: 0.60
Nodes (3): test_malformed_response_is_a_controlled_validation_error(), test_public_response_rejects_contact_details(), test_reviewed_explanation_preserves_the_exact_text()

### Community 301 - "Pruebas"
Cohesion: 0.73
Nodes (3): documented(), routes(), test_every_route_appears_in_a_contract_or_flow_document()

### Community 305 - "Herramientas · Publicación"
Cohesion: 0.60
Nodes (3): main(), start(), wait_clean()

### Community 311 - "Pruebas · Portabilidad"
Cohesion: 0.50
Nodes (3): code(), counted(), hook()

### Community 312 - "Pruebas · Derechos"
Cohesion: 0.60
Nodes (3): test_waiting_private_read_rechecks_reference_after_actual_rights_redaction(), observed(), reading()

### Community 316 - "Pruebas · Portabilidad"
Cohesion: 0.60
Nodes (3): test_guided_binary_page_requires_current_token_and_preserves_other_choices(), catalog(), ready_with_history()

### Community 35 - "Pruebas · Derechos"
Cohesion: 0.11
Nodes (39): benchmark(), _fresh(), measure(), native(), reference_fingerprint(), test_fingerprint_index_alternated_diagnostic(), native(), test_cross_connection_falls_back_without_consuming_existing_entry() (+31 more)

### Community 37 - "Pruebas"
Cohesion: 0.11
Nodes (35): collect_aux(), collect_physical(), decode_body(), decoder_limits(), private_file(), main(), prepare_origin(), prepare_origins() (+27 more)

### Community 39 - "Aplicación · Derechos"
Cohesion: 0.10
Nodes (33): account_mail_projection(), compile_package(), mail_records(), project_group(), projected_fields(), recipient_payload(), retained_resource_records(), safe_json() (+25 more)

### Community 48 - "Herramientas · Privacidad"
Cohesion: 0.11
Nodes (20): console_mail_projections(), checked_capture(), checked_scoped_captures(), log_records(), collect(), docker_output(), main(), scoped_origin_name() (+12 more)

### Community 481 - "Pruebas · Derechos"
Cohesion: 0.67
Nodes (3): test_hook_does_not_swallow_integrity_or_nested_loader_import_errors(), corrupted(), nested_missing()

### Community 61 - "Herramientas"
Cohesion: 0.13
Nodes (21): aux(), hex(), main(), quiet(), array(), aux(), db(), function() (+13 more)

### Community 658 - "Aplicación · Perfil beta"
Cohesion: 0.38
Nodes (6): refresh_intervals(), events(), test_ambiguous_or_partial_capture_never_invented(), test_dispatch_and_dirty_age_are_distinct_metrics(), test_invalid_measurements_rejected(), test_snapshot_error_preserved_without_dirty_age_claim()

### Community 661 - "Aplicación · Perfil beta"
Cohesion: 0.33
Nodes (3): test_territorial_unknown49_equivalence(), verify_territorial_unknown49_equivalence(), test_large_territorial_unknown49_equivalence()

### Community 666 - "Aplicación · Perfil beta"
Cohesion: 0.13
Nodes (32): fetch_http(), _run(), run_async_open_loop(), finished(), launch(), worker(), test_client_phases_preserve_partial_timeout_and_emitter_accounting(), exercise() (+24 more)

### Community 67 - "Aplicación · Cuentas"
Cohesion: 0.11
Nodes (18): enabled(), inspect_token(), apply(), display(), locked_subject(), source(), validate(), editors() (+10 more)

### Community 670 - "Aplicación · Perfil beta"
Cohesion: 0.41
Nodes (8): durable(), hashes(), main(), interrupted(), run(), process_start_ticks(), recover(), regression_lane_files()

### Community 673 - "Aplicación · Perfil beta"
Cohesion: 0.27
Nodes (9): test_native_oracle_hydration_profile(), measure(), observe(), reference_territorial_order(), test_explicit_geography_distribution_preserves_native_visibility_and_rights(), test_promotional_geography_covers_individual_and_agency_profiles(), test_statistics_finalization_scope_and_domain_preservation(), capture() (+1 more)

### Community 674 - "Aplicación · Perfil beta"
Cohesion: 0.50
Nodes (6): create_backlog(), events(), prepare_backlog(), verify_pages(), verify_pending(), verify_repaired()

### Community 683 - "Aplicación · Perfil beta"
Cohesion: 0.33
Nodes (3): test_large_mixed_state_territorial_equivalence(), test_mixed_state_territorial_equivalence(), verify_mixed_state_territorial_equivalence()

### Community 686 - "Aplicación · Perfil beta"
Cohesion: 0.42
Nodes (4): test_balanced_cycle_rejects_incompatible_base(), test_balanced_territorial_cycle_preserves_contract_mix(), test_invalid_territorial_census_rejected(), test_territorial_cycle_covers_languages_filters_and_boundaries()

### Community 688 - "Aplicación · Perfil beta"
Cohesion: 0.29
Nodes (6): create_backlog(), _marks(), prepare_backlog(), verify_pages(), verify_pending(), verify_repaired()

### Community 689 - "Aplicación · Perfil beta"
Cohesion: 0.35
Nodes (10): apply_mixed_plan(), _mutate(), native_sponsorships(), prepare_committed_mixed_plan(), prepare_mixed_plan(), _scope(), _select_mixed_plan(), _snapshot() (+2 more)

### Community 69 - "Pruebas · Derechos"
Cohesion: 0.11
Nodes (23): test_approval_replay_does_not_rebuild_full_source_per_read(), counted(), ready(), test_change_after_page_compilation_rolls_back_both_audited_reads(), altered(), test_native_shared_read_and_unshared_replay_are_equivalent_with_fresh_versions(), checked_versions(), counted() (+15 more)

### Community 695 - "Aplicación · Perfil beta"
Cohesion: 0.52
Nodes (4): test_combined_filter_cost(), observe(), read(), render()

### Community 70 - "Pruebas · Promociones"
Cohesion: 0.19
Nodes (19): actor(), audit(), authorize(), create_order(), digest(), receive_event(), synthetic_event(), synthetic_signature() (+11 more)

### Community 701 - "Aplicación · Perfil beta"
Cohesion: 0.38
Nodes (7): test_committed_attribution(), from_db(), observe(), read(), render(), validate(), values()

### Community 705 - "Aplicación · Perfil beta"
Cohesion: 0.44
Nodes (6): signature(), test_policy_checked_cost100(), capture(), measured_get(), observe(), render()

### Community 708 - "Aplicación · Perfil beta"
Cohesion: 0.42
Nodes (5): cases(), distribute(), observe_generator(), plan(), verify()

### Community 711 - "Aplicación · Perfil beta"
Cohesion: 0.12
Nodes (31): command(), main(), save(), snapshot(), test_owned_beta_http_calibration(), fetch(), test_backlog_requires_exact_small_territorial_observer_mode(), test_backlog_watchdog_covers_preparation_without_relaxing_other_commands() (+23 more)

### Community 712 - "Aplicación · Perfil beta"
Cohesion: 0.27
Nodes (12): app_lifetime(), collect_failed_service_states(), command_timeout(), controller_self_probe(), main(), absent(), container(), emit() (+4 more)

### Community 713 - "Aplicación · Perfil beta"
Cohesion: 0.19
Nodes (17): absent(), controller_terminal_state(), durable(), extract(), file_digest(), host_tools(), limit_client_log(), main() (+9 more)

### Community 714 - "Aplicación · Perfil beta"
Cohesion: 0.41
Nodes (11): manager_client(), prepared(), test_delete_codes_and_detach_phone_preserves_other_model_and_consent_evidence(), test_inflight_contact_operation_cannot_recreate_erased_codes(), manager_lock(), pause(), select_for_update(), worker() (+3 more)

### Community 718 - "Aplicación · Perfil beta"
Cohesion: 0.40
Nodes (13): audit(), payload(), test_discard_rejects_proof_expiring_during_upload_lock_wait(), after_wait(), test_global_duplicates_do_not_expose_staging_to_general_match_review(), test_processing_expiry_and_discard_invalidate_private_selection(), test_same_upload_key_serializes_in_postgresql(), invoke() (+5 more)

### Community 72 - "Pruebas · Derechos"
Cohesion: 0.16
Nodes (24): content_digest(), _native_sha256(), operation_content_digests(), _supported_key(), counted_native(), counted(), test_actual_audit_removed_after_second_child_rejects_even_for_identical_bytes(), removed() (+16 more)

### Community 720 - "Aplicación · Perfil beta"
Cohesion: 0.16
Nodes (7): fresh_authority(), authorized(), queue(), test_report_inspection_rechecks_authority_after_scope_wait(), after_scope_wait(), record_decryption(), revoke()

### Community 723 - "Aplicación · Perfil beta"
Cohesion: 0.47
Nodes (4): consume(), proposal_contents(), propose(), record()

### Community 726 - "Aplicación · Perfil beta"
Cohesion: 0.57
Nodes (4): prepared_coverage(), test_coverage_inspection_checks_current_authority_before_decrypt_after_wait(), attempt(), observed_checked_body()

### Community 727 - "Aplicación · Perfil beta"
Cohesion: 0.71
Nodes (5): audit(), context(), inspect(), record(), signature()

### Community 732 - "Aplicación · Perfil beta"
Cohesion: 0.58
Nodes (6): login_reviewer(), native_ids(), report(), test_queue_matches_native_coi_order_and_statuses(), test_queue_membership_and_owner_changes_are_fresh_next_request(), observe()

### Community 735 - "Aplicación · Perfil beta"
Cohesion: 0.57
Nodes (4): gallery_fixture(), test_gallery_delivery_browser_diagnostic(), response_received(), set_status()

### Community 742 - "Aplicación · Perfil beta"
Cohesion: 0.46
Nodes (5): test_native_closed_flow_cost(), count_sql(), measured(), run(), ready()

### Community 744 - "Aplicación · Perfil beta"
Cohesion: 0.26
Nodes (16): can_prepare(), canonical(), download(), generate(), audited_snapshots(), image_content(), image_contents(), inspect_image() (+8 more)

### Community 749 - "Aplicación · Perfil beta"
Cohesion: 0.46
Nodes (5): test_ci_broker_identity_is_checked_before_redis_client(), client(), inspect(), test_invalid_benchmark_selection_stops_before_service_commands(), forbidden()

### Community 75 - "Pruebas · Publicación"
Cohesion: 0.57
Nodes (4): test_demo_credential_write_failure_rolls_back_accounts_and_owned_media(), fail_write(), test_demo_fixture_refuses_production_and_existing_namespace(), test_demo_fixture_reproducible_private_credentials_and_real_publication()

### Community 750 - "Aplicación · Perfil beta"
Cohesion: 0.29
Nodes (6): _enqueue_refresh(), schedule_refresh(), test_catalogue_migration_preserves_data_without_scheduling_live_worker(), test_historical_catalogue_write_keeps_database_invalidation_and_native_rejection(), test_live_catalogue_write_still_schedules_after_commit(), test_live_many_to_many_through_still_schedules_after_commit()

### Community 752 - "Aplicación · Perfil beta"
Cohesion: 0.42
Nodes (7): compressed(), corpus(), measure_scan(), observe(), wrapped(), test_current_distinct_blob_scan_attribution(), test_current_scan_growth_and_density()

### Community 80 - "Aplicación · Privacidad"
Cohesion: 0.14
Nodes (15): _new_s3_client(), repository(), context(), part_bytes(), purge_orphan_export_objects(), seal_binary(), unseal_binary(), verify_export_objects() (+7 more)

### Community 81 - "Pruebas · Derechos"
Cohesion: 0.14
Nodes (26): real_settings(), test_mock_iterator_close_after_failure_does_not_mask_domain(), fail(), objects(), test_mock_metadata_exception_cannot_mask_earlier_physical_failure(), objects(), verify(), test_mock_two_pending_ordered_exception_and_wait_for_started_jobs() (+18 more)

### Community 82 - "Pruebas · Derechos"
Cohesion: 0.15
Nodes (18): _archive(), chunk_packages(), data_packages(), json_chunks(), stored_payload(), files(), test_cli_reconstructs_without_network_or_application_runtime(), test_invalid_copy_leaves_no_output_or_temporary_file() (+10 more)

### Community 86 - "Aplicación · Privacidad"
Cohesion: 0.15
Nodes (17): history_records(), scoped_history(), results_visit(), visit(), project_result(), task_reference(), checked_physical(), hex_bytes() (+9 more)

### Community 88 - "Aplicación · Privacidad"
Cohesion: 0.15
Nodes (17): deliver_safety_notices(), generate_portability_export(), purge_expired_access_coverage(), purge_expired_access_field_decision(), purge_expired_access_response_drafts(), purge_expired_access_scope_inventory(), purge_expired_account_confirmation_delivery(), purge_expired_copy_information() (+9 more)

### Community 90 - "Aplicación · Recuperación"
Cohesion: 0.22
Nodes (15): checked_unseal(), destroy_due(), _destroy_one(), verified_receipts(), identifier(), require(), validate_receipt(), _validate_receipt() (+7 more)

### Community 97 - "Pruebas · Derechos"
Cohesion: 0.21
Nodes (15): configured(), real_settings(), test_mock_config_drift_inside_constructor_never_retains_wrong_target(), changing_create(), test_mock_every_configuration_field_is_fresh(), test_mock_lifecycle_nested_failure_cap_and_all_close_attempts(), create(), test_mock_unknown_types_pid_thread_and_outside_scope_are_native() (+7 more)

### Community 99 - "Pruebas · Agencias"
Cohesion: 0.09
Nodes (9): test_mobile_agency_rejection_appeal(), test_browser_appeal_and_independent_mfa_review(), test_browser_listing_review_and_public_version(), test_browser_manager_rejection_appeal(), test_mobile_agency_transfer_to_self_and_human_review(), test_browser_moderator_mfa_and_organization_decision(), moderator_login(), test_browser_match_resolution_and_pending_approval() (+1 more)

### Community 14 - "Aplicación · Privacidad"
Cohesion: 0.03
Nodes (89): Ruta complaint_action, Ruta complaint_create, Ruta complaint_inspect, Ruta complaint_message, Ruta complaint_photo, Ruta complaint_queue, Ruta complaint_receipt, Ruta complaint_resolve (+81 more)

### Community 15 - "Interfaz · Privacidad"
Cohesion: 0.01
Nodes (5): Ruta dashboard, Ruta moderation_review, Ruta promotion_order_detail, Ruta promotion_orders, Ruta rights_inspect

### Community 114 - "Contrato · Portabilidad"
Cohesion: 0.10
Nodes (4): Aceptación exacta y vigente de documentos, CR01 cuentas y documentos, Cadena verificable de decisiones y artefactos, Sello enumerativo histórico no adoptado

### Community 117 - "Contrato · Publicación"
Cohesion: 0.10
Nodes (6): Recursos locales y aislamiento tras restauración, Estado derivado de publicación en PostgreSQL, Monolito modular SSR con HTMX puntual, Confirmación ORB/RANSAC sin modelos biométricos, Pruebas PostgreSQL sin sustituto SQLite, ADR-001 base técnica

### Community 141 - "Contrato"
Cohesion: 0.16
Nodes (6): Alpha técnico local aceptado el 20 de octubre, G01–08 pendientes de preparación productiva, C común de misma versión con lanes disjuntas, Auditoría de corpus Open Notebook como tarea posterior, MOD09 conserva objetivos 2s/5s como deuda futura, Acta10 Alpha 2026-10-20

### Community 142 - "Configuración · Cifrado"
Cohesion: 0.18
Nodes (19): Django, ImageHash, Pillow, argon2-cffi, blake3, celery, cryptography, django-storages (+11 more)

### Community 232 - "Pruebas"
Cohesion: 0.36
Nodes (5): EMAIL_BACKEND, MFA_ENCRYPTION_KEY_FALLBACKS, SAFETY_ENCRYPTION_KEY_FALLBACKS, SAFETY_HMAC_KEY, Rotación de eventos stderr configurada json-file1m×3 app/worker/Beat

### Community 250 - "Aplicación · Promociones"
Cohesion: 0.33
Nodes (4): Ruta promotion_product_versions, Ruta promotion_products, Ruta promotion_version_edit, Ruta promotion_version_preview

### Community 26 - "Aplicación · Agencias"
Cohesion: 0.04
Nodes (65): Ruta accept_current, Ruta account_email_confirmation, Ruta account_email_confirmation_exchange, Ruta account_token, Ruta age_check, Ruta agency_accept_invitation, Ruta agency_add_person, Ruta agency_appeal_queue (+57 more)

### Community 501 - "Contrato · Beta"
Cohesion: 0.00
Nodes (1806): Atributos y preferencias separados, Geografía y unicidad conservadas, Privacidad de precisión filtrable, Taxonomía romántica prevalece, Aceptación versionada, Autoridad vigente conservada, Política de perfiles románticos, Migración no republica (+1798 more)

### Community 76 - "Contrato"
Cohesion: 0.08
Nodes (11): Fixture sintético de demostración, CR09 denuncias derechos y reclamación sin cuenta, Medios geométricos reproducibles propios, Cobertura portable con selección y revisión exactas, Proof de ámbito consumible y explícitamente sintético, Orígenes históricos privados ligados a inventario y corte, Entradas distintas de denuncia reclamación y derechos, Interfaces comunes v1 (+3 more)

## Knowledge Gaps
- **1560 isolated node(s):** `config.celery.app.task`, `celery.signals.task_postrun.connect`, `celery.signals.task_prerun.connect`, `celery.signals.before_task_publish.connect`, `builtins.dict` (+1555 more)
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 2445 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)
- **246 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.