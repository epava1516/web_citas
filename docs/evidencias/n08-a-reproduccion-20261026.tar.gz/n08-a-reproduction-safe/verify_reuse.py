import ast,collections,hashlib,json,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n08-a-20261026');read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
previous=read('artifacts/recorridos-n07-c-20261025/reuse-verification.json');baseline=read('docs/evidencias/b16-final-candidate-reconciliation-20261025.json')['current_versioned_executable_sources']
changed={p:sha(p) for p,h in baseline.items() if sha(p)!=h};assert changed==previous['documented_variants'] and len(baseline)==1507
bridge=read(W/'agency-selector-bridge.json');assert bridge['person_queryset_AST_equal'] and bridge['changed_functions']==['panel'] and sha(bridge['source'])==bridge['current_sha256']
modules={'test_favorites','test_sitemaps','test_public_seo','test_promotion_catalog','test_promotion_orders','test_promotion_order_http','test_promotion_order_races','test_promotion_order_mobile_agency','test_promotion_order_inventory','test_promotion_audit_inventory','test_promotion_exposure','test_promotion_bump_races','test_promotion_catalog_localization','test_promotion_conflict_localization','test_promotion_localization','test_promotion_recovery'}
chosen={};unsupported=[];sources={};runs=[]
for run in ['20261024-094540-3a6ec8ac','20261025-094533-b3968c81']:
 P=Path('artifacts/local-ci')/run;r=read(P/'result.json');h=read(P/'source-hashes.json');cs=list(E.parse(P/'pytest.xml').iter('testcase'))
 selected=[]
 for c in cs:
  module=c.get('classname','').split('.')[-1]
  if module not in modules:continue
  source='tests/'+module+'.py';assert source in h and sha(source)==h[source],source
  sources[source]=h[source];key=(module,c.get('name'))
  failures=[k for k in ['failure','error','skipped'] if c.find(k)is not None]
  if failures:unsupported.append({'module':module,'case':c.get('name'),'run':run,'outcome':failures});continue
  record={'module':module,'case':c.get('name'),'run':run,'junit':str(P/'pytest.xml'),'test_source':source,'test_source_sha256':h[source],'result':'PASS_original_recorded_not_fresh_run','whole_run_result':r['result']}
  chosen[key]=record;selected.append(key)
 runs.append({'run':run,'reported_junit':r['junit'],'actual_testcase_elements':len(cs),'actual_failures':sum(c.find('failure')is not None for c in cs),'actual_errors':sum(c.find('error')is not None for c in cs),'actual_skipped':sum(c.find('skipped')is not None for c in cs),'selected_outcomes':len(selected),'raw_xml_sha256':sha(P/'pytest.xml'),'source_manifest_sha256':sha(P/'source-hashes.json'),'result_sha256':sha(P/'result.json')})
assert {m for m,n in chosen}==modules,modules-{m for m,n in chosen}
assert all(x['result']=='PASS_original_recorded_not_fresh_run' for x in chosen.values())
count=collections.Counter(m for m,n in chosen)
# Original strict source identity for the actual N08 handlers and templates; helper variant is scoped above.
for p in baseline:
 if p.startswith(('apps/catalog/','apps/core/sitemaps.py','apps/core/legal.py','apps/listings/favorites.py','apps/listings/seo.py','templates/catalog/','templates/core/legal','templates/listings/favorites')):assert sha(p)==baseline[p],p
out={'result':'PASS_N08_SELECTED_ORIGINAL_WITNESSES_SOURCE_SCOPED_NOT_BLOCK_ACCEPTANCE','baseline_executable_sources':len(baseline),'unchanged_baseline_sources':len(baseline)-len(changed),'accepted_variant_chain':changed,'chain_basis':'N07/408 prior proof1507sources with N03/N06/N07A changes, current exact same code; N08 no product changes.','agency_selector_bridge':bridge,'selected_original_cases':len(chosen),'selected_test_modules':len(modules),'counts_by_module':dict(sorted(count.items())),'test_source_files':sources,'original_runs':runs,'witnesses':list(chosen.values()),'unsupported_not_credited':unsupported,'historical_browser_limit':'Old selected browser outcomes retain original Chromium155/runtime context; no fresh156browser claim, no rerun just for installation/docs. N05currentgallery/focus156 scope stays distinct.','limits':'Selected existing outcomes only, not a new integrated suite or whole broad PASS. Suiteattr3833 vs3829actualelements explicit;3FAIL/129SKIP preserved. N01D4repeatedselectedcases replace same originals, not extra count. N08A new reference distinct and N08Bcommercial/task stage still pending. No realpayment/provider/production or comprehensive current-browser certification.'}
(W/'reuse-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['witnesses','test_source_files','original_runs','accepted_variant_chain','agency_selector_bridge','unsupported_not_credited']}))
