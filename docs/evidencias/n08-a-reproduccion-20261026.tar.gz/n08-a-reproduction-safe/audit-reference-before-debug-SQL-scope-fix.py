import collections,hashlib,json,math,statistics,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n08-a-20261026');P=Path('artifacts/local-ci')/sys.argv[1]
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=read(P/'result.json');freeze=read(W/'reference-freeze.json');h=read(P/'source-hashes.json')
assert r['result']=='PASS' and r['sources_unchanged'] and r['workers']==1 and r['selection']==freeze['selection'] and r['observe_http_operations']
assert all(sha(p)==v for p,v in freeze['sources'].items())
missing=set(freeze['sources'])-set(h);assert missing=={freeze['prereg_document_verified_separately']}
assert all(h[p]==v for p,v in freeze['sources'].items() if p in h)
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==3 and not any(c.find(k)is not None for c in cs for k in ['failure','error','skipped'])
expected_names={'test_favorites_secondary_surface_reference','test_sitemap_secondary_surface_reference','test_legal_secondary_surface_reference'};assert {c.get('name') for c in cs}==expected_names
summaries=[];raw=[];total=global_count=0
for c in cs:
 props={x.get('name'):x.get('value') for x in c.iter('property')};d=json.loads(props['secondary_surface_samples']);rows=d['rows'];ops=json.loads(props['http_operation_samples']);assert len(ops)==int(props['http_operation_count'])
 assert all(x['exception_class'] is None and x['observer_error_class'] is None for x in ops)
 name=c.get('name');expected=156 if 'favorites' in name else 84 if 'sitemap'in name else 60;assert len(rows)==expected;total+=len(rows);global_count+=len(ops)
 if 'favorites'in name:
  assert d['setup_descriptor']['favorite_get_snapshot_unchanged'] and d['setup_descriptor']['native_page_size']==24
  assert d['population_counts']['own_favorite_cohorts']==[0,1,10,100] and d['population_counts']['foreign_favorites']==1 and d['population_counts']['retained_unavailable_favorites']==1
  groups={(s,l,p) for s,n in [('own_0',1),('own_1',1),('own_10',1),('own_100',5),('own_100_one_revoked',5)] for l in ['es','en'] for p in range(1,n+1)}
  assert {(x['state'],x['language'],x['page']) for x in rows}==groups
 elif 'sitemap'in name:
  assert d['setup_descriptor']['native_page_size']==100 and d['population_counts']['candidate_cohorts']==[0,1,10,100,101] and d['population_counts']['candidate_count_after_revocation']==101 and d['population_counts']['unavailable_candidates']==1
  expected_groups={('sitemap_directory','directory',0)}|{('sitemap_index',f'candidates_{n}',0) for n in [0,1,10,100,101]}|{('sitemap_index','candidates_101_one_revoked',0)}|{('sitemap_listings',f'candidates_{n}',p) for n in [1,10,100,101] for p in range(1,math.ceil(n/100)+1)}|{('sitemap_listings','candidates_101_one_revoked',p) for p in [1,2]}
  assert {(x['surface'],x['state'],x['page']) for x in rows}==expected_groups and all(x['language']=='neutral' for x in rows)
 else:
  assert d['setup_descriptor']['legal_GET_snapshot_unchanged'] and d['setup_descriptor']['directory_fixture_calls']==0 and d['population_counts']['document_rows']==202 and d['population_counts']['active_cohorts_per_language']==[0,1,10,100]
  expected_groups={('legal_index',f'active_per_language_{n}',l) for n in [0,1,10,100] for l in ['es','en']}|{('legal_document','active_per_language_100',l) for l in ['es','en']}
  assert {(x['surface'],x['state'],x['language']) for x in rows}==expected_groups
 grouped=collections.defaultdict(list)
 for x in rows:
  assert x['status']==200 and x['response_bytes']>0
  for k in ['wall_seconds','cpu_seconds','sql_execute_seconds','sql_queries']:assert isinstance(x[k],(float,int)) and not isinstance(x[k],bool) and math.isfinite(x[k]) and x[k]>=0
  assert isinstance(x['sql_queries'],int)
  if x['language']!='neutral':assert x['response_language']==x['observed_content_language']==x['language']
  if x['surface']=='favorites':assert x['observed_cache_control']=='private, no-store'
  if x['surface'].startswith('sitemap'):assert x['observed_cache_control']=='no-store'
  grouped[(x['surface'],x['state'],x['language'],x['page'])].append(x)
 for key,samples in grouped.items():
  assert len(samples)==6 and [x['ordinal'] for x in samples]==list(range(6));later=samples[1:]
  summaries.append(dict(zip(['surface','state','language','page'],key))|{'samples':6,'first_ms':samples[0]['wall_seconds']*1000,'median5_ms':statistics.median(x['wall_seconds'] for x in later)*1000,'range5_ms':[min(x['wall_seconds'] for x in later)*1000,max(x['wall_seconds'] for x in later)*1000],'cpu_median5_ms':statistics.median(x['cpu_seconds'] for x in later)*1000,'sql_counts':sorted({x['sql_queries'] for x in samples}),'bytes':sorted({x['response_bytes'] for x in samples})})
 for route in {x['route_name'] for x in rows}:
  own=[x for x in rows if x['route_name']==route];observed=[x for x in ops if x['route_name']==route and x['method']=='GET' and x['status']==200];assert len(own)==len(observed),(name,route,len(own),len(observed))
  for a,b in zip(own,observed):assert a['sql_queries']==b['sql_queries'] and a['wall_seconds']>=b['request_seconds_instrumented']
 raw.append({'case':name,'reference':d,'global_operations':ops,'global_scope':props['http_operation_scope']})
assert total==300 and len(summaries)==50
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_N08A_SECONDARY_SURFACES_REFERENCE_NOT_BLOCK_ACCEPTANCE','run':P.name,'cases':3,'junit':r['junit'],'freeze_sources':len(freeze['sources']),'runner_sources_verified':len(freeze['sources'])-len(missing),'documents_verified_separately':sorted(missing),'application_change':False,'measured_GETs':300,'segments':50,'global_operations':global_count,'raw_cases':raw,'summary':summaries,'cleanup_verified':True,'telegram':tg,'scope':'Only N08A reference: own300GET inside globalops, no summation. Firstplus5 each population/state/page/lang; native24/100,legal202ownrows; synthetic sharedmedia/eagerprep, Client not browser/worker/TCP/provider/p95/legalcompliance or latencygain. N08Bcommercial and full17dispositions still pending; no wholeN08acceptance.'}
(W/'reference-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['raw_cases','summary']}))
