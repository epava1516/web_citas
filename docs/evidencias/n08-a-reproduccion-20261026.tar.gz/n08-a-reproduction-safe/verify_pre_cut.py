import hashlib,json,shutil,subprocess
from pathlib import Path
W=Path('artifacts/recorridos-n08-a-20261026');G=Path('graphify-out');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=json.loads((G/'SOURCE_MANIFEST.json').read_text());bad=[p for p,r in m.items() if sha(p)!=r['sha256']];assert not bad,bad
assert sha(G/'graph.json')=='ff23b4f622c947cd248ea236d832696ba74632ae094fc25e25d6ee5edc238bcc'
for n in ['SOURCE_MANIFEST.json','ESTADO_ACTUAL.json','GRAPH_VERIFICATION.json']:shutil.copy2(G/n,W/('pre-'+n))
out={'result':'PASS_CURRENT_PRE_N08_SOURCE_CUT','source_files':len(m),'graph_sha256':sha(G/'graph.json'),'mismatches':bad,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'N07/408 final scoped native semantics/AST preserved; complete2022declaredsource hashes current before formal N08 analysis. User340/341 handoff changes observed, not staged by root. Not global semantic rebuild.'};(W/'pre-source-cut.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
