import copy,hashlib,json,shutil,tarfile,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n08-a-20261026');S=W/'reproduction-safe';S.mkdir(exist_ok=False)
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,dest=None):
 p=Path(p);dest=S/(dest or p.relative_to(W));dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for p in W.iterdir():
 if p.is_file() and p.suffix in ['.json','.py']:put(p)
for sub in ['prereg','result']:
 for p in (W/sub).iterdir():
  if p.is_file() and p.suffix in ['.json','.py']:put(p)
 for p in (W/sub/'snapshots').iterdir():
  if p.is_file():put(p)
put('tests/test_secondary_surface_reference.py','instruments/test_secondary_surface_reference.py')
def strip_outputs(root):
 for node in root.iter():
  for child in list(node):
   if child.tag in ('system-out','system-err'):node.remove(child)
 return root
run=Path('artifacts/local-ci/20261026-004939-72f06ea0');dest=S/'runtime';dest.mkdir();r=read(run/'result.json');r['steps']=[{k:v for k,v in step.items() if k not in ['command','stdout','stderr']} for step in r['steps']]
(dest/'result-sanitized.json').write_text(json.dumps(r,indent=2)+'\n')
for name in ['source-hashes.json','native-manifest.json','telegram-notification.json']:shutil.copy2(run/name,dest/name)
E.ElementTree(strip_outputs(E.parse(run/'pytest.xml').getroot())).write(dest/'pytest-sanitized.xml',encoding='utf-8',xml_declaration=True)
reuse=read(W/'reuse-verification.json');suite=E.Element('testsuite',name='selected_original_recorded_N08_not_fresh_integrated',tests=str(len(reuse['witnesses'])));cache={}
for row in reuse['witnesses']:
 path=row['junit']
 if path not in cache:cache[path]=list(E.parse(path).iter('testcase'))
 matches=[c for c in cache[path] if c.get('name')==row['case'] and c.get('classname','').endswith(row['module'])];assert len(matches)==1
 case=strip_outputs(copy.deepcopy(matches[0]));case.set('original_run',row['run']);suite.append(case)
E.ElementTree(suite).write(S/'selected-original77-sanitized.xml',encoding='utf-8',xml_declaration=True)
manifest={'result':'N08A_SANITIZED_REPRODUCTION','files':{str(p.relative_to(S)):sha(p) for p in sorted(S.rglob('*')) if p.is_file()},'scope':'Original3PASS300GET runtime preserved; selfdebugSQLinvalid fields explicitly discarded in canonical audit. First auditorfailure/notificationfailure/retry retained.77historicaloutcomes not fresh run,3833declared/3829actualbroad/3FAIL129SKIP unchanged. No rawlogs/stepcommands/systemoutputs, no userlateraldraftcontents, no credentials. Own test/oracles/sourcefreeze preserved. No appcandidateimplemented.'}
(S/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');target=Path('docs/evidencias/n08-a-reproduccion-20261026.tar.gz')
with tarfile.open(target,'w:gz') as tar:tar.add(S,arcname='n08-a-reproduction-safe')
print(json.dumps({'artifact':str(target),'files':len(manifest['files'])+1,'sha256':sha(target),'bytes':target.stat().st_size}))
