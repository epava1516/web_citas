import ast,hashlib,json,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n03-a-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
r=read(W/'detector-review.json');assert r['STATUS']=='complete' and r['TESTS_RUN']==[] and not r['UNRESOLVED_ISSUES']
P=Path('artifacts/local-ci/20261024-213414-574e4266');old=read(P/'source-hashes.json');a=read('docs/evidencias/b10-similarity-growth-density-audit-20261024.json');result=read(P/'result.json');assert result['result']=='PASS'
for item in r['source_delta']['relevant_identical_sources']:
 p=item['file'];assert sha(p)==old[p]==item['current_sha256']==item['historical_sha256'] and item['identical']
assert len(r['source_delta']['relevant_identical_sources'])==15
cases=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==2
for c,row in zip(cases,a['observations'],strict=True):
 assert not any(c.findall(k) for k in ['failure','error','skipped'])
 props={e.attrib['name']:e.attrib['value'] for e in c.iter('property')};m=ast.literal_eval(props['distinct_blob_scan_diagnostic']);assert isinstance(m,dict) and m==row['measurement'];assert m['recorded_matches']==m['expected_candidates'] and m['calls']['compare_signatures']==m['candidates'];assert m['calls']['confirm_match']==m['calls']['record_match']==m['expected_candidates']
assert r['evidence_reuse']['original_junit_sha256']==sha(P/'pytest.xml')
out={'result':'PASS_N03_DETECTOR_HISTORICAL_REUSE_WITH_LIMITS','run':a['run'],'cases':2,'identical_relevant_sources':r['source_delta']['relevant_identical_sources'],'junit_sha256':sha(P/'pytest.xml'),'result_sha256':sha(P/'result.json'),'observations':a['observations'],'original_cleanup':a['cleanup'],'original_independent_inventory':a['independent_labels'],'original_telegram':a['telegram'],'scope':'Byte-identical selected detector/instrument/fixtures/settings/dependencies; original instrumented finite detector calls only. No new execution, upload/queue/currentOS/index or80000capacity claim.'}
(W/'detector-reuse-verified.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('REUSE_VERIFIED',len(out['identical_relevant_sources']),[(r['measurement']['candidates'],r['measurement']['elapsed_seconds']) for r in out['observations']])
