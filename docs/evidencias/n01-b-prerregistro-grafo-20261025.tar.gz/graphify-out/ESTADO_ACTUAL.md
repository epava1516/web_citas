# Grafo alfa — N00 aceptado y primer prerregistro N01

Contrato anterior cerrado localmente por acta23 y commit16ac270:15/18aceptados;B14/B15/B17deuda, noPASS. Su grafo de cierre y archivos permanecen inmutables en docs/evidencias/contrato-grafo-registro-final-20261025.json. Base original reconstruida desde cero:1922fuentes,AST/semántica y28lotes. Refrescos posteriores son focales y explícitos, no nuevas reconstrucciones completas.

Contrato340/roadmap341v1.2,N00aceptado por343,1/13bloques aceptados,N01en curso. Prerregistro346N01B,1caso100perfiles10segmentosES/ENy60peticiones,primera/5posteriores porsegmento,nofríoOSgarantizado. Sin ejecución aún,niTCP/p95/capacidadocausalidad. NuevoinstrumentoAST4nodos/15aristas/2funciones;appanterior1507SHAintactos. Tablaantes/después obligatoria porbloquecon evidenciacomparable,ono basecomparable declarada. N12–N14condicionados,MOD09sin prioridadautomática,QAespecífico aplazado,alfa.

Este refresco: 3 documentos, 15 entidades/13 relaciones semánticas nativas con cita,líneas ySHA comprobados. ASTdebasepreservado;deltaestructuraldelnuevoinstrumento. Corpus vigente1933fuentes,17993nodos/79888relaciones,853comunidades. Se conservan membresías de base y se añade una comunidad documental;no detección global nueva. Seguimiento17sólo líneas1–4,con huellas separadas delarchivo completo yvista. Historial/evidencias masivas/vendor yotras exclusiones permanecen explícitas en política.

Semántica selectiva y referencias estáticas;no prueba de runtime,permisos,coste,seguridad,legalidad oPASS. Entidades antiguas sustituidas aún citadas desde otras fuentes conservan handles noresueltos, sin implementación inventada. Las100anotaciones ambiguas de llamadas/bases son anotaciones, no dependencias a sí mismas. Consumo nativo desconocido;ceros técnicos delgenerador no son coste cero.

JSON contiene elgrafo completo;HTMLproyecta sólo comunidades, manteniendo guarda de5000nodos sin abrir un render completo.

