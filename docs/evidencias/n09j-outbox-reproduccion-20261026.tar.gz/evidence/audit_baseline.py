import hashlib,json,math,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n09-j-20261026');P=Path('artifacts/local-ci')/sys.argv[1]
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f,r,h=read(W/'baseline-freeze.json'),read(P/'result.json'),read(P/'source-hashes.json')
assert r['result']=='PASS'and r['sources_unchanged']and r['selection']==f['selection']
assert all(sha(p)==v for p,v in f['sources'].items())
assert set(f['sources'])-set(h)==set(f['sources_verified_separately'])
assert all(h[p]==v for p,v in f['sources'].items()if p in h)
cases=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==7
profiles=[];seen=set();kinds=['safety.ReportNotice','safety.ComplaintNotice','safety.RightsNotice'];delivery=['safety.SimulatedNoticeDelivery','safety.SimulatedComplaintNoticeDelivery','safety.SimulatedRightsNoticeDelivery']
for c in cases:
 assert all(c.find(k)is None for k in ['failure','error','skipped'])
 props={x.get('name'):x.get('value')for x in c.iter('property')};d=json.loads(props['owned_outbox_profile']);assert d['status']=='passed'
 scenario,n=d['scenario'],d['eligible_count'];assert(scenario,n)not in seen;seen.add((scenario,n))
 assert d['other_tables_before']==d['other_tables_after']and d['files_before']==d['files_after']and d['notice_before']==d['notice_after']
 phases=d['phases']
 if scenario=='volume':
  order=[kinds[i%3]for i in range(n)];expected_kinds=[order[:100],order[100:],[]]if n==101 else[order,[]];names=['first_batch','continuation','replay']if n==101 else['first_batch','replay']
 elif scenario=='skip_locked':
  expected_kinds=[[kinds[1],kinds[2]],[kinds[0]],[]];names=['skip_locked','after_unlock','replay'];assert d['held_row_lock_acquired']and d['holder_pid']!=d['worker_pid']and d['worker_completed_while_holder_active']and d['holder_released']and d['thread_finished']and d['worker_connections_closed']
 else:assert scenario=='failure'and n==2;expected_kinds=[[kinds[0],kinds[2]],[]];names=['adapter_failure','immediate_followup']
 assert [p['phase']for p in phases]==names
 for p,expected in zip(phases,expected_kinds,strict=True):
  fail=scenario=='failure'and p['phase']=='adapter_failure';result={'processed':len(expected),'simulated':0 if fail else len(expected),'retry':1 if fail else 0,'failed':1 if fail else 0,'disabled':False};assert p['result']==result
  assert p['adapter_calls']==len(expected)and p['adapter_kinds']==expected
  assert all(math.isfinite(p[k])and p[k]>=0 for k in ['wall_seconds','sql_seconds','adapter_seconds'])
  assert p['wall_seconds']>=max(p['sql_seconds'],p['adapter_seconds'])
  assert p['sql_count']==sum(x['count']for x in p['operations'].values())and p['sql_count']>=1
  assert 'DELETE'not in p['operations']
 for kind,model in zip(kinds,delivery,strict=True):
  old,new=d['deliveries_before']['tables'][model],d['deliveries_after']['tables'][model];count=0 if scenario=='failure'else sum(p['adapter_kinds'].count(kind)for p in phases);assert new['count']==old['count']+count
 if scenario=='failure':assert d['deliveries_before']==d['deliveries_after']
 assert abs(sum(p['wall_seconds']for p in phases)-d['measured_task_seconds'])<1e-8
 assert abs(d['case_body_seconds']-d['measured_task_seconds']-d['non_measured_case_seconds'])<1e-8
 assert d['case_body_seconds']>=d['pre_measurement_seconds']>=0
 profiles.append(d)
assert seen=={('volume',n)for n in[0,1,10,100,101]}|{('skip_locked',3),('failure',2)}
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq']if kind=='container'else['docker',kind,'ls','-q']
 assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists()
tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_SEVEN_FINITE_OUTBOX_BASELINE_NOT_WHOLE_N09','run':P.name,'junit':r['junit'],'frozen_sources':len(f['sources']),'profiles':profiles,'cleanup_verified':True,'telegram':tg,'scope':'3kindtask.run/actualforwardedlocalsimulator/N1instrumentedphase/0to101eligible+native/future/failedpins/skip3/fault2. Noappchange/noafter/Beatnewworker/providerproof.6oldfunctional+1oldnativeworkerprefixscopedreuse/notnewruns/wholeoldERRORretained/N09139open8of13.'}
(W/'baseline-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k!='profiles'}))
