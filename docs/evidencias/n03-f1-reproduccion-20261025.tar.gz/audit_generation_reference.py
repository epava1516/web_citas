import hashlib,json,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n03-f-20261025');P=Path('artifacts/local-ci/20261025-195610-4d4d1295')
r=json.loads((P/'result.json').read_text());f=json.loads((W/'reference-freeze.json').read_text());assert r['result']=='ERROR' and r['sources_unchanged'] and r['selection']==f['selection']
assert r['junit'][0]['tests']=='11' and r['junit'][0]['failures']=='8' and r['junit'][0]['errors']==r['junit'][0]['skipped']=='0'
assert all(Path(p).is_file() and hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in f['sources'].items())
rows=[];positive=[]
for c in E.parse(P/'pytest.xml').iter('testcase'):
 props={p.attrib['name']:p.attrib['value'] for p in c.iter('property')}
 if 'n03f_generation_budget' in props:
  d=json.loads(props['n03f_generation_budget']);assert c.find('failure')is not None and 'Automatic generation exceeded the inherited four-attempt ceiling' in c.find('failure').attrib['message']
  assert d['final_attempts']==d['initial_attempts']+1 and d['final_status']=='ready' and d['storage_opens']==1 and d['comparison_complete']
  rows.append(d)
 else:assert not any(c.find(k)is not None for k in ['failure','error','skipped']);positive.append(c.attrib['name'])
assert len(rows)==8 and len(positive)==3 and {(r['initial_status'],r['initial_attempts']) for r in rows}=={(s,a) for s in ['queued','processing','failed','ready'] for a in [4,5]}
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];q=subprocess.run(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],capture_output=True,text=True,check=True);assert not q.stdout.strip()
assert not Path(json.loads((P/'runner.json').read_text())['temporary']).exists();tg=json.loads((P/'telegram-notification.json').read_text());assert tg['delivery']=='sent'
out={'result':'CONFIRMED_8_REFERENCE_FAILURES_AND_3_PASS_NOT_BUDGET_ACCEPTANCE','run':P.name,'junit':r['junit'],'source_count':len(f['sources']),'sources_unchanged':True,'budget_cases':rows,'positive_controls':positive,'cleanup_verified':True,'telegram':tg}
(W/'reference-audit.json').write_text(json.dumps(out,indent=2));print('Confirmed8extra generations/storageopens and3positivePASS; sources/cleanup/Telegramverified.')
