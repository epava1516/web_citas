import hashlib,json,re
from pathlib import Path
W=Path('artifacts/recorridos-n03-f-20261025')
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
snapshots=read(W/'coverage-source-snapshots.json')
def source(p):return Path(snapshots[str(p)]['snapshot'])
r=read(W/'coverage-review.json');assert r['STATUS']=='complete'
assert isinstance(r['IMPLEMENTATION_NOTES'],str) and isinstance(r['TEST_RESULTS'],str)
for k in ['FILES_CHANGED','TESTS_RUN','ASSUMPTIONS','RISKS','UNRESOLVED_ISSUES','RECOMMENDATIONS']:assert isinstance(r[k],list)
for p,h in r['source_sha256'].items():assert hashlib.sha256(source(p).read_bytes()).hexdigest()==h,p
for identity,c in r['citations'].items():
 p=Path(c['file']);assert hashlib.sha256(source(p).read_bytes()).hexdigest()==c['sha256']
 loc=re.fullmatch(r'L(\d+)(?:-L?(\d+))?',c['line']);assert loc
 lines=source(p).read_text().splitlines();lo=int(loc[1]);hi=int(loc[2] or loc[1]);assert 1<=lo<=hi<=len(lines)
 assert c['quote'] in '\n'.join(lines[lo-1:hi]),identity
out={'result':'NATIVE_N03_COVERAGE_REVIEW_SCHEMA_SOURCES_CITATIONS_VERIFIED_NOT_ACCEPTANCE','requirements':len(r['requirements']),'citations':len(r['citations']),'sources':len(r['source_sha256']),'remaining_mandatory':['Global generation ceiling','Retained population growth','Final per-action/current-candidate/table conciliation'],'native_tokens':None}
(W/'coverage-review-snapshot-verification.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
