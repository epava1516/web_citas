import hashlib,json,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n03-f-20261025');P=Path('artifacts/local-ci/20261025-200423-1535dac0');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
r=read(P/'result.json');f=read(W/'candidate-freeze.json');assert r['result']=='PASS' and r['sources_unchanged'] and r['selection']==f['selection'] and r['workers']==1
changed_after_tests={p:{'frozen_sha256':h,'current_sha256':sha(p)} for p,h in f['sources'].items() if sha(p)!=h}
assert set(changed_after_tests)=={'.ai/tasks/desarrollo.md'},changed_after_tests
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==49 and not any(c.find(k)is not None for c in cs for k in ['failure','error','skipped'])
rows=[];runtime=None
for c in cs:
 props={x.attrib['name']:x.attrib['value'] for x in c.iter('property')}
 if 'n03f_generation_budget' in props:
  d=json.loads(props['n03f_generation_budget']);assert d['final_attempts']==d['initial_attempts'] and d['final_status']=='failed' and d['storage_opens']==0 and not d['comparison_complete']
  assert d['error_code']==('decode_or_storage_failed' if d['initial_status']=='failed' else 'generation_attempts_exhausted');rows.append(d)
 if 'n03e_media_worker_recovery' in props:runtime=json.loads(props['n03e_media_worker_recovery'])
assert len(rows)==8 and runtime==read(P/'n03e-runtime.json') and runtime['complete']
cap=runtime['phases']['generation_cap'];assert cap['before']==cap['after'] and cap['after']['status']=='failed' and cap['after']['attempts']==4
assert len(cap['executions'])==1 and cap['executions'][0]['state']=='SUCCESS' and cap['executions'][0]['retries']==0
assert not any(e['id']==cap['task_id'] and e['event'] in ['retry','failure'] for e in runtime['events'])
assert runtime['worker_exit_code']==runtime['beat_exit_code']==0 and runtime['runtime_role_removed'] and runtime['private_credentials_removed'] and runtime['private_runtime_removed']
assert all(runtime['processes_absent'].values()) and runtime['foreign_keys_preserved'] and runtime['unexpected_unscoped_keys']==0 and not runtime['cleanup_errors']
assert 'final_snapshot_error' not in runtime and 'role_cleanup_snapshot_error' not in runtime
executions=[e for e in runtime['events'] if e['event']=='execution'];assert len(executions)==len({(e['id'],e['retries']) for e in executions})
assert all(e['eager'] is False and e['role']=='worker' and e['sql_role']==runtime['runtime_role'] for e in executions)
D=runtime['phases']['beat_recovery'];assert D['positive_distinct_blob_count']==4 and D['excluded_controls_before']==D['excluded_controls_after']
assert len(D['media_publishes'])==4 and runtime['schedule_seconds']==60
assert [e['retries'] for e in runtime['phases']['storage_retry']['attempts']]==[0,1,2,3]
assert [e['state'] for e in runtime['phases']['storage_retry']['attempts']]==['RETRY','RETRY','RETRY','FAILURE']
for pid,ticks in runtime['pid_start_ticks'].items():
 try:current=int((Path('/proc')/pid/'stat').read_text().rsplit(')',1)[1].split()[19])
 except FileNotFoundError:continue
 assert current!=ticks
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];q=subprocess.run(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],capture_output=True,text=True,check=True);assert not q.stdout.strip()
assert not Path(read(P/'runner.json')['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_GLOBAL_GENERATION_CEILING_49_CASES_NOT_N03_BLOCK_ACCEPTANCE','run':P.name,'junit':r['junit'],'source_count':len(f['sources']),'sources_unchanged_during_run':True,'post_run_worklog_changes':changed_after_tests,'budget_cases':rows,'runtime':runtime,'actual_task_executions':len(executions),'global_guard_ack_preserves_failed4':True,'cleanup_verified':True,'telegram':tg,'remaining_mandatory':'Retained historical population growth and final per-action table/acceptance'}
(W/'candidate-final-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['runtime','budget_cases']}))
