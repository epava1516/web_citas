import hashlib,json,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n03-c-20261025');P=Path('artifacts/local-ci/20261025-181549-690b123b')
r=json.loads((P/'result.json').read_text());f=json.loads((W/'reference-freeze.json').read_text());assert r['result']=='ERROR' and r['sources_unchanged']
assert r['selection']==[f['selector']] and r['workers']==1
assert r['junit'][0]['tests']=='2' and r['junit'][0]['failures']=='2' and r['junit'][0]['errors']==r['junit'][0]['skipped']=='0'
cases=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==2
expected={'success':'Old completion replaced the newer derivative','failure':'Old failure overwrote the newer successful generation'}
for c in cases:
 variant=next(k for k in expected if '['+k+']' in c.attrib['name']);fail=c.find('failure');assert fail is not None and expected[variant] in fail.attrib['message']
assert hashlib.sha256((W/'services-before.py').read_bytes()).hexdigest()==f['sources']['apps/mediafiles/services.py']
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];q=subprocess.run(cmd+['--filter','label=web-modelos-local-ci-run=20261025-181549-690b123b'],capture_output=True,text=True,check=True);assert not q.stdout.strip()
assert not Path(json.loads((P/'runner.json').read_text())['temporary']).exists();tg=json.loads((P/'telegram-notification.json').read_text());assert tg['delivery']=='sent'
out={'audit':'CONFIRMED_REFERENCE_TWO_FUNCTIONAL_FAILURES_NOT_PASS','run':P.name,'runner_result':r['result'],'junit':r['junit'],'failures':expected,'source_count':len(f['sources']),'sources_unchanged_during_run':True,'cleanup_verified':True,'telegram':tg,'scope':'Two actual PostgreSQL threads invoke process directly, lease expiry timestamp induced; no broker/Beat/worker transport claim'}
(W/'reference-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
