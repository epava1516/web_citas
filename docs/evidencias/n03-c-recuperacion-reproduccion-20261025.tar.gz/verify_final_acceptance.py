import ast,hashlib,json,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n03-c-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
ref=read(W/'reference-audit.json');v1=read(W/'candidate-v1/candidate-audit.json');v2=read(W/'candidate-v2-audit.json')
assert ref['junit'][0]['failures']=='2' and ref['junit'][0]['errors']=='0'
assert v1['functional_cases']==32 and v2['functional_cases']==33
for audit in [ref,v1,v2]:
 run=audit['run'];P=Path('artifacts/local-ci')/run;r=read(P/'result.json');assert r['sources_unchanged']
 assert read(P/'telegram-notification.json')['delivery']=='sent'
 assert not Path(read(P/'runner.json')['temporary']).exists()
 for kind in ['container','volume','network']:
  cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];q=subprocess.run(cmd+['--filter','label=web-modelos-local-ci-run='+run],capture_output=True,text=True,check=True);assert not q.stdout.strip()
P=Path('artifacts/local-ci')/v2['run'];cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==33 and not any(c.find(k)is not None for c in cs for k in ['failure','error','skipped'])
assert any(c.attrib['name']=='test_current_generation_comparison_failure_keeps_existing_retry_state' for c in cs)
assert sum('test_expired_worker_cannot_overwrite_new_generation[' in c.attrib['name'] for c in cs)==2
f=read(W/'candidate-v2-freeze.json');assert all(sha(p)==h for p,h in f['sources'].items() if p!='.ai/tasks/desarrollo.md')
scope=read(W/'candidate-scope.json');assert sha(scope['changed_file'])==scope['after_sha256'] and sha(W/'services-before.py')==scope['before_sha256']
def rest(t):
 a=ast.parse(t);a.body=[n for n in a.body if not isinstance(n,ast.FunctionDef) or n.name!='process'];return ast.dump(a,include_attributes=False)
assert rest(Path('apps/mediafiles/services.py').read_text())==rest((W/'services-before.py').read_text())
assert sha(W/'test_media_job_recovery-reference.py')==read(W/'reference-freeze.json')['sources']['tests/test_media_job_recovery.py']
for name in ['recovery-review.json','prereg/report.json','amendment-graph/report.json','final-graph/report.json']:
 r=read(W/name);assert r['STATUS']=='complete';assert isinstance(r['IMPLEMENTATION_NOTES'],str) and isinstance(r['TEST_RESULTS'],str)
 for key in ['FILES_CHANGED','TESTS_RUN','ASSUMPTIONS','RISKS','UNRESOLVED_ISSUES','RECOMMENDATIONS']:assert isinstance(r[key],list)
out={'result':'PASS_LOCAL_N03C_GENERATION_FENCE_NOT_N03_BLOCK_ACCEPTANCE','original_failures_preserved':2,'first_candidate_passes':32,'final_candidate_passes':33,'all_three_runs_sources_unchanged_and_cleaned':True,'terminal_telegram_all_sent':True,'current_app_and_test_hashes_verified':True,'worklog_after_run_delta_explicit':True,'app_scope_only_process_ast':True,'original_reference_instrument_recovered_by_exact_hash':True,'native_reports_strict_schema':True,'pending':['Ready incomplete nonprogress reproduction','Real broker/worker/Beat retry reconciliation','N03 block acceptance']}
(W/'acceptance-verification.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
