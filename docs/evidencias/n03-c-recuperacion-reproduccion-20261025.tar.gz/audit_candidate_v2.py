import hashlib,json,math,statistics,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n03-c-20261025');P=Path('artifacts/local-ci')/sys.argv[1]
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
r=read(P/'result.json');f=read(W/'candidate-v2-freeze.json');assert r['result']=='PASS' and r['sources_unchanged'] and r['workers']==1
assert r['selection']==['tests/test_media_job_recovery.py','tests/test_preparation_cleanup.py','tests/test_photos.py']
assert all(Path(p).is_file() and hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in f['sources'].items())
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==33 and not any(c.find(k)is not None for c in cs for k in ['failure','error','skipped'])
rows=[]
for c in cs:
 props={x.attrib['name']:x.attrib['value'] for x in c.iter('property')}
 if 'n03c_recovery_selection' not in props:continue
 d=json.loads(props['n03c_recovery_selection']);assert len(d['samples'])==6
 for i,s in enumerate(d['samples']):
  assert s['ordinal']==i and s['queries']==1 and s['dispatches']==min(d['count'],100)
  assert math.isfinite(s['seconds']) and s['seconds']>=0
 later=[s['seconds']*1000 for s in d['samples'][1:]]
 rows.append({'queued':d['count'],'dispatches':min(d['count'],100),'queries':1,'first_ms':d['samples'][0]['seconds']*1000,'later_median_ms':statistics.median(later),'later_min_ms':min(later),'later_max_ms':max(later),'scope':d['scope']})
assert sorted(x['queued'] for x in rows)==[0,1,10,100,101]
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];q=subprocess.run(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],capture_output=True,text=True,check=True);assert not q.stdout.strip()
assert not Path(read(P/'runner.json')['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_GENERATION_FENCE_AND_FINITE_RECOVERY_NOT_N03_BLOCK_ACCEPTANCE','run':P.name,'junit':r['junit'],'functional_cases':len(cs),'sources_unchanged':True,'source_count':len(f['sources']),'recovery_selection':sorted(rows,key=lambda r:r['queued']),'cleanup_verified':True,'telegram':tg,'limitations':['No real Celery retry/backoff/Beat transport proof','Ready-incomplete ineligible/empty-signature nonprogress pending separate reproduction','No fairness/SLA/p95/capacity claim']}
(W/'candidate-v2-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
