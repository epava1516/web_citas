N06F preparado: medir referencias restantes con once selectores originales/doce casos, sin candidato nuevo. [Conciliación372](372-n06-e-conciliacion-acciones-variantes-20261025.md) verifica46acciones/76citas;20de41rutas tienen referencia acotada y21no. [Protocolo373](373-n06-f-prerregistro-referencias-restantes-20261025.md). N06abierto, N00/N01aceptados2/13, alfa.

Antes de medir: grafo focal y fuentes/selección/imágenes congelados; después auditar estados/oráculos/tiempos/limpieza/Telegram. No repetir MOD09restante diferido por usuario367. Tras estas referencias: cuatro colas de revisión con crecimiento pendiente y conciliación de variantes/compartidos antes del cierreN06. Panel371conserva su aceptación local.

