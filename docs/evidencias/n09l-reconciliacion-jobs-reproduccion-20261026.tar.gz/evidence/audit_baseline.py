import hashlib,json,math,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n09-l-20261026');P=Path('artifacts/local-ci')/sys.argv[1]
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f,r,h=read(W/'baseline-freeze.json'),read(P/'result.json'),read(P/'source-hashes.json')
assert r['result']=='PASS' and r['sources_unchanged'] and r['selection']==f['selection'] and r['workers']==1
assert all(sha(p)==v for p,v in f['sources'].items())
assert set(f['sources'])-set(h)==set(f['sources_verified_separately'])
assert all(h[p]==v for p,v in f['sources'].items() if p in h)
cases=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==12
profiles=[];seen=set();total_messages=0;total_expired=0;total_phases=0
for c in cases:
 assert all(c.find(k)is None for k in ['failure','error','skipped'])
 props={x.get('name'):x.get('value') for x in c.iter('property')};d=json.loads(props['owned_job_reconcile_profile']);assert d['status']=='passed'
 mode,n=d['mode'],d['volume'];assert(mode,n)not in seen;seen.add((mode,n));target=3 if mode=='mixed' else n
 assert d['target_count']==target and d['pins_count']==5 and d['rows_before_count']==d['rows_after_count']==target+5
 assert d['pins_before_sha256']==d['pins_after_sha256']
 assert d['owned_queue_keys_removed'] and d['broker_context_exited'] and d['redis_context_exited']
 if mode=='dispatch':
  names=['first_dispatch']+(['dispatch_continuation']if n==101 else[])+['queued_immediate_replay'];selected=[min(n,100)]+([1]if n==101 else[])+[0];expired=[0]*len(names);results=selected;injected=[0]*len(names)
 elif mode=='expiry':
  names=['first_expiry']+(['expiry_continuation']if n==101 else[])+['expiry_replay'];expired=[min(n,100)]+([1]if n==101 else[])+[0];selected=[0]*len(names);results=selected;injected=[0]*len(names)
 elif mode=='mixed':names=['mixed_first','mixed_running_repeat'];selected=[3,1];expired=[0,0];results=selected;injected=[0,0]
 else:
  assert mode=='failure' and n==2
  names=['broker_failure','first_dispatch','queued_immediate_replay'];selected=[2,2,0];expired=[0,0,0];results=[0,2,0];injected=[2,0,0]
 phases=d['phases'];assert [p['phase']for p in phases]==names
 assert [p['selected_rows']for p in phases]==selected and [p['expired_rows']for p in phases]==expired
 assert [p['reconcile_result']for p in phases]==results and [p['injected_failures']for p in phases]==injected
 previous=0
 for p,s,e,result,inj in zip(phases,selected,expired,results,injected,strict=True):
  assert p['eager_disabled_before_call'] and p['eager_disabled_after_call']
  assert p['task_return_none'] and p['dispatch_calls']==s and p['dispatch_success']==result==p['broker_publications']
  assert p['broker_calls']==result and p['dispatch_calls']==p['broker_calls']+p['injected_failures']
  assert p['actual_messages_before']==previous and p['actual_messages_after']==previous+result;previous+=result
  assert p['rows_before_count']==p['rows_after_count']==target+5
  changed=e+(result if mode!='mixed' else 2 if p['phase']=='mixed_first' else 0)
  assert p['actual_changed_rows']==changed and p['immutable_before_sha256']==p['immutable_after_sha256']
  assert p['domain_before']==p['domain_after'] and p['media_before']==p['media_after']
  assert all(math.isfinite(p[k]) and p[k]>=0 for k in ['wall_seconds','sql_seconds','dispatch_seconds','broker_seconds'])
  assert p['wall_seconds']>=max(p['sql_seconds'],p['dispatch_seconds'],p['broker_seconds']) and p['dispatch_seconds']>=p['broker_seconds']
  assert p['sql_count']==sum(x['count']for x in p['operations'].values()) and p['sql_count']>=2
  assert not({'INSERT','DELETE'}&set(p['operations']))
  if inj:assert p['injected_failure_type']=='ConnectionError' and p['actual_changed_rows']==0 and p['target_before_sha256']==p['target_after_sha256']
  total_expired+=e;total_phases+=1
 total_messages+=previous
 assert abs(sum(p['wall_seconds']for p in phases)-d['measured_seconds'])<1e-8
 assert abs(d['case_seconds']-d['measured_seconds']-d['non_measured_seconds'])<1e-8
 assert d['case_seconds']>=d['setup_seconds']>=0 and d['cleanup_seconds']>=0
 profiles.append(d)
assert seen=={(mode,n)for mode in ['dispatch','expiry']for n in [0,1,10,100,101]}|{('mixed',0),('failure',2)}
assert total_phases==27 and total_messages==218 and total_expired==212
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q']
 assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists()
tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_TWELVE_FINITE_JOB_RECONCILE_BASELINE_NOT_WHOLE_N09','run':P.name,'junit':r['junit'],'frozen_sources':len(f['sources']),'phases':total_phases,'actual_messages':total_messages,'expired_rows':total_expired,'profiles':profiles,'cleanup_verified':True,'telegram':tg,'scope':'NativeTask.run/realreconcile/ownedPGactualRedisuniquequeues/IDonly/no worker/generation/Beat/provider. N1instrumented/noafter/noappchange;expiry100dispatch100distinct/runningmixedatleastoncerepublication;N09139open8of13.'}
(W/'baseline-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='profiles'}))
