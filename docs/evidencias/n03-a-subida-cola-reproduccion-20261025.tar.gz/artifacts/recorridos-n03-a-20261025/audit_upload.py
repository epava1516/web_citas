import hashlib,json,math,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n03-a-20261025');run=sys.argv[1];P=Path('artifacts/local-ci')/run;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
f=read(W/'freeze.json');r=read(P/'result.json');assert r['result']=='PASS' and r['sources_unchanged'];assert r['selection']==['tests/test_photo_upload_queued_reference.py'] and r['workers']==1
assert len(r['junit'])==1 and r['junit'][0]['tests']=='1' and all(r['junit'][0][k]=='0' for k in ['errors','failures','skipped'])
assert all(Path(p).is_file() and sha(p)==h for p,h in f['sources'].items())
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==1 and not any(cs[0].findall(k) for k in ['failure','error','skipped']);props={x.attrib['name']:x.attrib['value'] for x in cs[0].iter('property')};d=json.loads(props['n03a_upload_queued_reference']);assert d==read(P/'n03a-runtime.json')
assert d['worker_root_exited'] and d['worker_exit_code']==0 and all(d['processes_absent'].values()) and len(d['pid_start_ticks'])>=3
assert d['runtime_role_removed'] and d['private_credentials_removed'] and d['foreign_keys_preserved'] and d['unexpected_unscoped_keys']==0
assert len(d['samples'])==2 and [s['media_task_count'] for s in d['samples']]==[1,0]
for ordinal,s in enumerate(d['samples'],1):
 assert s['ordinal']==ordinal and s['status']==302 and s['task_always_eager'] is False
 for k in ['request_seconds','request_thread_cpu_seconds','sql_execute_seconds','after_request_ready_observed_seconds','entry_to_ready_observed_seconds']:
  assert math.isfinite(s[k]) and s[k]>=0
 assert s['entry_monotonic']<=s['request_end_monotonic']<=s['ready_observed_monotonic']
 assert abs(s['entry_to_ready_observed_seconds']-(s['request_seconds']+s['after_request_ready_observed_seconds']))<1e-8
 assert isinstance(s['sql_queries'],int) and s['sql_queries']>=0
 for t in s['ledger']:
  assert t['task'] in {'apps.mediafiles.tasks.process_blob','apps.listings.tasks.refresh_publication_state'} and t['state']=='SUCCESS' and t['eager'] is False
  assert str(t['worker_pid']) in d['pid_start_ticks'] and t['publish_monotonic']<=t['worker_start_monotonic']<=t['worker_end_monotonic']
  assert abs(t['publish_to_start_seconds']-(t['worker_start_monotonic']-t['publish_monotonic']))<1e-8
  assert abs(t['worker_wall_seconds']-(t['worker_end_monotonic']-t['worker_start_monotonic']))<1e-8
inventory={}
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];q=subprocess.run(cmd+['--filter',f'label=web-modelos-local-ci-run={run}'],capture_output=True,text=True,check=True);inventory[kind]=q.stdout.split();assert not inventory[kind]
runner=read(P/'runner.json');assert not Path(runner['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_N03A_REAL_QUEUED_UPLOAD_REFERENCE_NOT_N03_ACCEPTANCE','run':run,'head':f['head'],'junit':r['junit'],'junit_sha256':sha(P/'pytest.xml'),'source_count':len(f['sources']),'source_mismatches':[],'reference':d,'independent_inventory':inventory,'temporary_absent':True,'terminal_telegram':tg,'native_manifest':read(P/'native-manifest.json'),'steps':[{k:v for k,v in x.items() if k!='command'} for x in r['steps']],'scope':d['scope']}
(W/'upload-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('AUDITED',run)
for s in d['samples']:
 print(s['kind'],'request_ms',round(1000*s['request_seconds'],3),'SQL',s['sql_queries'],'after_ready_ms',round(1000*s['after_request_ready_observed_seconds'],3),'total_observed_ms',round(1000*s['entry_to_ready_observed_seconds'],3))
 for t in s['ledger']:print(t['task'],'queue_ms',round(1000*t['publish_to_start_seconds'],3),'worker_ms',round(1000*t['worker_wall_seconds'],3))
