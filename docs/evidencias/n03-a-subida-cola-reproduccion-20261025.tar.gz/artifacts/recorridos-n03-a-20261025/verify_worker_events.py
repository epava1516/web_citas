import json
from pathlib import Path
W=Path('artifacts/recorridos-n03-a-20261025');a=json.loads((W/'upload-audit.json').read_text());P=Path('artifacts/local-ci')/a['run'];d=a['reference'];publishes=json.loads((P/'n03a-publishes.json').read_text());events=[]
for path in (P/'n03a-events').glob('*.jsonl'):
 assert path.stat().st_size<=2*1024*1024
 for line in path.read_bytes().splitlines(keepends=True):
  assert line.endswith(b'\n');events.append(json.loads(line))
executions={e['id']:e for e in events if e['event']=='execution'}
assert sum(e['task']=='apps.mediafiles.tasks.process_blob' for e in executions.values())==1
for sample in d['samples']:
 for task in sample['ledger']:
  e=executions[task['task_id']];pub=next(x for x in publishes if x['id']==task['task_id'])
  assert pub['task']==e['task']==task['task'] and pub['monotonic']==task['publish_monotonic']
  assert e['role']=='worker' and e['pid']==task['worker_pid'] and e['state']=='SUCCESS' and e['eager'] is False
  assert e['start_monotonic']==task['worker_start_monotonic'] and e['end_monotonic']==task['worker_end_monotonic']
  assert e['wall']==task['worker_wall_seconds'] and e['thread_cpu']==task['worker_thread_cpu_seconds'] and 'snapshot_error' not in e
for pid,ticks in d['pid_start_ticks'].items():
 path=Path('/proc')/pid/'stat'
 if path.exists():assert int(path.read_text().rsplit(')',1)[1].split()[19])!=ticks
proof={'result':'PASS_N03A_INDEPENDENT_WORKER_EVENT_CORRELATION','run':a['run'],'execution_count':len(executions),'media_execution_count':1,'sample_ledger_correlated':True,'pid_start_ticks_absent_or_reused':True,'scope':'Own parent publication journal and actual worker execution events, no subject IDs or credentials.'};(W/'worker-events-verification.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
