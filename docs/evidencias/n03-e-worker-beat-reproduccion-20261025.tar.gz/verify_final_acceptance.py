import hashlib,json,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n03-e-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
a=read(W/'worker-beat-audit.json');f=read(W/'freeze.json');P=Path('artifacts/local-ci')/a['run'];r=read(P/'result.json')
assert r['result']=='PASS' and r['sources_unchanged'] and r['selection']==f['selection']
assert all(sha(p)==h for p,h in f['sources'].items() if p!='.ai/tasks/desarrollo.md')
prior=read(Path('artifacts/recorridos-n03-d-20261025/candidate-freeze.json'))['sources'];assert all(f['sources'][p]==h for p,h in prior.items() if p.startswith(('apps/','config/')))
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==1 and not any(cs[0].find(k)is not None for k in ['failure','error','skipped'])
d=json.loads(next(x.attrib['value'] for x in cs[0].iter('property') if x.attrib['name']=='n03e_media_worker_recovery'));assert d==a['runtime']==read(P/'n03e-runtime.json')
assert d['complete'] and d['runtime_role_removed'] and d['private_credentials_removed'] and d['private_runtime_removed']
assert all(d['processes_absent'].values()) and d['worker_exit_code']==d['beat_exit_code']==0
for pid,ticks in d['pid_start_ticks'].items():
 try:current=int((Path('/proc')/pid/'stat').read_text().rsplit(')',1)[1].split()[19])
 except FileNotFoundError:continue
 assert current!=ticks
assert read(P/'telegram-notification.json')['delivery']=='sent' and not Path(read(P/'runner.json')['temporary']).exists()
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];q=subprocess.run(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],capture_output=True,text=True,check=True);assert not q.stdout.strip()
for path in [W/'writer-report.json',W/'prereg/report.json',W/'final-graph/report.json']:
 report=read(path);assert report['STATUS']=='complete' and isinstance(report['IMPLEMENTATION_NOTES'],str) and isinstance(report['TEST_RESULTS'],str)
 for k in ['FILES_CHANGED','TESTS_RUN','ASSUMPTIONS','RISKS','UNRESOLVED_ISSUES','RECOMMENDATIONS']:assert isinstance(report[k],list)
for p,row in read(W/'writer-integration-scope.json').items():assert sha(p)==row['integrated_sha256']
assert len(a['retry_delivery_observations'])==3 and all(row['publish_to_execution_start_seconds']>=max(0,row['eta_remaining_seconds_at_publish'] or 0) for row in a['retry_delivery_observations'])
out={'result':'PASS_LOCAL_N03E_REAL_WORKER_BEAT_NOT_N03_BLOCK_ACCEPTANCE','functional_cases':1,'actual_task_executions':38,'actual_events':101,'same_message_retry_executions':4,'real_validation_failure_no_retry':True,'real_beat_recovered_distinct_cohort':4,'native_media_schedule_seconds':60,'app_config_unchanged_from_N03D':True,'source_hashes_current_except_declared_worklog_delta':True,'all_pids_roles_credentials_private_and_runner_resources_gone':True,'terminal_telegram_sent':True,'native_reports_strict_schema':True,'limits':['Not global retry maximum','Not worker kill/redelivery','Not direct raw argument mapping','Not latency SLA/capacity/provider'],'N03_still_open':True}
(W/'acceptance-verification.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
