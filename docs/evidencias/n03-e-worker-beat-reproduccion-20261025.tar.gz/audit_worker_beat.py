import collections,hashlib,json,math,subprocess,xml.etree.ElementTree as E
from pathlib import Path
from datetime import datetime
W=Path('artifacts/recorridos-n03-e-20261025');P=Path('artifacts/local-ci/20261025-192053-4c827d97');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
f=read(W/'freeze.json');r=read(P/'result.json');assert r['result']=='PASS' and r['sources_unchanged'] and r['workers']==1 and r['selection']==f['selection']
assert r['junit'][0]['tests']=='1' and all(r['junit'][0][k]=='0' for k in ['errors','failures','skipped'])
assert all(Path(p).is_file() and sha(p)==h for p,h in f['sources'].items())
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==1 and not any(cs[0].find(k)is not None for k in ['failure','error','skipped'])
props={x.attrib['name']:x.attrib['value'] for x in cs[0].iter('property')};d=json.loads(props['n03e_media_worker_recovery']);assert d==read(P/'n03e-runtime.json')
assert d['complete'] and d['schedule_seconds']==60.0 and d['runtime_role'].startswith('capacity_runtime_')
assert d['runtime_role_removed'] and d['private_credentials_removed'] and d['private_runtime_removed'] and not d['cleanup_errors']
assert 'final_snapshot_error' not in d and 'role_cleanup_snapshot_error' not in d
assert d['worker_exit_code']==0 and d['beat_exit_code'] in [0,-15]
assert d['foreign_keys_preserved'] and d['unexpected_unscoped_keys']==0 and all(d['processes_absent'].values())
assert len(d['pid_start_ticks'])>=4 and d['worker_root_pid']!=d['beat_root_pid']
for pid,ticks in d['pid_start_ticks'].items():
 try:s=Path('/proc')/pid/'stat';current=int(s.read_text().rsplit(')',1)[1].split()[19])
 except FileNotFoundError:continue
 assert current!=ticks
assert sorted(int(k) for k in d['fixture_manifest'])==f['fixture_seeds']
assert len({v['canonical_sha256'] for v in d['fixture_manifest'].values()})==10
assert all(v['canonical_bytes']>0 and v['width']==640 and v['height']==480 for v in d['fixture_manifest'].values())
events=d['events'];assert len(events)<=2000 and not any('snapshot_error' in e for e in events)
MEDIA='apps.mediafiles.tasks.process_blob';RECOVER='apps.mediafiles.tasks.recover_media_jobs';REFRESH='apps.listings.tasks.refresh_publication_state'
assert all(e['task'] in [MEDIA,RECOVER,REFRESH] for e in events)
execs=[e for e in events if e['event']=='execution'];keys=[(e['id'],e['retries']) for e in execs];assert len(keys)==len(set(keys))
assert all(e['role']=='worker' and e['eager'] is False and e['sql_role']==d['runtime_role'] and str(e['pid']) in d['pid_start_ticks'] and e['pid'] not in [d['worker_root_pid'],d['beat_root_pid']] for e in execs)
pubs=d['harness_publishes']+[e for e in events if e['event']=='publish'];assert {(e['id'],e['retries']) for e in pubs}==set(keys)
pre={(e['id'],e['retries']) for e in events if e['event']=='prerun'};assert pre==set(keys)
for e in events:
 for k in ['monotonic','wall_epoch','start_monotonic','end_monotonic','wall','thread_cpu','countdown']:
  if k in e:assert isinstance(e[k],(int,float)) and math.isfinite(e[k]) and e[k]>=0
 if e['event']=='execution':
  assert e['start_monotonic']<=e['end_monotonic'] and abs(e['wall']-(e['end_monotonic']-e['start_monotonic']))<1e-8
A=d['phases']['storage_retry'];B=d['phases']['validation_failure'];D=d['phases']['beat_recovery'];a_id,b_id=A['task_id'],B['task_id']
a_rows=sorted([e for e in execs if e['id']==a_id],key=lambda e:e['retries']);assert [e['retries'] for e in a_rows]==[0,1,2,3] and [e['state'] for e in a_rows]==['RETRY','RETRY','RETRY','FAILURE']
retry=sorted([e for e in events if e['event']=='retry' and e['id']==a_id],key=lambda e:e['retries']);assert len(retry)==3 and all(0<=e['countdown']<=limit and e['exception_type']=='FileNotFoundError' for e,limit in zip(retry,[1,2,4]))
failures={e['id']:e for e in events if e['event']=='failure'};assert set(failures)=={a_id,b_id};assert failures[a_id]['exception_type']=='FileNotFoundError' and failures[b_id]['exception_type']=='ValidationError'
assert len([e for e in execs if e['id']==b_id])==1 and not any(e['event']=='retry' and e['id']==b_id for e in events)
assert all(e['state']=='SUCCESS' for e in execs if e['id'] not in [a_id,b_id])
assert D['positive_distinct_blob_count']==4 and D['excluded_controls_before']==D['excluded_controls_after'] and D['excluded_controls_unchanged']
assert D['positive_attempts']=={'queued':1,'stale':2,'failed':2,'ready':1}
for label,s in D['positive_snapshots'].items():assert s['status']=='ready' and s['attempts']==D['positive_attempts'][label] and s['error_code']==''
assert D['tick']['role']=='beat' and D['tick']['pid']==d['beat_root_pid'] and D['tick']['task']==RECOVER
assert len(D['recovery'])==1 and D['recovery'][0]['state']=='SUCCESS' and D['recovery'][0]['start_monotonic']>=D['tick']['monotonic']
assert 0<=D['first_tick_observed_seconds']<=90 and D['tick_to_ready_observed_seconds']>=0
assert len(D['media_publishes'])==len({e['id'] for e in D['media_publishes']})==4
assert all(e['role']=='worker' and e['task']==MEDIA and e['retries']==0 for e in D['media_publishes'])
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];q=subprocess.run(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],capture_output=True,text=True,check=True);assert not q.stdout.strip()
assert not Path(read(P/'runner.json')['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_REAL_MEDIA_RETRY_WORKER_BEAT_REFERENCE_NOT_N03_BLOCK_ACCEPTANCE','run':P.name,'junit':r['junit'],'source_count':len(f['sources']),'sources_unchanged':True,'worker_root_pid':d['worker_root_pid'],'beat_root_pid':d['beat_root_pid'],'execution_counts':dict(collections.Counter(e['task'] for e in execs)),'event_count':len(events),'retry_countdowns':[e['countdown'] for e in retry],'first_tick_observed_seconds':D['first_tick_observed_seconds'],'publish_to_recovery_start_seconds':D['publish_to_recovery_start_seconds'],'tick_to_ready_observed_seconds':D['tick_to_ready_observed_seconds'],'runtime':d,'all_processes_roles_credentials_resources_removed':True,'telegram':tg,'limitations':['One-message retry bound, not global attempt maximum','One native60s firsttick, not interval distribution/SLA','Cohort bound by independent state transitions and4executions, not raw argument mapping','No HTTP/load/provider or hard worker-kill/redelivery proof']}
delivery=[]
for retry_number in [1,2,3]:
 pub=next(e for e in events if e['event']=='publish' and e['id']==a_id and e['retries']==retry_number)
 executed=next(e for e in execs if e['id']==a_id and e['retries']==retry_number)
 wait=executed['start_monotonic']-pub['monotonic'];assert wait>=0
 eta_remaining=None if pub['eta'] is None else datetime.fromisoformat(pub['eta']).timestamp()-pub['wall_epoch']
 if eta_remaining is not None:assert wait>=max(0,eta_remaining)
 delivery.append({'retries':retry_number,'publish_to_execution_start_seconds':wait,'eta_remaining_seconds_at_publish':eta_remaining})
out['retry_delivery_observations']=delivery
(W/'worker-beat-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='runtime'}))
