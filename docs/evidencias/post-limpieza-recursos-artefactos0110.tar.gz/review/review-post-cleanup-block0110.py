import collections, hashlib, json, math, os, statistics, sys
from pathlib import Path
root=Path('/home/felidae/proyectos/web_modelos');out=Path('/tmp/post-cleanup-resource-checkpoint0110')
folder=Path(sys.argv[1]);summary=json.loads((folder/'load-summary.json').read_text())
manifest=json.loads((out/'frozen-manifest.json').read_text())
for path,h in manifest['source_sha256'].items():
 assert hashlib.sha256((root/path).read_bytes()).hexdigest()==h,path
for path,h in summary['block_artifact_sha256'].items():
 assert hashlib.sha256((folder/path).read_bytes()).hexdigest()==h,path
assert summary['gunicorn_stopped'] and summary['database_absence'] and summary['media_absence']
assert all(summary['worker_pid_absence'].values())
assert not Path('/proc/'+str(summary['master_pid'])).exists()
# Recheck live DB absence independently (summary is not sufficient).
import psycopg
credentials={}
for line in (root/'.env').read_text().splitlines():
 k,sep,v=line.partition('=')
 if sep and k in {'POSTGRES_DB','POSTGRES_USER','POSTGRES_PASSWORD'}:credentials[k]=v.strip().strip('\"\'')
allnames=json.loads((out/'owned-databases.json').read_text())
with psycopg.connect(dbname=credentials.get('POSTGRES_DB','clasificados'),user=credentials.get('POSTGRES_USER','clasificados'),password=credentials['POSTGRES_PASSWORD'],host='127.0.0.1',port=55432,autocommit=True) as conn:
 assert not conn.execute('SELECT datname FROM pg_database WHERE datname=%s',[allnames[-1]]).fetchall()
if not (folder/'benchmark-samples.json').exists():
 release={'partial':True,'reviewed':True,'source_hashes_verified':True,'own_cleanup_independently_verified':True,'trial_stop':summary.get('trial_stop')}
 (folder/'review-release.json').write_text(json.dumps(release,indent=2)+'\n'); print(release); sys.exit(0)
from scripts.benchmark_accounting import counts,review,distribution
ledger=json.loads((folder/'benchmark-samples.json').read_text())
rows,uploads=ledger['dynamic'],ledger['uploads']
raw=json.loads((folder/'benchmark-worker-events.json').read_text()); assert not raw['parse_errors']
probe=json.loads((folder/'resource-samples.jsonl.summary.json').read_text())
snapshots=[json.loads(l)for l in (folder/'resource-samples.jsonl').read_text().splitlines()]
starts,ends,routes={},{},{}
for event in raw['events']:
 target=starts if event['event']=='wsgi_start' else ends if event['event']=='wsgi_end' else routes if event['event']=='publication_route' else None
 if target is not None:
  assert event['id']not in target; target[event['id']]=event
assert len(rows)==600 and len({r['id']for r in rows})==600
assert len(uploads)==1 and counts(rows)==summary['counts'] and counts(uploads)==summary['final_upload_counts']
origin=summary['monotonic_origin_seconds'];duration=30;end=origin+duration
recomputed=review(rows,duration=30,rps=20,policy=summary['policy'])
assert recomputed['observable_latency_seconds']==summary['observable_latency_seconds']
assert recomputed['generator_delay_seconds']==summary['generator_delay_seconds']
assert recomputed['counts']==summary['counts']
def family(path):return 'search' if '?q='in path else 'detail' if '/listing/'in path else 'listing'
records=[]
for row in rows+uploads:
 identity=row['id'];entry=starts.get(identity,{}).get('started');exit_=entry+ends[identity]['wall']if entry is not None and identity in ends else None
 emission=origin+row['emitted_at']if row['emitted_at']is not None else None
 if entry is not None:
  assert emission is not None and entry>=emission
  if identity in ends:assert starts[identity]['pid']==ends[identity]['pid']
 records.append({'id':identity,'family':'upload'if identity.startswith('u-')else family(row['path']),
 't_emission':emission,'t_deadline':emission+65 if emission is not None else None,
 't_client_timeout_observed':origin+row['ended_at']if row.get('timeout')and row['ended_at']is not None else None,
 't_client_terminal':origin+row['ended_at']if row['ended_at']is not None else None,
 'client_success':not row.get('unexpected',True)if row['ended_at']is not None else None,
 't_wsgi_entry':entry,'t_wsgi_exit':exit_,'service':ends[identity]['wall']if identity in ends else None,
 'thread_cpu':ends[identity]['thread_cpu']if identity in ends else None,
 'pid':starts[identity]['pid']if identity in starts else None})
dynamic=[r for r in records if r['family']!='upload'];complete=[r for r in dynamic if r['service']is not None]
means={f:{'N':len(g),'mean_wsgi_seconds':statistics.mean(r['service']for r in g),'mean_thread_cpu_seconds':statistics.mean(r['thread_cpu']for r in g)}for f in ['listing','search','detail']if(g:=[r for r in complete if r['family']==f])}
D=sum(v['mean_wsgi_seconds']/3 for v in means.values())if len(means)==3 else None
uploadrecords=[r for r in records if r['family']=='upload'];U=uploadrecords[0]['service']
occupancy={}
for pid in sorted({r['pid']for r in records if r['pid']is not None}):
 g=sorted([r for r in records if r['pid']==pid and r['t_wsgi_exit']is not None],key=lambda r:r['t_wsgi_entry'])
 for a,b in zip(g,g[1:]):assert a['t_wsgi_exit']<=b['t_wsgi_entry']
 occupancy[str(pid)]={'N_complete':len(g),'worker_seconds_in_emission':sum(max(0,min(end,r['t_wsgi_exit'])-max(origin,r['t_wsgi_entry']))for r in g)}
 assert occupancy[str(pid)]['worker_seconds_in_emission']<=30
serial=summary['serial_reference'];warm_pids={starts[r['id']]['pid']for r in serial if r['id']in starts}
hz=probe['clock_ticks_per_second'];master=probe['app_master_pid'];pginit=probe['postgres_container_host_pid']
# Exclude owned generator/collector/pytest and runner processes from unrelated-host residual.
first_procs={p['pid']:p for p in snapshots[0]['processes']}
owned_client=first_procs[master]['ppid'];owned_runner=first_procs[owned_client]['ppid']
def numbers(text):
 if text=='not_measured':return {}
 return {l.split()[0].rstrip(':'):int(l.split()[1])for l in text.splitlines()if len(l.split())==2 and l.split()[1].isdigit()}
def group_cpu(sample):
 chain=sample['pg_cgroups']
 if not isinstance(chain,dict):return None
 leaf=next(iter(chain.values()));return numbers(leaf['cpu.stat']).get('usage_usec',0)/1e6 if leaf['cpu.stat']!='not_measured'else None
def analyze_resources(samples):
 if len(samples)<2:return 'not_measured'
 first,last=samples[0],samples[-1];dt=last['monotonic']-first['monotonic'];app_cpu=client_cpu=own_pg=0.;other=collections.Counter();waits=collections.Counter();other_db_active=0;appworkers=set();missing_intervals=0
 for a,b in zip(samples,samples[1:]):
  pa={p['pid']:p for p in a['processes']};pb={p['pid']:p for p in b['processes']};app={p['pid']for p in a['processes']if p['pid']==master or p['ppid']==master};appworkers|=app-{master}
  pg_group=pa.get(pginit,{}).get('cgroup')
  activity=[x for x in a['pg_activity']if x[2]]if isinstance(a['pg_activity'],list)else []
  ns={x[0]for x in activity};ownhosts={p['pid']for p in a['processes']if p['cgroup']==pg_group and (p.get('namespace_pids')or[None])[-1]in ns}
  for x in activity:
   if x[3]=='active':waits[(x[4]or'none',x[5]or'none')]+=1
  if isinstance(a['pg_activity'],list):other_db_active+=sum(x[3]=='active'and x[2]is False for x in a['pg_activity'])
  for pid,p in pa.items():
   q=pb.get(pid)
   if q is None or p['start_ticks']!=q['start_ticks']:
    missing_intervals+=int(pid in app or p['cgroup']==pg_group);continue
   delta=(q['cpu_ticks']-p['cpu_ticks'])/hz;assert delta>=0
   if pid in app:app_cpu+=delta
   elif pid in {owned_client,owned_runner}:client_cpu+=delta
   elif pid in ownhosts:own_pg+=delta
   if pid not in app and pid not in {owned_client,owned_runner} and p['cgroup']!=pg_group:other[(p['cgroup'],p['comm'])]+=delta
  assert len(app-{master})==summary['workers']
 pgfirst,pglast=group_cpu(first),group_cpu(last);pgcpu=pglast-pgfirst if pgfirst is not None and pglast is not None else None
 deltas=[y-x for x,y in zip(first['host_cpu_ticks'],last['host_cpu_ticks'])];hostcpu=sum(deltas[i]for i in [0,1,2,5,6])/hz
 residual=(hostcpu-app_cpu-client_cpu-pgcpu)/dt if pgcpu is not None else None
 slice_successes=sum(r['client_success']is True and r['t_client_terminal']is not None and first['monotonic']<=r['t_client_terminal']<=last['monotonic'] for r in dynamic)
 cgroups={}
 for label,key in [('app','app_cgroups'),('postgres','pg_cgroups')]:
  cgroups[label]={}
  if not isinstance(first[key],dict):continue
  for group,v in first[key].items():
   z=last[key].get(group,{})
   cgroups[label][group]={'cpu.max':v['cpu.max'],'cpuset':v['cpuset.cpus.effective'],'memory.max':v['memory.max'],'memory.high':v['memory.high'],'cpu.weight':v['cpu.weight'],
    'cpu_stat_delta':{k:numbers(z.get('cpu.stat','not_measured'))[k]-value for k,value in numbers(v['cpu.stat']).items()if k in numbers(z.get('cpu.stat','not_measured'))},
    'memory_events_delta':{k:numbers(z.get('memory.events','not_measured'))[k]-value for k,value in numbers(v['memory.events']).items()if k in numbers(z.get('memory.events','not_measured'))},
    'PSI':{k:v[k]for k in ['cpu.pressure','memory.pressure','io.pressure']},
    'io.stat_first':v.get('io.stat','not_measured'),'io.stat_last':z.get('io.stat','not_measured')}
 def procio(sample,kind):
  return {pid:numbers(text)for pid,text in sample.get(kind,{}).items()}
 io={}
 for kind in ['app_process_io','postgres_process_io']:
  a,b=procio(first,kind),procio(last,kind)
  io[kind]={'status':'measured' if any(a.values()) else 'not_measured','readable_pids':sum(bool(v)for v in a.values()),'persistent_process_counter_deltas':{pid:{k:b[pid][k]-v for k,v in values.items()if k in b[pid]}for pid,values in a.items()if pid in b},'scope':'Linux counters only, unavailable fields absent; sharedPG not individualSQL I/O'}
 return {'sample_start_offset':first['monotonic']-origin,'sample_end_offset':last['monotonic']-origin,'interval_seconds':dt,'samples':len(samples),
 'app_CPU_seconds':app_cpu,'app_mean_CPU_cores':app_cpu/dt,'owned_client_collector_runner_CPU_seconds':client_cpu,'postgres_shared_CPU_seconds':pgcpu,'postgres_mean_CPU_cores':pgcpu/dt if pgcpu is not None else 'not_measured',
 'own_pg_backend_CPU_seconds_lower_bound':own_pg,'host_execution_CPU_seconds':hostcpu,'host_mean_CPU_cores':hostcpu/dt,
 'unrelated_host_residual_mean_CPU_cores':residual,'other_persistent_process_CPU_seconds_lower_bound':sum(other.values()),
 'other_top_commands': [{'cgroup':k[0],'comm':k[1],'CPU_seconds':v}for k,v in other.most_common(8)],
 'CPU_slice_client_successes':slice_successes,'app_CPU_seconds_per_success_operational_slice':app_cpu/slice_successes if slice_successes else 'not_measured',
 'host_iowait_seconds':deltas[4]/hz,'host_steal_seconds':deltas[7]/hz,'process_churn_missing_CPU_intervals':missing_intervals,
 'pg_active_own_wait_samples':[{'wait_event_type':k[0],'wait_event':k[1],'observations':v}for k,v in waits.items()], 'other_database_active_samples':other_db_active,
 'max_pg_own_connections_sampled':max(sum(x[2]is True and x[1]=='client backend'for x in s['pg_activity'])for s in samples if isinstance(s['pg_activity'],list)),
 'max_pg_shared_connections_sampled':max(sum(x[1]=='client backend'for x in s['pg_activity'])for s in samples if isinstance(s['pg_activity'],list)),
 'mem_available_min':min(s['meminfo']['MemAvailable']for s in samples),'swap_free_min':min(s['meminfo']['SwapFree']for s in samples),
 'vmstat_deltas':{k:last['vmstat'].get(k,v)-v for k,v in first['vmstat'].items()},'host_PSI':first['host_pressure'],'cgroups':cgroups,'io':io,
 'app_RSS_first':sum(p['rss_bytes']for p in first['processes']if p['pid']==master or p['ppid']==master),
 'app_RSS_last':sum(p['rss_bytes']for p in last['processes']if p['pid']==master or p['ppid']==master),
 'app_RSS_sampled_max':max(sum(p['rss_bytes']for p in s['processes']if p['pid']==master or p['ppid']==master)for s in samples),
 'postgres_cgroup_memory_sampled_max':max(int(next(iter(s['pg_cgroups'].values()))['memory.current'])for s in samples),
 'host_diskstats_first':first.get('host_diskstats','not_measured'),'host_diskstats_last':last.get('host_diskstats','not_measured')}
window=[s for s in snapshots if origin<=s['monotonic']<=end]
# Enclosing observations retain full cohort CPU with explicit extra margins; do not pretend exact per-request attribution.
cohort_end=max([r['t_wsgi_exit']or r['t_client_terminal']or origin for r in records]+[origin])
left=max([i for i,s in enumerate(snapshots)if s['monotonic']<=origin],default=0)
right=next((i for i,s in enumerate(snapshots)if s['monotonic']>=cohort_end),len(snapshots)-1)
cohort=snapshots[left:right+1]
windowcounts=counts([{**r, 'ended_at':None}if r['ended_at']is not None and r['ended_at']>30 else r for r in rows])
assert windowcounts==summary['window_close']['dynamic']
checks={'scenario':summary['dataset']['published']==10000 and collections.Counter(family(r['path'])for r in rows)=={'listing':200,'search':200,'detail':200},
 'generator':not recomputed['invalid_reasons'],'accounting':counts(rows)['reconciled']and counts(uploads)['reconciled'],
 'timeout65':summary['policy']['request_timeout_seconds']==65,'drain70':summary['actual_elapsed_seconds']<=100.05,
 'pending_window_at_most20':windowcounts['pending']<=20,'final_pending_zero':counts(rows)['pending']==0,
 'latency':summary['observable_latency_seconds']['p95']<.8,'errors':summary['error_fraction_emitted']<.01,
 'upload':counts(uploads)['successful']==1 and uploads[0].get('status')==302}
verdict='INVALID'if not all(checks[k]for k in ['scenario','generator','accounting','timeout65'])or summary.get('trial_stop')else 'PASS'if all(checks.values())else 'FAIL'
pre=lambda items:[r['t_wsgi_entry']-r['t_emission']for r in items if r['t_wsgi_entry']is not None]
report={'index':summary['index'],'workers':summary['workers'],'source_hashes_verified':True,'own_cleanup_independently_verified':True,
 'scope':'30s diagnostic only; no60s gate or900s capacity acceptance','block_verdict':verdict,'transport_verdict':summary['verdict'],'checks':checks,
 'window':{'seconds':30,'counts':windowcounts,'successes_by_family':dict(collections.Counter(r['family']for r in dynamic if r['client_success']is True and r['t_client_terminal']<=end)),
 'throughput_client_successes_per_second':windowcounts['successful']/30,'pre_wsgi_entries_within_window':distribution(pre([r for r in dynamic if r['t_wsgi_entry']is not None and r['t_wsgi_entry']<=end])),
 'pre_wsgi_mean_entries_within_window':statistics.mean(pre([r for r in dynamic if r['t_wsgi_entry']is not None and r['t_wsgi_entry']<=end]))if any(r['t_wsgi_entry']is not None and r['t_wsgi_entry']<=end for r in dynamic)else 'not_measured',
 'occupancy_including_upload':occupancy,'resources':analyze_resources(window)},
 'cohort':{'counts':counts(rows),'uploads':counts(uploads),'observable_latency_seconds':summary['observable_latency_seconds'],'error_fraction':summary['error_fraction_emitted'],
 'drain_seconds':summary['actual_elapsed_seconds']-30,'observed_complete_wsgi':len(complete),'missing_complete_wsgi':600-len(complete),'means_by_family':means,
 'D_worker_seconds_per_request':D,'W20_without_upload':20*D if D is not None else None,
 'upload_wsgi':U,'upload_thread_CPU':uploadrecords[0]['thread_cpu'],'U_contractual_one_per_min':U/60 if U is not None else None,
 'upload_frequency_inferred_from_diagnostic':'none; singleeventnot2perminute; contractual1/min used separately','W20_contractual_including_upload':20*D+U/60 if D is not None and U is not None else None,
 'pre_wsgi_all_entered':distribution(pre(dynamic)),'pre_wsgi_all_entered_mean':statistics.mean(pre(dynamic))if pre(dynamic)else None,
 'thread_CPU_observed_dynamic_seconds':sum(r['thread_cpu']for r in complete),'resources_enclosing_cohort':analyze_resources(cohort),
 'requests_entering_wsgi_after_client_deadline':sum(r['t_wsgi_entry']is not None and r['t_wsgi_entry']>r['t_deadline']for r in dynamic),
 'requests_entering_wsgi_after_client_timeout_observed':sum(r['t_wsgi_entry']is not None and r['t_client_timeout_observed']is not None and r['t_wsgi_entry']>r['t_client_timeout_observed']for r in dynamic),
 'worker_seconds_after_deadline_observed':sum(max(0,r['t_wsgi_exit']-max(r['t_wsgi_entry'],r['t_deadline']))for r in complete),
 'thread_CPU_after_deadline_wholly_late_only':sum(r['thread_cpu']for r in complete if r['t_wsgi_entry']>r['t_deadline'])},
 'generator_delay_seconds':recomputed['generator_delay_seconds'],'warmup':{'serial_N':len(serial),'observed_worker_pids':sorted(warm_pids),'all_workers_observed':len(warm_pids)==summary['workers'],'body_hashes':summary['exact_body_hashes']},
 'upload_emission_monotonic':uploadrecords[0]['t_emission'],'actual_routes':dict(collections.Counter(routes[r['id']]['route']for r in dynamic if r['id']in routes)),
 'collector':{'N':len(snapshots),'elapsed_seconds':probe['elapsed'],'coverage_per_expected_1Hz':len(snapshots)/probe['elapsed'],
 'p95_full_poll_seconds':distribution(probe['sample_durations'])['p95'],'thread_CPU_seconds':probe['collector_thread_cpu'],
 'thread_CPU_per_elapsed_second':probe['collector_thread_cpu']/probe['elapsed'],'errors':probe['errors'],'fatal_error':probe['fatal_error']},
 'trial_stop':summary.get('trial_stop'),'clock_marks_artifact':'reconstructed-times.json',
 'not_measured':['causal WSGI/GC/PGmetadata overhead','exact socket/Gunicorn queue','CPU after deadline for straddling requests','individual PostgreSQL CPU/request','missing PSI interfaces','allocations/request','SQL rows and normalized query metrics during this concurrency experiment'],
 'limits':['WSGI events share host monotonic clock; start>=emission checked, no socketdispatch timestamp','CPU sampled scoped counters, snapshots sequential not atomic; interval boundaries/margins explicit','PG CPU includes sharedservice/background; ownbackend counts partial/churn lowerbound','unrelated host residual subtracts app,sharedPG,ownedpytest/sampler/client andrunner; includes kernel/unobserved activity, not individual service attribution','procIO and diskstats scoped cumulative counters, not SQL rows, wait time or request IO','D/W use means of observed complete populations and equalcontractweights; missing WSGI is not zero and can bias selection','30s block fails capacity even when eventual client successes; no reclassification of late server successes','CPU/successwindow operationalratio not individualCPU/request; cohortCPU includes enclosing sample margins','RSS maxima sampled and includes sharedpages; not additive physical memory; absent PSI is not no pressure']}
(folder/'reconstructed-times.json').write_text(json.dumps(records,indent=2)+'\n')
(folder/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
(folder/'review-release.json').write_text(json.dumps({'reviewed':True,'block_verdict':verdict,'sources_verified':True,'cleanup_verified':True,'analysis_sha256':hashlib.sha256((folder/'analysis.json').read_bytes()).hexdigest()},indent=2)+'\n')
print(json.dumps({k:report[k]for k in ['index','workers','block_verdict','warmup','generator_delay_seconds','trial_stop']}))
print(json.dumps({'window':windowcounts,'p95':report['cohort']['observable_latency_seconds']['p95'],'D':D,'CPUwindow':{k:v for k,v in report['window']['resources'].items()if k in ['app_mean_CPU_cores','postgres_mean_CPU_cores','host_mean_CPU_cores','unrelated_host_residual_mean_CPU_cores']},'collector':report['collector']}))
