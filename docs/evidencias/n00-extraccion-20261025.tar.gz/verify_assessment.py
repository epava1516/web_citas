"""Independent coverage/identity gate; does not accept N00 or product performance."""
import collections,hashlib,json
from pathlib import Path
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
x=json.loads(Path('docs/evidencias/inventario-acciones-final-20261025.json').read_text());a=json.loads(Path('docs/evidencias/n00-matriz-acciones-prioridades-20261025.json').read_text());rows=a['actions']
assert sha(a['inventory_source'])==a['inventory_sha256']
assert len(rows)==len({r['id'] for r in rows})
expected={'route':170,'task':27,'own_command':15,'framework_command':31,'runbook':11,'admin_pattern':16,'admin_global_action':1,'beat':25,'dispatch':14,'signal_connection':1,'template':129,'javascript':3}
assert dict(collections.Counter(r['kind'] for r in rows))==expected==a['counts_by_unit']
families={f'I{i:02d}' for i in range(1,29)};assert {f['id'] for f in a['families']}==families
for r in rows:
 assert r['families'] and set(r['families'])<=families
 assert r['blocks'] and r['authority'] and r['risk_if_regressed'] and r['evidence']
 assert r['usage_frequency']=='unknown_no_real_users_or_analytics'
 assert r['performance_state'].startswith('scenario_assignment_pending_N01')
 for p,h in r['source_sha256'].items():assert sha(p)==h,p
 for p in r['evidence']:assert Path(p).is_file(),p
routes={r['id']:r for r in rows if r['kind']=='route'}
for r in x['routes']:
 q=routes['route:'+r['id']]
 assert q['families']==r['families'] and q['variants_and_dependencies']['control_variants']==r['literal_control_variants']
 assert q['variants_and_dependencies']['methods']==r['details']['explicit_method_guard']
 assert q['authority']==r['authority_sources']
for f in a['families']:
 assert set(f['actions'])=={r['id'] for r in rows if f['id'] in r['families']} and f['actions']
 assert f['selected_scenarios']
 for p,h in f['source_fingerprints'].items():assert sha(p)==h,p
assert a['selected_scenario_groups'][0]['block']=='N04'
assert {f for s in a['selected_scenario_groups'] for f in s['families']}==families
assert len({s['id'] for s in a['selected_scenario_groups']})==9
assert {s['block'] for s in a['selected_scenario_groups']}=={f'N{i:02d}' for i in range(2,11)}
product=json.loads(Path('docs/evidencias/b16-final-candidate-reconciliation-20261025.json').read_text())['current_versioned_executable_sources']
assert len(product)==1507
for p,h in product.items():assert sha(p)==h,p
assert sha('docs/111-inventario-rendimiento-recorridos-beta-20261020.md')=='380b026c51b5e9647052838bb77a0712e9efff4ccdd857b5df3d4b545d921a95'
result={'result':'PASS_N00_STRUCTURAL_COVERAGE_AND_SOURCE_IDENTITY','families':28,'counts_by_distinct_unit':expected,'source_hash_mismatches':0,'accepted_executable_sources_unchanged':1507,'scenario_groups':9,'original111_unchanged':True,'assessment_sha256':sha('docs/evidencias/n00-matriz-acciones-prioridades-20261025.json'),'no_new_runtime_acceptance':True,'N00_accepted_by_this_gate':False,'remaining':['semantic_graph_reconciliation','primary_technical_acceptance_and_N01_preregistration'],'limits':a['limits']}
Path('docs/evidencias/n00-verificacion-matriz-20261025.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
