"""Source-identity based N00 assessment; no new runtime or latency claims."""
import collections,hashlib,json,subprocess
from pathlib import Path
W=Path('artifacts/recorridos-n00-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=Path('docs/evidencias/inventario-acciones-final-20261025.json');x=json.loads(base.read_text())
product=json.loads(Path('docs/evidencias/b16-final-candidate-reconciliation-20261025.json').read_text())['current_versioned_executable_sources']
for p,h in product.items():assert sha(p)==h,p
for p,r in x['source_fingerprints'].items():assert sha(p)==r['current_sha256'],p
for r in x['framework_management_commands']:assert sha(r['source_file'])==r['source_sha256']
for r in x['operational_runbooks']:
 for p,h in r['source_sha256'].items():assert sha(p)==h,p
m=json.loads(Path('graphify-out/SOURCE_MANIFEST.json').read_text())
# Source cut before analysis/edits: this run must precede changing any graph source.
for p,r in m.items():assert sha(p)==r['sha256'],p
plan=json.loads(Path('artifacts/next-contract-20261025/roadmap-plan.json').read_text());byfamily=plan['families']
public={'I01','I02','I03','I04','I05','I06','I07','I08'}
private={'I09','I10','I11','I12','I13','I14','I15','I18','I20','I21','I22','I23'}
state={'I16','I17','I19','I24','I25'}
def hazards(families):
 s=set(families);out=[]
 if s&public:out.append('Public exposure/eligibility and population/bytes cost; preserve privacy and complete results')
 if s&private:out.append('Private subject/version/purpose/role authority and sensitive evidence; no permission inferred from inventory')
 if s&state:out.append('Mutation/idempotency/locks/revocation and deferred-work consistency')
 if s&{'I27','I28'}:out.append('Operator/process/storage authority and isolated recovery; never run destructive commands against unrelated environments')
 if s&{'I06','I13','I14','I15','I22','I26'}:out.append('Content/bytes/CPU/memory/queue bounds require scenario-specific measurement')
 return out or ['Cross-cutting presentation/transport: preserve applicable backend authority']
rows=[]
def add(kind,identity,families,source,detail,evidence=None,authority=None):
 families=families or ['I27'];sources=[source] if isinstance(source,str) else source
 rows.append({'id':kind+':'+identity,'kind':kind,'families':families,'blocks':sorted({b for f in families for b in byfamily[f]}),'sources':sources,'source_sha256':{p:sha(p) for p in sources if Path(p).is_file()},'authority':authority or 'Preserve source-specific handler/service or operator authority; no new guard verification by this assessment','risk_if_regressed':hazards(families),'variants_and_dependencies':detail,'functional_evidence_state':'retained_family_witness_only_not_individual_PASS','performance_state':'scenario_assignment_pending_N01; no new latency measurement','evidence':evidence or sorted({p for f in x['families'] if f['id'] in families for p in f['evidence_docs']}),'usage_frequency':'unknown_no_real_users_or_analytics','disposition':'retained_source_scope; measure_or_justify_equivalent_witness_in_linked_block','source_delta':'conserved_current_bytes_since_inventory338'})
for r in x['routes']:
 add('route',r['id'],r['families'],[r['declaration_file'],r['handler_file']],{'methods':r['details']['explicit_method_guard'],'observed_method_branches':r['details']['observed_method_branches'],'method_limit':'absence of decorator does not imply GET-only','control_variants':r['literal_control_variants'],'static_dependency_closure':r['static_dependency_closure'],'runtime_patterns':r['runtime_patterns']},r['evidence_docs'],r['authority_sources'])
for r in x['tasks']:add('task',r['id'],r['families'],r['file'],{'beat':r['beat_declarations'],'calls':r['calls'],'policy':x['task_policy']},r['evidence_docs'])
for r in x['management_commands']:add('own_command',r['name'],r['families'],r['file'],{'arguments':r['arguments'],'execution':'not_run'},r['evidence_docs'],r['authority_limit'])
for r in x['framework_management_commands']:
 add('framework_command',r['name'],r['families'],r['source_file'],{'scope':r['optimization_scope'],'execution':'not_run'},authority=r['authority'])
 if r['optimization_scope']!='operator_tool':rows[-1]['disposition']='outside_application_optimization; QA/scaffolding not activated; retained in inventory'
for r in x['operational_runbooks']:add('runbook',r['id'],r['families'],r['sources'],{'existing_scope':r['functional_state'],'limit':r['limit'],'execution':'not_run'},r['evidence'],r['authority'])
for r in x['admin']:add('admin_pattern',r['id'],r['families'],list(x['framework_version_sources']),{'patterns':r['patterns'],'callback':r['callback'],'model_registry':['auth.group'],'execution':'not_run'},r['evidence_docs'],r['authority'])
for name in x['admin_global_actions']:add('admin_global_action',name,['I28'],list(x['framework_version_sources']),{'registered_global_action':name,'model_registry':['auth.group'],'execution':'not_run','limit':'permission and confirmation apply; registration alone is not an executable authority grant'},authority='Staff/active/model-specific permissions, confirmation and project gates; never execute by merely inventorying')
for i,r in enumerate(x['beat_declarations']):
 task=next(t for t in x['tasks'] if t['qualified']==r['task']);add('beat',str(i)+':'+r['task'],task['families'],'config/settings.py',r)
for i,r in enumerate(x['async_commit_triggers']):
 fam=sorted({f['id'] for f in x['families'] if r['file'] in f['relevant_sources']}) or ['I27']
 add('dispatch',str(i)+':'+r['file']+':'+str(r['line']),fam,r['file'],r)
for i,r in enumerate(x['signal_connections']):add('signal_connection',str(i),['I24'],r['file'],{**r,'event_kinds':['post_save','post_delete','m2m_changed'],'unit':'one connection loop with3eventkinds; not3source rows'})
for r in x['frontend']:add('template',r['file'],r['families'],r['file'],{'forms':r['forms'],'controls':r['controls'],'htmx':r['htmx_attributes'],'navigation_and_resources':r['navigation_and_resources'],'route_names':r['route_name_references'],'unit':'template/fragment participation, not independent business action'},r['evidence_docs'])
for r in x['javascript']:add('javascript',r['file'],r['families'],r['file'],{'events':r['listener_events'],'network_calls':r['network_calls'],'limit':r['limit']})
assert len({r['id'] for r in rows})==len(rows)
# Technical triage: no observed usage frequencies, no numerical risk scores invented.
order=[('S01','N04',['I01','I02','I03','I04','I05'],'Discovery segmentation','Shared public handler, filtering and state-page/promotion selection; existing aggregate budget/witness permits bounded comparison, individual scenarios remain uncertain.'),('S02','N07',['I13','I15','I16','I17','I24'],'Publication and asynchronous consistency','Authority/invalidation shared by public surfaces; preserve withdrawal under worker delay and distinguish job latency from Beat cadence.'),('S03','N09',['I20','I21','I23','I25'],'Private rights/decisions/outbox/purge','High consequence of authority/retention regression; prior witness reused only in exact scope, new cost grouping needs N01.'),('S04','N06',['I09','I10','I11','I12','I18'],'Account and profile operations','Core authoring/authority dependencies and explicit method/control variants; no new real-provider claims.'),('S05','N05',['I06','I26'],'Image/browser delivery','Bytes and browser interaction differ from Django mixed HTTP latency; existing gallery comparison is scoped.'),('S06','N02',['I22'],'MOD09 private export decomposition','Known2s/5s timing FAIL under explicit provisional exception; substantive work required, but no automatic precedence over common/shared authority paths.'),('S07','N03',['I13','I14'],'Media processing and density','Distinct-original and dense-match witnesses show growth sensitivity; end-to-end queue/upload and runtime cardinalities remain uncertain.'),('S08','N08',['I07','I08','I19'],'Secondary exposure and synthetic orders','Consistency with discovery/lifecycle, growth and private/public separation; no inferred traffic frequency.'),('S09','N10',['I27','I28'],'Operational cross-cutting costs','Isolated commands and recovery footprints; reuse bounded operational witnesses, prioritize changed dependency when encountered.')]
selection=[{'id':i,'block':b,'families':fs,'scenario_group':name,'rationale':why,'status':'selected_for_N01_preregistration_not_measured','reorder_rule':'A demonstrated critical defect, resource contention or prerequisite overrides this provisional sequence; record evidence.','sampling':'Enumerate affected actions/variants and justify representatives before execution; no blanket per-familyPASS.'} for i,b,fs,name,why in order]
familyrows=[]
for f in x['families']:
 familyrows.append({'id':f['id'],'name':f['name'],'blocks':byfamily[f['id']],'actions':[r['id'] for r in rows if f['id'] in r['families']],'authority_risk':hazards([f['id']]),'known_measurement_limit':f['limit'],'functional_state':f['functional_state'],'performance_state':f['performance_state'],'source_fingerprints':{p:sha(p) for p in f['relevant_sources']},'evidence':f['evidence_docs'],'selected_scenarios':[r['id'] for r in selection if f['id'] in r['families']]})
result={'state':'N00_SOURCE_ASSESSMENT_FOR_REVIEW_NOT_ACCEPTANCE','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'inventory_source':str(base),'inventory_sha256':sha(base),'pre_hito_graph_cut':{'sources':len(m),'source_sha_mismatches':0,'graph_sha256':sha('graphify-out/graph.json'),'method':'All current source hashes equal last scopedAST/semantic corpus; no changed sources required re-extraction before analysis.'},'accepted_executable_sources_unchanged':len(product),'counts_by_unit':dict(collections.Counter(r['kind'] for r in rows)),'distinct_signal_event_kinds':3,'admin_global_actions':x['admin_global_actions'],'actions':rows,'families':familyrows,'selected_scenario_groups':selection,'source_changes':{'added':[],'modified':[],'removed':[],'conserved_scope':'All338fingerprints, framework command sources and runbooks matched current bytes; no executable changes sinceB16.'},'limits':['Rows are distinct inventory units, not summed business functionality or executed tests.','Source identity supports retained evidence in original candidate/scenario scope, not universal functional/performance acceptance.','Static depth2 closures are not exhaustive runtime bindings.','No production usage/frequency/traffic inferred.','No new application request, database, provider or command handle execution.','Priority is engineering triage subject to N01 and findings; MOD09 debt is known but has no automatic first place.']}
Path('docs/evidencias/n00-matriz-acciones-prioridades-20261025.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'state':result['state'],'families':len(familyrows),'units':result['counts_by_unit'],'selected_groups':len(selection),'source_changes':0,'accepted_sources_unchanged':len(product)}))
