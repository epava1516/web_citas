import hashlib,json
from pathlib import Path
w=Path('artifacts/recorridos-n00-20261025');r=json.loads((w/'semantic-report.json').read_text());assert r['STATUS']=='complete' and not r['UNRESOLVED_ISSUES']
expected=json.loads((w/'semantic-inputs.json').read_text());v='/tmp/web-modelos-n00-semantic/followup-current-view.md';expected[v]={'source':'docs/17-seguimiento-desarrollo.md','sha256':hashlib.sha256(Path(v).read_bytes()).hexdigest()}
assert {i['path'] for i in r['READ_INPUTS']}==set(expected)
for i in r['READ_INPUTS']:
 assert i['fully_read'] and i['sha256']==expected[i['path']]['sha256']
 assert hashlib.sha256(Path(i['path']).read_bytes()).hexdigest()==i['sha256']
 p=w/'input-snapshots'/expected[i['path']]['source']
 if i['path']==v:p=w/'input-snapshots/followup-current-view.md'
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(Path(i['path']).read_bytes())
print('PASS_REPORT_SCOPE_AND_SNAPSHOTS; all5inputSHA and fullread declarations reconciled, not runtime proof')
