import ast,hashlib,json,statistics,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n03-g-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   assert k not in d;d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
r=read(W/'native-review.json');assert r['STATUS']=='complete'
for k in ['FILES_CHANGED','TESTS_RUN','ASSUMPTIONS','RISKS','UNRESOLVED_ISSUES','RECOMMENDATIONS']:assert isinstance(r[k],list)
for k in ['IMPLEMENTATION_NOTES','TEST_RESULTS']:assert isinstance(r[k],str)
citations=r['requirements_citations']+[c for a in r['action_dispositions'] for c in a['citations']]
snapshot_map=read(W/'review-snapshot-map.json')
for c in citations:
 p=Path(snapshot_map[c['file']]);assert sha(p)==c['sha256'],str(p)
 assert c['quote'] in '\n'.join(p.read_text().splitlines()[c['line_start']-1:c['line_end']]),str(p)
def defs(p):
 t=ast.parse(Path(p).read_text());return {n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
for b in r['source_bridges']:
 assert sha(b['before'])==b['before_sha256'] and sha(b['after'])==b['after_sha256']
 x,y=defs(b['before']),defs(b['after']);assert set(x)==set(y)
 assert {k for k in x if x[k]!=y[k]}==set(b['changed_definitions']),b
f=read('artifacts/recorridos-n03-a-20261025/freeze.json');sources=f.get('sources') or f.get('source_hashes');assert sources
for row in r['A_full_file_identity']:
 p=row['file'];assert sha(p)==row['A_frozen_sha256']==sources[p]
assert sha('artifacts/recorridos-n03-b-20261025/services-before.py')==sources['apps/mediafiles/services.py']
assert defs('artifacts/recorridos-n03-b-20261025/services-before.py')['ingest']==defs('apps/mediafiles/services.py')['ingest']
assert defs('artifacts/recorridos-n03-d-20261025/tasks-before.py')['process_blob']==defs('apps/mediafiles/tasks.py')['process_blob']
actions={a['id'] for a in r['action_dispositions']};assert len(actions)==6
old=read('artifacts/recorridos-n03-f-20261025/reconciliation-matrix.json');assert actions=={x['id'] for x in old['census_action_dispositions']}
# Inspect original terminal JUnit/result/notification rather than adding reports together.
runs={'20261025-173129-0e1fb9b8':(1,0),'20261025-175533-a061c196':(1,0),'20261025-180035-0ecdeb99':(1,0),'20261025-180404-86f68fb2':(46,0),'20261025-181549-690b123b':(2,2),'20261025-183022-372b5094':(33,0),'20261025-184432-abf4326e':(4,4),'20261025-184941-1ac056e3':(37,0),'20261025-192053-4c827d97':(1,0),'20261025-195610-4d4d1295':(11,8),'20261025-200423-1535dac0':(49,0),'20261025-202704-5fab8e4c':(3,0)}
witnesses=[]
for run,(n,fail) in runs.items():
 p=Path('artifacts/local-ci')/run;rr=read(p/'result.json');cs=list(E.parse(p/'pytest.xml').iter('testcase'))
 assert len(cs)==n and sum(c.find('failure')is not None for c in cs)==fail
 assert not any(c.find(k)is not None for c in cs for k in ['error','skipped'])
 assert rr['result']==('ERROR' if fail else 'PASS') and rr['sources_unchanged']
 assert read(p/'telegram-notification.json')['delivery']=='sent'
 witnesses.append({'run':run,'tests':n,'failures':fail,'junit_sha256':sha(p/'pytest.xml'),'result_sha256':sha(p/'result.json')})
b=read('artifacts/recorridos-n03-b-20261025/baseline-audit.json');c=read('artifacts/recorridos-n03-b-20261025/candidate-audit.json')
for key in ['corpus_sha256','corpus_bytes','candidates','expected_matches','scope']:assert b['measurement'][key]==c['measurement'][key]
for key in ['complete_result_sha256','persisted_method_score_sha256','confirm_calls','match_count','sql_queries']:assert [s[key] for s in b['measurement']['samples']]==[s[key] for s in c['measurement']['samples']]
assert all(s['feature_calls']==200 for s in b['measurement']['samples']) and all(s['feature_calls']==101 for s in c['measurement']['samples'])
for key in ['wall_seconds','thread_cpu_seconds']:assert c['summary'][key]['later_max']<b['summary'][key]['later_min']
# Only process changed after B; detector and similarity stay at the measured candidate.
assert defs('apps/mediafiles/services.py')['detect_matches']==defs('artifacts/recorridos-n03-c-20261025/services-before.py')['detect_matches']
scope=read('artifacts/recorridos-n03-b-20261025/candidate-scope.json');assert sha('apps/mediafiles/similarity.py')==scope['apps/mediafiles/similarity.py']['after']
f1=read('artifacts/recorridos-n03-f-20261025/candidate-final-audit.json');assert f1['global_guard_ack_preserves_failed4'] and len(f1['budget_cases'])==8 and f1['cleanup_verified']
f2=read('artifacts/recorridos-n03-f2-20261025/retention-final-audit.json');assert f2['cleanup_verified'] and f2['source_identity_verified_during_run']
frozen=read('artifacts/recorridos-n03-f2-20261025/reference-freeze.json')['sources']
for p,h in frozen.items():
 if p!='.ai/tasks/desarrollo.md':assert sha(p)==h,p
rows=f2['raw_properties'];assert {d['retained_historical_photos'] for d in rows}=={0,10,100} and all(len(d['samples'])==6 for d in rows)
assert len({d['corpus_sha256'] for d in rows})==1 and len({json.dumps(d['canonical_result'],sort_keys=True) for d in rows})==1
assert not r['mandatory_missing_beyond_F2_and_acta']
out={'result':'PASS_N03_ACTIONS_SOURCE_BRIDGES_ORIGINAL_WITNESSES_AND_FINITE_CRITERIA_ROOT_VERIFIED','head_before_acta':'5f68464','actions':sorted(actions),'citations_verified':len(citations),'source_bridges_verified':len(r['source_bridges']),'witnesses':witnesses,'functional_fail_references_preserved':[2,4,8],'F1_global_budget_current':True,'F2_finite_retention_current':True,'B_detector_and_similarity_current':True,'coverage':'N03 I13/I14 only; six census IDs preserved, other block owners retained. Source bridges plus executable regression; no universal absence of bugs, no HTTP capacity or providers.','acceptance_authority':'Root technical decision, not native report','next_mandatory_accepted_if_acta_integrated':4,'mandatory_total':13}
(W/'acceptance-verification.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
