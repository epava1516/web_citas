"""Host literal editorial refresh of table365; not a new runtime measurement."""
import hashlib,json,re
from pathlib import Path
W=Path('artifacts/recorridos-n02-d-20261025/prereg');S=W/'graph-integrated'
p=Path('docs/365-n02-c-resultado-contraste-agrupado-guard-20261025.md');text=p.read_text();lines=text.splitlines();sha=hashlib.sha256(p.read_bytes()).hexdigest()
g=json.loads((S/'graph.json').read_text());count=0
for row in g['nodes']+g['links']:
 if row.get('source_file')!=str(p):continue
 quote=row.get('evidence_quote')
 if quote:
  if '| Lecturas/hash/bytes porguard |' in quote:quote=quote.replace('| Lecturas/hash/bytes porguard | 2/10554 | 2/10554 | 0 |','| Lecturas completas por guard | 2 | 2 | Sin cambio |\n| Hashes de contenido por guard | 2 | 2 | Sin cambio |\n| Bytes leídos por guard | 10 554 | 10 554 | Sin cambio |')
  assert quote in text,row
  start=text[:text.index(quote)].count('\n')+1;end=start+quote.count('\n');row['source_location']=f'L{start}-L{end}';row['evidence_quote']=quote
 if 'source_sha256' in row:row['source_sha256']=sha
 row['editorial_refresh']='host_literal_table_clarification_20261025';count+=1
node=next(n for n in g['nodes'] if n['id'].endswith('_tiempos') and n.get('source_file')==str(p))
node['sample_scope']='60 calls/variant; primary median of five group means of ten calls (50/variant), first group separate; unchanged runtime evidence'
(S/'graph.json').write_text(json.dumps(g,ensure_ascii=False,indent=2))
m=json.loads((S/'SOURCE_MANIFEST.json').read_text());m[str(p)].update(sha256=sha,bytes=p.stat().st_size,input_path=str(p.resolve()),input_sha256=sha,editorial_refresh='host_literal_table_clarification_20261025');(S/'SOURCE_MANIFEST.json').write_text(json.dumps(m,indent=2))
proof=json.loads((W/'semantic-integration.json').read_text());assert str(p) not in proof['changed_sources'];proof['changed_sources'].append(str(p));proof['editorial_refresh']={'source':str(p),'scope':'Host literal evidence/location refresh and explicit existing sample arithmetic; no runtime or native extraction claim','rows':count,'sha256':sha};(W/'semantic-integration.json').write_text(json.dumps(proof,indent=2))
print(json.dumps(proof['editorial_refresh']))
