import hashlib,json,statistics,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n03-f2-20261025');P=Path('artifacts/local-ci/20261025-202704-5fab8e4c')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   assert k not in d;d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
r=read(P/'result.json');f=read(W/'reference-freeze.json');assert r['result']=='PASS' and r['sources_unchanged'] and r['selection']==f['selection'] and r['workers']==1
assert all(sha(p)==h for p,h in f['sources'].items())
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==3 and not any(c.find(k)is not None for c in cs for k in ['failure','error','skipped'])
rows=[]
for c in cs:
 props={x.attrib['name']:x.attrib['value'] for x in c.iter('property')};d=json.loads(props['n03f2_retained_population']);rows.append(d)
 assert d['active_current_photos']==d['ready_blobs']==2 and d['historical_revisions_including_empty_source']==d['retained_historical_photos']+1
 assert len(d['samples'])==6 and [x['phase'] for x in d['samples']]==['first']+['later']*5
 for x in d['samples']:
  assert x['signature_calls_peer']==x['confirmation_calls']==x['recorded_matches']==1
  assert x['selector_before']['dispatches']==1 and x['selector_after']['dispatches']==0
  assert x['selector_before']['sql_calls']==x['selector_after']['sql_calls']==1
  assert x['process_maxrss_kib']<1024*1024
 assert len({x['result_sha256'] for x in d['samples']})==1
 assert d['corpus_file_bytes']<128*1024*1024
assert {x['retained_historical_photos'] for x in rows}=={0,10,100}
assert len({x['corpus_sha256'] for x in rows})==1
assert len({json.dumps(x['canonical_result'],sort_keys=True) for x in rows})==1
assert len({x['samples'][0]['result_sha256'] for x in rows})==1
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q']
 q=subprocess.run(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],capture_output=True,text=True,check=True);assert not q.stdout.strip()
assert not Path(read(P/'runner.json')['temporary']).exists()
tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
summary=[]
for d in sorted(rows,key=lambda x:x['retained_historical_photos']):
 row={'retained':d['retained_historical_photos'],'corpus_bytes':d['corpus_file_bytes'],'first':d['samples'][0]}
 for stage in ['detector','selector_before','selector_after']:
  vals=[x[stage] for x in d['samples'][1:]]
  row[stage]={k:{'median':statistics.median(x[k] for x in vals),'min':min(x[k] for x in vals),'max':max(x[k] for x in vals)} for k in ['wall_seconds','thread_cpu_seconds','sql_calls','sql_execute_seconds']}
 summary.append(row)
out={'result':'PASS_FINITE_RETAINED_POPULATION_NO_APPLICATION_CHANGE_NOT_N03_ACCEPTANCE','run':P.name,'junit':r['junit'],'sources':len(f['sources']),'source_identity_verified':True,'corpus_sha256':rows[0]['corpus_sha256'],'canonical_result':rows[0]['canonical_result'],'summary':summary,'raw_properties':rows,'cleanup_verified':True,'telegram':tg,'scope':'Three distinct retained populations with two current contents fixed; 18 full direct calls, no application speedup, SLA, worker or 80k claim; N03 final action reconciliation pending'}
(W/'retention-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['raw_properties','canonical_result','summary']}));print(json.dumps(summary))
