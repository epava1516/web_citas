import hashlib,json,shutil,subprocess
from pathlib import Path
W=Path('artifacts/recorridos-n08-a2-20261026');G=Path('graphify-out');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=json.loads((G/'SOURCE_MANIFEST.json').read_text());bad=[p for p,r in m.items() if sha(p)!=r['sha256']];assert not bad,bad
assert sha(G/'graph.json')=='5f2f22d8e2c390ea2ee6c0422bc8568c27caa16f740dcc1009a68aa7d78ce265'
for n in ['SOURCE_MANIFEST.json','ESTADO_ACTUAL.json','GRAPH_VERIFICATION.json']:shutil.copy2(G/n,W/('pre-'+n))
out={'result':'PASS_CURRENT_PRE_N08A2_SOURCE_CUT','source_files':len(m),'graph_sha256':sha(G/'graph.json'),'mismatches':bad,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'N08A410 reference result semantic/AST preserved;2025exact declared source identities before bounded candidate study. Not full N15 rebuild; user lateral changes preserved.'};(W/'pre-source-cut.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
