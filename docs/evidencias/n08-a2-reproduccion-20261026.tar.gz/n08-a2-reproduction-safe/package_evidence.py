import hashlib,json,shutil,tarfile,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n08-a2-20261026');S=W/'reproduction-safe';S.mkdir(exist_ok=False)
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,dest=None):
 p=Path(p);dest=S/(dest or p.relative_to(W));dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for p in W.iterdir():
 if p.is_file() and p.suffix in ['.json','.py']:put(p)
for sub in ['prereg','result']:
 for p in (W/sub).iterdir():
  if p.is_file() and p.suffix in ['.json','.py']:put(p)
 for p in (W/sub/'snapshots').iterdir():
  if p.is_file():put(p)
for p in (W/'source-proposals').iterdir():
 if p.is_file():put(p)
for source in ['apps/listings/favorites.py','apps/core/sitemaps.py','tests/test_secondary_surface_batch_pair.py']:put(source,'sources/'+source)
run=Path('artifacts/local-ci/20261026-014812-0d85aaca');dest=S/'runtime';dest.mkdir();r=read(run/'result.json');r['steps']=[{k:v for k,v in x.items() if k not in ['command','stdout','stderr']}for x in r['steps']]
(dest/'result-sanitized.json').write_text(json.dumps(r,indent=2)+'\n')
for name in ['source-hashes.json','native-manifest.json','telegram-notification.json']:shutil.copy2(run/name,dest/name)
root=E.parse(run/'pytest.xml').getroot()
for element in root.iter():
 for child in list(element):
  if child.tag in ['system-out','system-err']:element.remove(child)
E.ElementTree(root).write(dest/'pytest-sanitized.xml',encoding='utf-8',xml_declaration=True)
m={'result':'N08A2_SINGLE_CANDIDATE_PAIRED_REPRODUCTION','files':{str(p.relative_to(S)):sha(p) for p in sorted(S.rglob('*'))if p.is_file()},'scope':'Actual13PASS72target/118newClientGET/167globalClient; no rawlogs/stepcommands/systemoutputs/credentials or userlateraldraftcontents. Two original/candidate sources, exactGitSHA, callbacks/normalization/oracles/metrics/frozen identities kept. All six budgets411 passed; candidate finite local acceptance, overallN08pending7/13. Browserobserved156, no p95/provider/currentruntimeimmutability or perversionRSSclaim.'}
(S/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n');target=Path('docs/evidencias/n08-a2-reproduccion-20261026.tar.gz')
with tarfile.open(target,'w:gz')as tar:tar.add(S,arcname='n08-a2-reproduction-safe')
print(json.dumps({'artifact':str(target),'files':len(m['files'])+1,'sha256':sha(target),'bytes':target.stat().st_size}))
