import collections,hashlib,json,math,statistics,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n08-a2-20261026');P=Path('artifacts/local-ci')/sys.argv[1];read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=read(W/'reference-freeze.json');r=read(P/'result.json');h=read(P/'source-hashes.json')
assert r['result']=='PASS' and r['sources_unchanged'] and r['selection']==f['selection'] and r['workers']==1 and r['observe_http_operations']
assert all(sha(p)==v for p,v in f['sources'].items())
missing=set(f['sources'])-set(h);assert missing=={f['prereg_document_verified_separately']};assert all(h[p]==v for p,v in f['sources'].items() if p in h)
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==13 and not any(c.find(k)is not None for c in cs for k in ['failure','error','skipped'])
assert collections.Counter(c.get('classname','').split('.')[-1] for c in cs)=={'test_secondary_surface_batch_pair':3,'test_favorites':3,'test_sitemaps':3,'test_public_seo':4}
paired=[];original=[];main=None;negative=[];summary=[];budgets=[];allglobals=[]
for c in cs:
 props={x.get('name'):x.get('value') for x in c.iter('property')};ops=json.loads(props['http_operation_samples']);assert len(ops)==int(props['http_operation_count']);assert all(x['exception_class']is None and x['observer_error_class']is None for x in ops);allglobals.extend(ops)
 key='secondary_batch_pair' if 'secondary_batch_pair'in props else 'secondary_batch_pair_negative' if 'secondary_batch_pair_negative'in props else None
 if key is None:original.append({'module':c.get('classname'),'case':c.get('name'),'operations':ops});continue
 d=json.loads(props[key]);rows=d['rows'];meta=d['metadata'];assert meta['baseline_commit']==f['baseline']['commit'] and meta['readonly_snapshots_verified']
 assert d['process_high_water_rss_bytes']<=f['acceptance_before_measurement']['RSS_process_high_water_limit_bytes'] and d['memory_diagnostic_limit_bytes']==1024**3
 for module,path in [('favorites','apps/listings/favorites.py'),('sitemaps','apps/core/sitemaps.py')]:assert meta['source_sha256'][module]=={'baseline':f['baseline']['files'][path]['sha256'],'candidate':f['sources'][path]}
 # Source holds every request inside_pair; directory setup has no same-route requests.
 assert len(rows)==len(ops),(c.get('name'),len(rows),len(ops))
 for a,b in zip(rows,ops):
  assert b['method']=='GET' and a['route_name']==b['route_name'] and a['status']==b['status'] and a['sql_queries']==b['sql_queries'] and a['wall_seconds']>=b['request_seconds_instrumented']
  assert a['resolved_callback_verified'] and a['variant']in ['baseline','candidate'] and len(a['normalized_sha256'])==64 and len(a['snapshot_sha256'])==64
  module='favorites' if a['surface']=='favorites' else 'sitemaps';assert a['observed_function_source_sha256']==meta['source_sha256'][module][a['variant']]
  for k in ['wall_seconds','cpu_seconds','sql_execute_seconds','sql_queries','response_bytes']:assert isinstance(a[k],(int,float)) and not isinstance(a[k],bool) and math.isfinite(a[k]) and a[k]>=0
  assert isinstance(a['sql_queries'],int) and isinstance(a['response_bytes'],int)
 pairs=collections.defaultdict(dict)
 for a in rows:
  keypair=tuple(a[k] for k in ['category','state','surface','language','page','ordinal']);assert a['variant']not in pairs[keypair];pairs[keypair][a['variant']]=a
 for keypair,versions in pairs.items():
  assert set(versions)=={'baseline','candidate'}
  a,b=versions['baseline'],versions['candidate'];assert a['status']==b['status'] and a['headers']==b['headers'] and a['cookie_security_attributes']==b['cookie_security_attributes'] and a['normalized_sha256']==b['normalized_sha256'] and a['snapshot_sha256']==b['snapshot_sha256']
  assert {a['order_position'],b['order_position']}=={0,1}
  if a['surface']!='favorites':assert a['body_sha256']==b['body_sha256'] and a['normalization']['csrf_hidden_values']==0
 if 'secondary_batch_pair'in props:
  assert main is None;main=d;assert len(rows)==114 and sum(x['category']=='target' for x in rows)==72 and sum(x['category']=='control' for x in rows)==42
  expected={('favorites',state,lang,1) for state in ['normal','one_revoked'] for lang in ['es','en']}|{('sitemap_listings',state,'neutral',1) for state in ['normal','one_revoked']}
  grouped=collections.defaultdict(list)
  for a in rows:
   if a['category']=='target':grouped[tuple(a[k] for k in ['surface','state','language','page'])].append(a)
  assert set(grouped)==expected
  for keyseg,samples in sorted(grouped.items()):
   measures={}
   for variant in ['baseline','candidate']:
    seq=sorted([x for x in samples if x['variant']==variant],key=lambda x:x['ordinal']);assert [x['ordinal']for x in seq]==list(range(6)) and all(x['status']==200 for x in seq)
    for x in seq:assert x['order_position']==((0 if x['ordinal']%2==0 else 1)if variant=='baseline'else(1 if x['ordinal']%2==0 else 0))
    after=seq[1:];measures[variant]={'first_ms':seq[0]['wall_seconds']*1000,'median5_ms':statistics.median(x['wall_seconds']for x in after)*1000,'range5_ms':[min(x['wall_seconds']for x in after)*1000,max(x['wall_seconds']for x in after)*1000],'cpu_median5_ms':statistics.median(x['cpu_seconds']for x in after)*1000,'sql_counts':sorted({x['sql_queries']for x in seq}),'sql_median5':statistics.median(x['sql_queries']for x in after),'response_bytes':sorted({x['response_bytes']for x in seq})}
   before,after=measures['baseline'],measures['candidate'];ratios={'SQL':after['sql_median5']/before['sql_median5'],'wall_median5':after['median5_ms']/before['median5_ms'],'CPU_median5':after['cpu_median5_ms']/before['cpu_median5_ms']}
   accepted=ratios['SQL']<=0.5 and ratios['wall_median5']<=0.8 and ratios['CPU_median5']<=1.0
   item=dict(zip(['surface','state','language','page'],keyseg))|{'measures':measures,'ratios':ratios,'accepted_per411':accepted};summary.append(item);budgets.append(accepted)
  small=[]
  for keypair,v in pairs.items():
   if keypair[1].startswith('small_'):
    a,b=v['baseline'],v['candidate'];ok=b['sql_queries']<=a['sql_queries'];small.append({'state':a['state'],'surface':a['surface'],'language':a['language'],'baseline_SQL':a['sql_queries'],'candidate_SQL':b['sql_queries'],'accepted':ok});budgets.append(ok)
  assert len(small)==9
  d['small_SQL_comparison']=small
 else:
  assert len(rows)==2 and all(x['state']=='null_and_foreign_revision' and x['status']==200 and x['normalization']['csrf_hidden_values']==3 for x in rows)
  assert meta['language']in ['es','en'];negative.append(meta['language'])
 paired.append({'case':c.get('name'),'report':d,'global_operations':ops,'scope':props['http_operation_scope']})
assert main is not None and len(paired)==3 and len(original)==10 and set(negative)=={'es','en'} and len(summary)==6
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container'else['docker',kind,'ls','-q'];assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
accepted=all(budgets)
out={'result':'PASS_N08A2_FUNCTIONAL_PAIR_AND_PREREGISTERED_GAIN'if accepted else'REJECT_N08A2_PERFORMANCE_KEEP_BASELINE_DEFER','run':P.name,'cases':13,'junit':r['junit'],'source_freeze_count':len(f['sources']),'sources_verified_separately':sorted(missing),'target_GETs':72,'instrumented_new_GETs':sum(len(x['report']['rows'])for x in paired),'global_operations_all13':len(allglobals),'normalization_scope':'OnlyCSRFhiddenvalue/requestnonce andCSRFcookie secret/rollingExpiry,othercookieshashedallattributesexact; XMLrawbytesexact. Same4modelpersistedsnapshotwithinpair; actualsource/callback/middleware/data, not validationstub.','summary':summary,'small_SQL_comparison':main['small_SQL_comparison'],'raw_paired_cases':paired,'original_current_cases':original,'all_preregistered_cost_gates_met':accepted,'functional_parity_verified':True,'cleanup_verified':True,'telegram':tg,'scope':'Finite sameDBactualsource contrast onecandidate, nativeguards and24/100retained;10original freshregressions included, no300GETroutine rerun. Ownexecute-wrapper118GETnestedinglobalnotadditive; firstplus5medians/ranges no p95/SLA/provider/beta. RSSwholeprocessnotperversion. N08Bcommercial andfull17dispositions pending; overall7/13.'}
(W/'pair-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['raw_paired_cases','original_current_cases','summary']}));print(json.dumps(summary,ensure_ascii=False))
if not accepted:raise SystemExit(1)
