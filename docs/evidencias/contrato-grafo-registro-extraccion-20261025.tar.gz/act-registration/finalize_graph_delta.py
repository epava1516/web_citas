"""Generate coherent scoped graph outputs; preserve base immutable archive."""
import collections,hashlib,json
from pathlib import Path
import networkx as nx
from graphify.analyze import god_nodes,surprising_connections,suggest_questions
from graphify.cluster import score_all
from graphify.report import generate
from graphify.export import to_html
W=Path('artifacts/inventory-final-20261025/act-registration');S=W/'graph-integrated'
data=json.loads((S/'graph.json').read_text());G=nx.MultiDiGraph()
for n in data['nodes']:G.add_node(n['id'],**{k:v for k,v in n.items() if k!='id'})
for e in data['links']:G.add_edge(e['source'],e['target'],**{k:v for k,v in e.items() if k not in ('source','target','key')})
H=nx.Graph();H.add_nodes_from(G.nodes(data=True))
for a,b,d in G.edges(data=True):
 if H.has_edge(a,b):H[a][b]['weight']+=float(d.get('weight',1))
 else:H.add_edge(a,b,weight=float(d.get('weight',1)))
communities={int(k):v for k,v in json.loads((S/'.graphify_analysis.json').read_text())['communities'].items()};labels={int(k):v for k,v in json.loads((S/'.graphify_labels.json').read_text()).items()}
labels[max(communities)]='Acta final y deuda'
for n in data['nodes']:
 if n['community']==max(communities):n['community_name']=labels[max(communities)]
(S/'.graphify_labels.json').write_text(json.dumps(labels,ensure_ascii=False))
cohesion=score_all(H,communities);gods=god_nodes(H);surprises=surprising_connections(H,communities);questions=suggest_questions(H,communities,labels)
analysis={'communities':communities,'cohesion':cohesion,'gods':gods,'surprises':surprises,'questions':questions}
(S/'.graphify_analysis.json').write_text(json.dumps(analysis,ensure_ascii=False))
manifest=json.loads((S/'SOURCE_MANIFEST.json').read_text());proof=json.loads((W/'semantic-integration.json').read_text())
scope=f'''# Grafo final alfa: base reconstruida e inventario integrado

Base desde cero preservada:1922fuentes,17850nodos/79100relaciones,846comunidades. Archivo y auditoría: docs/evidencias/grafo-final-reconstruccion-20261025.json. La base no se sustituye retrospectivamente por este refresco.

Registro focal final del acta23 y encabezados: {len(proof['changed_sources'])} documentos leídos semánticamente por agente nativo; {proof['native_nodes']} entidades y {proof['native_relations']} relaciones nativas con citas y huellas comprobadas. Corpus vigente:{len(manifest)}fuentes; {G.number_of_nodes()}nodos/{G.number_of_edges()}relaciones;{len(communities)}comunidades. Se reemplaza la semántica de los documentos cambiados y se recalculan sus citas literales. AST de producto/pruebas intacto. Comunidades de base conservadas, con comunidades documentales añadidas en dos refrescos: no es una nueva detección global.

Seguimiento17: sólo líneas1–4 de su sección actual, con SHA del archivo completo y de la vista por separado. Resto de exclusiones y método de base en CORPUS_POLICY.json. Referencias extranjeras a entidades sustituidas se conservan como referencias no resueltas explícitas, no implementaciones inventadas. Semántica selectiva, sin prueba de exhaustividad, PASS, seguridad, legalidad o capacidad productiva. Se conservan100anotaciones ambiguas de llamadas/bases como anotaciones y no dependencias a sí mismo.

B16 aceptado por acta22; inventario338/339 verificado e integrado en la fase anterior (1924fuentes,17847nodos/79498relaciones). Acta23emitida después de esa verificación y registrada en este corte.15/18aceptados localmente;B14/B15/B17diferidos. Contrato cerrado localmente, proyecto enalfa. El goal sólo se completa tras verificación final y registroGit. Consumo nativo desconocido: ceros técnicos del generador no equivalen a coste cero.

HTML muestra sólo proyección de comunidades; JSON contiene todas las entidades. No se eleva la guarda de5000nodos del exportador.

'''
detection={'total_files':len(manifest),'files':{},'total_words':0}
report=generate(H,communities,cohesion,labels,gods,surprises,detection,{'input':0,'output':0},str(Path.cwd()),suggested_questions=questions)
(S/'GRAPH_REPORT.md').write_text(scope+report);(S/'ESTADO_ACTUAL.md').write_text(scope)
C=nx.DiGraph();membership={i:c for c,v in communities.items() for i in v}
for c,v in communities.items():C.add_node('community_'+str(c),label=labels[c],file_type='concept',source_file=None,member_count=len(v))
for a,b,d in G.edges(data=True):
 c,f=membership[a],membership[b]
 if c==f:continue
 a,b='community_'+str(c),'community_'+str(f)
 if not C.has_edge(a,b):C.add_edge(a,b,weight=0.0,relation='community_relations',relation_count=0)
 C[a][b]['weight']+=float(d.get('weight',1));C[a][b]['relation_count']+=1
assert to_html(C,{c:['community_'+str(c)] for c in communities},str(S/'graph.html'),community_labels=labels,member_counts={c:len(v) for c,v in communities.items()})
policy=json.loads((S/'CORPUS_POLICY.json').read_text());policy.update(build_kind='fresh_base_plus_scoped_semantic_inventory_update',selected_files=sorted(manifest),latest_delta=proof,section_views={'docs/17-seguimiento-desarrollo.md':'lines1-4_only'},visualization_scope=f'{len(communities)}communityprojection; fullJSON',native_token_usage=None)
policy['semantic_delta_history']=[json.loads((W.parent/'semantic-integration.json').read_text()),proof]
policy['exclusions']=[r for r in policy['exclusions'] if r['path'] not in manifest]
(S/'CORPUS_POLICY.json').write_text(json.dumps(policy,indent=2))
health={'nodes':G.number_of_nodes(),'relations':G.number_of_edges(),'communities':len(communities),'source_files':len(manifest),'missing_endpoints':0,'dangling_endpoints':0,'duplicate_ids':0,'self_loops':nx.number_of_selfloops(G),'parallel_relations_preserved':G.number_of_edges()-len(set(G.edges())),'unresolved_reference_nodes':sum(n.get('external',False) for _,n in G.nodes(data=True)),'latest_refresh':'targeted_semantic_documents; unchangedAST','semantic_relation_exhaustiveness':False,'native_token_usage':None}
(S/'GRAPH_HEALTH.json').write_text(json.dumps(health,indent=2));(S/'ESTADO_ACTUAL.json').write_text(json.dumps({'phase':'alpha','locally_closed':15,'roadmap_total':18,'B16':'accepted_local_acta22','inventory':'verified338339','pending':[],'goal_complete':False,'contract_status':'closed_local_acta23_registered_goal_completion_after_final_checks' ,**health},indent=2))
# Keys remain NetworkX multigraph identities; assign unambiguously for every pair.
pair=collections.Counter()
for e in data['links']:
 p=(e['source'],e['target']);e['key']=pair[p];pair[p]+=1
(S/'graph.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
(S/'CURRENT_OUTPUTS.json').write_text(json.dumps({'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in S.iterdir() if p.is_file() and p.name not in ('CURRENT_OUTPUTS.json','GRAPH_VERIFICATION.json')},'base_commit':data['built_at_commit'],'latest_document_commit':'eaa180e+roadmap_delta'},indent=2))
print(json.dumps(health))
