"""Final contract documentary audit, after act registration and output assembly."""
import hashlib,json,tarfile
from pathlib import Path
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
W=Path('artifacts/inventory-final-20261025/act-registration');G=Path('graphify-out')
manifest=json.loads((G/'SOURCE_MANIFEST.json').read_text());assert len(manifest)==1925
for p,row in manifest.items():assert sha(p)==row['sha256'],p
act='docs/actas/23-cierre-contrato-clasificados-alpha-20261025.md';assert manifest[act]['semantic_scope']=='full_file'
graph=json.loads((G/'graph.json').read_text());assert any(n.get('source_file')==act and n.get('extraction_origin')=='native_semantic_contract_act_registration' for n in graph['nodes'])
proof=json.loads((W/'graph-delta-verification.json').read_text());assert proof['result']=='PASS_SCOPED_GRAPH_INVENTORY_INTEGRATION' and proof['graph_sha256']==sha(G/'graph.json')
pre=json.loads(Path('docs/evidencias/contrato-cierre-auditoria-20261025.json').read_text());assert pre['result']=='PASS_CONTRACT_PREACT_DELIVERY_AUDIT'
assert len(pre['point_dispositions'])==18 and len(pre['final_requirements'])==7
assert sum(r['disposition']=='accepted_local_prior_bounded_evidence' for r in pre['point_dispositions'])==15
assert [r['id'] for r in pre['point_dispositions'] if r['disposition']=='deferred_not_PASS']==['B14','B15','B17']
for row in pre['point_dispositions']:assert sha(row['authority'])==row['sha256']
for row in pre['final_requirements']:assert sha(row['evidence'])==row['sha256']
for p in ('docs/README.md','docs/103-roadmap-beta-clasificados-20261020.md','docs/17-seguimiento-desarrollo.md'):
 assert '23-cierre-contrato-clasificados-alpha-20261025.md' in Path(p).read_text(),p
assert sha('docs/111-inventario-rendimiento-recorridos-beta-20261020.md')=='380b026c51b5e9647052838bb77a0712e9efff4ccdd857b5df3d4b545d921a95'
product=json.loads(Path('docs/evidencias/b16-final-candidate-reconciliation-20261025.json').read_text())['current_versioned_executable_sources'];assert len(product)==1507
for p,h in product.items():assert sha(p)==h,p
for receipt in ('docs/evidencias/grafo-final-reconstruccion-20261025.json','docs/evidencias/inventario-grafo-integracion-20261025.json','docs/evidencias/contrato-grafo-registro-final-20261025.json'):
 r=json.loads(Path(receipt).read_text());assert sha(r['archive_path'])==r['archive_sha256'],receipt
 with tarfile.open(r['archive_path']) as t:assert any(n.endswith('graph.json') for n in t.getnames())
 if 'extraction_archive' in r:assert sha(r['extraction_archive'])==r['extraction_archive_sha256']
for p,h in json.loads((G/'CURRENT_OUTPUTS.json').read_text())['sha256'].items():assert sha(G/p)==h,p
result={'result':'PASS_FINAL_CONTRACT_DOCUMENTARY_CLOSURE','contract_status':'closed_local_with_explicit_deferred_scope','phase':'alpha','locally_accepted':15,'roadmap_total':18,'deferred_not_PASS':['B14','B15','B17'],'act':act,'act_sha256':sha(act),'final_requirement_count':7,'all_final_documentary_requirements_satisfied':True,'graph_sha256':sha(G/'graph.json'),'source_files':len(manifest),'original111_unchanged':True,'accepted_executable_sources_unchanged':1507,'no_new_product_batteries':True,'pending_contract_delivery_work':[],'debt_authority':'docs/336-deuda-siguiente-contrato-y-cierre-alpha-20261025.md','first_next_contract_priority':'Inventory I01–I28 measurement/correction/optimization','qa_optimization':'deferred_until_first_stable_productive_version','limitations':pre['limitations'],'git_record':'Final commit/push checked separately after this proof is written.'}
Path('docs/evidencias/contrato-cierre-final-verificacion-20261025.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
