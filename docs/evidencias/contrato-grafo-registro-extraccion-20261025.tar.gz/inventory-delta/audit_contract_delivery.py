"""Audit final documentary obligation, preserving bounded prior technical acceptance."""
import hashlib,json,tarfile
from pathlib import Path
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
W=Path('artifacts/inventory-final-20261025')
graph=json.loads(Path('docs/evidencias/grafo-final-reconstruccion-20261025.json').read_text())
for key,h in [('archive_path','archive_sha256'),('previous_archive','previous_archive_sha256'),('extraction_archive','extraction_archive_sha256')]:assert sha(graph[key])==graph[h]
assert graph['result']=='PASS_FRESH_GRAPH_DECLARED_CORPUS' and graph['prior_graph_reused'] is False
inventory=json.loads(Path('docs/evidencias/inventario-acciones-verificacion-20261025.json').read_text());assert inventory['result']=='PASS_INVENTORY_DECLARED_SOURCE_SCOPE'
assert inventory['inventory_sha256']==sha('docs/evidencias/inventario-acciones-final-20261025.json')
rep=json.loads(Path('docs/evidencias/inventario-acciones-reproduccion-20261025.json').read_text());assert sha(rep['archive'])==rep['sha256']
with tarfile.open(rep['archive']) as t:
 for name,h in rep['files'].items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==h
integrated=json.loads(Path('docs/evidencias/inventario-grafo-integracion-20261025.json').read_text())
assert integrated['result']=='PASS_SCOPED_GRAPH_INVENTORY_INTEGRATION'
assert sha(integrated['archive_path'])==integrated['archive_sha256']
assert sha('graphify-out/graph.json')==integrated['graph_sha256']
b16=json.loads(Path('docs/evidencias/b16-final-candidate-reconciliation-20261025.json').read_text());assert b16['b16_accepted'] is True
assert len(b16['current_versioned_executable_sources'])==1507
for p,h in b16['current_versioned_executable_sources'].items():assert sha(p)==h,p
assert sha('docs/111-inventario-rendimiento-recorridos-beta-20261020.md')==inventory['baseline_sha256']
acts={0:'17-beta-b00-aceptacion-local-20261024.md',1:'13-beta-b04b06-aceptacion-local-20261020.md',2:'12-beta-b02b03-aceptacion-local-20261020.md',3:'12-beta-b02b03-aceptacion-local-20261020.md',4:'13-beta-b04b06-aceptacion-local-20261020.md',5:'13-beta-b04b06-aceptacion-local-20261020.md',6:'13-beta-b04b06-aceptacion-local-20261020.md',7:'16-beta-b07-aceptacion-local-20261023.md',8:'18-beta-b08-aceptacion-local-20261024.md',9:'19-beta-b09-aceptacion-local-20261024.md',10:'21-beta-b10-disposicion-local-20261024.md',11:'20-beta-b11-aceptacion-local-20261024.md',12:'14-beta-b12-aceptacion-local-20261021.md',13:'15-beta-b13-aceptacion-local-20261021.md',16:'22-beta-b16-aceptacion-local-20261025.md'}
rows=[]
for i in range(18):
 if i in acts:
  p='docs/actas/'+acts[i];assert Path(p).is_file();text=Path(p).read_text();assert 'aceptad' in text.lower() or 'aceptación' in text.lower()
  rows.append({'id':f'B{i:02d}','disposition':'accepted_local_prior_bounded_evidence','authority':p,'sha256':sha(p),'scope':'Historical acceptance retained; no full prior test battery rerun by this documentary audit.'})
 else:
  p='docs/336-deuda-siguiente-contrato-y-cierre-alpha-20261025.md';assert f'B{i:02d}' in Path(p).read_text()
  rows.append({'id':f'B{i:02d}','disposition':'deferred_not_PASS','authority':p,'sha256':sha(p)})
requirements=[
 {'id':'FINAL01','requirement':'Preserve previous graph, fresh AST and semantic full declared corpus rebuild before differential','evidence':'docs/evidencias/grafo-final-reconstruccion-20261025.json','status':'verified_with_declared_corpus_limits'},
 {'id':'FINAL02','requirement':'Version, corpus, exclusions, tools, hashes, references, collisions and extraction omissions explicit','evidence':'docs/evidencias/grafo-final-b16-20261025.tar.gz','status':'verified_with_declared_corpus_limits'},
 {'id':'FINAL03','requirement':'Separate updated inventory and traceable differential preserving I01–I28','evidence':'docs/339-diferencial-inventario-recorridos-20261025.md','status':'verified'},
 {'id':'FINAL04','requirement':'Endpoints/method/actions, tasks/triggers, browser and administration; recomputed counts and exclusions','evidence':'docs/evidencias/inventario-acciones-final-20261025.json','status':'verified_declared_structural_scope'},
 {'id':'FINAL05','requirement':'Families/actions linked to contract, roadmap, authority/dependencies, existing measurement and limits','evidence':'docs/338-inventario-acciones-recorridos-alpha-20261025.md','status':'verified_declared_scope_not_per_route_PASS'},
 {'id':'FINAL06','requirement':'Evidence reuse bounded by source/scenario identity, no speculative new product batteries','evidence':'docs/evidencias/inventario-acciones-verificacion-20261025.json','status':'verified_1507_executable_hashes_unchanged'},
 {'id':'FINAL07','requirement':'Index/followup/roadmap, semantic graph integration and final checks before final act','evidence':'docs/evidencias/inventario-grafo-integracion-20261025.json','status':'verified_integration_act_pending'}]
for r in requirements:assert Path(r['evidence']).is_file();r['sha256']=sha(r['evidence'])
result={'result':'PASS_CONTRACT_PREACT_DELIVERY_AUDIT','phase':'alpha','locally_accepted':15,'deferred_not_PASS':['B14','B15','B17'],'roadmap_total':18,'point_dispositions':rows,'final_requirements':requirements,'accepted_executable_sources_unchanged':1507,'original111_unchanged':True,'graph_sha256':integrated['graph_sha256'],'remaining':['emit_final_contract_act','record_final_act_in_graph_and_final_metadata','final_document_checks_commit_push'],'limitations':['Prior local technical acts retain their exact candidate/witness scope; not a new full regression.','B10/MOD09 timing FAIL and provisional acceptance retained.','No production/beta opening, real subjects, providers or publication.','QA optimization deferred to first stable/productive version.','Native graph semantics selective, static relations not runtime proof.']}
Path('docs/evidencias/contrato-cierre-auditoria-20261025.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('point_dispositions','final_requirements')}))
