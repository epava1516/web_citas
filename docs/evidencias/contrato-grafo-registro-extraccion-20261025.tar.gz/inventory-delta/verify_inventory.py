"""Verify counts/joins against independent offline resolver and frozen sources."""
import ast
import hashlib
import json
import re
from pathlib import Path

ROOT=Path.cwd();WORK=ROOT/'artifacts/inventory-final-20261025'
data=json.loads(Path('docs/evidencias/inventario-acciones-final-20261025.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
preservation=json.loads((WORK/'baseline-preservation.json').read_text())
assert sha(preservation['path'])==preservation['sha256']
assert [r['id'] for r in data['families']]==[f'I{i:02d}' for i in range(1,29)]
families={r['id'] for r in data['families']}
routes=data['routes'];assert len(routes)==len({r['name'] for r in routes})==170
registry=data['runtime_registry']['rows'];runtime_names={r['name'] for r in registry if not r['admin']}
assert runtime_names=={r['name'] for r in routes}
for route in routes:
 assert route['families'] and set(route['families'])<=families
 assert route['runtime_patterns'] and route['authority_sources'] and route['evidence_docs']
 file=Path(route['handler_file']);tree=ast.parse(file.read_text())
 found=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.lineno==route['handler_line']]
 assert len(found)==1 and route['handler_qualified'].endswith('.'+found[0].name),route['name']
 for control in route['literal_control_variants']:
  assert control['values'] and all(isinstance(v,str) for v in control['values'])
 for dep in route['static_dependency_closure']:assert sha(dep['file'])==dep['source_sha256']
 for doc in route['evidence_docs']:assert Path(doc).is_file()
for f in data['families']:
 assert f['relevant_sources'] and f['evidence_docs']
 assert all(Path(p).is_file() for p in f['relevant_sources']+f['evidence_docs'])
task_names={t['qualified'] for t in data['tasks']};assert len(task_names)==27
assert {b['task'] for b in data['beat_declarations']}<=task_names
assert len(data['beat_declarations'])==25
assert task_names-{b['task'] for b in data['beat_declarations']}=={'apps.mediafiles.tasks.process_blob','apps.safety.tasks.generate_portability_export'}
assert len(data['framework_management_commands'])==31
assert len({c['name'] for c in data['framework_management_commands']})==31
for c in data['framework_management_commands']:
 assert sha(c['source_file'])==c['source_sha256']
 assert c['state']=='registered_not_executed'
assert len(data['operational_runbooks'])==11
assert len({r['id'] for r in data['operational_runbooks']})==11
for r in data['operational_runbooks']:
 assert not r['executed_by_this_inventory'] and set(r['families'])<=families
 assert r['authority'] and r['limit'] and r['evidence']
 for p,h in r['source_sha256'].items():assert sha(p)==h,p
 for p in r['evidence']:assert Path(p).is_file(),p
assert len(data['management_commands'])==15
assert data['delta']['command_counts']=={'baseline':11,'current':15,'added':4,'removed':0}
assert len(data['delta']['commands_by_delta']['modified'])==1
assert len(data['admin'])==16 and data['runtime_registry']['admin_models']==['auth.group']
assert len({(r['pattern'],r['name']) for r in registry})==366
assert len(data['frontend'])==len(list(Path('templates').glob('**/*.html')))==129
valid_names={r['name'] for r in routes}|{r['name'] for r in data['admin'] if r['name']}
assert {n for t in data['frontend'] for n in t['route_name_references']}<=valid_names
for p,row in data['source_fingerprints'].items():assert sha(p)==row['current_sha256'],p
for p,expected in data['framework_version_sources'].items():assert sha(p)==expected,p
for p,expected in data['delta']['declaration_files_byte_identical'].items():assert sha(p)==expected,p
product=json.loads(Path('docs/evidencias/b16-final-candidate-reconciliation-20261025.json').read_text())['current_versioned_executable_sources']
assert len(product)==1507
for p,expected in product.items():assert sha(p)==expected,p
for name,expected in {'home':{'I01','I02','I03','I04'},'listing_detail':{'I05'},'public_photo':{'I06'},'photo_upload':{'I13'},'listing_lifecycle':{'I17'}}.items():
 assert expected<=set(next(r for r in routes if r['name']==name)['families'])
original=Path(preservation['path']).read_text()
assert len(re.findall(r'^\| I\d\d \|',original,re.M))==28
proof={'result':'PASS_INVENTORY_DECLARED_SOURCE_SCOPE','counts':data['counts'],
       'baseline_sha256':preservation['sha256'],'original111_unchanged':True,
       'named_route_sets_match_offline_registry':True,'all170handlers_located_at_source_lines':True,
       'all27tasks_and25beat_entries_reconciled':True,'all129templates_scanned':True,
       'static_template_route_references_missing':0,'accepted_executable_sources_unchanged':1507,
       'new_http_requests_or_product_batteries':0,
       'inventory_sha256':sha('docs/evidencias/inventario-acciones-final-20261025.json'),
       'limits':data['limits']+['Structural/identity gate does not prove semantic exhaustiveness, runtime permissions or individual latency budgets.']}
Path('docs/evidencias/inventario-acciones-verificacion-20261025.json').write_text(json.dumps(proof,indent=2)+'\n')
(WORK/'verification.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
