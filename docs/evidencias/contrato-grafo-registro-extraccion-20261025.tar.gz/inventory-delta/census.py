"""Deterministic source census; observations are not functional-test evidence."""
import ast
import collections
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path.cwd()
OUT = ROOT / 'artifacts/inventory-final-20261025'
BASE = ROOT / 'artifacts/local-ci/20261020-111928-b91538fc/source-hashes.json'
OLD = json.loads(BASE.read_text())
CONTROL_FIELDS = {'operation', 'action', 'step', 'decision', 'outcome', 'event'}
modules = {}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def dotted(node):
    if isinstance(node, ast.Name): return node.id
    if isinstance(node, ast.Attribute):
        base = dotted(node.value)
        return base + '.' + node.attr if base else None
    return None

def constant(node):
    try: return ast.literal_eval(node)
    except (ValueError, TypeError, SyntaxError): return None

def load(path):
    path = Path(path)
    rel = str(path.relative_to(ROOT)) if path.is_absolute() else str(path)
    if rel in modules: return modules[rel]
    text = Path(rel).read_text(); tree = ast.parse(text)
    module = rel[:-3].replace('/', '.')
    package = module.rsplit('.', 1)[0]
    imports = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names: imports[a.asname or a.name.split('.')[0]] = a.name if a.asname else a.name.split('.')[0]
        elif isinstance(node, ast.ImportFrom):
            base = '.'.join(package.split('.')[:len(package.split('.')) - node.level + 1]) if node.level else ''
            prefix = '.'.join(x for x in [base, node.module] if x)
            for a in node.names: imports[a.asname or a.name] = prefix + '.' + a.name
    result = {'file': rel, 'text': text, 'tree': tree, 'module': module, 'imports': imports,
              'functions': {n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))},
              'classes': {n.name: n for n in tree.body if isinstance(n, ast.ClassDef)}}
    modules[rel] = result
    return result

def resolve_expr(node, module):
    value = dotted(node)
    if not value: return ast.unparse(node)
    first, *rest = value.split('.')
    return '.'.join([module['imports'].get(first, module['module'] + '.' + first)] + rest)

def find_symbol(full, depth=0):
    if depth > 8: return None
    parts = full.split('.')
    for end in range(len(parts) - 1, 0, -1):
        p = Path('/'.join(parts[:end]) + '.py')
        if not p.exists(): continue
        mod = load(p); rest = parts[end:]
        if len(rest) == 1:
            name = rest[0]
            if name in mod['functions']: return mod, mod['functions'][name]
            if name in mod['classes']: return mod, mod['classes'][name]
            if name in mod['imports']: return find_symbol(mod['imports'][name], depth + 1)
        return None
    return None

def choices(node, module):
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return choices(node.left, module) + choices(node.right, module)
    if isinstance(node, ast.Attribute) and node.attr == 'choices' and isinstance(node.value, ast.Subscript):
        sub = node.value
        if isinstance(sub.value, ast.Attribute) and sub.value.attr == 'base_fields':
            full = resolve_expr(sub.value.value, module); found = find_symbol(full)
            if found and isinstance(found[1], ast.ClassDef):
                field_name = constant(sub.slice)
                for item in found[1].body:
                    if isinstance(item, ast.Assign) and isinstance(item.value, ast.Call) and any(isinstance(t, ast.Name) and t.id == field_name for t in item.targets):
                        kw = next((k.value for k in item.value.keywords if k.arg == 'choices'), None)
                        if kw is not None: return choices(kw, found[0])
    if isinstance(node, ast.Name):
        for top in module['tree'].body:
            if isinstance(top, ast.Assign) and any(isinstance(t, ast.Name) and t.id == node.id for t in top.targets):
                node = top.value; break
    if not isinstance(node, (ast.List, ast.Tuple)): return []
    return [item.elts[0].value for item in node.elts if isinstance(item, (ast.List, ast.Tuple)) and item.elts
            and isinstance(item.elts[0], ast.Constant) and isinstance(item.elts[0].value, str)]

def function_details(module, fn):
    methods, decorators, templates, forms, control_values, dispatches, calls = [], [], [], [], [], [], []
    for d in getattr(fn, 'decorator_list', []):
        decorators.append(ast.unparse(d))
        name = dotted(d.func) if isinstance(d, ast.Call) else dotted(d)
        if name and name.endswith('require_http_methods') and d.args:
            methods += constant(d.args[0]) or []
        elif name and name.endswith('require_POST'): methods += ['POST']
        elif name and name.endswith('require_GET'): methods += ['GET']
        elif name and name.endswith('require_safe'): methods += ['GET', 'HEAD']
    branches = []
    for n in ast.walk(fn):
        if isinstance(n, ast.Compare) and 'request.method' in ast.unparse(n):
            branches += [v.value for v in ast.walk(n) if isinstance(v, ast.Constant) and v.value in ['GET','POST','HEAD','PUT','PATCH','DELETE','OPTIONS']]
        if not isinstance(n, ast.Call): continue
        expr = dotted(n.func)
        if expr: calls.append({'target_expression': expr, 'qualified_static': resolve_expr(n.func, module), 'line': n.lineno})
        for a in n.args:
            if isinstance(a, ast.Constant) and isinstance(a.value, str) and a.value.endswith('.html'):
                templates.append(a.value)
        if expr and expr.split('.')[-1].endswith('Form'):
            forms.append(resolve_expr(n.func, module))
        if expr and expr.endswith(('.delay', '.apply_async', '.on_commit', '.on_commit_lazily')):
            dispatches.append({'expression': ast.unparse(n), 'line': n.lineno})
    for full in sorted(set(forms)):
        found = find_symbol(full)
        if not found or not isinstance(found[1], ast.ClassDef): continue
        form_module, cls = found
        for field in cls.body:
            if not isinstance(field, ast.Assign) or not isinstance(field.value, ast.Call): continue
            for target in field.targets:
                if not isinstance(target, ast.Name) or target.id not in CONTROL_FIELDS: continue
                kw = next((k.value for k in field.value.keywords if k.arg == 'choices'), None)
                if kw is not None:
                    control_values.append({'field': target.id, 'values': choices(kw, form_module),
                                           'expression': ast.unparse(kw), 'file': form_module['file'], 'line': field.lineno,
                                           'status': 'literal_choices' if choices(kw, form_module) else 'dynamic_choices_unresolved'})
    for n in ast.walk(fn):
        if isinstance(n, ast.Compare):
            expr = ast.unparse(n.left)
            if any(re.search(r'\b' + field + r'\b', expr) for field in CONTROL_FIELDS):
                literals = [v.value for c in n.comparators for v in ast.walk(c) if isinstance(v, ast.Constant) and isinstance(v.value, str)]
                if literals: control_values.append({'field': expr, 'values': literals, 'file': module['file'], 'line': n.lineno, 'status': 'observed_branch_not_exhaustive'})
    return {'explicit_method_guard': sorted(set(methods)), 'observed_method_branches': sorted(set(branches)),
            'method_limit': None if methods else 'No explicit method decorator at this function; branch observations are not a method allowlist',
            'decorators': decorators, 'templates': sorted(set(templates)), 'form_classes': sorted(set(forms)),
            'controls': control_values, 'direct_call_expressions': calls, 'async_or_commit_dispatches': dispatches}

def families(view, name):
    mod, fn = view.rsplit('.', 1)
    if name == 'home': return ['I01','I02','I03','I04']
    if name == 'listing_detail': return ['I05']
    if name in {'public_photo','private_photo','moderation_photo','match_image','photo_reuse_image'}:
        return ['I06'] + (['I15'] if name == 'private_photo' else ['I16'] if name in {'moderation_photo','match_image'} else ['I25'] if name == 'photo_reuse_image' else [])
    if name == 'health': return ['I27','I28']
    if 'sitemap' in name or name == 'robots' or mod.endswith('.legal'): return ['I08']
    if 'promotion' in mod: return ['I19']
    if 'favorites' in mod: return ['I07']
    if 'lifecycle' in mod: return ['I17']
    if mod.startswith('apps.mediafiles'):
        return ['I13'] if 'upload' in fn else ['I06'] if fn in {'public_photo','private_photo','moderation_photo'} else ['I15']
    if mod.startswith('apps.listings'):
        if 'moderation' in mod or 'match_views' in mod: return ['I16']
        if 'appeal' in mod or 'restriction' in mod: return ['I15','I20']
        if 'detail' in fn: return ['I05']
        return ['I11'] if fn == 'dashboard' else ['I12']
    if mod.startswith('apps.core'):
        if any(x in mod for x in ['agenc','manager','organization']): return ['I18']
        if any(x in mod for x in ['mfa','verification']): return ['I10']
        return ['I11'] if fn in {'dashboard','index'} else ['I09']
    if any(x in mod for x in ['portability','rights_exports','rights_object']): return ['I22']
    if any(x in mod for x in ['complaint','report']): return ['I20']
    if 'notice_operations' in mod: return ['I23','I25']
    if 'media_operations' in mod: return ['I25']
    if 'communication' in mod or 'account_email' in mod: return ['I23']
    return ['I21']

routes, includes = [], []
for p in sorted([Path('config/urls.py')] + list(Path('apps').glob('**/*urls.py'))):
    module = load(p)
    for n in ast.walk(module['tree']):
        if not isinstance(n, ast.Call) or dotted(n.func) not in {'path','re_path'} or len(n.args) < 2: continue
        pattern = constant(n.args[0]); target = n.args[1]
        name = next((constant(k.value) for k in n.keywords if k.arg == 'name'), None)
        if isinstance(target, ast.Call) and dotted(target.func) == 'include':
            includes.append({'file': str(p), 'line': n.lineno, 'pattern': pattern, 'module': constant(target.args[0])}); continue
        if not name: continue
        full = resolve_expr(target, module); found = find_symbol(full)
        row = {'id': 'R_' + name, 'name': name, 'local_pattern': pattern, 'declaration_file': str(p), 'line': n.lineno,
               'view_expression': ast.unparse(target), 'view_qualified': full, 'families': families(full, name),
               'functional_state': 'partial_family_witness_not_individual_action_PASS', 'performance_state': 'pending_individual_measurement_unless_scoped_family_evidence'}
        if found:
            m, fn = found; row.update(handler_file=m['file'], handler_line=fn.lineno,
                                     handler_qualified=m['module'] + '.' + fn.name, details=function_details(m, fn))
            visited = set(); closure = []; pending = [(m, fn, 0)]
            while pending:
                owner, body, depth = pending.pop(0)
                identity = owner['module'] + '.' + body.name
                if identity in visited: continue
                visited.add(identity); details = function_details(owner, body)
                closure.append({'qualified':identity,'file':owner['file'],'line':body.lineno,'depth':depth,
                                'templates':details['templates'],'source_sha256':sha(owner['file'])})
                if depth < 2:
                    for call in details['direct_call_expressions']:
                        resolved = find_symbol(call['qualified_static'])
                        if resolved and isinstance(resolved[1],(ast.FunctionDef,ast.AsyncFunctionDef)):
                            pending.append((resolved[0],resolved[1],depth+1))
            row['static_dependency_closure'] = closure
            row['dependency_limit'] = 'Own-source function references through depth2; not complete transitive or dynamic runtime dependencies'
        else: row['unresolved_handler'] = True
        routes.append(row)

tasks, triggers, commands, signals, frontend = [], [], [], [], []
for p in sorted(Path('apps').glob('**/*.py')):
    module = load(p)
    for fn in module['functions'].values():
        if any((dotted(d.func) if isinstance(d, ast.Call) else dotted(d) or '').endswith('shared_task') for d in fn.decorator_list):
            tasks.append({'id': 'T_' + module['module'] + '.' + fn.name, 'qualified': module['module'] + '.' + fn.name,
                          'file': str(p), 'line': fn.lineno, 'decorators': [ast.unparse(d) for d in fn.decorator_list],
                          'calls': function_details(module, fn)['direct_call_expressions']})
    for n in ast.walk(module['tree']):
        if isinstance(n, ast.Call):
            expr = dotted(n.func) or ''
            if expr.endswith(('.delay','.apply_async','.on_commit','.on_commit_lazily')):
                triggers.append({'file': str(p), 'line': n.lineno, 'expression': ast.unparse(n), 'qualified_dispatch': resolve_expr(n.func,module)})
            if expr.endswith('.connect') and any(x in module['text'] for x in ['post_save','post_delete','m2m_changed']):
                signals.append({'file':str(p),'line':n.lineno,'expression':ast.unparse(n)})
    if '/management/commands/' in str(p) and p.name != '__init__.py':
        parser_args=[]
        for n in ast.walk(module['tree']):
            if isinstance(n,ast.Call) and (dotted(n.func) or '').endswith('.add_argument'):
                parser_args.append({'flags':[constant(a) for a in n.args if constant(a) is not None],
                                    'choices':next((constant(k.value) for k in n.keywords if k.arg=='choices'),None),'line':n.lineno})
        commands.append({'name':p.stem,'file':str(p),'arguments':parser_args})

settings=load('config/settings.py');beat=[]
for n in ast.walk(settings['tree']):
    if isinstance(n,ast.Dict):
        keys=[constant(k) for k in n.keys]
        if 'task' in keys and 'schedule' in keys:
            beat.append({'task':constant(n.values[keys.index('task')]),'schedule_seconds':constant(n.values[keys.index('schedule')]),'line':n.lineno})
for p in sorted(Path('templates').glob('**/*.html')):
    text=p.read_text();forms=[]
    for match in re.finditer(r'<form\b[^>]*>',text,re.I|re.S):
        forms.append({'line':text[:match.start()].count('\n')+1,'tag':match.group(0),
                      'method':(re.search(r'\bmethod=["\']([^"\']+)',match.group(0),re.I).group(1).upper() if re.search(r'\bmethod=["\']([^"\']+)',match.group(0),re.I) else 'GET(defaultHTML)')})
    controls=[{'field':m.group(1),'value':m.group(2),'line':text[:m.start()].count('\n')+1}
              for m in re.finditer(r'name=["\'](operation|action|step|decision|outcome|event)["\'][^>]*value=["\']([^"\']*)',text)]
    polling=[{'expression':m.group(0),'line':text[:m.start()].count('\n')+1} for m in re.finditer(r'hx-(?:get|post|trigger)=["\'][^"\']+["\']',text)]
    navigation=[]
    for match in re.finditer(r'<(a|img|script|link|button)\b[^>]*>',text,re.I|re.S):
        attrs={a.group(1).lower():a.group(3) for a in re.finditer(r'([a-zA-Z_:][-a-zA-Z0-9_:]*)\s*=\s*(["\'])(.*?)\2',match.group(0),re.S)}
        relevant={k:v for k,v in attrs.items() if k in {'href','src','srcset','loading','target','rel','type','name','value'}}
        if relevant:navigation.append({'tag':match.group(1).lower(),'line':text[:match.start()].count('\n')+1,'attributes':relevant})
    frontend.append({'file':str(p),'forms':forms,'controls':controls,'htmx_attributes':polling,
                     'has_form_control_or_htmx':bool(forms or controls or polling),'navigation_and_resources':navigation})
source_paths={r['declaration_file'] for r in routes}|{r.get('handler_file') for r in routes}|{r['file'] for r in tasks+triggers+commands+signals+frontend}|{'config/settings.py','docs/111-inventario-rendimiento-recorridos-beta-20261020.md'}
source_paths.discard(None)
source_paths.update(r['file'] for route in routes for r in route.get('static_dependency_closure',[]))
fingerprints={p:{'current_sha256':sha(p),'baseline_sha256':OLD.get(p),'delta':'added' if p not in OLD else 'conserved' if sha(p)==OLD[p] else 'modified'} for p in sorted(source_paths)}
result={'state':'SOURCE_CENSUS_NOT_FUNCTIONAL_OR_PERFORMANCE_ACCEPTANCE','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'baseline_witness':'20261020-111928-b91538fc; dated source witness cited by original111, not a claimed exact timestamp of its manual review',
        'routes':routes,'includes':includes,'tasks':tasks,'beat_declarations':beat,'async_commit_triggers':triggers,'signal_connections':signals,
        'management_commands':commands,'frontend':frontend,'source_fingerprints':fingerprints,
        'limits':['Methods only explicit decorators/observed branches, not invented allowlists','Literal form controls and branches do not exhaust dynamic dispatch','Direct calls are static expressions, not verified runtime bindings','Family witnesses never automatically grant individual action PASS','Admin/runtime resolver census separate and offline; no requests/database access']}
(OUT/'source-census.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'routes':len(routes),'unresolved_handlers':[r['name'] for r in routes if r.get('unresolved_handler')],
                  'tasks':len(tasks),'beat_declarations':len(beat),'commands':len(commands),'async_commit_calls':len(triggers),
                  'templates_with_interactions':len(frontend),'route_controls':sum(len(r.get('details',{}).get('controls',[])) for r in routes)},ensure_ascii=False))
