"""Offline URL-registry census. No request, database or network access allowed."""
import json
import os
import socket
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))

os.environ.update(DJANGO_SETTINGS_MODULE='config.settings', APP_ENV='development',
                  RECOVERY_MODE='0', DJANGO_SECRET_KEY='inventory-synthetic-only-' + 'x' * 48,
                  POSTGRES_DB='inventory_no_connection', POSTGRES_USER='synthetic',
                  POSTGRES_PASSWORD='synthetic', DB_HOST='127.0.0.1', DB_PORT='1',
                  SAFETY_HMAC_KEY='', MFA_ENCRYPTION_KEY='', MFA_ENCRYPTION_KEY_FALLBACKS='',
                  RIGHTS_PROXY_DELIVERY_ENABLED='0', RIGHTS_OBJECT_STORAGE_ENABLED='0',
                  PROMOTION_TEST_MODE='0')

def forbidden(*args, **kwargs):
    raise AssertionError('Offline inventory forbids network/database access')

socket.socket.connect = forbidden
socket.create_connection = forbidden
import django
from django.db.backends.base.base import BaseDatabaseWrapper

BaseDatabaseWrapper.ensure_connection = forbidden
django.setup()
from django.contrib import admin
from django.core.management import get_commands
from django.urls import URLResolver, get_resolver
from django.utils.translation import override

rows = []
def visit(patterns, prefix='', namespaces=(), language='es'):
    for entry in patterns:
        path = prefix + str(entry.pattern)
        if isinstance(entry, URLResolver):
            visit(entry.url_patterns, path, namespaces + ((entry.namespace,) if entry.namespace else ()), language)
        else:
            callback = entry.callback
            rows.append({'language': language, 'pattern': path,
                         'name': ':'.join(namespaces + (entry.name,)) if entry.name else None,
                         'callback': getattr(callback, '__module__', '') + '.' + getattr(callback, '__qualname__', ''),
                         'admin': 'admin' in namespaces})

for language in ['es', 'en']:
    with override(language):
        visit(get_resolver().url_patterns, language=language)
payload = {'method': 'Django URL resolver only, with socket and database connection methods blocked; not requests or integration tests',
           'django_version': django.get_version(), 'rows': rows,
           'admin_models': sorted(f'{m._meta.app_label}.{m._meta.model_name}' for m in admin.site._registry),
           'global_admin_actions': sorted(admin.site._actions),
           'management_registry': get_commands(),
           'limits': 'Registered routes under explicit synthetic development settings; permissions, model-specific customizations and future registrations may change exposure. No request executed.'}
Path('artifacts/inventory-final-20261025/runtime-urls.json').write_text(json.dumps(payload, indent=2) + '\n')
print(json.dumps({'state': 'OFFLINE_URL_REGISTRY_INVENTORIED', 'rows_with_two_language_passes': len(rows),
                  'admin_models': payload['admin_models'], 'django': payload['django_version']}))
