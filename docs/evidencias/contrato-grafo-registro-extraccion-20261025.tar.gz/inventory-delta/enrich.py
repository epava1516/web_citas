"""Join source observations, dated evidence and stable I01–I28 identities."""
import ast
import collections
import hashlib
import json
import re
from pathlib import Path

ROOT = Path.cwd(); WORK = ROOT/'artifacts/inventory-final-20261025'
data = json.loads((WORK/'source-census.json').read_text())
runtime = json.loads((WORK/'runtime-urls.json').read_text())
baseline_path = ROOT/'docs/111-inventario-rendimiento-recorridos-beta-20261020.md'
baseline_text = baseline_path.read_text()
old = json.loads(Path('artifacts/local-ci/20261020-111928-b91538fc/source-hashes.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
families = []
EVIDENCE = {
 'I01':('B07/B08/B16','318,330,332,334','Mezcla vigente y oráculos; no p95 exclusivo de listado ni todas las poblaciones.'),
 'I02':('B07/B08/B16','318,329,330,332,334','Promociones sintéticas; prioridad/páginas/autoridad, no compra ni autosubida bajo toda carga.'),
 'I03':('B07/B08/B16','318,330,332,334','Combinaciones ciudad/perfil/idioma/texto con oráculo; no producto cartesiano de todos los filtros.'),
 'I04':('B07/B08/B16','318,330,334','Páginas inicial/intermedia/última y vacíos; no todas las páginas grandes ni p95 por página.'),
 'I05':('B02/B03/B07/B16','105,329,330,334','Ficha participa en tercios de mezcla; agregado no equivale a p95 individual.'),
 'I06':('B03/B09/B16','305,306,307,329','Entrega/privacidad y carga inicial de galería; sin presupuesto universal de transferencia o red.'),
 'I07':('B03/B16','329','Exposición y retirada en favoritos con tercero intacto; sin presupuesto individual de latencia.'),
 'I08':('B02/B03/B16','105,329','Textos versionados, superficies y SEO locales; textos sintéticos no revisión jurídica ni medición de cada sitemap.'),
 'I09':('B00/B02/B03/B16','105,299,329','Autoridad de cuenta/sesión y aceptación vigentes en escenarios; sin entrega de identidad externa real.'),
 'I10':('B00/B14/B16','299,312,329','Guardias locales/MFA y rechazo de simuladores; proveedores reales no elegidos ni integrados.'),
 'I11':('B02/B03/B16','105,329','Panel/perfil simple, navegación y actores probados; no presupuesto de cada cardinalidad de panel.'),
 'I12':('B02/B03/B11/B16','105,311,329','Perfil romántico, rechazo de campos profesionales e historia privada preservada; UI/autoridad no p95 de guardado.'),
 'I13':('B03/B07/B10/B16','327,328,329,334','15subidas302conPhoto/UploadAttempt en borradores distintos; no procesamiento asíncrono entero desde302.'),
 'I14':('B10/B16','327,328','Detector1000Blob/5positivos3,20s y100densos14,39s; no80koriginales, ingestión/cola completa o índice adoptado.'),
 'I15':('B03/B06/B16','329','Fotos WEBP/sinEXIF, lectura privada/retirada/revisión por escenarios; no medición completa de transferencia/ordenación.'),
 'I16':('B02/B03/B06/B16','105,317,329','Revisión/publicación ESEN, rechazo/corrección, actores y worker/Beat reales; tiempos humanos excluidos.'),
 'I17':('B04/B05/B06/B16','329','Ventana4h, renovación idempotente, carreras, caducidad y retirada sin esperarBeat; sin p95 por operación.'),
 'I18':('B00/B02/B03/B16','299,329','Representados con teléfono compartido y autoridad separada; no identidad/representación externa real.'),
 'I19':('B07/B08/B14/B16','329,330,334','Derechos/rotación/rollback y fixtures comerciales; no ventas, pasarela ni compra concurrente reales.'),
 'I20':('B06/B09/B12/B13/B16','305,307,329,335','ColaSQL30/210→10/10y revocación/retirada/urgencia; no latencia de cada decisión ni cobertura humana real.'),
 'I21':('B00/B11/B13/B16','299,311,329,335','Autoridad fresca antes de descifrado, derechos y recuperación por escenario; no aceptación jurídica global.'),
 'I22':('B10/MOD09/B11/B13/B16','326,328,334,335','Dos sujetos1500revisiones/16MiBJSON/64MiBoriginales:FAILtemporal actual conservado, integridad verificada; selección31páginas p95<2s.'),
 'I23':('B12/B13/B14/B16','140,160,329,335','Outbox/reintento y dos caídas locales; primer intento no recepción email/SMS externa.'),
 'I24':('B07/B08/B12/B13/B16','317,329,330,334,335','Guardia de modelos históricos y reparación actual14→0marcas; autoridad inmediata separada de convergencia; backlog no universal.'),
 'I25':('B12/B13/B16','140,160,329,335','16purgas/limpiezas conciliadas y5restauraciones actuales; noPITR/custodia externa/recifrado exhaustivo o todas las cardinalidades.'),
 'I26':('B02/B03/B09/B11/B16','305,306,307,311,329','Geografía local sinXHR, teclado/ESEN y galería8→1imagen inicial; noSLO browser completo con red/dispositivo reales.'),
 'I27':('B00/B07/B10/B12/B13/B16','326,328,329,334,335','Cuotas8CPU/8GiB/swap0y recursos propios; no aislamiento del host ni capacidad universal o cada endpoint a20RPS.'),
 'I28':('B12/B13/B17/B16','137,140,143,160,335,336','15comandos y registroAdmin offline; no ejecutar comandos destructivos niCRUDAdmin; responsables/custodia/apertura pendientes.')}
doc_paths = {p.name.split('-',1)[0]:str(p) for p in Path('docs').glob('*.md')}
baseline_rows = re.findall(r'^\| (I\d\d) \| ([^|]+) \| ([^|]+) \| ([^|]+) \|$',baseline_text,re.M)
assert len(baseline_rows)==28
for ident,name,operations,measurement in baseline_rows:
 road,docs,limit=EVIDENCE[ident]
 families.append({'id':ident,'name':name.strip(),'baseline_operations':operations.strip(),
                  'baseline_measurement':measurement.strip(),'roadmap':road.split('/'),
                  'evidence_docs':[doc_paths[x] for x in docs.split(',')],
                  'functional_state':'parcial_por_escenarios_con_aceptacion_local_B16_separada',
                  'performance_state':'parcial' if ident in {'I01','I02','I03','I04','I05','I13','I14','I20','I22','I24','I25','I26','I27','I28'} else 'pendiente_de_medicion_individual',
                  'delta':'familia_conservada_con_implementacion_o_evidencia_actualizada','limit':limit,
                  'contract':'docs/16-contrato-ejecucion-desarrollo.md;docs/14-contrato-funcional-v1.md',
                  'acceptance_scope':'docs/actas/22-beta-b16-aceptacion-local-20261025.md;not universal PASS for this inventory'})
by_family={f['id']:f for f in families}

for route in data['routes']:
 route['runtime_patterns']=list(dict.fromkeys(r['pattern'] for r in runtime['rows'] if r['name']==route['name']))
 assert route['runtime_patterns'],route['name']
 route['declaration_delta']='conserved_exact_dated_source_bytes' if sha(route['declaration_file'])==old.get(route['declaration_file']) else 'changed_source_requires_review'
 route['authority_sources']=[{'file':'apps/core/middleware.py','scope':'RecoveryGate/AccountGate/CSRF/session policy; not a substitute for scoped handler guards'},
                             {'file':route['handler_file'],'line':route['handler_line'],'scope':'handler/decorators/service calls recorded; guards must be preserved'}]
 route['evidence_docs']=list(dict.fromkeys(p for f in route['families'] for p in by_family[f]['evidence_docs']))
 route['roadmap']=sorted(set(p for f in route['families'] for p in by_family[f]['roadmap']))
 route['literal_control_variants']=[c for c in route['details']['controls'] if c['status']=='literal_choices']
 route['control_limit']='Form enum values are conditional on state/authority; separate fields are not an asserted valid Cartesian product. Display-only branches remain diagnostics, not actions.'

def task_families(name):
 if name.startswith('apps.catalog.'):return ['I19']
 if name.startswith('apps.listings.'):return ['I17','I24'] if name.endswith('expire_listings') else ['I24']
 if name.endswith('process_blob'):return ['I13','I14']
 if name.startswith('apps.mediafiles.'):return ['I15','I25']
 if 'generate_portability' in name:return ['I22']
 if 'portability' in name or 'export_object' in name or 'object_deliver' in name:return ['I22','I25']
 if name.endswith('deliver_safety_notices'):return ['I23']
 if 'urgent_report' in name:return ['I20','I23']
 return ['I21','I25']

for task in data['tasks']:
 task['families']=task_families(task['qualified'])
 task['beat_declarations']=[b for b in data['beat_declarations'] if b['task']==task['qualified']]
 task['declaration_delta']='conserved_exact_dated_source_bytes' if sha(task['file'])==old.get(task['file']) else 'modified'
 task['source_sha256']=sha(task['file']);task['functional_state']='parcial_por_escenarios';task['performance_state']='pendiente_por_lote_y_cola'
 task['evidence_docs']=list(dict.fromkeys(p for f in task['families'] for p in by_family[f]['evidence_docs']))
 task['source_limit']='Same task declaration bytes do not prove unchanged transitive services or scheduling mode. Shared_task defaults90soft/120hard; overrides in decorators are recorded.'
for command in data['management_commands']:
 command['families']=['I28']+(['I25'] if 'recovery' in command['name'] or 'restore' in command['name'] else ['I24'] if command['name']=='refresh_publication_state' else ['I27'] if command['name'] in {'bootstrap','initialize_rights_runtime','configure_rights_evidence_role'} else [])
 command['source_sha256']=sha(command['file']);command['delta']='added' if command['file'] not in old else 'conserved' if sha(command['file'])==old[command['file']] else 'modified'
 command['functional_state']='inventariado_no_ejecutado_por_este_censo';command['evidence_docs']=by_family['I28']['evidence_docs']
 command['authority_limit']='Operator process/files/database privileges and command-specific confirmations required; census never runs handle().'

admin=[]
for row in runtime['rows']:
 if not row['admin'] or row['language']!='es':continue
 ident=row['name'] or 'unnamed_'+hashlib.sha256(row['pattern'].encode()).hexdigest()[:12]
 admin.append({'id':'A_'+ident,'name':row['name'],'patterns':[x['pattern'] for x in runtime['rows'] if x['admin'] and x['callback']==row['callback'] and x['name']==row['name']],
               'callback':row['callback'],'families':['I28'],'functional_state':'pendiente;registro_offline_no_peticion',
               'performance_state':'pendiente','authority':'DjangoAdmin staff/active plus model permissions where applicable; project AccountGate/current legal acceptance/MFA and RecoveryGate remain applicable',
               'authority_sources':['apps/core/middleware.py','apps/core/mfa.py','django.contrib.admin.sites','django.contrib.admin.options'],
               'evidence_docs':by_family['I28']['evidence_docs'],'limit':'Only auth.group registered in this configured census; generic routes may deny or404 for unsupported targets. No CRUD/action executed.'})

source=Path('apps/listings/publication_state.py').read_text();tree=ast.parse(source);tables=[]
for node in tree.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='DEPENDENCY_TABLES' for t in node.targets):tables=sorted(ast.literal_eval(node.value.args[0]))
sql_sources=[]
for p in Path('apps/listings/migrations').glob('*.py'):
 if 'CREATE TRIGGER' in p.read_text() or 'TRIGGERS =' in p.read_text():sql_sources.append({'file':str(p),'source_sha256':sha(p),'scope':'SQL trigger templates; not a live database trigger census'})
data['publication_triggers']={'model_signal_events':['post_save','post_delete','m2m_changed'],'callback':'apps.listings.publication_signals.schedule_refresh',
                             'eligible_tables':tables,'transaction_callback':'_enqueue_refresh after commit, deduplicated; historical registries excluded',
                             'sources':['apps/listings/apps.py','apps/listings/publication_signals.py','apps/listings/publication_state.py'],
                             'database_trigger_templates':sql_sources,'families':['I24','I27'],'limit':'Bulk/rawSQL do not emit model signals; database invalidation/native authority/Beat remain distinct.'}
data['javascript']=[{'file':str(p),'source_sha256':sha(p),'families':['I26'],
                     'listener_events':re.findall(r'addEventListener\(["\']([^"\']+)',p.read_text()),
                     'network_calls':re.findall(r'\b(fetch|XMLHttpRequest|WebSocket)\s*\(',p.read_text()),
                     'limit':'Source observations, not measured DOM latency or browser execution'} for p in sorted(Path('static').glob('*.js'))]
for frontend in data['frontend']:
 frontend['families']=['I26'];frontend['source_sha256']=sha(frontend['file']);frontend['functional_state']='parcial_por_escenarios;markup_no_prueba_backend'
 frontend['route_name_references']=sorted(set(re.findall(r'{%\s*url\s+["\']([^"\']+)',Path(frontend['file']).read_text())))
 frontend['evidence_docs']=by_family['I26']['evidence_docs']

current_commands={c['file'] for c in data['management_commands']};old_commands={f for f in old if '/management/commands/' in f and f.endswith('.py') and not f.endswith('/__init__.py')}
declaration_files=sorted({r['declaration_file'] for r in data['routes']}|{t['file'] for t in data['tasks']})
assert all(sha(f)==old[f] for f in declaration_files)
delta={'baseline_document_sha256':sha(baseline_path),'baseline_dated_source_witness':data['baseline_witness'],
       'declaration_files_byte_identical':{f:sha(f) for f in declaration_files},
       'named_route_counts':{'baseline':170,'current':170,'added':0,'removed':0,'declaration_modified':0},
       'shared_task_counts':{'baseline':27,'current':27,'added':0,'removed':0,'declaration_modified':0},
       'command_counts':{'baseline':len(old_commands),'current':len(current_commands),'added':len(current_commands-old_commands),'removed':len(old_commands-current_commands)},
       'commands_by_delta':{k:[c['name'] for c in data['management_commands'] if c['delta']==k] for k in ['added','modified','conserved']},
       'family_counts':{'baseline':28,'current':28,'added':0,'retired':0,'documentation_and_evidence_expanded':28},
       'limit':'Exact declaration identity is established against the dated source witness cited by111; not a claim that111 recorded every action/method or that all transitive behavior is unchanged.'}
data.update(families=families,admin=admin,admin_global_actions=runtime['global_admin_actions'],runtime_registry=runtime,delta=delta,
            source_versions={'accepted_application_baseline':'b97d8c6','inventory_commit':data['source_commit'],'graph_base_sha256':json.loads(Path('docs/evidencias/grafo-final-reconstruccion-20261025.json').read_text())['graph_sha256']})
unique_runtime={(r['pattern'],r['name']) for r in runtime['rows']}
data['counts']={'families':28,'named_application_routes':170,'application_localized_patterns':len({(r['pattern'],r['name']) for r in runtime['rows'] if not r['admin']}),
                'admin_canonical_patterns':len(admin),'admin_localized_patterns':len({(r['pattern'],r['name']) for r in runtime['rows'] if r['admin']}),
                'all_distinct_runtime_patterns':len(unique_runtime),'shared_tasks':27,'beat_source_declarations':len(data['beat_declarations']),
                'management_commands':15,'async_commit_call_sites':len(data['async_commit_triggers']),'model_signal_event_kinds':3,
                'templates_scanned':len(data['frontend']),
                'templates_with_interactions':sum(t['has_form_control_or_htmx'] for t in data['frontend']),
                'templates_with_navigation_or_resources':sum(bool(t['navigation_and_resources']) for t in data['frontend']),
                'own_javascript_files':len(data['javascript']),
                'literal_form_control_values':sum(len(c['values']) for r in data['routes'] for c in r['literal_control_variants'])}
data['budget_policy']={'contractual':'Public mix10000/20RPS/900s,p95<800ms/errors<1%,8CPU/8GiB,original generator gates retained; MOD09exception scoped',
                       'proposed_not_accepted':'Additional p99,individual/browser/async budgets in111remain proposals, not new gates',
                       'no_new_tests_by_inventory':True,'qa_optimization_contract':'deferred until first stable/productive version'}
for p in ['apps/core/middleware.py','apps/core/mfa.py','config/celery.py',
          'apps/listings/apps.py','apps/listings/publication_signals.py','apps/listings/publication_state.py'] + [r['file'] for r in data['javascript']] + [r['file'] for r in sql_sources] + [c['file'] for r in data['routes'] for c in r['details']['controls'] if c.get('file')]:
 data['source_fingerprints'].setdefault(p,{'current_sha256':sha(p),'baseline_sha256':old.get(p),
                                         'delta':'added' if p not in old else 'conserved' if sha(p)==old[p] else 'modified'})
data['styles']=[{'file':'static/app.css','current_sha256':sha('static/app.css'),'families':['I26'],'limit':'Source stylesheet, not a browser timing or accessibility verdict'}]
data['task_policy']={'default_queue':'clasificados','namespace':'clasificados:{TASK_QUEUE_GENERATION}:',
                     'serialization':'JSON','ignore_result':True,'default_soft_seconds':90,'default_hard_seconds':120,
                     'generate_portability_export_soft_hard_seconds':[240,300],
                     'process_blob_retry':'OSError,backoff,max_retries3;recover_media_jobs examines queued/stale>3min/failed attempts<4/missing comparison,limit100',
                     'beat_modes':{'normal_development_without_synthetic_promotions':24,'synthetic_promotions_enabled':25,'recovery_mode':0},
                     'recovery_worker_guard':'RecoveryAwareTask.before_start ignores consumed business messages; not merely empty Beat schedule',
                     'limits':'Source-defined policies, not end-to-end SLA or live queue observation. Conditional mode/cadence does not prove a job ran.'}
data['framework_version_sources']={str(p):sha(p) for p in [Path('.venv/lib/python3.12/site-packages/django/contrib/admin/sites.py'),Path('.venv/lib/python3.12/site-packages/django/contrib/admin/options.py'),Path('.venv/lib/python3.12/site-packages/django/contrib/auth/admin.py')]}
overrides={'I14':['apps/mediafiles/services.py','apps/mediafiles/similarity.py'],
           'I24':['apps/listings/apps.py','apps/listings/publication_signals.py','apps/listings/publication_state.py']+[r['file'] for r in sql_sources],
           'I27':['config/settings.py','config/celery.py','apps/core/middleware.py','apps/core/mfa.py'],
           'I26':['static/app.css']+[r['file'] for r in data['javascript']]}
for family in families:
 ident=family['id'];related={r['handler_file'] for r in data['routes'] if ident in r['families']}
 related.update(dep['file'] for r in data['routes'] if ident in r['families'] for dep in r.get('static_dependency_closure',[]))
 related.update('templates/'+template for r in data['routes'] if ident in r['families'] for dep in r.get('static_dependency_closure',[]) for template in dep['templates'] if Path('templates/'+template).exists())
 related.update(t['file'] for t in data['tasks'] if ident in t['families'])
 related.update(c['file'] for c in data['management_commands'] if ident in c['families'])
 related.update(overrides.get(ident,[]))
 if ident=='I26':related.update(t['file'] for t in data['frontend'])
 family['relevant_sources']=sorted(related)
 for p in related:data['source_fingerprints'].setdefault(p,{'current_sha256':sha(p),'baseline_sha256':old.get(p),'delta':'added' if p not in old else 'conserved' if sha(p)==old[p] else 'modified'})
data['framework_management_commands']=[]
for name,package in sorted(runtime['management_registry'].items()):
 if package.startswith('apps.'):continue
 p=Path('.venv/lib/python3.12/site-packages')/package.replace('.','/')/'management/commands'/f'{name}.py'
 assert p.exists()
 data['framework_management_commands'].append({'name':name,'package':package,'source_file':str(p),'source_sha256':sha(p),
                                              'families':['I28'],'state':'registered_not_executed',
                                              'optimization_scope':'QA_deferred' if name in {'test','testserver'} else 'code_generation_not_product_journey' if name in {'startapp','startproject'} else 'operator_tool',
                                              'authority':'OS/process/database authority and command-specific flags, not an HTTP permission grant'})
runbooks=[
 ('O_STARTUP','Inicio/parada y comprobación de servicios locales',['I27','I28'],['docs/02-arquitectura.md','docs/12-operacion-seguridad.md','compose.yaml'], 'Configuración/locales ensayados; no despliegue o disponibilidad del destino.'),
 ('O_WORKER_BROKER','Recuperación de worker/broker y outbox',['I23','I25','I28'],[doc_paths['141'],doc_paths['160']], 'Dos caídas propias y replay; no reinicio de host o fallo a mitad de toda tarea.'),
 ('O_ENCRYPTION','Transición de cifrado y lectores retenidos',['I21','I25','I28'],[doc_paths['142'],doc_paths['143']], 'Lectura antigua/escritura nueva e inventario acotado; no recifrado exhaustivo, retirada universal o recuperación de claves perdidas.'),
 ('O_DJANGO_SIGNING','Rotación de firma Django y consumidores',['I09','I21','I28'],[doc_paths['147'],doc_paths['151']], 'Sesiones y HMAC derivados tienen ámbitos diferentes; no revalidación automática de todas las decisiones/bindings.'),
 ('O_PG_CREDENTIAL','Rotación y reconexión de credencial PostgreSQL',['I27','I28'],[doc_paths['148']], 'Reconexiones propias y reinicio coordinado; no hot reload universal o credencial productiva.'),
 ('O_REDIS_CREDENTIAL','Rotación Redis/Kombu y continuidad de cola',['I23','I27','I28'],[doc_paths['149']], 'Mensajes/namespace propios conservados en escenario; no garantía exactly-once o recepción externa.'),
 ('O_PROXY_SECRET','Recarga del secreto del proxy Caddy',['I22','I27','I28'],[doc_paths['154']], 'Transporte local, secreto viejo rechazado y grant pendiente; no operación de proveedor/destino.'),
 ('O_RESTORE','Copia/pg_dump/pg_restore/medios y reconciliación',['I21','I25','I28'],[doc_paths['152'],doc_paths['155'],doc_paths['160']], 'Cinco restauraciones actuales en353y autoridad/replay/medio verificados; noPITR/offsite/custodia humana real.'),
 ('O_RUNTIME_RETURN','Retorno y vuelta entre versiones de runtime',['I25','I27','I28'],[doc_paths['145'],doc_paths['146'],doc_paths['158']], 'Ciclo histórico local versionado, sin downgrade de esquema; no afirmar repetición sobre toda imagen/candidata actual.'),
 ('O_DOMAIN_INCIDENT','Incidente y revocación de clave HMAC de dominio',['I09','I21','I28'],[doc_paths['159']], 'Cierra autoridad antigua y permite entrada nueva; no migración automática de bindings ni reutilizar clave comprometida para reabrirlos.'),
 ('O_URGENT_WITHDRAWAL','Retirada urgente, escalado y sustitución local',['I16','I20','I28'],[doc_paths['144'],doc_paths['160']], 'Drills y retirada ES/EN con evidencia/tercero preservados; no cobertura humana o tiempo de resolución real.')]
data['operational_runbooks']=[]
for ident,title,ids,sources,limit in runbooks:
 assert all(Path(p).is_file() for p in sources)
 data['operational_runbooks'].append({'id':ident,'name':title,'families':ids,'sources':sources,
                                     'source_sha256':{p:sha(p) for p in sources},'functional_state':'parcial_por_testigo_local_fechado',
                                     'performance_state':'no_SLA_productivo','authority':'Ingeniería local en aislamiento; operador/custodia/autorización real pendientes deB17',
                                     'evidence':['docs/actas/15-beta-b13-aceptacion-local-20261021.md','docs/evidencias/b16-operational-gates-reconciliation-20261025.json'],
                                     'limit':limit,'executed_by_this_inventory':False})
 for ident_family in ids:by_family[ident_family]['relevant_sources']=sorted(set(by_family[ident_family]['relevant_sources'])|set(sources))
 for p in sources:data['source_fingerprints'].setdefault(p,{'current_sha256':sha(p),'baseline_sha256':old.get(p),'delta':'added' if p not in old else 'conserved' if sha(p)==old[p] else 'modified'})
data['counts'].update(framework_management_commands=len(data['framework_management_commands']),operational_runbooks=len(data['operational_runbooks']))
(ROOT/'docs/evidencias/inventario-acciones-final-20261025.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
(WORK/'enriched-inventory.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'counts':data['counts'],'delta':delta['command_counts'],'commands':delta['commands_by_delta']},ensure_ascii=False))
