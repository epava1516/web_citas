"""Render the traceable census without changing the historical baseline."""
import collections
import json
from pathlib import Path

data=json.loads(Path('docs/evidencias/inventario-acciones-final-20261025.json').read_text())
def esc(value): return str(value).replace('|','\\|').replace('\n',' ')
def link(path,label=None): return f'[{label or Path(path).name}](../{path})'
def code(value): return '`'+esc(value)+'`'

lines=['# Inventario actualizado de acciones y recorridos — alfa, 25 de octubre de 2026','',
'''Versión actualizada separada de la [base111](111-inventario-rendimiento-recorridos-beta-20261020.md), que permanece intacta. Conserva I01–I28 y se acompaña del [diferencial339](339-diferencial-inventario-recorridos-20261025.md) y de la [matriz legible por máquina](evidencias/inventario-acciones-final-20261025.json). Se realiza después de la [reconstrucción completa del grafo](evidencias/grafo-final-reconstruccion-20261025.json), conforme a la adenda del contrato16.

El proyecto permanece en alfa. B16 tiene aceptación local por acta22; B14/B15/B17 se difieren según336, sin convertirse en PASS. Este inventario está completado en el alcance declarado; sus estados parciales se refieren a cobertura funcional o medición de cada escenario, no a una reapertura automática de las aceptaciones locales.

## Método y unidades

Censo AST de declaraciones de URL, funciones, decoradores de método, controles de formularios, llamadas propias hasta profundidad dos, tareas, despachos y comandos. Registro de URL de Django5.2.17 inspeccionado con conexiones de socket y de base de datos bloqueadas, configuración sintética explícita, sin ejecutar peticiones ni comandos administrativos. La expansión del registro no es prueba funcional de Admin.

Son 170 declaraciones con nombre de la aplicación y 27 tareas `shared_task`, igual que en la base. Los doce archivos que definen ambas superficies coinciden por bytes con el testigo de fuentes20261020-111928-b91538fc citado por111. Esto acredita identidad de esas declaraciones, no de todos sus servicios transitivos ni de la hora exacta de revisión manual de111.

Las 170 declaraciones producen334 patrones de aplicación al considerar ES/EN y no duplicar las seis rutas sin idioma. Admin añade16 patrones canónicos,32 con idiomas:366 patrones distintos en total. Son patrones con parámetros, no un número finito de URLs concretas o de funcionalidades. El barrido de dos idiomas devuelve372 filas antes de deduplicar esas seis rutas comunes.

Además:15 comandos propios,25 declaraciones de Beat,14 lugares de despacho/callback de commit, tres tipos de señales de modelo,106 plantillas con formularios/controles/HTMX y tres JavaScript propios. Hay154 valores de controles de formulario asociados a rutas, con repeticiones: no son154 acciones de negocio independientes ni un producto cartesiano válido. Estos recuentos representan unidades diferentes y no se suman.

## Matriz estable I01–I28

Cada familia enlaza contrato14/16 y los puntos indicados del roadmap103. La matriz JSON vincula cada ruta, tarea o comando con fuentes, líneas, huellas, dependencias relevantes y evidencia familiar. La cobertura de una familia no adjudica PASS a todos sus métodos, estados o valores de control. «Parcial» conserva ese límite.
''',
'| ID | Familia | Roadmap | Evidencia y límite de medición |','| --- | --- | --- | --- |']
for f in data['families']:
 refs=', '.join(f'[{Path(p).name.split("-")[0]}]({Path(p).name})' for p in f['evidence_docs'])
 lines.append(f"| {f['id']} | {esc(f['name'])} | {'/'.join(f['roadmap'])} | {refs}. {esc(f['limit'])} |")
lines += ['', '''## Estado de mediciones y presupuestos

La carga pública vigente334 termina con18000 respuestas correctas y15 subidas, p95 observable410,559ms, bajo cuotas8CPU/8GiB y swap0. Es una mezcla en tercios de listado/búsqueda/ficha ES/EN y filtros combinados, con68 oráculos antes/después; no certifica p95 de cada endpoint, cada idioma por separado, todos los filtros ni toda cardinalidad. La subida302 con persistencia no mide procesamiento y cola completos.

I14 conserva el diagnóstico de detector:1000Blob distintos/cinco positivos,3,20s;100Blob densos/cien coincidencias,14,39s. No es latencia de subida, cola completa,80mil originales o retención ilimitada. No se adoptó índice nuevo.

I22 conserva el FAIL temporal actual362: cobertura alrededor3,37s y paquetes JSON/binario alrededor6,5–6,8s frente a objetivos2/5s, con integridad y separación verificadas. MOD09 mantiene su aceptación provisional y deuda; no se reescribe como PASS. Las31 lecturas de selección por sujeto sí tienen p95 recalculados1,472582/1,474600s y solapamiento real. Tampoco ese dato acepta todo el flujo.

Los límites contractuales de mezcla pública permanecen estrictamente<800ms/<1%, con contabilidad y generador originales. Los p99, umbrales individuales, tiempos de navegador y plazos asíncronos adicionales de111 siguen siendo propuestas pendientes de validación, no gates adoptados retrospectivamente. Un timeout no es un tiempo de respuesta aceptable. La frecuencia real de usuarios y los costes productivos aún no están acreditados.

## Matriz de endpoints y controles

En la tabla, los patrones son locales a su archivo de declaración; las formas completas y ambos idiomas están en JSON. Métodos se toman de decoradores explícitos. Veinticinco funciones no tienen un decorador de método: sus ramas observadas no constituyen una lista de métodos admitidos, y middleware/delegaciones pueden intervenir. No se inventa GET exclusivo. Las ramas de presentación como `event.operation == expire` se conservan como diagnóstico de código y no como una nueva acción ofrecida.

Toda ruta conserva RecoveryGate, sesiones/CSRF y AccountGate cuando aplican, además de sus permisos y autoridad de sujeto, versión, consentimiento, representación, MFA y revocación en servicios. La lista de llamadas no prueba esos permisos: las evidencias y límites familiares remiten a pruebas concretas de B16. Las dependencias de profundidad dos son navegación estática, no un grafo transitivo ni un trace runtime exhaustivos.
''',
'| Ruta estable | Familia | Métodos explícitos | Patrón local | Implementación | Valores de control |',
'| --- | --- | --- | --- | --- | --- |']
for r in data['routes']:
 methods='/'.join(r['details']['explicit_method_guard']) or 'sin decorador de método'
 controls='; '.join(c['field']+'='+','.join(c['values']) for c in r['literal_control_variants']) or '—'
 implementation=link(r['handler_file'],r['handler_qualified'])+f" L{r['handler_line']}"
 lines.append(f"| {code(r['id'])} | {'/'.join(r['families'])} | {methods} | {code(r['local_pattern'])} | {implementation} | {code(controls) if controls!='—' else controls} |")
lines += ['', '''## Tareas, disparadores y recuperación

Las25 declaraciones de Beat no son25 tareas ejecutadas. Sin promoción sintética hay24 entradas; con ese modo hay25; en recuperación, cero y `RecoveryAwareTask.before_start` ignora además mensajes de negocio consumidos. Cola por defecto `clasificados`, prefijo por generación y JSON; estados `succeeded` o resultados ignorados no acreditan recepción externa.

Cadencias declaradas: una de10s, una de30s,21 de60s y dos de3600s, contando la promoción condicional. `process_blob` y `generate_portability_export` se despachan a demanda; recuperar medios vuelve a encolar trabajo elegible. Límites generales90s suave/120s duro; exportación240/300s por intento. El procesamiento fotográfico reintenta OSError con backoff y máximo tres reintentos; la recuperación revisa cola, antigüedad mayor de tres minutos, intentos y comparación incompleta, por lotes de cien. No son SLA de extremo a extremo.

Publicación conecta `post_save`, `post_delete` y `m2m_changed` al callback deduplicado después del commit. Se excluyen registros históricos de migración. Las tablas elegibles y las plantillas de triggers SQL están enumeradas en JSON; no se simula un censo de triggers de una base viva. Escrituras bulk/rawSQL, invalidación de base, lectura nativa y reparación por Beat se distinguen de las señales Python. Retirada o revocación no esperan a la próxima cadencia para impedir exposición.
''',
'| Tarea | Familia | Cadencia declarada | Fuente |','| --- | --- | --- | --- |']
for t in data['tasks']:
 cadence=', '.join(str(int(b['schedule_seconds']))+'s' for b in t['beat_declarations']) or 'a demanda'
 if t['qualified'].endswith('bump_promotions'):cadence+='; sólo modo sintético'
 lines.append(f"| {code(t['qualified'])} | {'/'.join(t['families'])} | {cadence} | {link(t['file'])} L{t['line']} |")
lines += ['', '''## Operación administrativa

Admin registra únicamente `auth.group` en este censo. Sus rutas genéricas pueden denegar o devolver404 para objetivos sin soporte. Las guardias de Django de usuario activo/staff y permisos del modelo se suman a AccountGate, MFA y RecoveryGate del proyecto. El registro global ofrece `delete_selected`, condicionado a permisos y confirmación; no se ejecutó ni se acredita por enumerarlo. Los paneles propios de moderación/derechos están en sus familias correspondientes, no se confunden con Django Admin.
''','| Nombre Admin | Callback | Patrones ES/EN |','| --- | --- | --- |']
for a in data['admin']:
 lines.append(f"| {code(a['name'] or a['id'])} | {code(a['callback'])} | {'; '.join(code(p) for p in a['patterns'])} |")
lines += ['', '| Comando propio | Diferencia de fuente | Fuente y alcance |','| --- | --- | --- |']
for c in data['management_commands']:
 lines.append(f"| {code(c['name'])} | {c['delta']} | {link(c['file'])}; argumentos/confirmaciones en JSON; no se ejecutó `handle()` |")
lines += ['', '### Herramientas de Django y recorridos operativos', '',
'El registro añade31 comandos del framework a los15 propios. Se enumeran con su fuente y huella en JSON; no se han ejecutado. Las herramientas de QA y generación de proyectos quedan fuera de la optimización de recorridos de aplicación.', '',
'| Comando Django | Alcance |', '| --- | --- |']
for c in data['framework_management_commands']:
 lines.append(f"| {code(c['name'])} | {esc(c['optimization_scope'])}; registrado, no ejecutado |")
lines += ['', 'Los once recorridos operativos enlazan manuales, autoridad, evidencia fechada y límites. Su enumeración no acredita una operación nueva ni disponibilidad productiva. B17 conserva las responsabilidades externas pendientes.', '',
'| Recorrido | Familia | Fuentes | Evidencia y límite |', '| --- | --- | --- | --- |']
for r in data['operational_runbooks']:
 refs=', '.join(link(p) for p in r['sources'])
 evidence=', '.join(link(p) for p in r['evidence'])
 lines.append(f"| {esc(r['name'])} | {'/'.join(r['families'])} | {refs} | {evidence}. {esc(r['limit'])} |")
lines += ['', '''## Navegador y entrega

Se revisan las129 plantillas propias, incluidos enlaces, botones e imágenes/recursos;106 contienen formularios, controles de operación o HTMX. Las referencias literales de nombres URL resuelven contra las170 declaraciones. Los atributos dinámicos conservan su expresión, sin inventar destino. Los tres JavaScript propios cubren selectores geográficos y asociación de errores; las opciones geográficas se manipulan localmente, sin una nueva API de geografía. HTMX y recursos del navegador se distinguen del JavaScript propio; la dependencia vendorizada no se cuenta como código propio.

La consulta periódica de exportación pendiente y la entrega diferida de fotografías requieren fijar sesiones simultáneas, duración, bytes, red y dispositivo al medir. Un navegador probado funcionalmente no demuestra un p99 de interacción; el HTML no acredita el backend. La mejora de galería de B09 conserva su evidencia de carga inicial dentro de su escenario, sin generalizar a toda red.

## Primera cola del siguiente contrato

1. Acordar escenarios, clase de tamaño, uso esperado y presupuestos aplicables sobre esta matriz. Priorizar evidencia de coste y riesgo; no inferir frecuencia desde centralidad del grafo o duración de QA.
2. Retomar deuda medida de I22/MOD09 e I14: cobertura/paquetes, cardinalidad de Blob, densidad, confirmación/registro, retención, concurrencia y cola. Conservar la excepción y los negativos hasta una comparación nueva válida.
3. Segmentar I01–I05 por selectividad, página, idioma, estado y frío/caliente; completar I11–I17 desde recepción hasta estado utilizable, manteniendo autoridad y formatos. No repetir la batería contractual por rutina.
4. Medir decisiones/colas I20–I25 y navegador/imágenes I06/I26 según volumen y responsabilidad local. Tratar transferencia, espera humana y proveedor por separado.
5. Revisar los nuevos comandos y la administración I28 en escenarios propios, con roles y confirmaciones. B14/B15/B17 siguen diferidos según336; no se eligen proveedores, no se implementa personalización ni se abre beta por esta matriz.

La medición/corrección/optimización específica de QA permanece aplazada hasta la primera versión estable/productiva. Este inventario es de acciones de aplicación y operación, no ese contrato de QA. Las próximas pruebas de producto sólo se justificarán por un cambio, incertidumbre o escenario concreto; no por el número de filas.

## Límites de exhaustividad

Cobertura estructural contrastada con todas las declaraciones propias de rutas y tareas, registro de URL del modo explícito, comandos, plantillas y señales indicados. No enumera todas las combinaciones de datos/estados, métodos de librería, URL concreta con cada UUID, destinatario/proveedor, proceso humano o rama dinámica. La recuperación y los modos cambian exposición y planificación. Las fuentes externas y los permisos efectivos requieren el entorno autorizado correspondiente. Esas exclusiones son explícitas, no PASS ni defectos supuestos.

No se detectó una referencia literal de plantilla a nombre URL inexistente en este censo. No se ha ejecutado una batería nueva ni cambiado código de aplicación. El cierre documental exige aún integrar este inventario al grafo y comprobar los entregables finales del contrato.
''']
Path('docs/338-inventario-acciones-recorridos-alpha-20261025.md').write_text('\n'.join(lines)+'\n')

delta=data['delta'];fp=data['source_fingerprints'];rows=['# Diferencial del inventario de recorridos — 25 de octubre de 2026','',
f"Base preservada: [111](111-inventario-rendimiento-recorridos-beta-20261020.md), SHA256 `{delta['baseline_document_sha256']}`. Resultado separado: [inventario338](338-inventario-acciones-recorridos-alpha-20261025.md) y [censo completo](evidencias/inventario-acciones-final-20261025.json). Se parte del grafo reconstruido y auditado, no se arrastran sus estados como pruebas de ejecución.", '',
'''## Comparación trazable

El original111 citaba el ensayo20261020-111928-b91538fc. Se recupera su manifiesto de fuentes como testigo fechado; no se finge que111 guardó un listado de todas sus acciones o la hora exacta de su inspección manual. Doce archivos de rutas/tareas son idénticos porSHA: los conjuntos de170 rutas nombradas y27 tareas conservan identidad frente a ese testigo, no sólo cantidades iguales.

No se añadieron, retiraron o modificaron declaraciones en esos doce archivos. Esto no significa que formularios, servicios, autoridad, plantillas, datos o rendimiento permanezcan iguales. Las huellas actuales y previas de fuentes relacionadas se conservan en JSON. Cambios de archivo no prueban por sí solos cambio funcional de cada función que contiene.

Los11 comandos anteriores pasan a15: se añaden `operational_snapshot`, `operational_assessment`, `operational_events_report` y `encryption_key_inventory`; `apply_recovery_ledger` cambia y diez se conservan por bytes. No se retira ninguno de ese conjunto. Los cuatro nuevos son acciones de operación dentro de I28, no familias ficticias I29–I32.

Admin, métodos, controles y disparadores no estaban enumerados individualmente en111. Su expansión actual se clasifica como **cobertura añadida al inventario**, no como funcionalidad necesariamente añadida al producto. La misma distinción se aplica a las106 plantillas y los tres scripts propios.
''', '| Unidad | Base | Actual | Diferencia acreditada |','| --- | ---: | ---: | --- |',
'| Familias I01–I28 | 28 | 28 | Identidades conservadas; evidencia y desglose ampliados |',
'| Declaraciones URL propias con nombre | 170 | 170 | 0 añadidas/retiradas/modificadas en archivos declarantes comparados |',
'| shared_task | 27 | 27 | 0 añadidas/retiradas/modificadas en archivos declarantes comparados |',
'| Comandos propios | 11 en testigo fechado | 15 | 4 añadidos,1 modificado,10 conservados,0 retirados |',
'| Admin | Pendiente de expansión | 16 patrones canónicos | Desglose nuevo, no incremento demostrado de funcionalidad |',
'| Patrones por idiomas y comunes | No censados | 366 totales | 334 aplicación+32Admin; no URLs concretas ni funcionalidades |',
'| Beat | No confundido con27 tareas | 25 declaraciones,24/25/0 por modo | Cadencias y modos añadidos al inventario |',
'| Controles de formulario | No desglosados | 154 valores asociados a rutas | Valores y condiciones, no154 acciones independientes |',
'| Señales y callbacks | Pendientes | 3 tipos de señal y14 lugares async/commit | Unidades distintas; no sumar como trabajos ejecutados |','',
'## Disposición de las 28 familias','',
'| ID | Familia | Diferencia frente a111 | Fuentes relacionadas cambiadas/nuevas |','| --- | --- | --- | --- |']
for f in data['families']:
 related=set(f['relevant_sources'])
 changed=[p for p in related if p in fp and fp[p]['delta'] in ['modified','added']]
 difference='Familia conservada; métodos/dependencias/evidencia conciliados'
 if f['id']=='I22':difference+='; FAILtemporal MOD09 y selecciónTCP dispuestos por separado'
 if f['id']=='I28':difference+=';4 comandos nuevos y expansiónAdmin'
 rows.append(f"| {f['id']} | {esc(f['name'])} | {difference} | {len(changed)} archivos; detalle SHA en JSON, no equivalencia transitiva |")
rows += ['', '''## Cambios relevantes y deuda

El contrato adapta el perfil romántico y preserva historia privada, autoridad fresca, revisión y ciclo de vida. La evidencia actual añade la regresión funcional/capacidad conciliada de B16, variantes explícitas y carga contractual vigente. No se convierte la antigua columna «por conciliar» en un PASS universal: el inventario actual conserva límites por escenario, versión y método.

B07/B08/B09 mantienen optimizaciones aceptadas con sus comparaciones; B10 queda resuelto como evaluación/disposición, con deuda MOD09 y detector exacto. B14/B15/B17 se trasladan según336, sin aceptación de proveedores, personalización o apertura. El inventario y su primera cola de medición/optimización son la primera prioridad del siguiente contrato; QA específico sigue aplazado a la primera versión estable/productiva.

El documento111 y sus propuestas de presupuestos no se modifican. No se eleva un objetivo propuesto a contrato ni se repite una prueba válida para actualizar este registro. Una revisión futura que cambie código, escenarios o exposición deberá actualizar las huellas, la evidencia y este diferencial.

## Entrega y aceptación documental

Se requiere comprobar identidad I01–I28, conjuntos de rutas/tareas, vínculo de cada fila a fuente/familia/evidencia, huellas, referencias de plantillas y límites de Admin/modos. La integración semántica de338/339 y del seguimiento/roadmap se realizará sobre el grafo nuevo, declarando el alcance focal y sin presentarlo como una segunda reconstrucción desde cero. El acta final sólo se emitirá después de esa comprobación. El proyecto sigue en alfa.
''']
Path('docs/339-diferencial-inventario-recorridos-20261025.md').write_text('\n'.join(rows)+'\n')
print('Wrote338and339; original111untouched')
