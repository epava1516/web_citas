import ast,copy,hashlib,json,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n03-d-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
a,b=read(W/'reference-audit.json'),read(W/'candidate-audit.json');assert a['junit'][0]['failures']=='4' and b['functional_cases']==37
for audit in [a,b]:
 P=Path('artifacts/local-ci')/audit['run'];r=read(P/'result.json');assert r['sources_unchanged']
 assert read(P/'telegram-notification.json')['delivery']=='sent' and not Path(read(P/'runner.json')['temporary']).exists()
 for kind in ['container','volume','network']:
  cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];q=subprocess.run(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],capture_output=True,text=True,check=True);assert not q.stdout.strip()
P=Path('artifacts/local-ci')/b['run'];cases=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==37 and not any(c.find(k)is not None for c in cases for k in ['failure','error','skipped'])
f=read(W/'candidate-freeze.json');assert all(sha(p)==h for p,h in f['sources'].items() if p!='.ai/tasks/desarrollo.md')
for p,row in read(W/'candidate-scope.json').items():
 assert sha(p)==row['after_sha256'];before=W/(Path(p).stem+'-before.py');assert sha(before)==row['before_sha256']
 a_tree,b_tree=ast.parse(before.read_text()),ast.parse(Path(p).read_text())
 def rest(t):
  t=copy.deepcopy(t);t.body=[n for n in t.body if not isinstance(n,ast.FunctionDef) or n.name!=row['changed_definition']];return ast.dump(t,include_attributes=False)
 assert rest(a_tree)==rest(b_tree)
 if p.endswith('services.py'):
  old=next(n for n in a_tree.body if isinstance(n,ast.FunctionDef) and n.name=='process');new=next(n for n in b_tree.body if isinstance(n,ast.FunctionDef) and n.name=='process')
  targets=[n for n in ast.walk(old) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Compare) and any(isinstance(t,ast.Name) and t.id=='ready' for t in n.targets)];assert len(targets)==1
  targets[0].value=ast.parse('blob.status == "ready" and bool(blob.signature)',mode='eval').body;assert ast.dump(old,include_attributes=False)==ast.dump(new,include_attributes=False)
assert read(W/'native-review-verification.json')['citations']==11
for name in ['prereg/report.json','fix-review.json','final-graph/report.json']:
 r=read(W/name);assert r['STATUS']=='complete' and isinstance(r['IMPLEMENTATION_NOTES'],str) and isinstance(r['TEST_RESULTS'],str)
 for k in ['FILES_CHANGED','TESTS_RUN','ASSUMPTIONS','RISKS','UNRESOLVED_ISSUES','RECOMMENDATIONS']:assert isinstance(r[k],list)
for kind,d in b['measurements'].items():
 assert all(t['dispatches']==1 for t in a['measurements'][kind]['ticks'])
 assert sum(t['dispatches'] for t in d['ticks'])<sum(t['dispatches'] for t in a['measurements'][kind]['ticks'])
out={'result':'PASS_LOCAL_N03D_PROGRESS_NOT_N03_BLOCK_ACCEPTANCE','original_failures_preserved':4,'candidate_functional_passes':37,'sources_intact_during_runs':True,'current_source_hashes_verified_except_declared_worklog_delta':True,'all_resources_temporary_removed':True,'terminal_telegram_both_sent':True,'app_scope_two_functions_only':True,'fences_unchanged_ast':True,'native_source_citations_verified':11,'recovery_selector_queries_per_call':1,'selector_time_increase_not_hidden':True,'pending':['Real Celery retry/backoff and Beat reconciliation','N03/N07 action sufficiency','No global four-attempt claim']}
(W/'acceptance-verification.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
