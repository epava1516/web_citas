import hashlib,json,math,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n03-d-20261025');P=Path('artifacts/local-ci/20261025-184941-1ac056e3')
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
r=read(P/'result.json');f=read(W/'candidate-freeze.json');assert r['result']=='PASS' and r['sources_unchanged'] and r['workers']==1
assert r['selection']==['tests/test_media_recovery_progress.py','tests/test_media_job_recovery.py','tests/test_preparation_cleanup.py','tests/test_photos.py']
assert all(Path(p).is_file() and hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in f['sources'].items())
cs=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cs)==37 and not any(c.find(k)is not None for c in cs for k in ['failure','error','skipped'])
measurements={};selections=[]
expected={'empty_signature':[1,0],'history_only':[0,0],'mixed_history_current':[1,0],'missing_original':[1,1,1,0]}
for c in cs:
 props={x.attrib['name']:x.attrib['value'] for x in c.iter('property')}
 if 'n03d_progress' in props:
  d=json.loads(props['n03d_progress']);kind=d['kind'];assert kind in expected and kind not in measurements
  assert [t['dispatches'] for t in d['ticks']]==expected[kind]
  for i,t in enumerate(d['ticks']):
   assert t['tick']==i and math.isfinite(t['selector_seconds']) and t['selector_seconds']>=0
   if t['process_seconds']is not None:assert math.isfinite(t['process_seconds']) and t['process_seconds']>=0
  if kind=='missing_original':
   assert [t['attempts'] for t in d['ticks']]==[2,3,4,4] and all(t['status']=='failed' for t in d['ticks'])
   assert [t['storage_error'] for t in d['ticks']]==[True,True,True,False]
  else:
   assert all(t['status']=='ready' and t['signature_present'] and not t['storage_error'] for t in d['ticks'])
   assert all(t['attempts']==(2 if kind=='empty_signature' else 1) for t in d['ticks'])
  measurements[kind]=d
 if 'n03c_recovery_selection' in props:
  d=json.loads(props['n03c_recovery_selection']);assert len(d['samples'])==6
  assert all(s['queries']==1 and s['dispatches']==min(d['count'],100) for s in d['samples']);selections.append(d['count'])
assert set(measurements)==set(expected) and sorted(selections)==[0,1,10,100,101]
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];q=subprocess.run(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],capture_output=True,text=True,check=True);assert not q.stdout.strip()
assert not Path(read(P/'runner.json')['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_RECOVERY_PROGRESS_AND_REGRESSION_NOT_N03_BLOCK_ACCEPTANCE','run':P.name,'junit':r['junit'],'functional_cases':len(cs),'source_count':len(f['sources']),'sources_unchanged':True,'measurements':measurements,'recovery_selection_cohorts':selections,'recovery_selection_queries_each':1,'cleanup_verified':True,'telegram':tg,'limitations':['Direct process and captured dispatch do not prove worker/Beat/backoff','Only empty-signature legacy metadata repaired; no arbitrary malformed-data guarantee','Observed clocks describe different work before/after, not causal speedup','No global four-attempt guarantee across Celery messages']}
(W/'candidate-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps({'result':out['result'],'functional_cases':len(cs),'measurements':measurements,'junit':r['junit']}))
