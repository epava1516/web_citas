import hashlib,json,math,subprocess,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n03-d-20261025');P=Path('artifacts/local-ci/20261025-184432-abf4326e')
r=json.loads((P/'result.json').read_text());f=json.loads((W/'reference-freeze.json').read_text());assert r['result']=='ERROR' and r['sources_unchanged'] and r['selection']==f['selection']
assert r['junit'][0]['tests']==r['junit'][0]['failures']=='4' and r['junit'][0]['errors']==r['junit'][0]['skipped']=='0'
assert all(Path(p).is_file() and hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in f['sources'].items())
expected={'empty_signature':'Ready without signature never progresses','history_only':'Historical-only image requeues without progress','mixed_history_current':'Historical sibling keeps completed current work queued','missing_original':'Missing original silently loops as ready'}
measurements={}
for c in E.parse(P/'pytest.xml').iter('testcase'):
 props={x.attrib['name']:x.attrib['value'] for x in c.iter('property')};d=json.loads(props['n03d_progress']);assert d['kind'] in expected and d['kind'] not in measurements
 assert c.find('failure')is not None and expected[d['kind']] in c.find('failure').attrib['message']
 assert len(d['ticks'])==(4 if d['kind']=='missing_original' else 2)
 for i,t in enumerate(d['ticks']):
  assert t['tick']==i and t['dispatches']==1 and not t['storage_error'] and t['attempts']==1 and t['status']=='ready'
  assert all(math.isfinite(t[k]) and t[k]>=0 for k in ['selector_seconds','process_seconds'])
 measurements[d['kind']]=d
assert set(measurements)==set(expected)
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];q=subprocess.run(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],capture_output=True,text=True,check=True);assert not q.stdout.strip()
assert not Path(json.loads((P/'runner.json').read_text())['temporary']).exists();tg=json.loads((P/'telegram-notification.json').read_text());assert tg['delivery']=='sent'
out={'audit':'CONFIRMED_FOUR_REFERENCE_FAILURES_NOT_PASS','run':P.name,'runner_result':r['result'],'junit':r['junit'],'source_count':len(f['sources']),'sources_unchanged':True,'expected_failure_messages':expected,'measurements':measurements,'cleanup_verified':True,'telegram':tg,'scope':'Real PostgreSQL, private synthetic storage and direct task/service; captured dispatch not broker/worker/Beat proof'}
(W/'reference-audit.json').write_text(json.dumps(out,indent=2));print('Audited4FAIL,10repeateddispatches,noprogress,sources/cleanup/Telegram.')
