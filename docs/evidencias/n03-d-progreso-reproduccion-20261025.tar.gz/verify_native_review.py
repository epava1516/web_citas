import hashlib,json,re
from pathlib import Path
W=Path('artifacts/recorridos-n03-d-20261025')
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
for name in ['fix-review.json','prereg/report.json']:
 r=read(W/name);assert r['STATUS']=='complete';assert isinstance(r['IMPLEMENTATION_NOTES'],str) and isinstance(r['TEST_RESULTS'],str)
 for k in ['FILES_CHANGED','TESTS_RUN','ASSUMPTIONS','RISKS','UNRESOLVED_ISSUES','RECOMMENDATIONS']:assert isinstance(r[k],list)
r=read(W/'fix-review.json')
for p,h in r['source_sha256'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
for key,cite in r['fact_citations'].items():
 p=Path(cite['file']);assert hashlib.sha256(p.read_bytes()).hexdigest()==cite['source_sha256']
 loc=re.fullmatch(r'L(\d+)(?:-L?(\d+))?',cite['line']);assert loc
 lines=p.read_text().splitlines();lo=int(loc[1]);hi=int(loc[2] or loc[1]);assert 1<=lo<=hi<=len(lines)
 assert cite['evidence_quote'] in '\n'.join(lines[lo-1:hi]),key
out={'result':'NATIVE_REVIEW_SCHEMA_SOURCES_AND_CITATIONS_VERIFIED_NOT_RUNTIME_ACCEPTANCE','source_count':len(r['source_sha256']),'citations':len(r['fact_citations']),'native_token_usage':None}
(W/'native-review-verification.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
