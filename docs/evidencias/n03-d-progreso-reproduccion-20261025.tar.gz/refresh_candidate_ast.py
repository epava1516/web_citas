import collections,copy,hashlib,json,re,shutil
from pathlib import Path
from graphify.extract import extract
W=Path('artifacts/recorridos-n03-d-20261025/candidate-graph');W.mkdir(exist_ok=True)
B=Path('graphify-out');S=W/'graph';shutil.copytree(B,S)
files=['apps/mediafiles/services.py','apps/mediafiles/tasks.py'];p=files[0];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();norm=lambda s:re.sub('[^a-z0-9]+','_',s.lower()).strip('_')
g=json.loads((S/'graph.json').read_text());oldnodes={n['id']:n for n in g['nodes']};r=extract([Path(f).resolve() for f in files],root=Path.cwd(),cache_root=W,parallel=False);assert not r['failed_sources'];(W/'ast.json').write_text(json.dumps(r,indent=2))
nodes={i:copy.deepcopy(n) for i,n in oldnodes.items() if n.get('source_file') not in files};edges=[copy.deepcopy(e) for e in g['links'] if e.get('source_file') not in files]
for f in files:
 fileid='file_'+norm(f);nodes[fileid]={'id':fileid,'label':f,'source_file':f,'source_location':'L1','file_type':'code','extraction_origin':'declared_corpus_manifest'}
for n in r['nodes']:
 if n.get('source_file') not in files:continue
 n=copy.deepcopy(n);n['extraction_origin']='fresh_AST_N03D_recovery_progress';nodes[n['id']]=n
 edges.append({'source':'file_'+norm(n['source_file']),'target':n['id'],'relation':'has_extracted_entity','source_file':n['source_file'],'source_location':n['source_location'],'confidence':'EXTRACTED','confidence_score':1.0,'weight':1.0})
for raw in r['edges']:
 e=copy.deepcopy(raw)
 for k in ['source','target']:
  i=e[k]
  if i not in nodes:
   refs=[j for j,n in nodes.items() if n.get('external') and n.get('label')==i];j=refs[0] if len(refs)==1 else 'n03c_reference_'+norm(i)
   if j not in nodes:nodes[j]={'id':j,'label':i,'external':True,'source_file':None,'source_location':None,'file_type':'concept','resolution_status':'static_reference_not_runtime_binding'}
   e[k]=j
 e['extraction_origin']='fresh_AST_N03D_recovery_progress';e.setdefault('confidence_score',1.0 if e.get('confidence')=='EXTRACTED' else .85);edges.append(e)
for e in edges:
 for k in ['source','target']:
  i=e[k]
  if i not in nodes:nodes[i]={'id':i,'label':oldnodes[i]['label'],'source_file':None,'source_location':None,'file_type':'concept','external':True,'resolution_status':'retired_static_reference_only'}
manifest=json.loads((S/'SOURCE_MANIFEST.json').read_text());
for p in files:manifest[p]={'sha256':sha(p),'bytes':Path(p).stat().st_size,'category':'code','semantic_scope':'AST_full_source_not_runtime_proof','extraction_origin':'fresh_AST_N03D_recovery_progress'}
for f,row in manifest.items():
 if f not in []:assert sha(f)==row['sha256'],f
a=json.loads((S/'.graphify_analysis.json').read_text());communities={int(c):[i for i in ids if i in nodes] for c,ids in a['communities'].items()};communities={c:v for c,v in communities.items() if v};assigned={i for v in communities.values() for i in v};new=set(nodes)-assigned
labels=json.loads((S/'.graphify_labels.json').read_text())
if new:cid=max(communities)+1;communities[cid]=sorted(new);labels[str(cid)]='N03D progreso de recuperación pendiente de validación'
for c,ids in communities.items():
 for i in ids:nodes[i].update(community=c,community_name=labels[str(c)])
pair=collections.Counter()
for e in edges:key=(e['source'],e['target']);e['key']=pair[key];pair[key]+=1
assert all(e[k] in nodes for e in edges for k in ['source','target'])
g.update(nodes=list(nodes.values()),links=edges);g['graph'].update(corpus_files=len(manifest),extraction_scope='preserved_base_plus_current_generation_fence_AST_not_acceptance')
for name,data in [('graph.json',g),('SOURCE_MANIFEST.json',manifest),('.graphify_analysis.json',{'communities':communities}),('.graphify_labels.json',labels)]:
 (S/name).write_text(json.dumps(data,ensure_ascii=False,indent=2))
proof={'result':'AST_CURRENT_RECOVERY_PROGRESS_CANDIDATE_NOT_RUNTIME_ACCEPTANCE','changed_sources':files,'source_files':len(manifest),'nodes':len(nodes),'relations':len(edges),'dangling':0,'graph_sha256':sha(S/'graph.json'),'prior_reports_scope':'384preregistration_not_candidate_acceptance'}
(W/'verification.json').write_text(json.dumps(proof,indent=2))
for f in S.iterdir():
 if f.is_file():shutil.copy2(f,B/f.name)
print(json.dumps(proof))
