# Grafo alfa — Panel N06D optimizado; conciliación N06 pendiente

N00/N01aceptados2/13. N02D367:1FAILtemporal2004,770sJUnit,no mejora global clara. Usuario acepta tiempos actuales en alfa y difiere optimización restanteMOD09al final del desarrollo. Guard local365conservado,2s/5s/FAILy deuda intactos,sin repetir batería. N06abierto: referencia encolada359,restantes variantes pendientes. Compactación y reactivación del mismo goal confirmadas por auditoría367, no nueva prueba de runtime del grafo.

N06D371:panelowner n+8→8SQL,100editores108→8;ES279,575→54,110msEN225,516→46,849msobservados. Referencia6PASS/candidata6PASS/extra3PASSincluidonavegador;no15casosdistintos,editorvariósinSQL/cambiocódigo,causalidadtemporaluniversalnoprobada. Refresco focal371/341/README/vista17líneas1–4,AST previo preservado. 1969fuentes,18501nodos/81051relaciones,878comunidades. No reconstrucción global ni semántica exhaustiva. Relaciones documentales son afirmaciones de fuentes, no ejecución independiente. Consumo nativo desconocido. JSONcompleto y HTMLde comunidades; anotaciones ambiguas y multirrelaciones conservadas.

