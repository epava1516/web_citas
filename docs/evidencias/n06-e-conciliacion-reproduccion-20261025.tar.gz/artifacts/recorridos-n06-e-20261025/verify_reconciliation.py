import ast,hashlib,json,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n06-e-20261025')
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=read(W/'functional-review.json');assert r['STATUS']=='complete' and r['TESTS_RUN']==[]
for key in ['SUMMARY','FILES_CHANGED','IMPLEMENTATION_NOTES','TEST_RESULTS','ASSUMPTIONS','RISKS','UNRESOLVED_ISSUES','RECOMMENDATIONS']:assert key in r
original=read(W/'actions-original.json');perf=read(W/'performance-reconciliation.json');rows=r['action_dispositions'];assert len(rows)==46 and {a['id'] for a in rows}=={a['id'] for a in original} and len({a['id'] for a in rows})==46
oldrun=Path('artifacts/local-ci/20261024-094540-3a6ec8ac');oldhash=read(oldrun/'source-hashes.json');cases=list(E.parse(oldrun/'pytest.xml').iter('testcase'));unique=set();checks=0
for row in rows:
 assert row['witnesses']
 for w in row['witnesses']:
  path,name=w['selector'].split('::',1);name=name.split('[',1)[0];assert sha(path)==w['source_sha256']
  funcs=[n for n in ast.walk(ast.parse(Path(path).read_text())) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name];assert len(funcs)==1 and funcs[0].lineno==w['line_start'] and funcs[0].end_lineno==w['line_end'],w
  assert w['historical_test_source_identical']==(oldhash.get(path)==sha(path))
  module=path[:-3].replace('/','.');matches=[c for c in cases if c.attrib.get('classname')==module and (c.attrib['name']==name or c.attrib['name'].startswith(name+'['))]
  h=w['historical_execution'];assert len(matches)==h['matching_cases'];passed=sum(not any(c.findall(k) for k in ['failure','error','skipped']) for c in matches);assert passed==h['PASS']
  assert len(matches)-passed==len(h['not_PASS'])
  for recent in w['recent_direct_execution']:
   p=Path('artifacts/local-ci')/recent['run']/'pytest.xml';cs=[c for c in E.parse(p).iter('testcase') if c.attrib.get('classname')==module and c.attrib['name']==recent['case']];assert len(cs)==1 and not any(cs[0].findall(k) for k in ['failure','error','skipped']) and recent['outcome']=='PASS'
  unique.add(w['selector']);checks+=1
 for s in row['current_primary_source_identity']:
  assert sha(s['file'])==s['sha256'];assert s['same_as_original_functional_run']==(oldhash.get(s['file'])==sha(s['file']))
# Exact accepted panel-only bridge for agencies; other N06 action modules unchanged.
panel=read('artifacts/recorridos-n06-d-20261025/candidate-scope.json');assert sha('apps/core/agencies.py')==panel['after_sha256'];assert sha('artifacts/recorridos-n06-d-20261025/agencies-before.py')==panel['before_sha256']
def rest(p):
 t=ast.parse(Path(p).read_text());t.body=[n for n in t.body if not isinstance(n,ast.FunctionDef) or n.name!='panel'];return ast.dump(t,include_attributes=False)
assert rest('apps/core/agencies.py')==rest('artifacts/recorridos-n06-d-20261025/agencies-before.py')
merged=[]
for p in perf['actions']:
 f=next(a for a in rows if a['id']==p['id']);merged.append({**p,'functional_review':f})
result={'result':'PASS_N06E_RECONCILIATION_NOT_BLOCK_ACCEPTANCE','action_count':len(rows),'witness_citations_checked':checks,'unique_selectors_checked':len(unique),'historical_overall_result':read(oldrun/'result.json')['result'],'historical_junit_sha256':sha(oldrun/'pytest.xml'),'performance_counts':perf['counts'],'actions':merged,'priority_gaps':r['priority_gaps'],'limits':r['RISKS'],'new_test_executions':0,'scope':'Current source/AST/selected existing JUnit verification; historical overall ERROR preserved. No wholesale current test, transitive dependency or N06 acceptance claim.'}
(W/'reconciliation-verified.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in result.items() if k not in ['actions','priority_gaps','limits']})
