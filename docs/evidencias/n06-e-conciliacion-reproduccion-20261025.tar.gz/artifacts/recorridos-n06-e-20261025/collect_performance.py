"""Reconcile action-level measured references; no execution or closure inference."""
import ast,hashlib,json
from pathlib import Path
W=Path('artifacts/recorridos-n06-e-20261025');read=lambda p:json.loads(Path(p).read_text());actions=read(W/'actions-original.json');evidence={}
for case in read('docs/evidencias/n01-d-operaciones-auditoria-20261025.json')['case_observations']:
 for group in case['groups']:
  evidence.setdefault(group['route_name'],[]).append({'source':'docs/evidencias/n01-d-operaciones-auditoria-20261025.json','case':case['case'],'method':group['method'],'status':group['status'],'samples':group['n'],'wall_ms':group['request_ms'],'sql_queries':group['sql_queries'],'scope':'Historical N01D instrumented Client call phase, not p95/current closure'})
for case in read('docs/evidencias/n06-c-representacion-auditoria-20261025.json')['cases']:
 for sample in case['samples']:
  evidence.setdefault(sample['route_name'],[]).append({'source':'docs/evidencias/n06-c-representacion-auditoria-20261025.json','case':case['name'],'ordinal':sample['ordinal'],'method':sample['method'],'status':sample['status'],'samples':1,'wall_ms':[1000*sample['request_seconds_instrumented']],'sql_queries':[sample['sql_queries']],'scope':'N06C instrumented fixture/call reference, not p95/provider latency'})
for case in read('docs/evidencias/n06-b-cola-auditoria-20261025.json')['outcomes']:
 for sample in case['samples']:
  evidence.setdefault('listing_start',[]).append({'source':'docs/evidencias/n06-b-cola-auditoria-20261025.json','case':case['case'],'ordinal':sample['ordinal'],'method':'POST','status':sample['status'],'samples':1,'wall_ms':[1000*sample['request_seconds_instrumented']],'sql_queries':[sample['sql_queries']],'scope':'N06B real local queued mode; not equivalent to eager references; no provider/capacity claim'})
evidence['agency_panel']=[{'source':'docs/evidencias/n06-d-panel-auditoria-comparacion-20261025.json','scope':'N06D current local candidate/baseline per actor/cohort/language; five later plus first separate, 72requests/run','comparisons':read('artifacts/recorridos-n06-d-20261025/comparison.json')['rows']}]
product=read('docs/evidencias/b16-final-candidate-reconciliation-20261025.json')['current_versioned_executable_sources'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows=[]
for a in actions:
 key=a['id'].removeprefix('route:R_');refs=evidence.get(key,[]) if a['kind']=='route' else []
 changes=[p for p,h in a['source_sha256'].items() if Path(p).is_file() and sha(p)!=h]
 assert all(p=='apps/core/agencies.py' for p in changes),(a['id'],changes)
 rows.append({'id':a['id'],'kind':a['kind'],'families':a['families'],'blocks':a['blocks'],'sources':a['sources'],'source_fingerprints':{p:sha(p) for p in a['sources']},'changed_since_N00':changes,'measurement_disposition':'measured_scoped_reference' if refs else ('not_measured' if a['kind']=='route' else 'shared_runbook_or_dispatch_not_HTTP_latency'),'performance_references':refs,'functional_disposition':'pending_independent_selector_and_execution_reconciliation','limit':'Reference for observed transitions only; no automatic all-method/actor/state/growth acceptance.'})
out={'state':'PERFORMANCE_REFERENCE_RECONCILIATION_NOT_BLOCK_ACCEPTANCE','actions':rows,'counts':{'total':len(rows),'route':sum(r['kind']=='route' for r in rows),'routes_with_scoped_measurement':sum(bool(r['performance_references']) for r in rows),'routes_without_measurement':sum(r['kind']=='route' and not r['performance_references'] for r in rows),'shared_non_HTTP':sum(r['kind']!='route' for r in rows)},'sources_used':sorted({x['source'] for vs in evidence.values() for x in vs}),'scope':'No new test or invented time; measurements retain individual modalities and provenance; functional source is not execution evidence.'}
(W/'performance-reconciliation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(out['counts']);print('UNMEASURED',[r['id'] for r in rows if r['kind']=='route' and not r['performance_references']])
