"""Scoped semantic delta on a preserved fresh graph; no product AST changes."""
import collections,copy,hashlib,json,re,shutil
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path.cwd();W=ROOT/'artifacts/recorridos-n07-b-20261025/result-graph'; BASE=W/'graph-base';STAGE=W/'graph-integrated'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
norm=lambda s:re.sub('[^a-z0-9]+','_',s.lower()).strip('_')
if not BASE.exists():shutil.copytree(ROOT/'graphify-out',BASE)
if STAGE.exists():raise SystemExit('Stage exists; preserve it and choose a new staged run')
shutil.copytree(BASE,STAGE)
raw=json.loads((W/'semantic-fragment.json').read_text())
inputs=json.loads((W/'semantic-inputs.json').read_text())
changed={r['source'] for r in inputs.values()};manifest=json.loads((BASE/'SOURCE_MANIFEST.json').read_text())
# Independent literal/source validation before accepting any agent output.
for kind in ('nodes','edges'):
 for item in raw[kind]:
  p=item['source_file'];assert p in inputs,p
  assert sha(inputs[p]['source'])==inputs[p]['sha256']==item['source_sha256']
  expected=Path(inputs[p]['source']).read_text()
  if inputs[p].get('section')=='lines1-4_only':expected='\n'.join(expected.splitlines()[:4])+'\n'
  assert Path(p).read_text()==expected
  loc=re.fullmatch(r'L(\d+)(?:-L?(\d+))?',item['source_location']);assert loc,item
  lo=int(loc[1]);hi=int(loc[2] or loc[1]);lines=Path(p).read_text().splitlines()
  assert 1<=lo<=hi<=len(lines)
  assert item['evidence_quote'] and item['evidence_quote'] in '\n'.join(lines[lo-1:hi]),item
  if kind=='edges':
   assert item['confidence'] in ('EXTRACTED','INFERRED','AMBIGUOUS')
   assert item['confidence_score']==1 if item['confidence']=='EXTRACTED' else 0<=item['confidence_score']<=1
ids=[n['id'] for n in raw['nodes']];assert len(ids)==len(set(ids));assert all(re.fullmatch('[a-z0-9_]+',n) for n in ids)
assert not raw.get('hyperedges'), 'Hyperedges require explicit reconciliation'
old=json.loads((BASE/'graph.json').read_text());nodes={n['id']:copy.deepcopy(n) for n in old['nodes']}
fileid=lambda p:'file_'+norm(p)
retired={i for i,n in nodes.items() if n.get('source_file') in changed and i!=fileid(n['source_file'])}
for i in retired:del nodes[i]
edges=[copy.deepcopy(e) for e in old['links'] if e.get('source_file') not in changed]
# Only foreign citations to removed entities survive as explicit unresolved reference handles.
needed={e[k] for e in edges for k in ('source','target') if e[k] in retired}
for i in needed:nodes[i]={'id':i,'label':i,'file_type':'concept','source_file':None,'source_location':None,'external':True,'resolution_status':'prior_semantic_entity_replaced_reference_only','extraction_origin':'scoped_delta_reference_preservation'}
newids={}
resolved_legacy_references=[]
for n in raw['nodes']:
 rel=inputs[n['source_file']]['source'];newid=n['id']
 if rel=='docs/17-seguimiento-desarrollo.md':newid=newid.replace('followup_current_view','docs_17_seguimiento_desarrollo')
 if newid in nodes and newid not in needed:
  previous=nodes[newid]
  assert previous.get('external') and previous.get('resolution_status')=='prior_semantic_entity_replaced_reference_only',(newid,previous)
  assert newid.startswith(norm(str(Path(rel).with_suffix('')))+'_'),(newid,rel)
  resolved_legacy_references.append(newid)
 assert newid not in nodes or newid in needed or newid in resolved_legacy_references,(newid,nodes.get(newid))
 newids[n['id']]=newid;n=copy.deepcopy(n);n.update(id=newid,source_file=rel,extraction_origin='native_semantic_n07b_result',temporal_scope='Documentary claim, not independent runtime verification')
 nodes[newid]=n
for e in raw['edges']:
 assert e['source'] in newids and e['target'] in newids,e
 e=copy.deepcopy(e);e.update(source=newids[e['source']],target=newids[e['target']],source_file=inputs[e['source_file']]['source'],extraction_origin='native_semantic_n07b_result');edges.append(e)
for p,row in inputs.items():
 rel=row['source'];full=ROOT/rel
 manifest[rel]={'sha256':sha(full),'bytes':full.stat().st_size,'category':'document','input_path':p,'semantic_scope':row.get('section','full_file'),'input_sha256':sha(p),'extraction_origin':'native_semantic_n07b_result'}
 nodes[fileid(rel)]={'id':fileid(rel),'label':rel,'source_file':rel,'source_location':'L1','file_type':'document','extraction_origin':'declared_corpus_manifest','semantic_scope':row.get('section','full_file')}
for i in newids.values():
 n=nodes[i];edges.append({'source':fileid(n['source_file']),'target':i,'relation':'has_extracted_entity','source_file':n['source_file'],'source_location':n['source_location'],'confidence':'EXTRACTED','confidence_score':1.0,'weight':1.0,'extraction_origin':'extraction_provenance_not_application_dependency'})
refs=[]
for p,row in inputs.items():
 rel=row['source'];text=Path(p).read_text()
 for m in re.finditer(r'\]\(([^)\s]+)\)',text):
  target=m[1].split('#',1)[0]
  if not target or '://' in target:continue
  try:dest=str(((ROOT/rel).parent/target).resolve().relative_to(ROOT))
  except ValueError:continue
  if dest not in manifest:refs.append({'source':rel,'target':dest,'status':'outside_declared_corpus_reference_only'});continue
  edges.append({'source':fileid(rel),'target':fileid(dest),'relation':'cites','confidence':'EXTRACTED','confidence_score':1.0,'source_file':rel,'source_location':'L'+str(text[:m.start()].count('\n')+1),'evidence':m[0],'weight':1.0,'extraction_origin':'scoped_literal_markdown_citations'})
assert all(e[k] in nodes for e in edges for k in ('source','target'))
analysis=json.loads((BASE/'.graphify_analysis.json').read_text());communities={int(k):[i for i in v if i in nodes] for k,v in analysis['communities'].items()};communities={k:v for k,v in communities.items() if v}
assigned={i for v in communities.values() for i in v};cid=max(communities)+1;communities[cid]=sorted(set(nodes)-assigned)
labels=json.loads((BASE/'.graphify_labels.json').read_text());labels={int(k):v for k,v in labels.items() if int(k) in communities};labels[cid]='N07B referencia finita aceptada; N07 abierto'
for c,members in communities.items():
 for i in members:nodes[i].update(community=c,community_name=labels[c])
new={**old,'nodes':list(nodes.values()),'links':edges};new['graph'].update(updated_at=datetime.now(timezone.utc).isoformat(),extraction_scope='fresh_base_plus_scoped_next_contract_preparation',semantic_sources=sum(r['category']!='code' for r in manifest.values()),corpus_files=len(manifest),community_detection='fresh_base_memberships_preserved_plus_scoped_document_community',native_token_usage=None)
(STAGE/'graph.json').write_text(json.dumps(new,ensure_ascii=False,indent=2))
(STAGE/'SOURCE_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(STAGE/'.graphify_analysis.json').write_text(json.dumps({'communities':communities},ensure_ascii=False))
(STAGE/'.graphify_labels.json').write_text(json.dumps(labels,ensure_ascii=False))
proof={'state':'SCOPED_NATIVE_DELTA_LITERAL_VALIDATED','changed_sources':sorted(changed),'semantic_changed_sources':sorted(changed),'old_graph_sha256':sha(BASE/'graph.json'),'fragment_sha256':sha(W/'semantic-fragment.json'),'native_nodes':len(raw['nodes']),'native_relations':len(raw['edges']),'resolved_legacy_reference_ids':resolved_legacy_references,'retired_semantic_nodes':len(retired),'retired_foreign_references_preserved':len(needed),'excluded_citations':refs,'source_files':len(manifest),'nodes':len(nodes),'relations':len(edges),'communities':len(communities),'scope':'Base full rebuild preserved; targeted semantic document replacement, AST unchanged. Selective semantic relationships, not exhaustive truth or runtime proof.','native_token_usage':None}
(W/'semantic-integration.json').write_text(json.dumps(proof,indent=2));print(json.dumps({k:v for k,v in proof.items() if k!='excluded_citations'}))
