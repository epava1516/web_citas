import collections,hashlib,json
from pathlib import Path
W=Path('artifacts/recorridos-n07-b-20261025/result-graph');S=W/'graph-integrated';B=W/'graph-base';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((S/'SOURCE_MANIFEST.json').read_text());assert len(m)==2017
for p,r in m.items():assert sha(p)==r['sha256'],p
old=json.loads((B/'graph.json').read_text());new=json.loads((S/'graph.json').read_text());nodes={n['id']:n for n in new['nodes']};assert len(nodes)==len(new['nodes']);assert all(e[k] in nodes for e in new['links'] for k in ('source','target'))
changed={'docs/17-seguimiento-desarrollo.md','docs/405-n07-b-resultado-publicacion-worker-beat-20261025.md','tests/test_publication_worker_cadence_reference.py'}
def canon(x):return json.dumps({k:v for k,v in x.items() if k not in ('key','community','community_name')},sort_keys=True)
for n in old['nodes']:
 if n.get('source_file') not in changed:assert canon(n)==canon(nodes[n['id']]),n['id']
assert collections.Counter(canon(e) for e in old['links'] if e.get('source_file') not in changed)==collections.Counter(canon(e) for e in new['links'] if e.get('source_file') not in changed)
for n in new['nodes']:
 if n.get('extraction_origin')=='native_semantic_n07b_result':
  text=Path(n['source_file']).read_text().splitlines();loc=n['source_location'].replace('L','').split('-');lo=int(loc[0]);hi=int(loc[-1]);assert n['evidence_quote'] in '\n'.join(text[lo-1:hi]);assert n['source_sha256']==sha(n['source_file'])
a=json.loads((S/'.graphify_analysis.json').read_text());members=[i for v in a['communities'].values() for i in v];assert len(members)==len(set(members))==len(nodes) and set(members)==set(nodes)
for p,h in json.loads((S/'CURRENT_OUTPUTS.json').read_text())['sha256'].items():assert sha(S/p)==h,p
state=json.loads((S/'ESTADO_ACTUAL.json').read_text());assert state['next_mandatory_accepted']==6 and 'N07'in state['pending']
assert sha('docs/111-inventario-rendimiento-recorridos-beta-20261020.md')=='380b026c51b5e9647052838bb77a0712e9efff4ccdd857b5df3d4b545d921a95'
out={'result':'PASS_SCOPED_N07B_RESULT_GRAPH','sources':len(m),'nodes':len(nodes),'relations':len(new['links']),'communities':len(a['communities']),'graph_sha256':sha(S/'graph.json'),'scope':'405 and first4 native semantics, current instrument AST; finite reference accepted, N07 open; unaffected-source entities/edges preserved'}
(S/'GRAPH_VERIFICATION.json').write_text(json.dumps(out,indent=2)+'\n');(W/'verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
