import hashlib,json,shutil,subprocess
from pathlib import Path
W=Path('artifacts/recorridos-n07-b-20261025');G=Path('graphify-out');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=json.loads((G/'SOURCE_MANIFEST.json').read_text());bad=[p for p,r in m.items() if sha(p)!=r['sha256']];assert not bad,bad
assert sha(G/'graph.json')=='2666164a7a6c21e4a15d93f4d576e43c3f91cfe616078721b6075a05c94fe7f5'
for n in ['SOURCE_MANIFEST.json','ESTADO_ACTUAL.json','GRAPH_VERIFICATION.json']:shutil.copy2(G/n,W/('pre-'+n))
assert sha(W/'instrument-proposed.py')==json.loads((W/'root-source-review.json').read_text())['source_sha256']
out={'result':'PASS_CURRENT_PRE_N07B_SOURCE_CUT','source_files':len(m),'graph_sha256':sha(G/'graph.json'),'mismatches':bad,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'N07A result native semantics and current AST preserved, no new content changes before N07B analysis; not global semantic reconstruction. Proposed instrument unexecuted.'};(W/'pre-source-cut.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
