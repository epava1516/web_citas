"""Validate an owned, resource-limited capacity topology; never a capacity PASS."""

import argparse
import json
import os
import subprocess
import sys
import time
import uuid
import xml.etree.ElementTree as ET
from pathlib import Path

from run_local_ci import hashes

ROOT = Path(__file__).resolve().parents[1]
MIB = 1024 * 1024
ALLOCATIONS = {"pg": (100000, 1536), "redis": (25000, 512), "app": (275000, 6144)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--control", action="store_true", help="Execute small case instrumentation only")
    parser.add_argument("--diagnose", action="store_true", help="SQL attribution during small-case preparation")
    parser.add_argument("--fixture-target", action="store_true", help="Validate full-sized synthetic data only")
    parser.add_argument("--selection-tcp", action="store_true", help="Measure target-sized selection page TCP only")
    parser.add_argument("--selection-concurrent", action="store_true", help="Two independent target TCP cases; requires --selection-tcp")
    parser.add_argument("--selection-gunicorn", action="store_true", help="Real two-worker Gunicorn; requires concurrent selection")
    parser.add_argument("--selection-profile", action="store_true", help="Extra profiled requests; requires Gunicorn")
    parser.add_argument("--database-heavy", action="store_true", help="Rebalance same4CPU budget to PG1.5/app2.25; requires Gunicorn")
    parser.add_argument("--selection-complete", action="store_true", help="All31pages and20fresh approvals; requires balanced Gunicorn")
    args = parser.parse_args()
    if args.selection_complete and not (args.selection_gunicorn and args.database_heavy):
        parser.error("--selection-complete requires --selection-gunicorn --database-heavy")
    if args.database_heavy and not args.selection_gunicorn:
        parser.error("--database-heavy requires --selection-gunicorn")
    allocations = dict(ALLOCATIONS)
    if args.database_heavy:
        allocations.update(pg=(150000, 1536), app=(225000, 6144))
    if args.selection_profile and not args.selection_gunicorn:
        parser.error("--selection-profile requires --selection-gunicorn")
    if args.selection_gunicorn and not args.selection_concurrent:
        parser.error("--selection-gunicorn requires --selection-concurrent")
    if args.selection_concurrent and not args.selection_tcp:
        parser.error("--selection-concurrent requires --selection-tcp")
    if args.selection_tcp and (args.control or args.diagnose or args.fixture_target):
        parser.error("--selection-tcp is exclusive")
    if args.fixture_target and (args.control or args.diagnose):
        parser.error("--fixture-target is exclusive with --control/--diagnose")
    if args.diagnose and not args.control:
        parser.error("--diagnose requires --control")
    run_id = time.strftime("%Y%m%d-%H%M%S", time.gmtime()) + "-" + uuid.uuid4().hex[:8]
    prefix = "web-modelos-capacity-" + run_id
    output = ROOT / "artifacts/capacity-environment" / run_id
    output.mkdir(parents=True)
    before = hashes()
    (output / "source-hashes.json").write_text(json.dumps(before, indent=2))
    report = {
        "id": run_id,
        "result": "ERROR",
        "scope": "Owned topology readiness only; not capacity, browser, N3 or storage budget proof.",
        "allocations": allocations,
        "steps": [],
        "controls": {},
        "cleanup": {},
    }
    containers = []
    network = prefix + "-net"
    network_attempted = False
    env = {k: v for k, v in os.environ.items() if k in {"PATH", "HOME", "LANG"}}

    def run(command, label, check=True):
        start = time.monotonic()
        result = subprocess.run(command, capture_output=True, text=True, timeout=600 if args.selection_tcp and label == "control-pytest" else 180, env=env)
        (output / (label + ".log")).write_text(result.stdout + result.stderr)
        report["steps"].append(
            {"label": label, "command": command, "exit": result.returncode,
             "seconds": time.monotonic() - start}
        )
        if check and result.returncode:
            raise RuntimeError(f"{label} failed; see durable log")
        return result

    def container(role, image, extra, command):
        name = prefix + "-" + role
        containers.append(name)  # Cleanup even if Docker partially creates then fails.
        quota, memory = allocations[role]
        run(
            ["docker", "run", "--pull=never", "-d", "--name", name,
             "--network", network, "--network-alias", role,
             "--cpus", str(quota / 100000), "--memory", str(memory * MIB),
             "--memory-swap", str(memory * MIB), "--pids-limit", "256",
             "--log-driver", "local", "--log-opt", "max-size=4m", "--log-opt", "max-file=1", "--log-opt", "compress=false",
             *extra, image, *command], "start-" + role,
        )
        controls = run(
            ["docker", "exec", name, "cat", "/sys/fs/cgroup/cpu.max",
             "/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory.swap.max"], "controls-" + role,
        ).stdout.splitlines()
        if controls != [f"{quota} 100000", str(memory * MIB), "0"]:
            raise RuntimeError(f"Unverified effective limits: {role}")
        report["controls"][role] = controls
        return name

    try:
        for image in ["postgres:17-alpine", "redis:7.4-alpine", "web-modelos-app:latest"]:
            run(["docker", "image", "inspect", "--format", "{{.Id}}", image], "image-" + image.split(":")[0])
        network_attempted = True
        run(["docker", "network", "create", "--internal", network], "network")
        pg = container(
            "pg", "postgres:17-alpine",
            ["--tmpfs", "/var/lib/postgresql/data:size=1073741824",
             "-e", "POSTGRES_USER=ci", "-e", "POSTGRES_PASSWORD=ci-synthetic",
             "-e", "POSTGRES_DB=capacity_ci"], [],
        )
        container("redis", "redis:7.4-alpine", [],
                  ["redis-server", "--save", "", "--appendonly", "no", "--maxmemory", "268435456"])
        python_root = Path.home() / ".local/share/uv/python"
        if not python_root.is_dir():
            raise RuntimeError("Current uv interpreter root missing")
        app = container(
            "app", "web-modelos-app:latest",
            ["--read-only", "--cap-drop=ALL", "--security-opt=no-new-privileges",
             "--user", f"{os.getuid()}:{os.getgid()}", "--workdir", str(ROOT),
             "--mount", f"type=bind,src={ROOT},dst={ROOT},readonly",
             "--mount", f"type=bind,src={python_root},dst={python_root},readonly",
             "--tmpfs", f"/tmp:size=1073741824,uid={os.getuid()},gid={os.getgid()}",
             "-e", "PYTHONDONTWRITEBYTECODE=1", "-e", "DJANGO_SETTINGS_MODULE=config.settings",
             "-e", "DB_HOST=pg", "-e", "DB_PORT=5432", "-e", "POSTGRES_DB=capacity_ci",
             "-e", "POSTGRES_USER=ci", "-e", "POSTGRES_PASSWORD=ci-synthetic",
             "-e", "REDIS_URL=redis://redis:6379/0", "--entrypoint", str(ROOT / ".venv/bin/python3")],
            ["-c", "import time; time.sleep(1800)"],
        )
        for attempt in range(30):
            ready = run(["docker", "exec", pg, "pg_isready", "-U", "ci", "-d", "capacity_ci"],
                        "pg-ready-" + str(attempt), check=False)
            if ready.returncode == 0:
                break
            time.sleep(1)
        else:
            raise RuntimeError("Own PG readiness timed out")
        # Explicit current source, migrations, private synthetic database and broker.
        probe = (
            "import django,json,tempfile; django.setup(); "
            "from django.core.management import call_command; "
            "from django.db import connection; import redis; "
            "call_command('migrate',interactive=False,verbosity=0); call_command('check'); "
            "cursor=connection.cursor(); cursor.execute('select version(),current_database()'); "
            "row=cursor.fetchone(); "
            "assert row[1]=='capacity_ci'; "
            "assert redis.Redis(host='redis').ping(); "
            "f=tempfile.TemporaryFile(dir='/tmp'); f.write(b'synthetic-media'); f.seek(0); "
            "assert f.read()==b'synthetic-media'; f.close(); "
            "print(json.dumps({'postgres':row[0],'database':row[1],'redis_ping':True,"
            "'migrations_applied':True,'temporary_media_io':True,'django':django.get_version()}))"
        )
        run(["docker", "exec", app, str(ROOT / ".venv/bin/python3"), "-c", probe], "django-probe")
        if args.control or args.fixture_target or args.selection_tcp:
            settings_source = (
                "from config.settings import *\n"
                "CAPACITY_ENVIRONMENT_VERIFIED = True\n"
                "MEDIA_ROOT = '/tmp/capacity-media'\n"
                f"CAPACITY_SQL_DIAGNOSE = {args.diagnose!r}\n"
                f"CAPACITY_SELECTION_GUNICORN = {args.selection_gunicorn!r}\n"
                f"CAPACITY_SELECTION_PROFILE = {args.selection_profile!r}\n"
                f"CAPACITY_SELECTION_COMPLETE = {args.selection_complete!r}\n"
                "DATABASES['default']['TEST'] = {'NAME': 'test_capacity_ci'}\n"
            )
            run(["docker", "exec", app, str(ROOT / ".venv/bin/python3"), "-c",
                 "from pathlib import Path; Path('/tmp/capacity_settings.py').write_text(" +
                 repr(settings_source) + ")"], "control-settings")
            result = run(
                ["docker", "exec", "-e", f"PYTHONPATH=/tmp:{ROOT}",
                 "-e", "DJANGO_SETTINGS_MODULE=capacity_settings", app,
                 str(ROOT / ".venv/bin/python3"), "-m", "pytest", "-q", "--tb=short",
                 "-o", "DJANGO_SETTINGS_MODULE=capacity_settings", "-o", "junit_family=xunit1",
                 "-p", "no:cacheprovider", "--basetemp=/tmp/capacity-pytest",
                 "--junitxml=/tmp/capacity-control.xml",
                 "tests/test_capacity_selection_concurrent_tcp.py" if args.selection_concurrent else
                 "tests/test_capacity_selection_tcp.py" if args.selection_tcp else
                 "tests/test_capacity_target_fixture.py" if args.fixture_target else "tests/test_capacity_case_control.py"],
                "control-pytest", check=False,
            )
            junit = run(["docker", "exec", app, "cat", "/tmp/capacity-control.xml"],
                        "control-junit")
            (output / "pytest.xml").write_text(junit.stdout)
            suites = list(ET.parse(output / "pytest.xml").getroot().iter("testsuite"))
            report["junit"] = [suite.attrib for suite in suites]
            if args.diagnose:
                properties = {item.attrib["name"]: item.attrib["value"]
                              for suite in suites for item in suite.iter("property")}
                if not json.loads(properties.get("preparation_sql_attribution", "{}")):
                    raise RuntimeError("Requested SQL diagnosis missing: INVALID instrument")
            if result.returncode or not suites or any(
                int(suite.attrib.get(key, 0)) for suite in suites
                for key in ("failures", "errors", "skipped")
            ) or sum(int(suite.attrib.get("tests", 0)) for suite in suites) != 1:
                raise RuntimeError("Small control did not pass exactly one required test")
            if args.selection_tcp:
                properties = {item.attrib["name"]: item.attrib["value"]
                              for suite in suites for item in suite.iter("property")}
                measurements = json.loads(properties.get("selection_tcp_measurements", "{}"))
                cases = measurements.get("cases", []) if args.selection_concurrent else [measurements]
                if len(cases) != (2 if args.selection_concurrent else 1) or any(len(case.get("samples", [])) != (31 if args.selection_complete else 20) for case in cases):
                    raise RuntimeError("Requested TCP measurements missing")
                report["result"] = "SELECTION_TCP_PASS_NOT_FULL_CAPACITY"
            elif args.fixture_target:
                properties = {item.attrib["name"]: item.attrib["value"]
                              for suite in suites for item in suite.iter("property")}
                if len(json.loads(properties.get("target_fixture_manifest", "[]"))) != 2:
                    raise RuntimeError("Requested target fixture manifest missing")
                report["result"] = "FIXTURE_VALID_NOT_CAPACITY"
            else:
                report["result"] = "CONTROL_PASS_NOT_TARGET_CAPACITY"
        else:
            report["result"] = "READY_NOT_CAPACITY"
        report["cgroup_memory"] = {}
        for role in allocations:
            observed = run(["docker", "exec", prefix + "-" + role, "cat",
                            "/sys/fs/cgroup/memory.current", "/sys/fs/cgroup/memory.peak"],
                           "memory-" + role).stdout.splitlines()
            report["cgroup_memory"][role] = dict(zip(["current_bytes", "peak_bytes"], map(int, observed), strict=True))
        report["memory_scope"] = "Disjoint container peaks; sum is upper bound, not synchronous whole-environment peak. Host controller excluded."

    except Exception as exc:
        report["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        for name in reversed(containers):
            try:
                removal = run(["docker", "rm", "-fv", name], "remove-" + name, check=False)
                inventory = run(["docker", "ps", "-a", "--filter", f"name=^{name}$",
                                 "--format", "{{.Names}}"], "inventory-" + name, check=False)
                absent = inventory.returncode == 0 and not inventory.stdout.strip()
                report["cleanup"][name] = {"absent": absent, "removal_exit": removal.returncode}
                if not absent:
                    report["result"] = "ERROR"
            except Exception as exc:
                report["cleanup"][name] = {"error": str(exc)}
                report["result"] = "ERROR"
        if network_attempted:
            try:
                run(["docker", "network", "rm", network], "remove-network", check=False)
                inventory = run(["docker", "network", "ls", "--filter", f"name=^{network}$",
                                 "--format", "{{.Name}}"], "network-inventory", check=False)
                absent = inventory.returncode == 0 and not inventory.stdout.strip()
                report["cleanup"][network] = {"absent": absent}
                if not absent:
                    report["result"] = "ERROR"
            except Exception as exc:
                report["cleanup"][network] = {"error": str(exc)}
                report["result"] = "ERROR"
        report["sources_unchanged"] = hashes() == before
        if not report["sources_unchanged"]:
            report["result"] = "INVALID"
        (output / "report.json").write_text(json.dumps(report, indent=2))
    print(json.dumps({"result": report["result"], "evidence": str(output)}))
    return 0 if report["result"] in {"READY_NOT_CAPACITY", "CONTROL_PASS_NOT_TARGET_CAPACITY", "FIXTURE_VALID_NOT_CAPACITY", "SELECTION_TCP_PASS_NOT_FULL_CAPACITY"} else 1


if __name__ == "__main__":
    sys.exit(main())
