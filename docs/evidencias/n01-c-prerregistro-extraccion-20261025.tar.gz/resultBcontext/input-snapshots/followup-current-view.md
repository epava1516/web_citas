N01Bauditado:1PASS/60peticiones/10segmentosESEN,100perfiles. [Resultado347](347-n01-b-resultado-segmentos-20261025.md). Listado/página2/perfil:36fallback/state_unknown_over_limit;vacío12state;ficha12sinmarcador. Sin cambioproducto,ni mejora causal/p95/capacidad. N00aceptado1/13,N01encurso,alfa.

Siguiente:semántica347/README/17antesdelnuevohito;prerregistrar estado preparadonativo vsdesconocido,oráculos/rutaylímites. No confundirfixture sinworker condefecto ni medircaminooptimizado sin verificarlo. Tablaantes/despuésporbloque al cierre.

