"""Root audit of the finite preregistered four-case commercial reference."""
import collections
import hashlib
import json
import math
import statistics
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

W = Path('artifacts/recorridos-n08-c-20261026')
P = Path('artifacts/local-ci') / sys.argv[1]
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
freeze = read(W / 'reference-freeze.json')
result = read(P / 'result.json')
assert result['result'] == 'PASS' and result['sources_unchanged']
assert result['selection'] == freeze['selection'] and result['workers'] == 1
assert result['observe_http_operations']
assert '--isolate-test-broker' in read(P / 'runner.json')['command']
hashes = read(P / 'source-hashes.json')
missing = set(freeze['sources']) - set(hashes)
assert missing == set(freeze['sources_verified_separately'])
assert all(sha(p) == value for p, value in freeze['sources'].items())
assert all(hashes[p] == value for p, value in freeze['sources'].items() if p in hashes)
assert sha('graphify-out/graph.json') == freeze['graph_sha256']
assert sha(W / 'correction.json') == freeze['correction_sha256']
cases = list(ET.parse(P / 'pytest.xml').iter('testcase'))
assert len(cases) == 1 and not any(c.find(k) is not None for c in cases for k in ('failure', 'error', 'skipped'))
assert collections.Counter(c.get('classname', '').split('.')[-1] for c in cases) == {
    'test_promotion_worker_cadence_reference': 1,
}
case=cases[0]
properties={p.get('name'):p.get('value') for p in case.iter('property')}
all_global=json.loads(properties['http_operation_samples'])
assert len(all_global)==int(properties['http_operation_count'])
assert all(p['exception_class'] is None and p['observer_error_class'] is None for p in all_global)
worker=json.loads(properties['n08c_promotion_cadence'])
assert worker==read(P/'n08c-promotion-runtime.json')
assert worker is not None and worker['complete']
assert worker['schedule']['seconds'] == 60.0 and worker['schedule']['entry'] == 'synthetic-promotion-bumps'
for key in ('runtime_role_removed', 'private_credentials_removed', 'private_runtime_removed', 'foreign_keys_preserved'):
    assert worker[key]
assert worker['unexpected_unscoped_keys'] == 0 and not worker['cleanup_errors']
assert len(worker['processes_absent']) >= 4 and all(worker['processes_absent'].values())
assert worker['worker_exit_code'] == 0 and worker['beat_exit_code'] in (0, -15)
assert worker['editorial_before'] == worker['editorial_after']
events = worker['events']
executions = [e for e in events if e['event'] == 'execution']
proofs = {e['id']: e for e in events if e['event'] == 'role_proof'}
published = {e['id'] for e in events if e['event'] == 'publish'} | {e['id'] for e in worker['harness_publishes']}
assert len({e['id'] for e in executions}) == len(executions)
assert published == {e['id'] for e in executions} == set(proofs)
for execution in executions:
    proof = proofs[execution['id']]
    assert execution['state'] == 'SUCCESS' and execution['eager'] is False
    assert proof['sql_role'] == worker['runtime_role'] and proof['pid'] == execution['pid']
    assert str(execution['pid']) in worker['processes_absent']
phases = worker['phases']
assert phases['startup']['queued_before_worker'] and phases['startup']['execution']['result'] == 1
assert phases['startup']['second_future_has_zero_bumps']
assert phases['live_replay']['quota_one_per_utc_day']
beat = phases['native_beat']
assert len(beat['ticks']) == 2 and beat['tick_separation_seconds'] > 0
assert beat['second_zero_bumps'] and beat['last_checked_advanced_each_tick']
assert beat['first_excluded_by_suspension'] and beat['second_selected_but_revoked']
assert all(e['execution']['result'] == 0 for e in beat['ticks'])
for kind in ('container', 'volume', 'network'):
    command = ['docker', 'ps', '-aq'] if kind == 'container' else ['docker', kind, 'ls', '-q']
    assert not subprocess.check_output(command + ['--filter', 'label=web-modelos-local-ci-run=' + P.name], text=True).strip()
assert not Path(read(P / 'runner.json')['temporary']).exists()
telegram = read(P / 'telegram-notification.json')
assert telegram['delivery'] == 'sent'
output={'result':'PASS_N08C_CORRECTED_NATIVE_WORKER_60S_TWO_TICKS_FINITE_REFERENCE','run':P.name,
        'cases':1,'junit':result['junit'],'frozen_sources':len(freeze['sources']),
        'global_Client_calls_including_fixtures':len(all_global),'worker':worker,
        'executions':len(executions),'cleanup_verified':True,'telegram':telegram,
        'scope':'OnlyC1rerun after instrument fixtureassert ordering fix. Native restrictedprefork2 and actualtwoBeat60ticks; startup/replay separate, noSLA/p95/capacity/provider. First3PASS1FAIL and B3valid436Client retained. No newapplicationchange;N08full17audit stillpending/7of13.'}
(W/'reference-c-audit.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in output.items() if k!='worker'},ensure_ascii=False))
