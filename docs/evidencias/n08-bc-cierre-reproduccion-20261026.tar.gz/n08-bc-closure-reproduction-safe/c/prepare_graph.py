import json,shutil,subprocess,sys
from pathlib import Path
W=Path('artifacts/recorridos-n08-c-20261026')
def pairs(values):
 d={}
 for k,v in values:
  if k in d:raise ValueError('Duplicate JSON key '+k)
  d[k]=v
 return d
def read(p):return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda v:(_ for _ in ()).throw(ValueError(v)))
r=read(W/'prereg/report.json');assert r['STATUS']=='complete' and not r['TESTS_RUN']
r=read(W/'prereg/semantic-fragment.json');assert r['nodes'] and r['edges'] and not r.get('hyperedges')
subprocess.run(['.venv/bin/ruff','check','tests/test_promotion_worker_cadence_reference.py'],check=True)
python=Path('graphify-out/.graphify_python').read_text().strip();assert Path(python).is_file()
for script in ['refresh_ast.py','prereg/integrate_semantics.py','prereg/finalize_graph.py','prereg/verify_graph.py']:
 subprocess.run([python,str(W/script)],check=True)
for p in (W/'prereg/graph-integrated').iterdir():
 if p.is_file():shutil.copy2(p,Path('graphify-out')/p.name)
print('PASS: scoped N08B415 result/C corrective graph published after source/literal/integrity verification')
