import json,shutil,subprocess,sys
from pathlib import Path
W=Path('artifacts/recorridos-n08-b-20261026')
def pairs(values):
 d={}
 for k,v in values:
  if k in d:raise ValueError('Duplicate JSON key '+k)
  d[k]=v
 return d
def read(p):return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda v:(_ for _ in ()).throw(ValueError(v)))
for name in ['writer-b-report.json','writer-c-report.json','prereg/report.json']:
 r=read(W/name);assert r['STATUS']=='complete' and not r['TESTS_RUN']
r=read(W/'prereg/semantic-fragment.json');assert len(r['nodes'])==26 and len(r['edges'])==22 and not r.get('hyperedges')
python=Path('graphify-out/.graphify_python').read_text().strip();assert Path(python).is_file()
for script in ['refresh_ast.py','prereg/integrate_semantics.py','prereg/finalize_graph.py','prereg/verify_graph.py']:
 subprocess.run([python,str(W/script)],check=True)
for p in (W/'prereg/graph-integrated').iterdir():
 if p.is_file():shutil.copy2(p,Path('graphify-out')/p.name)
print('PASS: scoped N08BC prereg graph published after source/literal/integrity verification')
