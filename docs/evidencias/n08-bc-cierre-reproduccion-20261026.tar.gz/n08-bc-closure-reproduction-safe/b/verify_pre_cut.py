import hashlib,json,shutil,subprocess
from pathlib import Path
W=Path('artifacts/recorridos-n08-b-20261026');G=Path('graphify-out');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=json.loads((G/'SOURCE_MANIFEST.json').read_text());bad=[p for p,r in m.items() if sha(p)!=r['sha256']];assert not bad,bad
assert sha(G/'graph.json')=='82b338ede064ff0cf77b0c35b47925bf39cd4569e60148cc09519738a62b4c80'
for n in ['SOURCE_MANIFEST.json','ESTADO_ACTUAL.json','GRAPH_VERIFICATION.json']:shutil.copy2(G/n,W/('pre-'+n))
out={'result':'PASS_CURRENT_PRE_N08B_SOURCE_CUT','source_files':len(m),'graph_sha256':sha(G/'graph.json'),'mismatches':bad,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'N08A2/412 result graph preserved,2028exactdeclared sources beforeN08B commercial reference study;notN15fullrebuild,externaluserchangespreserved.'};(W/'pre-source-cut.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
