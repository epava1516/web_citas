"""Root audit of the finite preregistered four-case commercial reference."""
import collections
import hashlib
import json
import math
import statistics
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

W = Path('artifacts/recorridos-n08-b-20261026')
P = Path('artifacts/local-ci') / sys.argv[1]
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
freeze = read(W / 'reference-freeze.json')
result = read(P / 'result.json')
assert result['result'] == 'ERROR' and result['sources_unchanged']
assert result['selection'] == freeze['selection'] and result['workers'] == 1
assert result['observe_http_operations']
assert '--isolate-test-broker' in read(P / 'runner.json')['command']
hashes = read(P / 'source-hashes.json')
missing = set(freeze['sources']) - set(hashes)
assert missing == set(freeze['sources_verified_separately'])
assert all(sha(p) == value for p, value in freeze['sources'].items())
assert all(hashes[p] == value for p, value in freeze['sources'].items() if p in hashes)
assert sha('graphify-out/graph.json') == freeze['graph_sha256']
assert sha(W / 'work-plan.json') == freeze['work_plan_sha256']
cases = list(ET.parse(P / 'pytest.xml').iter('testcase'))
assert len(cases) == 4 and sum(c.find('failure') is not None for c in cases) == 1
assert not any(c.find(k) is not None for c in cases for k in ('error', 'skipped'))
assert collections.Counter(c.get('classname', '').split('.')[-1] for c in cases) == {
    'test_commercial_surface_reference': 3, 'test_promotion_worker_cadence_reference': 1,
}
expected = {'history_and_detail': (120, 8, 0), 'order_form_options': (96, 4, 0),
            'catalogue_versions_edit_preview': (180, 18, 10)}
commercial = []
summary = []
all_global = []
worker = None
for case in cases:
    properties = {p.get('name'): p.get('value') for p in case.iter('property')}
    operations = json.loads(properties['http_operation_samples'])
    assert len(operations) == int(properties['http_operation_count'])
    assert all(p['exception_class'] is None and p['observer_error_class'] is None for p in operations)
    all_global.extend(operations)
    if case.get('classname', '').split('.')[-1] == 'test_promotion_worker_cadence_reference':
        failure = case.find('failure')
        assert failure is not None and 'assert celery_app.conf.task_always_eager' in failure.text
        assert not operations and 'n08c_promotion_cadence' not in properties
        continue
    assert not any(case.find(k) is not None for k in ('failure', 'error', 'skipped'))
    data = json.loads(properties['commercial_surface_samples'])
    rows, controls, meta = data['rows'], data['controls'], data['metadata']
    axis = meta['axis']
    get_count, negative_count, post_count = expected[axis]
    assert meta['readonly_segments_verified'] and len(rows) == get_count
    assert sum(x['method'] == 'GET' for x in controls) == negative_count
    assert sum(x['method'] == 'POST' for x in controls) == post_count
    assert meta['planned_total_calls'] == len(rows) + len(controls)
    # The fixture does not call these six commercial routes. Match within route/status,
    # retaining ordinal order; the global observer does not expose language/page fields.
    by_key = collections.defaultdict(list)
    global_by_key = collections.defaultdict(list)
    routes = {'promotion_orders', 'promotion_order_detail', 'promotion_products',
              'promotion_product_versions', 'promotion_version_edit', 'promotion_version_preview'}
    for sample in rows + controls:
        assert sample['language'] == sample['response_language'] == sample['headers']['Content-Language']
        assert sample['path_is_resolver_shape']
        for key in ('wall_seconds', 'cpu_seconds', 'sql_queries', 'sql_execute_seconds', 'response_bytes'):
            value = sample[key]
            assert isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0
        assert isinstance(sample['sql_queries'], int) and isinstance(sample['response_bytes'], int)
        by_key[(sample['method'], sample['route_name'], sample['status'])].append(sample)
    for sample in operations:
        if sample['route_name'] in routes:
            global_by_key[(sample['method'], sample['route_name'], sample['status'])].append(sample)
    assert set(by_key) == set(global_by_key)
    for key, samples in by_key.items():
        observed = global_by_key[key]
        assert len(samples) == len(observed)
        for local, global_ in zip(samples, observed):
            assert local['sql_queries'] == global_['sql_queries']
            assert local['wall_seconds'] >= global_['request_seconds_instrumented']
    segments = collections.defaultdict(list)
    for sample in rows:
        assert sample['method'] == 'GET' and sample['status'] == 200
        assert len(sample['snapshot_sha256']) == 64
        segments[tuple(sample[k] for k in ('axis', 'cohort', 'language', 'page'))].append(sample)
    for key, samples in sorted(segments.items()):
        assert [s['ordinal'] for s in samples] == list(range(6))
        assert len({s['snapshot_sha256'] for s in samples}) == 1
        warm = samples[1:]
        summary.append(dict(zip(('axis', 'cohort', 'language', 'page'), key)) | {
            'first_ms': samples[0]['wall_seconds'] * 1000,
            'median5_ms': statistics.median(s['wall_seconds'] for s in warm) * 1000,
            'range5_ms': [min(s['wall_seconds'] for s in warm) * 1000, max(s['wall_seconds'] for s in warm) * 1000],
            'cpu_median5_ms': statistics.median(s['cpu_seconds'] for s in warm) * 1000,
            'SQL_counts': sorted({s['sql_queries'] for s in samples}),
            'response_bytes': sorted({s['response_bytes'] for s in samples}),
            'after_candidate_ms': None, 'gain_percent': None,
        })
    commercial.append({'case': case.get('name'), 'report': data,
                       'global_operation_count_including_fixture': len(operations),
                       'own_calls_matched_to_global': len(rows) + len(controls)})
assert {x['report']['metadata']['axis'] for x in commercial} == set(expected)
assert len(summary) == 66
assert sum(x['own_calls_matched_to_global'] for x in commercial) == 436
for kind in ('container', 'volume', 'network'):
    command = ['docker', 'ps', '-aq'] if kind == 'container' else ['docker', kind, 'ls', '-q']
    assert not subprocess.check_output(command + ['--filter', 'label=web-modelos-local-ci-run=' + P.name], text=True).strip()
assert not Path(read(P / 'runner.json')['temporary']).exists()
telegram = read(P / 'telegram-notification.json')
assert telegram['delivery'] == 'sent'
output = {'result': 'PASS_N08B_THREE_CASES_FINITE_REFERENCE_FROM_MIXED_RUN_NOT_FULL_PASS', 'run': P.name,
          'accepted_commercial_cases': 3, 'original_failed_cases': 1, 'junit': result['junit'], 'frozen_sources': len(freeze['sources']),
          'measured_GET': 396, 'negative_GET': 30, 'native_catalogue_POST': 10,
          'own_commercial_Client_calls': 436, 'global_Client_calls_including_fixtures': len(all_global),
          'own_SQL_count_match': True, 'commercial': commercial, 'summary': summary,
          'worker_executed': False, 'C_failure': 'Instrument eager assertion before dynamic fixture; no worker spawned', 'cleanup_verified': True,
          'telegram': telegram, 'scope': 'Current Client reference only, first+5 by66segments. No candidate or causal performance gain. CPU excludes PG. Own436 nested in global, never summed. C failed before fixture/runtime, no worker/Beat evidence. Only C may be rerun; do not repeat B. Historic77 and A2current13 retained, not rerun. N08full17 audit pending;7/13 overall.'}
(W / 'reference-b-audit.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in output.items() if k not in ('commercial', 'summary', 'worker')}, ensure_ascii=False))
