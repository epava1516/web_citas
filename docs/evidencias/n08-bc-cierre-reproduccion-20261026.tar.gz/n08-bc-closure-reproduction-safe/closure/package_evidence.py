"""Archive owned N08B/C sources and safe runtime evidence, retaining the first failure."""
import hashlib
import json
import shutil
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

W = Path('artifacts/recorridos-n08-closure-20261026')
S = W / 'reproduction-safe'
S.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
def put(path, name):
    path = Path(path); dest = S / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dest)

for phase in ('b', 'c'):
    root = Path(f'artifacts/recorridos-n08-{phase}-20261026')
    for path in root.iterdir():
        if path.is_file() and path.suffix in ('.json', '.py'):
            put(path, phase + '/' + path.name)
    for stage in ('prereg', 'terminal'):
        folder = root / stage
        if not folder.exists(): continue
        for path in folder.iterdir():
            if path.is_file() and path.suffix in ('.json', '.py'):
                put(path, phase + '/' + stage + '/' + path.name)
        for path in (folder / 'snapshots').glob('*'):
            if path.is_file(): put(path, phase + '/' + stage + '/snapshots/' + path.name)
    for path in (root / 'instrument-graph').glob('*.json'):
        put(path, phase + '/instrument-graph/' + path.name)
for path in W.iterdir():
    if path.is_file() and path.suffix in ('.json', '.py'):
        put(path, 'closure/' + path.name)
for path in (W / 'result').iterdir():
    if path.is_file() and path.suffix in ('.json', '.py'):
        put(path, 'closure/result/' + path.name)
for path in (W / 'result/snapshots').glob('*'):
    if path.is_file(): put(path, 'closure/result/snapshots/' + path.name)
for path in ('tests/test_commercial_surface_reference.py', 'tests/test_promotion_worker_cadence_reference.py',
             'apps/listings/favorites.py', 'apps/core/sitemaps.py'):
    put(path, 'sources/' + path)
for path in Path('docs').glob('41[3-7]-*.md'):
    put(path, 'sources/' + str(path))
raw_manifest = {}
for run in ('20261026-030555-20d5ac97', '20261026-031404-bfa5f7d6'):
    root = Path('artifacts/local-ci') / run
    dest = S / 'runtime' / run
    dest.mkdir(parents=True)
    result = read(root / 'result.json')
    result['steps'] = [{k: v for k, v in step.items() if k not in ('command', 'stdout', 'stderr')}
                       for step in result['steps']]
    (dest / 'result-sanitized.json').write_text(json.dumps(result, indent=2) + '\n')
    for name in ('source-hashes.json', 'native-manifest.json', 'telegram-notification.json'):
        shutil.copy2(root / name, dest / name)
    runner = read(root / 'runner.json')
    runner.pop('command', None)
    runner['isolated_broker_flag_verified_from_original'] = True
    (dest / 'runner-sanitized.json').write_text(json.dumps(runner, indent=2) + '\n')
    xml = ET.parse(root / 'pytest.xml').getroot()
    for element in xml.iter():
        element.attrib.pop('hostname', None)
        for child in list(element):
            if child.tag in ('system-out', 'system-err'):
                element.remove(child)
            elif child.tag in ('failure', 'error'):
                # The original remains local and hash-addressed. Never export Settings repr/trace.
                child.attrib.clear()
                child.set('message', 'Original C instrumentation assertion before dynamic fixture; see415 and correction.json')
                child.text = 'Sanitized original failure; original SHA256 retained in MANIFEST.'
    ET.ElementTree(xml).write(dest / 'pytest-sanitized.xml', encoding='utf-8', xml_declaration=True)
    raw_manifest[run] = {name: sha(root / name) for name in ('result.json', 'pytest.xml', 'runner.json', 'source-hashes.json')}
manifest = {'state': 'N08_BC_AND_ALL17_SAFE_REPRODUCTION', 'raw_original_hashes': raw_manifest,
            'files': {str(p.relative_to(S)): sha(p) for p in sorted(S.rglob('*')) if p.is_file()},
            'scope': 'Originalmixed3PASS1FAIL and onlyC1correctivePASS retained; B3valid436Client, C5realSUCCESS/twoBeat60ticks. No rawlogs/stepcommands/runnercommands/systemoutputs/failureSettingsrepr/credentials/userlateraldraftcontents. Runtimeusespublicsyntheticfixturesonly. PriorA/A2packages retained separately. Nativeusageunknown. N08accepted8of13;fullgoalactive.'}
(S / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
target = Path('docs/evidencias/n08-bc-cierre-reproduccion-20261026.tar.gz')
with tarfile.open(target, 'w:gz') as tar:
    tar.add(S, arcname='n08-bc-closure-reproduction-safe')
print(json.dumps({'archive': str(target), 'files': len(manifest['files']) + 1, 'sha256': sha(target), 'bytes': target.stat().st_size}))
