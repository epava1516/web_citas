import collections,hashlib,json
from pathlib import Path
W=Path('artifacts/recorridos-n08-closure-20261026/result');S=W/'graph-integrated';B=W/'graph-base';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((S/'SOURCE_MANIFEST.json').read_text());assert len(m)==2035
for p,r in m.items():assert sha(p)==r['sha256'],p
old=json.loads((B/'graph.json').read_text());new=json.loads((S/'graph.json').read_text());nodes={n['id']:n for n in new['nodes']};assert len(nodes)==len(new['nodes']);assert all(e[k] in nodes for e in new['links'] for k in ('source','target'))
changed={'docs/17-seguimiento-desarrollo.md','docs/417-n08-aceptacion-local-superficies-comerciales-20261026.md','docs/341-roadmap-recorridos-optimizacion-alpha-20261025.md'}
def canon(x):return json.dumps({k:v for k,v in x.items() if k not in ('key','community','community_name')},sort_keys=True)
for n in old['nodes']:
 if n.get('source_file') not in changed:assert canon(n)==canon(nodes[n['id']]),n['id']
assert collections.Counter(canon(e) for e in old['links'] if e.get('source_file') not in changed)==collections.Counter(canon(e) for e in new['links'] if e.get('source_file') not in changed)
for n in new['nodes']:
 if n.get('extraction_origin')=='native_semantic_n08_417_acceptance':
  text=Path(n['source_file']).read_text().splitlines();loc=n['source_location'].replace('L','').split('-');lo=int(loc[0]);hi=int(loc[-1]);assert n['evidence_quote'] in '\n'.join(text[lo-1:hi]);assert n['source_sha256']==sha(n['source_file'])
a=json.loads((S/'.graphify_analysis.json').read_text());members=[i for v in a['communities'].values() for i in v];assert len(members)==len(set(members))==len(nodes) and set(members)==set(nodes)
for p,h in json.loads((S/'CURRENT_OUTPUTS.json').read_text())['sha256'].items():assert sha(S/p)==h,p
state=json.loads((S/'ESTADO_ACTUAL.json').read_text());assert state['next_mandatory_accepted']==8 and 'N07'not in state['pending'] and 'N08'not in state['pending'] and 'N09'in state['pending']
assert sha('docs/111-inventario-rendimiento-recorridos-beta-20261020.md')=='380b026c51b5e9647052838bb77a0712e9efff4ccdd857b5df3d4b545d921a95'
raw=json.loads((W/'semantic-fragment.json').read_text()); prior=json.loads((W/'roadmap-prior-node-ids.json').read_text())
assert all(n['id'] in nodes for n in prior)
assert len([n for n in raw['nodes'] if n['source_file'].endswith('/341-roadmap-recorridos-optimizacion-alpha-20261025.md')])==66
import re
expected_owners=set()
for line in Path('docs/341-roadmap-recorridos-optimizacion-alpha-20261025.md').read_text().splitlines():
 match=re.match(r'\|\s*(I\d{2})\s*\|',line)
 if match:
  for owner in re.findall(r'N\d{2}',line.split('|')[-2]):expected_owners.add((match[1],owner))
actual_owners=set()
for e in raw['edges']:
 if e['relation']=='assigned_to':
  pair=('I'+e['source'].rsplit('_i',1)[1],'N'+e['target'].rsplit('_n',1)[1]);actual_owners.add(pair)
  assert pair[0] in e['evidence_quote'] and pair[1] in e['evidence_quote']
assert actual_owners==expected_owners and len({i for i,n in actual_owners})==28
assert all('docs_341_roadmap_recorridos_n'+str(i).zfill(2) in nodes for i in range(16))
assert any('htmx4' in n.get('evidence_quote','') and 'siguiente contrato' in n.get('evidence_quote','') for n in raw['nodes'])
out={'result':'PASS_SCOPED_N08_FINAL_ACCEPTANCE_GRAPH','sources':len(m),'nodes':len(nodes),'relations':len(new['links']),'communities':len(a['communities']),'graph_sha256':sha(S/'graph.json'),'scope':'417/full341/17first4 finalN08acceptance8of13;source/runtime/17IDs/8criteriaaudited;16blocks28familiesownersand66roadmapIDsretained;nofullgoalcompletion;unaffectedsourcespreserved'}
(S/'GRAPH_VERIFICATION.json').write_text(json.dumps(out,indent=2)+'\n');(W/'verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
