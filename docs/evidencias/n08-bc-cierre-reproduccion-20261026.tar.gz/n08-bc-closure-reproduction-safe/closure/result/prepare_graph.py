import json,shutil,subprocess
from pathlib import Path
W=Path('artifacts/recorridos-n08-closure-20261026/result')
def pairs(values):
 d={}
 for k,v in values:
  if k in d:raise ValueError('duplicatekey '+k)
  d[k]=v
 return d
for p in ['semantic-fragment.json','report.json']:
 json.loads((W/p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
python=Path('graphify-out/.graphify_python').read_text().strip()
for script in ['integrate_semantics.py','finalize_graph.py','verify_graph.py']:
 subprocess.run([python,str(W/script)],check=True)
for p in (W/'graph-integrated').iterdir():
 if p.is_file():shutil.copy2(p,Path('graphify-out')/p.name)
print('PASS: N08 final acceptance graph published;8of13/N09next/fullgoalactive')
