"""Root source/result reconciliation for all seventeen N08 inventory identifiers."""
import ast
import collections
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

W = Path('artifacts/recorridos-n08-closure-20261026')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
manifest = read('graphify-out/SOURCE_MANIFEST.json')
assert len(manifest) == 2034
assert all(sha(p) == row['sha256'] for p, row in manifest.items())
graph_before_acceptance = sha('graphify-out/graph.json')
baseline = read('docs/evidencias/b16-final-candidate-reconciliation-20261025.json')['current_versioned_executable_sources']
accepted = read('docs/evidencias/n08-a2-fuentes-conciliacion-20261026.json')['accepted_variants']
changed = {p: sha(p) for p, value in baseline.items() if sha(p) != value}
assert len(baseline) == 1507 and len(changed) == 9 and changed == accepted
def functions(source):
    return {n.name: n for n in ast.parse(source).body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
ast_proof = []
for path, changed_function in [('apps/listings/favorites.py', 'index'), ('apps/core/sitemaps.py', 'listings')]:
    before = subprocess.check_output(['git', 'show', '7107363794b378be3fe71e69998f83d9230888f2:' + path], text=True)
    old, new = functions(before), functions(Path(path).read_text())
    assert set(old) == set(new)
    delta = [k for k in old if ast.dump(old[k], include_attributes=False) != ast.dump(new[k], include_attributes=False)]
    assert delta == [changed_function]
    assert [ast.dump(d) for d in old[changed_function].decorator_list] == [ast.dump(d) for d in new[changed_function].decorator_list]
    ast_proof.append({'source': path, 'changed_function': changed_function, 'other_functions_AST_equal': True,
                      'decorators_AST_equal': True, 'current_sha256': sha(path)})
reuse = read('artifacts/recorridos-n08-b-20261026/reuse-verification.json')
assert reuse['selected_original_cases'] == 77 and reuse['selected_test_modules'] == 16
xml_cache = {}
for witness in reuse['witnesses']:
    assert sha(witness['test_source']) == witness['test_source_sha256']
    path = witness['junit']
    if path not in xml_cache: xml_cache[path] = list(ET.parse(path).iter('testcase'))
    matches = [c for c in xml_cache[path] if c.get('classname', '').split('.')[-1] == witness['module'] and c.get('name') == witness['case']]
    assert len(matches) == 1 and not any(matches[0].find(k) is not None for k in ('failure', 'error', 'skipped'))
assert len({(w['module'], w['case']) for w in reuse['witnesses']}) == 77
for run in reuse['original_runs']:
    p = Path('artifacts/local-ci') / run['run']
    assert sha(p / 'pytest.xml') == run['raw_xml_sha256']
    assert sha(p / 'source-hashes.json') == run['source_manifest_sha256']
    assert sha(p / 'result.json') == run['result_sha256']
agency = read('artifacts/recorridos-n08-a-20261026/agency-selector-bridge.json')
old = functions(subprocess.check_output(['git', 'show', agency['historical_head'] + ':' + agency['source']], text=True))
new = functions(Path(agency['source']).read_text())
assert ast.dump(old['person_queryset'], include_attributes=False) == ast.dump(new['person_queryset'], include_attributes=False)
assert sha(agency['source']) == agency['current_sha256']

A = read('artifacts/recorridos-n08-a-20261026/reference-audit.json')
A2 = read('artifacts/recorridos-n08-a2-20261026/pair-audit.json')
B = read('artifacts/recorridos-n08-b-20261026/reference-b-audit.json')
C = read('artifacts/recorridos-n08-c-20261026/reference-c-audit.json')
assert A['measured_GETs'] == 300 and A['self_debug_SQL_discarded'] and A['segments'] == 50
assert A2['cases'] == 13 and A2['all_preregistered_cost_gates_met'] and A2['functional_parity_verified']
assert A2['target_GETs'] == 72 and A2['instrumented_new_GETs'] == 118 and len(A2['original_current_cases']) == 10
assert sha('artifacts/recorridos-n08-a2-20261026/pair-audit.json') == read('docs/evidencias/n08-a2-candidato-aceptacion-20261026.json')['audit_sha256']
assert B['accepted_commercial_cases'] == 3 and B['original_failed_cases'] == 1 and len(B['summary']) == 66
assert (B['measured_GET'], B['negative_GET'], B['native_catalogue_POST']) == (396, 30, 10)
assert B['own_commercial_Client_calls'] == B['global_Client_calls_including_fixtures'] == 436
assert B['own_SQL_count_match'] and not B['worker_executed']
assert C['cases'] == 1 and C['executions'] == 5 and C['global_Client_calls_including_fixtures'] == 0
worker = C['worker']
assert worker['complete'] and len(worker['executor_pids']) == 1
assert all(worker['processes_absent'].values()) and len(worker['processes_absent']) == 4
assert worker['schedule']['seconds'] == 60.0 and worker['phases']['native_beat']['second_zero_bumps']
assert worker['phases']['native_beat']['last_checked_advanced_each_tick']
assert len(worker['phases']['native_beat']['ticks']) == 2
assert worker['editorial_before'] == worker['editorial_after']
for key in ('runtime_role_removed', 'private_credentials_removed', 'private_runtime_removed', 'foreign_keys_preserved'):
    assert worker[key]
assert worker['unexpected_unscoped_keys'] == 0
correction = read('artifacts/recorridos-n08-c-20261026/correction.json')
assert sha(correction['source']) == correction['after_sha256']
before = Path('artifacts/recorridos-n08-c-20261026/instrument-before-fix.py').read_text()
assert hashlib.sha256(before.encode()).hexdigest() == correction['before_sha256']
assert before.replace('    assert celery_app.conf.task_always_eager\n    user, first_listing, version, credentials = setup(request, settings)\n',
                      '    user, first_listing, version, credentials = setup(request, settings)\n    assert celery_app.conf.task_always_eager\n') == Path(correction['source']).read_text()
runtime_checks = []
for run, total, passes, failures in [(A['run'], 3, 3, 0), (A2['run'], 13, 13, 0), (B['run'], 4, 3, 1), (C['run'], 1, 1, 0)]:
    p = Path('artifacts/local-ci') / run
    result = read(p / 'result.json'); hashes = read(p / 'source-hashes.json')
    cases = list(ET.parse(p / 'pytest.xml').iter('testcase'))
    assert len(cases) == total and sum(c.find('failure') is not None for c in cases) == failures
    assert not any(c.find(k) is not None for c in cases for k in ('error', 'skipped'))
    assert result['result'] == ('ERROR' if failures else 'PASS') and result['sources_unchanged']
    current_scope = {f: v for f, v in hashes.items() if f.startswith(('apps/', 'config/', 'templates/', 'requirements'))}
    delta = {f: {'frozen': v, 'current': sha(f)} for f, v in current_scope.items() if sha(f) != v}
    assert set(delta) == ({'apps/listings/favorites.py', 'apps/core/sitemaps.py'} if run == A['run'] else set())
    assert read(p / 'telegram-notification.json')['delivery'] == 'sent'
    assert all(v['absent'] for v in result['cleanup'].values())
    assert not Path(read(p / 'runner.json')['temporary']).exists()
    for kind in ('container', 'volume', 'network'):
        command = ['docker', 'ps', '-aq'] if kind == 'container' else ['docker', kind, 'ls', '-q']
        assert not subprocess.check_output(command + ['--filter', 'label=web-modelos-local-ci-run=' + run], text=True).strip()
    runtime_checks.append({'run': run, 'recorded_result': result['result'], 'actual_testcases': total, 'PASS': passes,
                           'FAIL': failures, 'ERROR': 0, 'SKIP': 0, 'QA_junit_seconds': float(result['junit'][0]['time']),
                           'source_hashes_sha256': sha(p / 'source-hashes.json'), 'raw_junit_sha256': sha(p / 'pytest.xml'),
                           'result_sha256': sha(p / 'result.json'), 'app_config_template_sources': len(current_scope),
                           'current_product_delta': delta, 'cleanup_verified': True, 'telegram_sent': True})

census = read('artifacts/recorridos-n08-a-20261026/census.json')
matrix = read('docs/evidencias/n00-matriz-acciones-prioridades-20261025.json')['actions']
assert {r['id'] for r in census} == {r['id'] for r in matrix if 'N08' in r['blocks']} and len(census) == 17
groups = [
    ('G1_favorites', ['route:R_favorites', 'route:R_favorite_add', 'route:R_favorite_remove'],
     ['test_favorites'], ['410', '412'], 'Native24 allpages/placeholders/foreignNULLrevision/currentguard; add/remove AST identical and original replay/race/browser retained; current A2tenoriginals include favorites3.', 'GET100 firstpage ES/EN paired A2; mutation timing retained N01D, no new add/remove speed claim.'),
    ('G2_crawl', ['route:R_robots', 'route:R_sitemap_index', 'route:R_sitemap_directory', 'route:R_sitemap_listings'],
     ['test_sitemaps', 'test_public_seo'], ['410', '412'], 'Nativecandidate100/101index+allpages; count-before-visibility retained; alternates/canonical/private/development/withdrawal/currentbrowser originals retained. Onlylistings AST changes acceptedA2.', 'XML100 paired A2; original robots/method guards retained; no millions/sitemapcapacity or network p95.'),
    ('G3_legal', ['route:R_legal_index', 'route:R_legal_document'], [], ['410'],
     'ES/EN active-doc cohorts0/1/10/100,202syntheticrows,foreign-language/inactive404 and readonly allscalar snapshots.', '60GET10segments first+5; legalcontent/jurisdiction/operator compliance not certified.'),
    ('G4_orders', ['route:R_promotion_orders', 'route:R_promotion_order_detail'],
     ['test_promotion_orders', 'test_promotion_order_http', 'test_promotion_order_races', 'test_promotion_order_mobile_agency', 'test_promotion_order_inventory', 'test_promotion_audit_inventory', 'test_promotion_localization', 'test_promotion_conflict_localization', 'test_promotion_recovery'], ['415'],
     'Native25 allpages0/1/10/26/100history; independent0/1/10/100optionaxes; actor/foreign/MFA/noGETwrites/syntheticwarning. Historical nativePOST/signedevents/replay/immutableprice/locks/concurrency/privateCSRF remain exactsource outcomes.', '120historydetail+96options measuredGET plus12negatives; zero provider/livepayment or 100nativepurchase claim.'),
    ('G5_catalogue', ['route:R_promotion_products', 'route:R_promotion_product_versions', 'route:R_promotion_version_edit', 'route:R_promotion_version_preview'],
     ['test_promotion_catalog', 'test_promotion_catalog_localization'], ['415'],
     'Native50 allpagesproducts0/1/10/51/100 andversions1/10/51/100; NULLamountnotzero; ESENedit/preview readonly; actual10POST4audits/lang/release-replay,no orders/grants; permissionrevocation and originals.', '180measuredGET18negativeGET10nativePOST; first+5 only equivalentGET, no time distribution over distinctmutations.'),
    ('G6_autobump', ['task:T_apps.catalog.tasks.bump_promotions', 'beat:24:apps.catalog.tasks.bump_promotions'],
     ['test_promotion_exposure', 'test_promotion_bump_races'], ['416'],
     'Native boundedscan100/last_checked advancement/quota/window/races originalPG outcomes; new signedindividual+agency actualrestrictedprefork2 queue+replay+twoBeat60ticks,revokedsecondneverbumps/editorialunchanged/cleanup.', 'Only2entitlements in actualworker; original101case isfunctional taskbody not workerlatency/capacity. One actualexecutingchildof2created; two ticks not SLA. N04ranking/withdrawal andN07lifecycle kept shared.')]
actions = []
for group, ids, modules, docs, proof, limits in groups:
    for id_ in ids:
        original = next(r for r in census if r['id'] == id_)
        actions.append({'id': id_, 'kind': original['kind'], 'families': original['families'], 'group': group,
                        'original_inventory_record': original, 'current_source_sha256': {p: sha(p) for p in original['sources']},
                        'functional_state': 'VERIFIED_LOCAL_WITH_DECLARED_LIMITS', 'performance_state': 'PAIRED_GAIN_ACCEPTED_412' if id_ in ('route:R_favorites', 'route:R_sitemap_listings') else 'CURRENT_REFERENCE_OR_SOURCE_SCOPED_ORIGINAL_NO_NEW_GAIN',
                        'evidence_documents': docs, 'source_scoped_original_witnesses': [r for r in reuse['witnesses'] if r['module'] in modules],
                        'proof': proof, 'limits': limits, 'disposition': 'ACCEPTED_LOCAL_N08_SCOPED',
                        'shared_owners': ['N09_retention_privacy', 'N10_operation', 'N11_integrated', 'N15_final_inventory'] if group == 'G6_autobump' else ['N11_integrated', 'N15_final_inventory']})
assert len(actions) == len({r['id'] for r in actions}) == 17
criteria = [
    {'id': 'C1', 'requirement': 'All17censused actions/familiesI07I08I19 disposed without renumbering', 'evidence': 'actions17/groups3+4+2+2+4+2/directsourcehashes/currentcensus443', 'result': 'PASS_SCOPED'},
    {'id': 'C2', 'requirement': 'Freshpubliceligibility/withdrawal/privateboundaries preserve authority', 'evidence': 'A2sameinstance/NULLforeign/placeholder/privateoriginals plus Cactualrevocation; N04/N07sharedaccepted', 'result': 'PASS_SCOPED'},
    {'id': 'C3', 'requirement': 'Counts/order/nativepagination/alternates/legalfiltering preserved', 'evidence': 'A300/50segments and A2rawXML/parity101/native24/100; Bnative25/50allpages; legal202readonlyrecords', 'result': 'PASS_SCOPED'},
    {'id': 'C4', 'requirement': 'Syntheticcommercialauthority/idempotency/audit/immutableprice/no real payments', 'evidence': 'B436Client and native10POST/8audits; sourceexact77originals include26catalogue/11orderraces/7bumpraces; zero realproviderclaim', 'result': 'PASS_SCOPED'},
    {'id': 'C5', 'requirement': 'Autobumpquotalocks/replay/100boundedscan and actualscheduler stage', 'evidence': 'Originalfunctional101scan retained; C1actual5SUCCESSroleproofs/two60ticks/noeditorialmutation/revokedgrantabsent', 'result': 'PASS_SCOPED'},
    {'id': 'C6', 'requirement': 'Preregistered source-equivalentmeasurements, goal411andresources preserved', 'evidence': 'A2all6targets/lowcostguards/RSS<=1GiB sameDBpairs; B66segments/Cseparatestages currentnotgain; no marginalcandidate', 'result': 'PASS_SCOPED'},
    {'id': 'C7', 'requirement': 'Originalfail/skip/debugSQLlimits and acceptedsourcechain remain explicit', 'evidence': 'Originalmixed3PASS1FAIL and oneCcorrective; debugSQLdiscarded;77historicalnotfresh;1507=1498same+9acceptedvariants', 'result': 'PASS_SCOPED'},
    {'id': 'C8', 'requirement': 'Ownedruntime/cleanup/Telegram/sourcefreeze and no provider/beta scopeexpansion', 'evidence': '4rawruns sourceunchanged/cleanup/sent;C4PIDsremoved/roleprivatecleanup/foreignRedisunchanged; no production', 'result': 'PASS_SCOPED'},
]
proof = {'result': 'PASS_N08_ALL17_TECHNICAL_ACCEPTANCE_RECONCILIATION', 'technical_acceptance': True,
         'inventory_actions': 17, 'groups': {g[0]: len(g[1]) for g in groups}, 'criteria': criteria,
         'baseline_sources': 1507, 'unchanged_baseline_sources': 1498, 'accepted_variants': changed,
         'handler_AST_proof': ast_proof, 'selected_historical_cases': 77, 'historical_modules': 16,
         'new_explicit_cases': 10, 'runtime_checks': runtime_checks, 'one_integrated_green_suite_claimed': False,
         'graph_before_acceptance': graph_before_acceptance, 'goal_complete': False,
         'scope': 'Finite local N08 technical sufficiency, not production capacity/provider/beta or fullcontractdone. Delivery archiving/final semanticgraph/Git pending; N11 integration/N15 inventory stillrequired. Source references in original records remain historical; current hashes separate.'}
(W / 'dispositions-final.json').write_text(json.dumps({'result': 'N08_ALL17_TECHNICALLY_ACCEPTED_WITH_LIMITS', 'actions': actions,
    'criteria': criteria, 'source_scope': proof['scope']}, ensure_ascii=False, indent=2) + '\n')
(W / 'acceptance-verification.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in proof.items() if k not in ('criteria', 'accepted_variants', 'handler_AST_proof', 'runtime_checks')}, ensure_ascii=False))
