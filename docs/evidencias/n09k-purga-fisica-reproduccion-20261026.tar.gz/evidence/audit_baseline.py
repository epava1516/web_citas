import hashlib,json,math,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n09-k-20261026');P=Path('artifacts/local-ci')/sys.argv[1]
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f,r,h=read(W/'baseline-freeze.json'),read(P/'result.json'),read(P/'source-hashes.json')
assert r['result']=='PASS' and r['sources_unchanged'] and r['selection']==f['selection']
assert all(sha(p)==v for p,v in f['sources'].items())
assert set(f['sources'])-set(h)==set(f['sources_verified_separately'])
assert all(h[p]==v for p,v in f['sources'].items() if p in h)
cases=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==8
profiles=[];seen=set()
for c in cases:
 assert all(c.find(k)is None for k in ['failure','error','skipped'])
 props={x.get('name'):x.get('value') for x in c.iter('property')};d=json.loads(props['owned_delivery_purge_profile']);assert d['status']=='passed'
 mode,n=d['mode'],d['eligible_count'];assert(mode,n)not in seen;seen.add((mode,n))
 assert d['domain_before']==d['domain_after'] and d['media_before']==d['media_after'] and d['row_before']==d['row_after']
 assert d['row_before']['row_count']==n+2 and d['row_before']['pin_count']==2
 assert d['directory_before']['entries']==n+4 and d['directory_after']['entries']==3
 if mode=='volume' and n==1001:names=['first_batch','second_batch','idempotent_replay'];counts=[1000,1,0];physical=[1001,1,0]
 elif mode in ['volume','eligibility']:names=['first_batch','idempotent_replay'];counts=[n,0];physical=[n+1,0]
 elif mode=='skip_locked':
  names=['while_holder_active','after_release','idempotent_replay'];counts=[2,1,0];physical=[3,1,0]
  assert d['holder_pid']!=d['worker_pid'] and d['completed_while_holder_active'] and d['holder_released'] and d['thread_finished'] and d['worker_connections_closed']
 else:
  assert mode=='partial_failure' and n==2
  names=['second_unlink_failure','first_batch','idempotent_replay'];counts=[None,2,0];physical=[1,2,0]
  assert d['sql_rollback_physical_first_delete_retained'] and d['failure_order_sha256']
 phases=d['phases'];assert [p['phase']for p in phases]==names and [p['returned_count']for p in phases]==counts
 assert [p['physical_files_removed']for p in phases]==physical
 for p,count in zip(phases,counts,strict=True):
  assert all(math.isfinite(p[k]) and p[k]>=0 for k in ['wall_seconds','sql_seconds','unlink_seconds','directory_next_seconds'])
  assert p['wall_seconds']>=max(p['sql_seconds'],p['unlink_seconds'],p['directory_next_seconds'])
  assert p['sql_count']==sum(x['count']for x in p['operations'].values()) and p['sql_count']>=1
  assert not({'INSERT','DELETE'}&set(p['operations']))
  if count is None:
   assert p['exception_type']=='OSError' and p['changed_rows_count']==0 and p['unlink_calls']==2
   assert p['directory_iterators']==p['directory_next_calls']==0 and p['remaining_before_count']==p['remaining_after_count']==2
  else:
   assert p['changed_rows_count']==count and p['remaining_before_count']-p['remaining_after_count']==count
   assert p['directory_iterators']==1 and p['directory_next_calls']>=1 and p['unlink_calls']>=p['physical_files_removed']
 assert sum(p['physical_files_removed']for p in phases)==n+1
 assert abs(sum(p['wall_seconds']for p in phases)-d['measured_seconds'])<1e-8
 assert abs(d['case_seconds']-d['measured_seconds']-d['non_measured_seconds'])<1e-8
 assert d['case_seconds']>=d['setup_seconds']>=0
 profiles.append(d)
assert seen=={('volume',n)for n in[0,1,10,100,1001]}|{('eligibility',4),('skip_locked',3),('partial_failure',2)}
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q']
 assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists()
tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_EIGHT_FINITE_PHYSICAL_DELIVERY_PURGE_BASELINE_NOT_WHOLE_N09','run':P.name,'junit':r['junit'],'frozen_sources':len(f['sources']),'profiles':profiles,'cleanup_verified':True,'telegram':tg,'scope':'NativeTask.run/ownedPGactualFS/smallvolume0to1001/matrix4/skip3/partialfailure2+recovery;N1instrumented/noafter/noappchange/noTTLadmission/newworkerCaddyRustFSBeatproviderproof.1000rowsnotglobalscanbound.4oldscopedwitnessesseparatereuse/wholeoldERRORretained/N09139open8of13.'}
(W/'baseline-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k!='profiles'}))
