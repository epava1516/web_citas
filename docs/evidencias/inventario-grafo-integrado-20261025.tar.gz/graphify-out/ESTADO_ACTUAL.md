# Grafo final alfa: base reconstruida e inventario integrado

Base desde cero preservada:1922fuentes,17850nodos/79100relaciones,846comunidades. Archivo y auditoría: docs/evidencias/grafo-final-reconstruccion-20261025.json. La base no se sustituye retrospectivamente por este refresco.

Actualización focal: 5 documentos leídos semánticamente por agente nativo; 97 entidades y 177 relaciones nativas con citas y huellas comprobadas. Corpus vigente:1924fuentes; 17847nodos/79498relaciones;847comunidades. Se reemplaza la semántica de los documentos cambiados y se recalculan sus citas literales. AST de producto/pruebas intacto. Comunidades de base conservadas, con una comunidad documental adicional: no es una nueva detección global.

Seguimiento17: sólo líneas1–4 de su sección actual, con SHA del archivo completo y de la vista por separado. Resto de exclusiones y método de base en CORPUS_POLICY.json. Referencias extranjeras a entidades sustituidas se conservan como referencias no resueltas explícitas, no implementaciones inventadas. Semántica selectiva, sin prueba de exhaustividad, PASS, seguridad, legalidad o capacidad productiva. Se conservan100anotaciones ambiguas de llamadas/bases como anotaciones y no dependencias a sí mismo.

B16 aceptado por acta22; inventario338/339 verificado.15/18aceptados localmente;B14/B15/B17diferidos. El proyecto permanece en alfa; acta final pendiente. Consumo nativo desconocido: ceros técnicos del generador no equivalen a coste cero.

HTML muestra sólo proyección de comunidades; JSON contiene todas las entidades. No se eleva la guarda de5000nodos del exportador.

