# Grafo alfa — N03 aceptado localmente; N04 siguiente

4/13 bloques aceptados: N00/N01/N03/N06. Acta393 concilia seis acciones, nueve criterios, cinco puentes AST y trece citas con JUnit originales. ORB14,954175→12,729232s (−14,878%) en contraste finito/paridad exacta; C/D/F1 corregidos con49PASS y F2 histórico3PASS/18llamadas. Fallos originales preservados, sin sumar baterías distintas. Alcance finito, no80k/SLA/proveedor/apertura. N07/N09/N10 conservados; MOD09 restante diferido al final. Sin nueva optimización marginal.

Semántica focal393/341/README/vista17primeras4líneas, sin cambio de aplicación: 2001 fuentes, 18929 nodos/82016 relaciones, 904 comunidades. Base preservada, no reconstrucción global ni exhaustividad semántica. Consumo nativo desconocido. Próximo N04 I01–I05, con censo y testigos discoveryN01 antes de candidato.

