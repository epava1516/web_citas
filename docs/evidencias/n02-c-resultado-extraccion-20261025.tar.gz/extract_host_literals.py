"""Host fallback after delegated model-capacity error; documentary claims only."""
import hashlib,json,re
from pathlib import Path
w=Path(__file__).resolve().parent;inputs=json.loads((w/'semantic-inputs.json').read_text());nodes=[];edges=[]
by_source={row['source']:p for p,row in inputs.items()}

def add(source,suffix,label,lo,hi=None):
 p=by_source[source];text=Path(p).read_text();lines=text.splitlines();hi=hi or lo;assert 1<=lo<=hi<=len(lines)
 identity=re.sub('[^a-z0-9]+','_',str(Path(source).with_suffix('')).lower()).strip('_')+'_'+suffix
 nodes.append({'id':identity,'label':label,'file_type':'concept','source_file':p,'source_location':f'L{lo}-L{hi}','source_sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest(),'evidence_quote':'\n'.join(lines[lo-1:hi]),'claim_scope':'Documented local result/limit; runtime evidence is separate audited artifact'})
 return identity

def link(a,b,relation='references'):
 n=next(n for n in nodes if n['id']==b)
 edges.append({'source':a,'target':b,'relation':relation,'confidence':'EXTRACTED','confidence_score':1.0,'weight':1.0,**{k:n[k] for k in ['source_file','source_location','source_sha256','evidence_quote']}})

doc='docs/365-n02-c-resultado-contraste-agrupado-guard-20261025.md';root=add(doc,'resultado','N02C:1PASS/120guards/12groups; prior sources unchanged,2/13open alpha',3)
for suffix,label,lo,hi in [
 ('diseno','Same actual held-seal context;2smallfiles10554bytes,firstpairseparate,5groupsof10pervariant',7,None),
 ('tiempos','Median5groupmeans39.513→28.857ms;CPU29.546→20.611/SQLexecute12.097→9.099ms',9,17),
 ('instrumentacion','Original Python profiler overhead included;all120individualsamples/outliers retained,not clean latency',19,None),
 ('parejas','All five warm group-mean pairs improve;pair4only0.190ms',21,27),
 ('adopcion','Local guard adopted by fixed criterion,not statisticalguarantee/sitegain/loadacceptance',29,None),
 ('integridad','120freshnativechecktransactions;480preexistingPGrowlockwitnesses/240fullreads and hashes',33,None),
 ('reutilizacion','16priororacles reused with1516sourceidentities;363historicalinconclusion/FAILpreserved',35,None),
 ('limites','OwnedPGRedis/localfiles;identitysimulator explicit,noHTTP/p95/fullMOD09/memorycapacityproof',37,None),
 ('limpieza','Frozen sources/cleanup/Telegramverified;92.15sPytest94.378scommandareQA',39,None),
 ('pendientes','Guard adoption does not closeN02;remainingstages/fulloriginalMOD09/N06/allmandatoryscope pending',43,None)]:link(root,add(doc,suffix,label,lo,hi))
road='docs/341-roadmap-recorridos-optimizacion-alpha-20261025.md';rr=add(road,'alcance_vigente','Alpha roadmap2/13mandatoryaccepted,N12–14conditionalnotPASS',3)
for suffix,label,line,end in [
 ('n02_estado','N02localguardadopted365;remainingattribution/fullMOD09pending',19,None),
 ('n06_estado','N06attribution/queuedreference;remainingvariantsmandatory',23,None),
 ('criterios_n02','N02mustattributeallstages/growth/concurrency;2s5s/FAILexceptionpreserved',56,58),
 ('cierre_final','N15requiresall13mandatory/28families,freshfullgraph/differentialinventory/acta',160,162),
 ('tablas','Eachblockneedsbeforeafterapplicationtimes/samples/validdifferences,nofictitiousgains',201,None),
 ('qa_y_alpha','QAoptimizationdeferred;mandatorypendingpreventsclose,alpha/exceptionwithoutFAILconversion',205,None)]:link(rr,add(road,suffix,label,line,end))
readme='docs/README.md';idx=add(readme,'n02c_indice','IndexlinksN02C5/5localguardadoptionwhileMOD09pending',1);authority=add(readme,'autoridad_resultados','Originalversionhash/scenariolimits govern observedresults;no crossversionorcommonbatteryextrapolation',106);link(idx,authority)
view='docs/17-seguimiento-desarrollo.md';status=add(view,'n02c_actual','Current4lineview:localadoption,1PASS120guards5/5,2/13N02N06openalpha',1);nxt=add(view,'siguiente','NextfullMOD09stageattribution/growth/concurrency;2s5s/FAIL/exceptionand363snapshotintact',3);link(status,nxt)
# Direct literal Markdown references explicitly link these documentary roots.
for a in [idx,status]:
 n=next(n for n in nodes if n['id']==a);assert '365-n02-c-resultado-contraste-agrupado-guard-20261025.md' in n['evidence_quote'];edges.append({'source':a,'target':root,'relation':'cites','confidence':'EXTRACTED','confidence_score':1.0,'weight':1.0,**{k:n[k] for k in ['source_file','source_location','source_sha256','evidence_quote']}})
fragment={'nodes':nodes,'edges':edges,'hyperedges':[],'input_tokens':0,'output_tokens':0,'usage_tracking':'Host/delegate allocation unknown; technicalzerosnotcostzero','extraction_method':'Hostsemanticliteral-backedfallbackafterdelegatedcapacityerror,notindependentagentoutput'}
(w/'semantic-fragment.json').write_text(json.dumps(fragment,indent=2,ensure_ascii=False)+'\n')
report={'STATUS':'complete','SUMMARY':'Host extracted four full declared inputs after delegated model capacity failure;23documentarynodes/relations selective,notruntimeproof.','FILES_CHANGED':['artifacts/recorridos-n02-c-20261025/result/semantic-fragment.json','artifacts/recorridos-n02-c-20261025/result/report.json'],'IMPLEMENTATION_NOTES':['Delegated extraction failed before writing outputs: Selected model is at capacity. No model change or automatic retry.','Host read all four snapshots, with bounded followup reads for truncated batch output; literal line/sourceSHA supplied for every node/edge.','Scope preserves local instrumented adoption, original profiler overhead,0.190mspairmargin,previoushistoricalFAIL/inconclusion and mandatorycontractpending.'],'TESTS_RUN':[],'TEST_RESULTS':['No tests performed by this extraction; independent source/quote/unchanged-graph gate still required.'],'ASSUMPTIONS':['Inputs remain unchanged until parent graph verification.'],'RISKS':['Semanticrelationshipsselective,notexhaustive;no independent second-model semantic review in this fallback.','MOD09/fullcontractnotaccepted by component.'],'UNRESOLVED_ISSUES':[],'RECOMMENDATIONS':['Verify every literal/sourceSHA and unchanged-source graph/AST before publishing.']}
report['SUMMARY']=f'Host extracted four declared inputs after delegated capacity failure;{len(nodes)}nodes/{len(edges)}relations selective documentary claims,notruntimeproof.'
(w/'report.json').write_text(json.dumps(report,indent=2)+'\n');(w/'delegated-capacity-failure.json').write_text(json.dumps({'task':'n02c-result-semantic','agent':'n02a_result_semantic','outcome':'failed_before_outputs','reason':'Selected model is at capacity','automatic_retry':False,'model_override':False,'fallback':'host_literal_backed_extraction_with_deterministicverification'},indent=2)+'\n');print(report['SUMMARY'])
