# N09G — revisión diferencial acotada antes del resultado runtime

Base28a02db; candidata apps/safety/rectification_final.py SHA3d56d2feba96d38c3e74347049d11f26c0574b62e36c7a66a901e0689e5faa4d. Riesgo alto por autorización y privados; repositorio grande, estrategia quirúrgica. Informe propio root, no revisión independiente por agente ni certificación integral.

## Contexto e historia

La implementación original de context/evidence procede de187b8e6e (gitblame45–74); historial reciente fa81bf6,72ff79a,187b8e6. F28a02db introdujo capture_authority para otros consumidores. No se elimina actor(): AST intacto, consumidor GET conservado. Las comprobaciones de contexto se sustituyen por autoridad original capturada, no se elimina la exigencia de permisos/asignación.

## Superficie y alcance

Una ruta autenticada con cuatro llamadas públicas desde rectification_final_views.final: prepare,inspect,review,close; un consumidor adicional actor en GET. Helpers internos context/evidence/draft_context/record no tienen consumidores externos conocidos tras búsqueda. No cambia ninguna firma pública. Un módulo de aplicación modificado, sin modelos, migraciones, servicios, vistas o plantillas. Casos originales de cierre/localización seleccionados junto con los13diagnósticos íntegros; F75/E38 retenidos.

## Modelo de amenaza concreto

Operador inicialmente autorizado, con sesión/MFA, expediente y evidencia nativa preparada, que pierde respond mientras una segunda conexión PostgreSQL mantiene RecipientReview/Draft/Review/SubjectUser/PhoneClaim. El acceso autenticado no exime la revisión. El original deja volver privados en seis familias: cinco antes de denegación tardía y uno con nueva Action/retorno. Otra condición mantiene todos los permisos pero deja caducar por reloj real la prueba durante la espera; el original crea borrador. Es una carrera que requiere estado privilegiado y espera, no acceso anónimo ni explotación remota demostrada.

## Evaluación de la candidata

Captura PK y epochs originales y exige cuatro permisos con User nuevo en cada comprobación, sin lock del operador. Contexto mantiene clase/estado/versiones/asignación/lecturas. Callback vincula PK original de prueba y reconsulta vigencia tras filas bloqueadas. Se propaga por helpers existentes de F para fuente de cuenta/snapshot/scope, y se llama después del claim antes del inventario privado. inspect usa el llamador, no al autor del borrador; la auditoría temprana queda en la misma transacción y se revierte al denegar.

Cierre nuevo comprueba antes de descifrar revisión y antes de payload privado, manteniendo independencia/latest/digests/read/epochs/pending. Replay resuelto usa autoridad original actual e integridad histórica; no exige prueba activa de un expediente resolved/unverified. No se introduce callback activo después de la transición final. Esto se contrasta con caso original concurrente y replay, no se presume por lectura.

## Límites y aceptación pendiente

Sin hallazgo adicional confirmado en este diff tras trazado acotado. Esto no declara seguridad global ni prueba de toda materialización: seis fronteras seleccionadas, cuatro operaciones, una ruta. No hay nueva evidencia HTTP, worker real ni proveedor; las pruebas de identidad usan el adaptador sintético permitido en alpha, nunca proveedor productivo. Más consultas de autoridad/vigencia tienen coste; no se atribuye mejora de rendimiento. Evaluación/revisión de destinatarios usadas como fixture y otras ramas tardías siguen pendientes en N09. El runtime18/auditoría decidirá si esta candidata se acepta; este informe no sustituye resultados.
