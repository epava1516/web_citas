import collections,hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
W=Path('artifacts/recorridos-n09-g-20261026');P=Path('artifacts/local-ci')/sys.argv[1]
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f,r,h=read(W/'baseline-freeze.json'),read(P/'result.json'),read(P/'source-hashes.json')
assert r['sources_unchanged'] and r['selection']==f['selection']
assert all(sha(p)==v for p,v in f['sources'].items())
assert set(f['sources'])-set(h)==set(f['sources_verified_separately'])
assert all(h[p]==v for p,v in f['sources'].items() if p in h)
cases=list(ET.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==13
records={}
for c in cases:
 props={p.get('name'):p.get('value') for p in c.iter('property')}
 d=json.loads(props['rectification_final_authority_wait']);assert d['label'] not in records
 records[d['label']]={'runtime':d,'failure':c.find('failure')is not None,'error':c.find('error')is not None,'skip':c.find('skipped')is not None}
families=['prepare_review','inspect_draft','review_draft','close_review','prepare_account_source','prepare_contact_claim']
assert set(records)=={a+':'+b for a in families for b in ['valid','permission']}|{'prepare_review:proof_expiry'}
def wait_ok(row):
 d=row['runtime']
 return (d.get('actual_wait') and d.get('first_wait_inside_expected_helper')
  and d.get('worker_pid')!=d.get('holder_pid') and d.get('holder_pid')in d.get('blocker_pids',[])
  and d.get('thread_finished') and d.get('connections_closed') and d.get('holder_released')
  and not d.get('final_snapshot_exception_type') and not row['error'] and not row['skip'])
def changes(d):
 if 'domain_before'not in d or 'domain_after'not in d:return None
 return sorted(k for k,v in d['domain_before']['tables'].items()if v!=d['domain_after']['tables'][k])
controls={};classified=[]
for family in families:
 row=records[family+':valid'];d=row['runtime'];expected={'safety.RightsAction'}
 if family=='close_review':expected|={'safety.RightsResponse','safety.RightsNotice','safety.RightsRequest'}
 valid=bool(wait_ok(row) and not row['failure'] and d.get('status')=='success'
   and d.get('target_returns',0)>0 and set(changes(d)or[])==expected
   and d.get('files_before')==d.get('files_after'))
 controls[family]=valid
 classified.append({'family':family,'variant':'valid','verdict':'VALID_NATIVE_CONTROL'if valid else'INVALID_CONTROL_DIAGNOSTIC','changed_tables':changes(d),**row})
for label,row in records.items():
 family,variant=label.split(':')
 if variant=='valid':continue
 d=row['runtime'];admissible=bool(controls[family] and wait_ok(row))
 if variant=='permission':admissible=bool(admissible and d.get('permission_revoked'))
 else:
  admissible=bool(admissible and d.get('other_fields_unchanged') and d.get('natural_deadline_passed')
    and d.get('proof_expired') and d.get('proof_fields_unchanged_during_wait')
    and d.get('permission_preserved') and d.get('all_final_roles_preserved')
    and not d.get('permission_revoked') and d.get('domain_admission')==d.get('domain_before'))
 intact=(d.get('domain_before')==d.get('domain_after') and d.get('files_before')==d.get('files_after')
         and d.get('minimal_before')==d.get('minimal_after'))
 expected_status='PermissionDenied'if variant=='permission'else'ValidationError'
 private=d.get('target_returns_after_revocation',0)>0
 if not admissible:verdict='INVALID_NEGATIVE_DIAGNOSTIC'
 elif d.get('status')=='success' and private:
  verdict=('CONFIRMED_NATIVE_PRIVATE_RETURN_EFFECT_AFTER_PERMISSION_REVOCATION'if variant=='permission'
           else'CONFIRMED_NATIVE_PRIVATE_PROCESSING_AND_EFFECT_AFTER_PROOF_EXPIRED_DURING_WAIT')
 elif d.get('status')==expected_status and intact and private:
  verdict=('CONFIRMED_PRIVATE_TARGET_RETURN_BEFORE_LATE_PERMISSION_DENIAL'if variant=='permission'
           else'CONFIRMED_PRIVATE_TARGET_RETURN_BEFORE_LATE_PROOF_DENIAL')
 elif d.get('status')==expected_status and intact and not private and not row['failure']:
  assert d.get('target_calls_after_revocation',0)==0 or family=='prepare_account_source'
  verdict='DENIED_BEFORE_SELECTED_PRIVATE_BOUNDARY_NO_REPRODUCTION'
 else:verdict='UNCLASSIFIED_REQUIRES_REVIEW'
 classified.append({'family':family,'variant':variant,'verdict':verdict,'changed_tables':changes(d),**row})
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq']if kind=='container'else['docker',kind,'ls','-q']
 assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists()
tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
counts=dict(collections.Counter(x['verdict']for x in classified))
out={'result':'THIRTEEN_FINAL_DIAGNOSTICS_CLASSIFIED_NOT_CONTRACT_ACCEPTANCE','run':P.name,'original_result':r['result'],'junit':r['junit'],'frozen_sources':len(f['sources']),'verdict_counts':counts,'cases':classified,'cleanup_verified':True,'telegram':tg,'limits':'All native services,notHTTP;exactselectedprivateboundarynotallinternalprojections. TTL10s fixturebeforeadmission,clockdeadlinepasseswhileactualPGwait,no intervalDBmutation/permschanged inexpirycase. Fourops/sixwaitfamilies/one route,not13bugs orblocks. F75/E38retained,N09full139open8of13.'}
(W/'baseline-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k!='cases'}))
