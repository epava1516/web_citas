import hashlib,json,statistics
from pathlib import Path
out=Path('/tmp/worker-capacity-4-vs-6-ready0110')
blocks=[json.loads((p/'analysis.json').read_text())for p in sorted(out.glob('block-*'))if(p/'analysis.json').exists()]
allfolds=sorted(out.glob('block-*'))
for b in blocks:
 for section in [b['window']['resources'],b['cohort']['resources_enclosing_cohort']]:
  for io in section['io'].values():io.setdefault('status','measured'if io['readable_pids']else'not_measured')
assert len(blocks)==4, 'Incomplete sequence; retain partials without assuming missing blocks'
assert [b['workers']for b in blocks]==[4,6,6,4]
releases=[json.loads((p/'review-release.json').read_text())for p in allfolds]
assert all(r['reviewed']and r['sources_verified']and r['cleanup_verified']for r in releases)
for p,r in zip(allfolds,releases):assert hashlib.sha256((p/'analysis.json').read_bytes()).hexdigest()==r['analysis_sha256']
reference=blocks[0]['warmup']['body_hashes']
assert all(b['warmup']['body_hashes']==reference for b in blocks)
spacings=[b['upload_emission_monotonic']-a['upload_emission_monotonic']for a,b in zip(blocks,blocks[1:])]
assert min(spacings)>=60
pairs=[]
for base,more in [(blocks[0],blocks[1]),(blocks[3],blocks[2])]:
 a,b=base['window'],more['window'];ca,cb=base['cohort'],more['cohort']
 improvement=b['counts']['successful']/a['counts']['successful']-1
 inflation=cb['D_worker_seconds_per_request']/ca['D_worker_seconds_per_request']
 competition=abs(b['resources']['unrelated_host_residual_mean_CPU_cores']-a['resources']['unrelated_host_residual_mean_CPU_cores'])
 checks={'completion_at_least10percent_more':improvement>=.10,'client_p95_lower':cb['observable_latency_seconds']['p95']<ca['observable_latency_seconds']['p95'],
 'errors_no_higher':cb['error_fraction']<=ca['error_fraction'],'D_at_most1_10baseline':inflation<=1.10,
 'unrelated_host_CPU_difference_at_most_point5':competition<=.5}
 pairs.append({'four_block':base['index'],'six_block':more['index'],'completion_ratio_improvement':improvement,'D_ratio_six_over_four':inflation,
 'D_delta_worker_seconds_per_request':cb['D_worker_seconds_per_request']-ca['D_worker_seconds_per_request'],
 'W20_contractual_delta_worker_seconds_per_second':cb['W20_contractual_including_upload']-ca['W20_contractual_including_upload'],
 'p95_delta_seconds':cb['observable_latency_seconds']['p95']-ca['observable_latency_seconds']['p95'],
 'pre_wsgi_cohort_mean_delta_seconds':cb['pre_wsgi_all_entered_mean']-ca['pre_wsgi_all_entered_mean'],
 'pending_window_delta':b['counts']['pending']-a['counts']['pending'],
 'app_CPU_mean_delta':b['resources']['app_mean_CPU_cores']-a['resources']['app_mean_CPU_cores'],
 'PG_CPU_mean_delta':b['resources']['postgres_mean_CPU_cores']-a['resources']['postgres_mean_CPU_cores'],
 'host_CPU_mean_delta':b['resources']['host_mean_CPU_cores']-a['resources']['host_mean_CPU_cores'],
 'unrelated_host_CPU_difference':competition,'checks':checks,'effect_filter_satisfied':all(checks.values())})
competition=[b['window']['resources']['unrelated_host_residual_mean_CPU_cores']for b in blocks]
spread=max(competition)-min(competition)
validity={'all_scenarios_generator_ledgers_valid':all(b['checks']['scenario']and b['checks']['generator']and b['checks']['accounting']for b in blocks),
 'identical_verified_public_bodies':all(b['warmup']['body_hashes']==reference for b in blocks),
 'all_workers_observed_in_warmup':all(b['warmup']['all_workers_observed']for b in blocks),
 'full_dynamic_wsgi_coverage':all(b['cohort']['observed_complete_wsgi']==600 for b in blocks),
 'all_route_counts_expected':all(b['actual_routes']=={'projection':400,'native':200}for b in blocks),
 'identical_upload_body_sha256':len({json.loads((p/'load-summary.json').read_text())['upload_body_sha256']for p in allfolds})==1,
 'upload_spacing_at_least60seconds':min(spacings)>=60,
 'no_resource_stop':not any(b['trial_stop']for b in blocks),
 'collectors_nonfatal':not any(b['collector']['fatal_error']for b in blocks),
 'sampler_coverage_at_least90percent':all(b['collector']['coverage_per_expected_1Hz']>=.9 for b in blocks),
 'collector_prior_diagnostic_p95_at_most250ms':all(b['collector']['p95_full_poll_seconds']<=.25 for b in blocks),
 'collector_prior_diagnostic_CPU_at_most_point15':all(b['collector']['thread_CPU_per_elapsed_second']<=.15 for b in blocks),
 'host_competition_range_at_most_point5':spread<=.5}
# Observer costs are reported, never a backend gain. Underlying proposal's causal host bound is decisive.
essential=[k for k in validity if not k.startswith('collector_prior') and k!='all_workers_observed_in_warmup']
causal='VALID_COMPARISON'if all(validity[k]for k in essential)else 'INCONCLUSIVE'
effect='MEETS_PREFIXED_FILTER'if all(p['effect_filter_satisfied']for p in pairs)and causal=='VALID_COMPARISON'else 'INCONCLUSIVE'if causal=='INCONCLUSIVE'else 'DOES_NOT_MEET_PREFIXED_FILTER'
report={'status':'TERMINAL_REVIEWED','proposal':'docs/evidencias/propuesta-capacidad-4-vs-6-0110.json','manifest':'docs/evidencias/comparacion-capacidad-4-vs-6-manifiesto0110.json',
 'raw_output':str(out),'balanced_orders':[4,6,6,4],'validity':validity,'comparative_validity_verdict':causal,
 'host_competition_mean_CPU_cores_by_block':competition,'host_competition_max_minus_min_CPU_cores':spread,
 'upload_spacing_seconds':spacings,'balanced_pairs':pairs,'benefit_verdict':effect,
 'observed_effect_filter_verdict':'MEETS_PREFIXED_FILTER' if all(all(v for k,v in p['checks'].items()if k!='unrelated_host_CPU_difference_at_most_point5')for p in pairs)else'DOES_NOT_MEET_PREFIXED_FILTER',
 'causal_benefit_verdict':causal,
 'compliance':{'per30second_block_verdicts':[b['block_verdict']for b in blocks], 'full60_second_gate':'NOT_RUN; historicalFAIL remains','900_second_contract':'NOT_RUN; historicalINVALID remains; blocked',
 'CR09':'OPEN','goal':'PAUSED','permanent_six_workers':'NOT_ADOPTED'},
 'formula':{'D':'sum(p_i*E[T_WSGI,i]); p_i=1/3, familyNexplicit, worker-seconds/request',
 'W':'lambda*D + U; lambda20; Ucontractual=mean(uploadWSGI)/60, actualtrial U=uploadWSGI/30; worker-seconds/second, NOT CPU',
 'unrelated_host':'(host_execution_CPU - owned_app_CPU - sharedPG_CPU - ownpytest/client/collector/runner_CPU)/actualsampleinterval; residualscope not attribution; comparedmeans, <=.5 bound',
 'operational_CPU_efficiency':'appCPUwithin declared sampled interval / client successes in same interval; includes work for stillpending requests, not individualCPU/request'},
 'blocks':blocks,
 'limits':['Four30s blocks do not substitute full60s gate or credit900s capacity','Two balancedpairs, one sharedhost, synthetic repeatedfixture; no diverse/externalproduction capacity extrapolation','Warmup identical36requests perblock, allworkers ready; serialPIDcoverage is an observed lowerbound, coldprobe PIDs not instrumented; no claim that every route warmed everyworker. Not an added retrospectiveacceptancecriterion','OS snapshots sequential1Hz; underlyingcountertimealignment bounded by collectionoverhead, service means include this instrument; no exactpreWSGIqueue attribution','No serverPythonprofiler; causal lightWSGI/metadata/GC overhead not_measured; PG CPU sharedbackground and otherdatabases','Unavailable PSI/procIO interfaces not zero; waits samplecounts not durations; RSSincludes sharedpages','Only workers varied in serverconfiguration; immutablefixture cloned and privateupload/media/session reproduced; dynamic reporttoken validates signature/freshness/exact target before comparator-only normalization','CPU scopedcohort includes stated bracketingmargins; individualWSGIthreadCPU direct, not wholeapplication/PG CPU/request','HistoricalmedianHTTP/source/scenario deltas not accumulated; no backendoptimization in this experiment','No autorerun/ladder/no permanentworkerschange/noPGscale/cache/900'],
 'decision':'PENDING_ROOT_REVIEW'}
(out/'comparison-analysis.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k]for k in ['comparative_validity_verdict','validity','host_competition_mean_CPU_cores_by_block','host_competition_max_minus_min_CPU_cores','balanced_pairs','benefit_verdict','compliance']},indent=2))
