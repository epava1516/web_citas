# Differential review — N10D Admin login epoch

## Executive assessment

HIGH review risk because authentication/session state changes. One confirmed baseline availability defect (MEDIUM functional impact): current password succeeds for an admitted staff account at epoch1, then AccountGate deletes its missing-epoch session. Baseline1PASS/1FAIL is actual evidence, not a scanner inference. No unauthorized access or MFA bypass was reproduced. Recommendation: APPROVE the bounded epoch correction after root audit of ten unique cases across two cuts (6reused+4focal), not a single tenPASS suite. N10/whole contract remain open.

## Scope and change

Base8589acd; only apps/core/admin.py changes production behavior. New bind_admin_login_epoch receiver runs after native authentication session setup for senderUser, methodPOST, namespaceadmin and url_namelogin. It copies the admitted User instance epoch without another query. Two imports, one receiver and module description change. CurrentGroupAdmin and current_group_actor ASTs match HEAD exactly; no vendor, middleware, accounts, MFA, settings, models or migration edits.

The original tests/test_admin_login_epoch.py is byteidentical to its baseline; tests/test_admin_login_guards.py adds eight cases. Preregistration483 fixed the alternatives/selection before implementation;484 fixes detailed candidate acceptance before execution. Native reviewer was read-only and did not run tests or change app; root traced the framework and checked the candidate independently.

## History and trust boundaries

Git blame identifies AccountGate epoch handling in9acfc481, including the explicit compatibility-only0 comment and logout on mismatch. No such check is removed. Core signin authenticates then stamps its admitted epoch. VendorAdmin LoginView authenticates but did not stamp it. Django auth.login resolves session flush/cycle, auth fields, request.user and CSRF rotation before user_logged_in; receiver order relative to last_login does not alter the session-cycle fact.

The server ResolverMatch is trusted routing metadata, not a submitted namespace. Native AdminAuthenticationForm still rejects inactive/nonstaff and bad password, native CSRF remains in place, and AccountGate/MFA still govern subsequent private requests. The receiver neither authenticates, refreshes the actor, changes privileges nor writes mfa_version.

## Blast radius

Two actual production password entry paths located: core.accounts.signin and native Admin LoginView. The receiver is reachable through user_logged_in globally for this sender, but the route/method guard selects only the latter POST. Vendor login/alogin emitters and test force_login may send the signal; non-Admin selectors must be no-ops. No new HTTP route, backend, task, model or provider is introduced. Quantitative selection:1productionfile,1newreceiver,2originalcases+8newcases; Groupclass/helper unchanged.

## Concrete adversarial checks

1. Wrong password or nonstaff should never reach successful native login; no auth/session/epoch/MFA row effect. CSRF rejection should occur before form authentication. Three native reject cases cover those boundaries.
2. Epoch revoked after real passwordcheck must not be adopted. The test forwards check_password and then increments only the synthetic actor DB epoch; receiver must stamp the earlier admitted version, and AccountGate must delete it on next request. This is a controlled interposition, not an SQL-wait claim.
3. Valid epoch1 staff must reach MFA without receiving mfa_version automatically. Two original cases verify the handoff; two new ES/EN cases enter a real TOTP and then access Admin, with only exact last_login/TOTP/Session changes.
4. A plain force_login must not start binding epochs globally. A core signin must still stamp via its own code. A forwarding signal observer at the end of dispatch verifies no Admin binding happened in either; subsequent requests retain AccountGate behavior.

## Coverage, evidence and limits

Every case uses owned serial realPostgreSQL/Redis and all-model/through/file oracles. Authentication and native views are not mocked. TOTP clocks and password hashes are real; synthetic secrets remain local. The late-epoch test uses a forwarding method interposition; it proves this exact ordering without claiming a concurrent SQL wait. Session mutation is allowed only for its exact own key and expected auth/MFA fields; no whole-model exclusions.

Actual runtime: first candidate7PASS3FAIL due omitted legitimate RateWindow rows; corrected only the new oracle, exact per-action bucket/counter/time, retaining app bytes. Focused4PASS76.644sQA plus six source/AST-identical priorPASS give ten unique cases. Original application1PASS1FAIL and first candidate7PASS3FAIL remain archived. All1795frozen sources stable, ownresources cleaned and terminalTelegram confirmed. No security approval is inferred from Ruff, AST equivalence or an agent report. N11 integrated regression remains required; other auth entry points, future backends and universal races after the last check are outside this review. Source-return equality from481 belongs to the previous runtime; older images are not an authorized rollback for this fix.
