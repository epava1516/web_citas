"""Validate an owned, resource-limited capacity topology; never a capacity PASS."""

import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

from run_local_ci import hashes

ROOT = Path(__file__).resolve().parents[1]
MIB = 1024 * 1024
ALLOCATIONS = {"pg": (100000, 1536), "redis": (25000, 512), "app": (275000, 6144)}


def main():
    run_id = time.strftime("%Y%m%d-%H%M%S", time.gmtime()) + "-" + uuid.uuid4().hex[:8]
    prefix = "web-modelos-capacity-" + run_id
    output = ROOT / "artifacts/capacity-environment" / run_id
    output.mkdir(parents=True)
    before = hashes()
    (output / "source-hashes.json").write_text(json.dumps(before, indent=2))
    report = {
        "id": run_id,
        "result": "ERROR",
        "scope": "Owned topology readiness only; not capacity, browser, N3 or storage budget proof.",
        "allocations": ALLOCATIONS,
        "steps": [],
        "controls": {},
        "cleanup": {},
    }
    containers = []
    network = prefix + "-net"
    network_attempted = False
    env = {k: v for k, v in os.environ.items() if k in {"PATH", "HOME", "LANG"}}

    def run(command, label, check=True):
        start = time.monotonic()
        result = subprocess.run(command, capture_output=True, text=True, timeout=180, env=env)
        (output / (label + ".log")).write_text(result.stdout + result.stderr)
        report["steps"].append(
            {"label": label, "command": command, "exit": result.returncode,
             "seconds": time.monotonic() - start}
        )
        if check and result.returncode:
            raise RuntimeError(f"{label} failed; see durable log")
        return result

    def container(role, image, extra, command):
        name = prefix + "-" + role
        containers.append(name)  # Cleanup even if Docker partially creates then fails.
        quota, memory = ALLOCATIONS[role]
        run(
            ["docker", "run", "--pull=never", "-d", "--name", name,
             "--network", network, "--network-alias", role,
             "--cpus", str(quota / 100000), "--memory", str(memory * MIB),
             "--memory-swap", str(memory * MIB), "--pids-limit", "256",
             "--log-driver", "local", "--log-opt", "max-size=4m", "--log-opt", "max-file=1", "--log-opt", "compress=false",
             *extra, image, *command], "start-" + role,
        )
        controls = run(
            ["docker", "exec", name, "cat", "/sys/fs/cgroup/cpu.max",
             "/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory.swap.max"], "controls-" + role,
        ).stdout.splitlines()
        if controls != [f"{quota} 100000", str(memory * MIB), "0"]:
            raise RuntimeError(f"Unverified effective limits: {role}")
        report["controls"][role] = controls
        return name

    try:
        for image in ["postgres:17-alpine", "redis:7.4-alpine", "web-modelos-app:latest"]:
            run(["docker", "image", "inspect", "--format", "{{.Id}}", image], "image-" + image.split(":")[0])
        network_attempted = True
        run(["docker", "network", "create", "--internal", network], "network")
        pg = container(
            "pg", "postgres:17-alpine",
            ["--tmpfs", "/var/lib/postgresql/data:size=1073741824",
             "-e", "POSTGRES_USER=ci", "-e", "POSTGRES_PASSWORD=ci-synthetic",
             "-e", "POSTGRES_DB=capacity_ci"], [],
        )
        container("redis", "redis:7.4-alpine", [],
                  ["redis-server", "--save", "", "--appendonly", "no", "--maxmemory", "268435456"])
        python_root = Path.home() / ".local/share/uv/python"
        if not python_root.is_dir():
            raise RuntimeError("Current uv interpreter root missing")
        app = container(
            "app", "web-modelos-app:latest",
            ["--read-only", "--cap-drop=ALL", "--security-opt=no-new-privileges",
             "--user", f"{os.getuid()}:{os.getgid()}", "--workdir", str(ROOT),
             "--mount", f"type=bind,src={ROOT},dst={ROOT},readonly",
             "--mount", f"type=bind,src={python_root},dst={python_root},readonly",
             "--tmpfs", f"/tmp:size=1073741824,uid={os.getuid()},gid={os.getgid()}",
             "-e", "PYTHONDONTWRITEBYTECODE=1", "-e", "DJANGO_SETTINGS_MODULE=config.settings",
             "-e", "DB_HOST=pg", "-e", "DB_PORT=5432", "-e", "POSTGRES_DB=capacity_ci",
             "-e", "POSTGRES_USER=ci", "-e", "POSTGRES_PASSWORD=ci-synthetic",
             "-e", "REDIS_URL=redis://redis:6379/0", "--entrypoint", str(ROOT / ".venv/bin/python3")],
            ["-c", "import time; time.sleep(1800)"],
        )
        for attempt in range(30):
            ready = run(["docker", "exec", pg, "pg_isready", "-U", "ci", "-d", "capacity_ci"],
                        "pg-ready-" + str(attempt), check=False)
            if ready.returncode == 0:
                break
            time.sleep(1)
        else:
            raise RuntimeError("Own PG readiness timed out")
        # Explicit current source, migrations, private synthetic database and broker.
        probe = (
            "import django,json,tempfile; django.setup(); "
            "from django.core.management import call_command; "
            "from django.db import connection; import redis; "
            "call_command('migrate',interactive=False,verbosity=0); call_command('check'); "
            "cursor=connection.cursor(); cursor.execute('select version(),current_database()'); "
            "row=cursor.fetchone(); "
            "assert row[1]=='capacity_ci'; "
            "assert redis.Redis(host='redis').ping(); "
            "f=tempfile.TemporaryFile(dir='/tmp'); f.write(b'synthetic-media'); f.seek(0); "
            "assert f.read()==b'synthetic-media'; f.close(); "
            "print(json.dumps({'postgres':row[0],'database':row[1],'redis_ping':True,"
            "'migrations_applied':True,'temporary_media_io':True,'django':django.get_version()}))"
        )
        run(["docker", "exec", app, str(ROOT / ".venv/bin/python3"), "-c", probe], "django-probe")
        report["result"] = "READY_NOT_CAPACITY"
    except Exception as exc:
        report["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        for name in reversed(containers):
            try:
                removal = run(["docker", "rm", "-fv", name], "remove-" + name, check=False)
                inventory = run(["docker", "ps", "-a", "--filter", f"name=^{name}$",
                                 "--format", "{{.Names}}"], "inventory-" + name, check=False)
                absent = inventory.returncode == 0 and not inventory.stdout.strip()
                report["cleanup"][name] = {"absent": absent, "removal_exit": removal.returncode}
                if not absent:
                    report["result"] = "ERROR"
            except Exception as exc:
                report["cleanup"][name] = {"error": str(exc)}
                report["result"] = "ERROR"
        if network_attempted:
            try:
                run(["docker", "network", "rm", network], "remove-network", check=False)
                inventory = run(["docker", "network", "ls", "--filter", f"name=^{network}$",
                                 "--format", "{{.Name}}"], "network-inventory", check=False)
                absent = inventory.returncode == 0 and not inventory.stdout.strip()
                report["cleanup"][network] = {"absent": absent}
                if not absent:
                    report["result"] = "ERROR"
            except Exception as exc:
                report["cleanup"][network] = {"error": str(exc)}
                report["result"] = "ERROR"
        report["sources_unchanged"] = hashes() == before
        if not report["sources_unchanged"]:
            report["result"] = "INVALID"
        (output / "report.json").write_text(json.dumps(report, indent=2))
    print(json.dumps({"result": report["result"], "evidence": str(output)}))
    return 0 if report["result"] == "READY_NOT_CAPACITY" else 1


if __name__ == "__main__":
    sys.exit(main())
