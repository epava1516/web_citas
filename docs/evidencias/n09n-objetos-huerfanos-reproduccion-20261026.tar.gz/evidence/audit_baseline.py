import hashlib,json,math,re,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n09-n-20261026');P=Path('artifacts/local-ci')/sys.argv[1]
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f,r,h=read(W/'baseline-freeze.json'),read(P/'result.json'),read(P/'source-hashes.json')
assert r['result']=='PASS' and r['sources_unchanged'] and r['selection']==f['selection'] and r['workers']==1
assert all(sha(p)==v for p,v in f['sources'].items())
assert set(f['sources'])-set(h)==set(f['sources_verified_separately'])
assert all(h[p]==v for p,v in f['sources'].items()if p in h)
cases=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==5
profiles=[];seen=set();containers=set();phase_count=removed_total=0
for c in cases:
 assert all(c.find(k)is None for k in ['failure','error','skipped'])
 props={p.get('name'):p.get('value')for p in c.iter('property')};d=json.loads(props['owned_orphan_object_profile']);assert d['status']=='passed'and d['cleanup']=='owned_bucket_absent_404'
 n,mode=d['N'],d['mode'];assert(mode,n)not in seen;seen.add((mode,n));assert d['live_references']==n+2
 assert d['bucket_initial_count']==2*n+4 and d['bucket_final_count']==n+4
 assert re.fullmatch('[0-9a-f]{64}',d['container_id']);containers.add(d['container_id'])
 assert d['cpu_limit']==0.5 and d['memory_bytes']==512*1024*1024 and d['data_tmpfs_bytes']==128*1024*1024
 if mode=='volume':names=['fresh','aged','aged_replay'];removed=[0,n,0];returns=removed;attempts=removed
 else:
  assert mode=='interrupted'and n==2
  names=['fresh','aged_interrupted','aged_recovery','aged_replay'];removed=[0,1,1,0];returns=[0,None,1,0];attempts=[0,2,1,0]
 phases=d['phases'];assert [p['phase']for p in phases]==names
 before=2*n+4;remaining=n
 for p,delete,result,attempt in zip(phases,removed,returns,attempts,strict=True):
  remaining-=delete
  assert p['result']==result and p['removed_count']==p['delete_successes']==delete and p['delete_attempts']==attempt
  assert p['bucket_before_count']==before and p['bucket_after_count']==before-delete;before-=delete
  assert p['remaining_orphans_count']==remaining
  assert p['survivors_before_sha256']==p['bucket_after_sha256']
  if delete==0:assert p['bucket_before_sha256']==p['bucket_after_sha256']
  assert p['row_before_sha256']==p['row_after_sha256']==d['row_state_sha256']
  assert p['media_before']==p['media_after']==d['media']
  assert p['retained_objects_exact']and p['sql_rows_preserved']and p['media_preserved']and p['live_readback']
  assert p['descriptor_count']==n+2 and p['sql_count']>=2 and p['listing_pages']==1
  # Counts represent objects returned in a page, not inner-loop candidates visited.
  assert p['listing_items']==p['bucket_before_count']-2
  assert all(math.isfinite(p[k])and p[k]>=0 for k in ['wall_seconds','sql_seconds','descriptor_seconds','listing_next_seconds','delete_seconds'])
  assert p['wall_seconds']>=max(p[k]for k in ['sql_seconds','descriptor_seconds','listing_next_seconds','delete_seconds'])
  if result is None:assert p['failure_class']=='OSError'
  removed_total+=delete;phase_count+=1
 assert remaining==0 and before==n+4
 assert abs(sum(p['wall_seconds']for p in phases)-d['measured_seconds'])<1e-8
 assert abs(d['case_seconds']-d['measured_seconds']-d['outside_task_seconds'])<1e-8
 assert d['case_seconds']>=d['measured_seconds']>=0
 profiles.append(d)
assert seen=={('volume',n)for n in [0,1,10,100]}|{('interrupted',2)}
assert phase_count==16 and removed_total==113 and len(containers)==1
for identifier in containers:
 result=subprocess.run(['docker','container','inspect','--format','{{.Id}}',identifier],capture_output=True,text=True)
 assert result.returncode!=0 and 'no such'in(result.stdout+result.stderr).lower()
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq']if kind=='container'else['docker',kind,'ls','-q']
 assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists()
tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_FIVE_FINITE_REAL_RUSTFS_ORPHAN_BASELINE_NOT_WHOLE_N09','run':P.name,'junit':r['junit'],'frozen_sources':len(f['sources']),'phases':phase_count,'physical_orphans_removed':removed_total,'object_fixture_containers_verified_absent':sorted(containers),'profiles':profiles,'cleanup_verified':True,'telegram':tg,'scope':'NativeTask.run/ownedPGactualRustFS/privatepercasebuckets/realLastModified/syntheticapp2days;noappchange/worker/Beat/provider/natural24h/hourly/largepackage/N1noafterp95SLA;19samefiles6oldscopedwitnesses;N09139open8of13.'}
(W/'baseline-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='profiles'}))
