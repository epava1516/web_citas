import hashlib,json,math,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n09-m-20261026');P=Path('artifacts/local-ci')/sys.argv[1]
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f,r,h=read(W/'baseline-freeze.json'),read(P/'result.json'),read(P/'source-hashes.json')
assert r['result']=='PASS' and r['sources_unchanged'] and r['selection']==f['selection'] and r['workers']==1
assert all(sha(p)==v for p,v in f['sources'].items())
assert set(f['sources'])-set(h)==set(f['sources_verified_separately'])
assert all(h[p]==v for p,v in f['sources'].items()if p in h)
cases=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==13
seen=set();profiles=[];phase_count=urgent_inserts=retention_inserts=retention_failed=retention_plans=changed_plans=0
for c in cases:
 assert all(c.find(k)is None for k in ['failure','error','skipped'])
 props={p.get('name'):p.get('value')for p in c.iter('property')};d=json.loads(props['owned_alert_retention_reconcile_profile']);assert d['status']=='passed'
 kind,mode,n=d['kind'],d['mode'],d['volume'];key=(kind,mode,n);assert key not in seen;seen.add(key);k=d['retained_purpose_count'];assert(k==0 if kind=='urgent'else k>=2)
 if mode=='volume':names=['first_batch']+(['second_batch']if n==101 else[])+['idempotent_replay'];selected=[min(n,100)]+([1]if n==101 else[])+[0]
 elif mode=='skip_locked':
  assert n==3
  names=['while_holder_active','after_release','idempotent_replay'];selected=[2,1,0]
  assert d['holder_pid']!=d['worker_pid'] and d['completed_while_holder_active'] and d['worker_connections_closed'] and d['thread_finished'] and d['holder_released']
 else:
  assert kind=='retention' and mode=='mixed' and n==3
  names=['first_batch','invalid_retry'];selected=[3,1]
 phases=d['phases'];assert [p['phase']for p in phases]==names
 previous=1 if kind=='urgent'else k+(1 if mode=='mixed'else 0)
 for p,s in zip(phases,selected,strict=True):
  invalid=1 if mode=='mixed'else 0
  inserts=s if kind=='urgent'else(2*k-1 if mode=='mixed' and p['phase']=='first_batch'else 0 if mode=='mixed'else s*k)
  changed=0 if kind=='urgent'else(1 if mode=='mixed' and p['phase']=='first_batch'else 0 if mode=='mixed'else s)
  parents=s-invalid
  assert p['selected_count']==s and p['invalid_selected_count']==invalid
  expected={'reconciled':s}if kind=='urgent'else{'plans':s,'scheduled':inserts,'failed':invalid}
  assert p['result']==expected and p['inserted_rows']==inserts and p['inserted_parent_count']==parents
  assert p['changed_plan_rows']==changed
  assert p['target_before_count']==previous and p['target_after_count']==previous+inserts;previous+=inserts
  assert p['preserved_target_sha256']==p['target_before_sha256']
  assert p['domain_before']==p['domain_after'] and p['media_before']==p['media_after']
  if kind=='urgent':
   assert p['plan_rows_count']==0 and p['report_rows_count']==n+2
   assert p['plan_immutable_before_sha256']is None and p['plan_immutable_after_sha256']is None
   urgent_inserts+=inserts
  else:
   assert p['plan_rows_count']==n+1 and p['report_rows_count']==0
   assert p['plan_immutable_before_sha256']==p['plan_immutable_after_sha256']
   retention_inserts+=inserts;retention_failed+=invalid;retention_plans+=s;changed_plans+=changed
  assert all(math.isfinite(p[x])and p[x]>=0 for x in ['wall_seconds','sql_seconds'])
  assert p['wall_seconds']>=p['sql_seconds']
  assert p['sql_count']==sum(x['count']for x in p['operations'].values())and p['sql_count']>=1
  assert 'DELETE'not in p['operations']
  phase_count+=1
 assert abs(sum(p['wall_seconds']for p in phases)-d['measured_seconds'])<1e-8
 assert abs(d['case_seconds']-d['measured_seconds']-d['setup_and_qa_seconds'])<1e-8
 assert d['case_seconds']>=d['setup_seconds']>=0
 profiles.append(d)
assert seen=={(kind,'volume',n)for kind in ['urgent','retention']for n in [0,1,10,100,101]}|{('urgent','skip_locked',3),('retention','skip_locked',3),('retention','mixed',3)}
assert phase_count==30 and urgent_inserts==215 and retention_failed==2 and retention_plans==219 and changed_plans==216
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq']if kind=='container'else['docker',kind,'ls','-q']
 assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists()
tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_THIRTEEN_FINITE_ALERT_RETENTION_BASELINE_NOT_WHOLE_N09','run':P.name,'junit':r['junit'],'frozen_sources':len(f['sources']),'phases':phase_count,'urgent_alerts_inserted':urgent_inserts,'retention_reviews_inserted':retention_inserts,'retention_plans_seen':retention_plans,'retention_failed_observations':retention_failed,'retention_plan_count_updates':changed_plans,'profiles':profiles,'cleanup_verified':True,'telegram':tg,'scope':'NativeTask.run/ownedPG/noappchange/worker/Beat/provider/humanreview/erasure. N1instrumented/noafter/p95/SLA;priority1/existingalerts/partialfollowuppins/domainmediaimmutable;actualPGskip2then1then0x2/mixedinvalidfailureagainexpected;N09139open8of13.'}
(W/'baseline-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='profiles'}))
