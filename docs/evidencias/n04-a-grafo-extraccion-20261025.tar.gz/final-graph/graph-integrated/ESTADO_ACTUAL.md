# Grafo alfa — N04A estudio de descubrimiento; N04 abierto

4/13 bloques aceptados N00/N01/N03/N06.394 estudia dos acciones (R_home/R_listing_detail), cinco familias y doce fuentes directas/dependencias declaradas idénticas a N01C/B16/actual. N01A/B/C y B16 conservan sus testigos finitos; no nueva prueba ni cambio de aplicación. Falta atribución de promoción/profundidad/selectividad por etapas en estado mantenido; perfiles históricos que fuerzan fallback no la sustituyen. Próximo N04B prerregistro antes de medir/candidato. N03 cerrado393 y costes residuales explícitos, sin optimización marginal; MOD09 restante al final. Sin capacidad/SLA/proveedor/apertura.

Semántica focal394/341/README/vista17 primeras4líneas: 2002fuentes,18943nodos/82042relaciones,905comunidades. Base preservada, no reconstrucción global ni semántica exhaustiva; no prueba independiente de runtime. Consumo nativo desconocido.

