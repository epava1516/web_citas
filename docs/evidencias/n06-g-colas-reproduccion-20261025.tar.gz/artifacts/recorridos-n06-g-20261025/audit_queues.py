import hashlib,json,math,statistics,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n06-g-20261025');run=sys.argv[1];P=Path('artifacts/local-ci')/run

def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError(k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=read(W/'freeze.json');r=read(P/'result.json');assert r['result']=='PASS' and r['sources_unchanged'];assert r['selection']==['tests/test_review_queue_growth_reference.py'] and r['workers']==1
assert len(r['junit'])==1 and r['junit'][0]['tests']=='8' and all(r['junit'][0][k]=='0' for k in ['errors','failures','skipped'])
mismatch=[p for p,h in f['sources'].items() if not Path(p).is_file() or sha(p)!=h];assert not mismatch,mismatch
rows=[];cases=[];samplekeys={'size','ordinal','wall_seconds','cpu_seconds','response_bytes','shown_count','sql_queries','sql_execute_seconds'}
for c in E.parse(P/'pytest.xml').iter('testcase'):
 assert not any(c.findall(k) for k in ['failure','error','skipped']);props={p.attrib['name']:p.attrib['value'] for p in c.iter('property')};d=json.loads(props['review_queue_samples']);assert len(d['samples'])==30 and len(d['authority_controls'])==16
 for size in [0,1,10,100,101]:
  samples=[s for s in d['samples'] if s['size']==size];assert [s['ordinal'] for s in samples]==list(range(6))
  for s in samples:
   assert set(s)==samplekeys and s['shown_count']==min(size,100)
   assert isinstance(s['sql_queries'],int) and s['sql_queries']>=0
   assert all(math.isfinite(s[k]) and s[k]>=0 for k in ['wall_seconds','cpu_seconds','sql_execute_seconds','response_bytes'])
  controls=[x for x in d['authority_controls'] if x['size']==size and x['kind']!='permission_revoked'];assert {(x['kind'],x['status']) for x in controls}=={('no_permission',403),('anonymous',302),('stale_mfa',302)}
  row={'kind':d['kind'],'language':d['language'],'size':size,'samples':samples}
  for k in ['wall_seconds','cpu_seconds','sql_execute_seconds','sql_queries','response_bytes']:
   vals=[s[k] for s in samples[1:]];row[k]={'first':samples[0][k],'median_later':statistics.median(vals),'range_later':[min(vals),max(vals)]}
  rows.append(row)
 assert d['authority_controls'][-1]=={'size':101,'kind':'permission_revoked','status':403}
 cases.append({'case':c.attrib['name'],'kind':d['kind'],'language':d['language'],'authority_controls':d['authority_controls'],'qa_seconds':float(c.attrib['time'])})
assert len(cases)==8 and len(rows)==40 and len({(c['kind'],c['language']) for c in cases})==8
inventory={}
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq'] if kind=='container' else ['docker',kind,'ls','-q'];q=subprocess.run(cmd+['--filter',f'label=web-modelos-local-ci-run={run}'],capture_output=True,text=True,check=True);inventory[kind]=q.stdout.split();assert not inventory[kind]
runner=read(P/'runner.json');assert not Path(runner['temporary']).exists();tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
query_growth=[]
for kind,language in sorted({(r['kind'],r['language']) for r in rows}):
 group=[r for r in rows if r['kind']==kind and r['language']==language];q={str(r['size']):r['sql_queries']['median_later'] for r in group};query_growth.append({'kind':kind,'language':language,'queries_by_size':q,'constant_median_nonempty':len({v for k,v in q.items() if k!='0'})==1})
out={'result':'PASS_N06G_SCOPED_REFERENCE_NOT_N06_CLOSURE','run':run,'junit':r['junit'],'junit_sha256':sha(P/'pytest.xml'),'head':f['head'],'source_count':len(f['sources']),'source_mismatches':mismatch,'cases':cases,'rows':rows,'measured_requests':240,'authority_controls':128,'query_growth':query_growth,'independent_inventory':inventory,'temporary_absent':True,'terminal_telegram':tg,'native_manifest':read(P/'native-manifest.json'),'steps':[{k:v for k,v in x.items() if k!='command'} for x in r['steps']],'scope':'Eight synthetic queue/language cases; incremental cohorts0/1/10/100/101 first+five, exact top100/closed exclusion/render links and guards. No app candidate,p95,provider or production capacity.'}
(W/'queues-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('AUDITED',run);print('QUERIES',query_growth)
for r in rows:
 if r['size'] in (1,100,101):print(r['kind'],r['language'],r['size'],r['sql_queries']['median_later'],round(1000*r['wall_seconds']['median_later'],3))
