import hashlib,json,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
W=Path('artifacts/recorridos-n09-i-20261026');P=Path('artifacts/local-ci')/sys.argv[1]
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f,r,h=read(W/'baseline-freeze.json'),read(P/'result.json'),read(P/'source-hashes.json')
assert r['result']=='PASS'and r['sources_unchanged']and r['selection']==f['selection']
assert all(sha(p)==v for p,v in f['sources'].items())
assert set(f['sources'])-set(h)==set(f['sources_verified_separately'])
assert all(h[p]==v for p,v in f['sources'].items()if p in h)
cases=list(E.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==6
profiles=[];seen=set()
for c in cases:
 assert all(c.find(k)is None for k in ['failure','error','skipped'])
 props={x.get('name'):x.get('value')for x in c.iter('property')};d=json.loads(props['owned_logical_purge_profile']);assert d['status']=='passed'
 skip=bool(d.get('held_row_lock_acquired'));n=d['expired_count'];assert(n,skip)not in seen;seen.add((n,skip))
 assert d['expired_count_confirmed']==n and d['target_row_count']==n+2
 assert d['other_tables_before']==d['other_tables_after']and d['files_before']==d['files_after']
 assert d['immutable_before_sha256']==d['immutable_after_sha256']and d['pins_before_sha256']==d['pins_after_sha256']
 phases=d['phases'];counts=[x['returned_count']for x in phases]
 expected=[2,1,0]if skip else[100,1,0]if n==101 else[n,0];assert counts==expected
 names=['skip_locked_first_batch','after_holder_release','idempotent_replay']if skip else['first_batch','second_batch','idempotent_replay']if n==101 else['first_batch','idempotent_replay'];assert[x['phase']for x in phases]==names
 for p in phases:
  assert p['wall_seconds']>=p['sql_seconds']>=0 and p['sql_count']==sum(x['count']for x in p['operations'].values())
  assert p['sql_count']>=1 and p['operations'].get('SELECT',{}).get('count',0)>=1
  assert p['operations'].get('UPDATE',{}).get('count',0)==int(p['returned_count']>0)
  assert not({'INSERT','DELETE'}&set(p['operations']))
 assert abs(sum(p['wall_seconds']for p in phases)-d['measured_purge_seconds'])<1e-8
 assert abs(d['case_body_seconds']-d['measured_purge_seconds']-d['non_measured_case_seconds'])<1e-8
 assert d['case_body_seconds']>=d['pre_measurement_seconds']>=0
 if skip:assert d['holder_pid']!=d['worker_pid']and d['worker_completed_while_holder_active']and d['holder_released']and d['thread_finished']and d['worker_connections_closed']
 else:
  if n==0:assert d['target_rows_before_sha256']==d['target_rows_after_sha256']
 profiles.append(d)
assert seen=={(n,False)for n in[0,1,10,100,101]}|{(3,True)}
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq']if kind=='container'else['docker',kind,'ls','-q']
 assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists()
tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
out={'result':'PASS_SIX_FINITE_LOGICAL_PURGE_BASELINE_NOT_WHOLE_N09','run':P.name,'junit':r['junit'],'frozen_sources':len(f['sources']),'profiles':profiles,'cleanup_verified':True,'telegram':tg,'scope':'CopyInformationtask.runonly/N1instrumentedphase/0to101expiredplus2pins/skip3. Nativebase+syntheticretainedmetadata volume. Noappchange/noafter/othermodellatency/HTTPworkerBeatproviderproof.25oldpurgewitnessesseparatereuse,notnewruns/N09full139open8of13.'}
(W/'baseline-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k!='profiles'}))
