from pathlib import Path
import json,hashlib
W=Path('artifacts/recorridos-n04-a-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(xs):
  d={}
  for k,v in xs:
   assert k not in d;d[k]=v
  return d
 return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
r=read(W/'inventory-review.json');assert r['STATUS']=='complete'
for k in ['FILES_CHANGED','TESTS_RUN','ASSUMPTIONS','RISKS','UNRESOLVED_ISSUES','RECOMMENDATIONS']:assert isinstance(r[k],list)
for k in ['IMPLEMENTATION_NOTES','TEST_RESULTS']:assert isinstance(r[k],str)
citations=[]
def walk(x):
 if isinstance(x,dict):
  if {'file','sha256','quote','line_start','line_end'}<=set(x):citations.append(x)
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(r)
for c in citations:
 assert sha(c['file'])==c['sha256'],c['file']
 lines=Path(c['file']).read_text().splitlines();assert 1<=c['line_start']<=c['line_end']<=len(lines)
 assert c['quote'] in '\n'.join(lines[c['line_start']-1:c['line_end']]),c['file']
b16=read('docs/evidencias/b16-final-candidate-reconciliation-20261025.json')['current_versioned_executable_sources']
freezes={v:read(p)['product_sha256'] for v,p in [('N01A','artifacts/recorridos-n01-20261025/freeze.json'),('N01B','artifacts/recorridos-n01-b-20261025/freeze.json'),('N01C','artifacts/recorridos-n01-c-20261025/freeze.json')]}
for b in r['source_bridges']:
 p=b['file'];h=sha(p);assert h==b['current_sha256']==b['B16_sha256']==b16[p]
 for n in b['N01_bridges']:assert h==n['frozen_sha256']==freezes[n['version']][p]
actions=read('docs/evidencias/n00-matriz-acciones-prioridades-20261025.json')['actions'];expected={a['id'] for a in actions if 'N04'in a['blocks']};assert expected=={a['id'] for a in r['action_dispositions']}=={'route:R_home','route:R_listing_detail'}
out={'result':'N04_NATIVE_REVIEW_SCHEMA_CITATIONS_SOURCES_VERIFIED_NOT_BLOCK_ACCEPTANCE','actions':sorted(expected),'source_bridges':len(r['source_bridges']),'citations':len(citations),'native_tokens':None,'limits':'No new execution, source identity and sampling study only; next scenario preregistration/measurement and block acta pending.'};(W/'review-verification.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
