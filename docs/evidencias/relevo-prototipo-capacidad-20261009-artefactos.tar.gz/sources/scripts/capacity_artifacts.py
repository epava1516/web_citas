"""Finite private artifact writes; kernel file ceiling is applied by the controller."""

import os
from pathlib import Path

MAX_FILE_BYTES = 32 * 1024 ** 2
MAX_FILES = 100


def write_artifact(directory, name, text):
    directory = Path(directory)
    if not name or Path(name).name != name or name in {".", ".."}:
        raise ValueError("Artifact must have a single local filename")
    destination = directory / name
    if destination.is_symlink():
        raise ValueError("Artifact must not follow a symlink")
    data = text.encode("utf-8")
    if len(data) > MAX_FILE_BYTES:
        raise ValueError("Artifact exceeds the declared file ceiling")
    if not destination.exists() and sum(1 for _ in directory.iterdir()) >= MAX_FILES:
        raise ValueError("Artifact count exceeds the declared ceiling")
    descriptor = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
