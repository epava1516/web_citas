"""Launch the capacity controller under real Docker quotas, with owned durable output."""

import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path

from run_local_ci import hashes

ROOT = Path(__file__).resolve().parents[1]
MIB = 1024 ** 2


def host_tools():
    programs = {name: Path(shutil.which(name)).resolve() for name in ["docker", "git"]}
    libraries = {}
    for program in programs.values():
        result = subprocess.run(["ldd", str(program)], capture_output=True, text=True, check=True)
        for line in result.stdout.splitlines():
            parts = line.split()
            if len(parts) >= 3 and parts[1] == "=>" and parts[2].startswith("/"):
                libraries[parts[0]] = Path(parts[2]).resolve()
            elif parts and parts[0].startswith("/"):
                libraries[Path(parts[0]).name] = Path(parts[0]).resolve()
    loader = next(name for name in libraries if name.startswith("ld-linux"))
    return programs, libraries, loader


def main():
    run_id = time.strftime("%Y%m%d-%H%M%S", time.gmtime()) + "-" + uuid.uuid4().hex[:8]
    name = "web-modelos-capacity-" + run_id + "-controller"
    output = ROOT / "artifacts/capacity-environment" / run_id
    output.mkdir(parents=True)
    before = hashes()
    programs, libraries, loader = host_tools()
    python_root = Path.home() / ".local/share/uv/python"
    socket = Path("/var/run/docker.sock")
    bootstrap = f"""
import os, resource, runpy, sys
from pathlib import Path
root = Path({str(ROOT)!r})
tools = Path('/tmp/tools')
tools.mkdir()
loader = '/opt/host-tools/lib/{loader}'
for tool in ['docker', 'git']:
    wrapper = '#!/bin/sh\\nexec ' + loader + ' --library-path /opt/host-tools/lib /opt/host-tools/native/' + tool + ' "$@"\\n'
    (tools / tool).write_text(wrapper)
    (tools / tool).chmod(0o755)
os.environ['PATH'] = str(tools) + ':' + os.environ['PATH']
resource.setrlimit(resource.RLIMIT_FSIZE, (33554432, 33554432))
sys.path.insert(0, str(root / 'scripts'))
sys.argv = [str(root / 'scripts/check_capacity_environment.py'), '--owned-controller', *{sys.argv[1:]!r}]
runpy.run_path(sys.argv[0], run_name='__main__')
"""
    command = [
        str(programs["docker"]), "--host", "unix:///var/run/docker.sock", "run", "--pull=never",
        "--rm", "--sig-proxy=false", "--name", name, "--network", "none",
        "--read-only", "--cap-drop=ALL", "--security-opt=no-new-privileges",
        "--user", f"{os.getuid()}:{os.getgid()}", "--group-add", str(socket.stat().st_gid),
        "--cpus", "0.05", "--memory", str(128 * MIB), "--memory-swap", str(128 * MIB),
        "--pids-limit", "128", "--log-driver", "none", "--workdir", str(ROOT),
        "--mount", f"type=bind,src={ROOT},dst={ROOT},readonly",
        "--mount", f"type=bind,src={output},dst={output}",
        "--mount", f"type=bind,src={python_root},dst={python_root},readonly",
        "--mount", "type=bind,src=/var/run/docker.sock,dst=/var/run/docker.sock,readonly",
        "--tmpfs", f"/tmp:size=67108864,uid={os.getuid()},gid={os.getgid()}",
        "-e", "PYTHONDONTWRITEBYTECODE=1", "-e", f"HOME={Path.home()}",
        "-e", f"CAPACITY_RUN_ID={run_id}", "-e", f"CAPACITY_CONTROLLER_NAME={name}",
    ]
    mounts = {f"native/{key}": path for key, path in programs.items()}
    mounts.update({f"lib/{key}": path for key, path in libraries.items()})
    for target, source in mounts.items():
        command += ["--mount", f"type=bind,src={source},dst=/opt/host-tools/{target},readonly"]
    command += ["--entrypoint", str(ROOT / ".venv/bin/python3"), "web-modelos-app:latest", "-c", bootstrap]
    report = {"id": run_id, "controller": name, "command": command,
              "scope": "Owned controller and all its CLI children constrained; host Docker bootstrap/"
                       "terminal collection and shared OS/daemon are infrastructure outside timed workload.",
              "tools": {target: {"path": str(source), "sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                                  "bytes": source.stat().st_size} for target, source in mounts.items()}}
    print(f"owned-controller — {output}", flush=True)
    try:
        with (output / "controller.log").open("w") as log:
            process = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                                     timeout=11500, check=False)
        report["exit"] = process.returncode
    finally:
        report["cleanup"] = {}
        for suffix in ["controller", "app", "redis", "pg"]:
            owned = "web-modelos-capacity-" + run_id + "-" + suffix
            subprocess.run([str(programs["docker"]), "rm", "-fv", owned], capture_output=True)
            inventory = subprocess.run([str(programs["docker"]), "ps", "-a", "--filter",
                f"name=^/{owned}$", "--format", "{{.Names}}"], capture_output=True, text=True)
            report["cleanup"][owned] = inventory.returncode == 0 and not inventory.stdout.strip()
        network = "web-modelos-capacity-" + run_id + "-net"
        subprocess.run([str(programs["docker"]), "network", "rm", network], capture_output=True)
        inventory = subprocess.run([str(programs["docker"]), "network", "ls", "--filter",
                                   f"name=^{network}$", "--format", "{{.Name}}"], capture_output=True, text=True)
        report["cleanup"][network] = inventory.returncode == 0 and not inventory.stdout.strip()
        report["sources_unchanged"] = hashes() == before
        (output / "launcher.json").write_text(json.dumps(report, indent=2) + "\n")
    result = json.loads((output / "report.json").read_text()) if (output / "report.json").exists() else {}
    success = report.get("exit") == 0 and report["sources_unchanged"] and all(report["cleanup"].values())
    print(json.dumps({"result": result.get("result", "INVALID_CONTROLLER_NO_REPORT"),
                      "cleanup_verified": all(report["cleanup"].values()), "evidence": str(output)}))
    return 0 if success else 1


if __name__ == "__main__":
    raise SystemExit(main())
