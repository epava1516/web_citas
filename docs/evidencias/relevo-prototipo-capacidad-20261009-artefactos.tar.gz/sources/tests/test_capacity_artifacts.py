"""Real bounded artifact writes reject byte/count overflow and foreign targets."""

import pytest

from scripts import capacity_artifacts as artifacts


def test_artifact_limits_count_utf8_bytes_and_allow_replacing_owned_file(tmp_path, monkeypatch):
    monkeypatch.setattr(artifacts, "MAX_FILE_BYTES", 4)
    monkeypatch.setattr(artifacts, "MAX_FILES", 2)
    artifacts.write_artifact(tmp_path, "a", "éé")
    artifacts.write_artifact(tmp_path, "b", "next")
    artifacts.write_artifact(tmp_path, "a", "same")
    assert (tmp_path / "a").read_bytes() == b"same"
    with pytest.raises(ValueError, match="file ceiling"):
        artifacts.write_artifact(tmp_path, "a", "ééé")
    with pytest.raises(ValueError, match="count"):
        artifacts.write_artifact(tmp_path, "c", "x")
    assert (tmp_path / "a").read_bytes() == b"same" and not (tmp_path / "c").exists()


@pytest.mark.parametrize("name", ["../foreign", "/tmp/foreign", "sub/file", "", ".", ".."])
def test_artifact_cannot_escape_owned_directory(tmp_path, name):
    with pytest.raises(ValueError, match="filename"):
        artifacts.write_artifact(tmp_path, name, "x")


def test_artifact_does_not_follow_existing_symlink(tmp_path):
    foreign = tmp_path / "foreign"
    foreign.write_text("preserve")
    (tmp_path / "link").symlink_to(foreign)
    with pytest.raises(ValueError, match="symlink"):
        artifacts.write_artifact(tmp_path, "link", "replace")
    assert foreign.read_text() == "preserve"
