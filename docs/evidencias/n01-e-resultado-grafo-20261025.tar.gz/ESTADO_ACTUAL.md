# Grafo alfa — resultado operativo N01E

Contrato340/341:N00aceptado1/13,N01abierto. N01D11PASS109HTTP;N01E4PASS18servicio,0/10/100PublicationDirty,50SQLcada llamada,techo técnico<=50para escenario exacto,sinSLOpared ni optimización.352concilia19fichas/93citas,seisbasesHTTPparciales;modalidades/presupuestosfaltantes siguen pendientes.

Refresco focal de353/README/vista17líneas1–4 con semántica nativa literal ySHA;ASTprevio preservado. No reconstrucción completa ni semántica exhaustiva. 1944fuentes,18150nodos/80237relaciones,861comunidades; membresías previas preservadas más comunidad documental.1506fuentes ejecutables originales intactas,runner instrumental variante explícita. Consumo nativo desconocido;ceros técnicos no significan coste cero. JSONcompleto,HTMLsólo comunidades;100anotaciones ambiguas previas conservadas. Relaciones estáticas no prueban runtime;exclusiones previas preservadas.

