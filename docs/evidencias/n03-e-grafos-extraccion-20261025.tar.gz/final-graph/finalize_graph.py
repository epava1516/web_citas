"""Export scoped contract-preparation graph, with an explicit historical baseline."""
import collections,hashlib,json
from pathlib import Path
import networkx as nx
from graphify.analyze import god_nodes,surprising_connections,suggest_questions
from graphify.cluster import score_all
from graphify.report import generate
from graphify.export import to_html
W=Path('artifacts/recorridos-n03-e-20261025/final-graph');S=W/'graph-integrated';data=json.loads((S/'graph.json').read_text())
G=nx.MultiDiGraph()
for n in data['nodes']:G.add_node(n['id'],**{k:v for k,v in n.items() if k!='id'})
for e in data['links']:G.add_edge(e['source'],e['target'],**{k:v for k,v in e.items() if k not in ('source','target','key')})
H=nx.Graph();H.add_nodes_from(G.nodes(data=True))
for a,b,d in G.edges(data=True):
 if H.has_edge(a,b):H[a][b]['weight']+=float(d.get('weight',1))
 else:H.add_edge(a,b,weight=float(d.get('weight',1)))
communities={int(k):v for k,v in json.loads((S/'.graphify_analysis.json').read_text())['communities'].items()};labels={int(k):v for k,v in json.loads((S/'.graphify_labels.json').read_text()).items()}
cohesion=score_all(H,communities);gods=god_nodes(H);surprises=surprising_connections(H,communities);questions=suggest_questions(H,communities,labels)
(S/'.graphify_analysis.json').write_text(json.dumps({'communities':communities,'cohesion':cohesion,'gods':gods,'surprises':surprises,'questions':questions},ensure_ascii=False))
manifest=json.loads((S/'SOURCE_MANIFEST.json').read_text());proof=json.loads((W/'semantic-integration.json').read_text())
scope=f"""# Grafo alfa — N03E worker y Beat reales verificados; N03 abierto

3/13bloques aceptados,N03abierto.387real1PASS/sinappchange:workerprefork2+Beatnativo60s,A3retryFileNotFoundconesperas1/2/3s,BValidationErrorsinretry,cohorte4recuperada/controlesintactos.101eventos38exec/1744huellas/roles/PIDs/credenciales/recursosretirados/TGsent. Primertick61,504s/pub→readyobservado1,150s,noSLA/intervalosglobales. Nomáximoglobaldeintentos ni kill/redelivery/mapeorawargsafirmados;conciliaciónN03FpendienteN03N07. MOD09diferido,sinoptimizaciónmarginaldetector.

Semánticafocal387/341/README/vista17primeras4líneas,ASTinstrumentos:{len(manifest)}fuentes,{G.number_of_nodes()}nodos/{G.number_of_edges()}relaciones,{len(communities)}comunidades.1501originales+6variantesdearchivoexistentes,appintactadesde553253c. Tokensnativosdesconocidos,no reconstrucciónglobal/semánticaexhaustivani pruebaindependiente delruntime.

"""

report=generate(H,communities,cohesion,labels,gods,surprises,{'total_files':len(manifest),'files':{},'total_words':0},{'input':0,'output':0},str(Path.cwd()),suggested_questions=questions)
(S/'GRAPH_REPORT.md').write_text(scope+report);(S/'ESTADO_ACTUAL.md').write_text(scope)
C=nx.DiGraph();membership={i:c for c,v in communities.items() for i in v}
for c,v in communities.items():C.add_node('community_'+str(c),label=labels[c],file_type='concept',source_file=None,member_count=len(v))
for a,b,d in G.edges(data=True):
 c,f=membership[a],membership[b]
 if c==f:continue
 a,b='community_'+str(c),'community_'+str(f)
 if not C.has_edge(a,b):C.add_edge(a,b,weight=0.0,relation='community_relations',relation_count=0)
 C[a][b]['weight']+=float(d.get('weight',1));C[a][b]['relation_count']+=1
assert to_html(C,{c:['community_'+str(c)] for c in communities},str(S/'graph.html'),community_labels=labels,member_counts={c:len(v) for c,v in communities.items()})
policy=json.loads((S/'CORPUS_POLICY.json').read_text());history=policy.get('semantic_delta_history',[]);history.append(proof)
policy.update(build_kind='scoped_native_semantic_N03E_result_on_preserved_base',selected_files=sorted(manifest),latest_delta=proof,semantic_delta_history=history,section_views={'docs/17-seguimiento-desarrollo.md':'lines1-4_only'},visualization_scope=f'{len(communities)}communityprojection; fullJSON',native_token_usage=None)
policy['exclusions']=[r for r in policy['exclusions'] if r['path'] not in manifest]
(S/'CORPUS_POLICY.json').write_text(json.dumps(policy,indent=2))
health={'nodes':G.number_of_nodes(),'relations':G.number_of_edges(),'communities':len(communities),'source_files':len(manifest),'missing_endpoints':0,'dangling_endpoints':0,'duplicate_ids':0,'self_loops':nx.number_of_selfloops(G),'parallel_relations_preserved':G.number_of_edges()-len(set(G.edges())),'unresolved_reference_nodes':sum(n.get('external',False) for _,n in G.nodes(data=True)),'latest_refresh':'targeted_native_N03E_result','semantic_relation_exhaustiveness':False,'native_token_usage':None}
(S/'GRAPH_HEALTH.json').write_text(json.dumps(health,indent=2));(S/'ESTADO_ACTUAL.json').write_text(json.dumps({'phase':'alpha','previous_contract':'closed_local_acta23','previous_locally_accepted':15,'previous_roadmap_total':18,'next_contract':'340N00_N01_N06accepted_N02deferred','next_roadmap':'341','next_mandatory_accepted':3,'next_mandatory_total':13,'next_conditioned':['N12','N13','N14'],'technical_execution_started':True,'pending':['N02_remaining_optimization_deferred_by_user_to_development_end','N03_contract_action_conciliation_pending','N04','N05','N07','N08','N09','N10','N11','N15'],'active_implementation_goal_created':True,**health},indent=2))
pair=collections.Counter()
for e in data['links']:
 p=(e['source'],e['target']);e['key']=pair[p];pair[p]+=1
(S/'graph.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
(S/'CURRENT_OUTPUTS.json').write_text(json.dumps({'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in S.iterdir() if p.is_file() and p.name not in ('CURRENT_OUTPUTS.json','GRAPH_VERIFICATION.json')},'original_rebuild_base_commit':data['built_at_commit'],'latest_document_base_commit':'553253c','source_identity':'Exact SOURCE_MANIFEST hashes; N03E result387 and instrument AST current; app unchanged from553253c; source-specific provenance retained.'},indent=2))
print(json.dumps(health))
