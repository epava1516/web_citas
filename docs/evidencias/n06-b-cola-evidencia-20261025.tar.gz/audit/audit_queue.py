"""Audit exact queued reference artifacts, source freeze and task correlation."""
import hashlib,json,math,sys
from pathlib import Path
from uuid import UUID
from xml.etree import ElementTree as ET
w=Path('artifacts/recorridos-n06-b-20261025');run=Path(sys.argv[1]);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def finite(v):return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and v>=0
r=read(run/'result.json');assert r['result']=='PASS' and r['sources_unchanged'];assert all(v['absent'] for v in r['cleanup'].values());assert read(run/'telegram-notification.json')['delivery']=='sent'
f=read(w/'freeze.json')
for p,h in f['sha256'].items():assert sha(p)==h,p
cases=ET.parse(run/'pytest.xml').findall('.//testcase');assert len(cases)==2
outcomes=[];artifact_files=[run/'result.json',run/'pytest.xml',run/'source-hashes.json',w/'freeze.json'];tasks={'apps.mediafiles.tasks.process_blob','apps.listings.tasks.refresh_publication_state'}
for c in cases:
 assert not any(c.find(k) is not None for k in ['failure','error','skipped'])
 props={p.attrib['name']:p.attrib['value'] for p in c.findall('./properties/property')};report=json.loads(props['n06b_queued_baseline']);case=report['case'];assert case in ('approved','rejected_correction')
 raw_report=run/('n06b-runtime-'+case+'.json');assert read(raw_report)==report;artifact_files.append(raw_report)
 assert report['worker_exit_code']==0 and report['worker_root_exited'] and report['runtime_role_removed'] and report['private_credentials_removed']
 assert report['foreign_keys_preserved'] and report['unexpected_unscoped_keys']==0
 assert len(report['processes_absent'])>=3 and all(report['processes_absent'].values());assert set(report['pid_start_ticks'])==set(report['processes_absent'])
 publisher=run/('n06b-publishes-'+case+'.json');pubs=read(publisher);artifact_files.append(publisher);published={p['id']:p for p in pubs};assert len(published)==len(pubs)
 for p in pubs:assert UUID(p['id']) and p['task'] in tasks and finite(p['monotonic'])
 events=[]
 for p in (run/('n06b-events-'+case)).glob('*.jsonl'):
  data=p.read_bytes();assert data.endswith(b'\n') and len(data)<=2*1024*1024;events.extend(json.loads(line) for line in data.splitlines());artifact_files.append(p)
 executions={e['id']:e for e in events if e['event']=='execution'};assert executions
 for e in executions.values():
  assert e['state']=='SUCCESS' and e['eager'] is False and e['role']=='worker' and e['task'] in tasks
  assert str(e['pid']) in report['processes_absent'] and 'snapshot_error' not in e
  assert all(finite(e[k]) for k in ('start_monotonic','end_monotonic','wall','thread_cpu'))
  assert math.isclose(e['wall'],e['end_monotonic']-e['start_monotonic'],abs_tol=1e-8)
 assert set(published)<=executions.keys()
 assert len(report['samples'])==(1 if case=='approved' else 2)
 for ordinal,s in enumerate(report['samples'],1):
  assert s['case']==case and s['ordinal']==ordinal and s['status']==302 and s['task_always_eager'] is False
  assert finite(s['request_seconds_instrumented']) and finite(s['after_request_ready_seconds'])
  assert s['sql_queries']==sum(v['sql_queries'] for v in s['stages'].values())>0
  assert set(s['stages'])<= {'create_draft','manager_authority','request_other'}
  for stage in s['stages'].values():assert stage['sql_queries']>0 and finite(stage['sql_execute_seconds'])
  assert {t['task'] for t in s['task_ledger']}==tasks and s['active_photo_count']==1
  for t in s['task_ledger']:
   p=published[t['task_id']];e=executions[t['task_id']]
   assert t['task']==p['task']==e['task'] and t['worker_pid']==e['pid']
   assert t['state']=='SUCCESS' and t['eager'] is False and t['publish_monotonic']==p['monotonic']
   assert t['worker_start_monotonic']==e['start_monotonic'] and t['worker_end_monotonic']==e['end_monotonic']
   assert finite(t['publish_to_start_seconds']) and finite(t['worker_wall_seconds'])
   assert math.isclose(t['publish_to_start_seconds'],e['start_monotonic']-p['monotonic'],abs_tol=1e-8)
   assert t['worker_wall_seconds']==e['wall']
 outcomes.append(report)
assert {o['case'] for o in outcomes}=={'approved','rejected_correction'}
a={'result':'PASS_N06B_REAL_QUEUE_REFERENCE','run':str(run),'cases':2,'start_samples':3,'outcomes':outcomes,'source_freeze_unchanged':True,'owned_resources_absent':True,'terminal_telegram':'sent','pytest_command_seconds':next(s['seconds'] for s in r['steps'] if s['name']=='pytest'),'scope':'Real owned Redis/prefork2 restricted runtime and Client request; no Beat/TCP/capacity or causal code speedup. Preparation and post-request observed readiness separate.','sha256':{str(p):sha(p) for p in artifact_files}}
(w/'queue-audit.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps({k:v for k,v in a.items() if k not in ('outcomes','sha256')}))
for o in outcomes:
 for s in o['samples']:print(json.dumps({'case':o['case'],'ordinal':s['ordinal'],'request_ms':s['request_seconds_instrumented']*1000,'observed_after_request_ready_ms':s['after_request_ready_seconds']*1000,'sql':s['sql_queries'],'tasks':s['task_ledger']}))
