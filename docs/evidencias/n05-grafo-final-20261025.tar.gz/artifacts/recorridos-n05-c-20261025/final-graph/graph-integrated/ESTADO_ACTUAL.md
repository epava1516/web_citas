# Grafo alfa — N05 aceptado localmente; N07 siguiente

6/13 bloques aceptados N00/N01/N03/N04/N05/N06.399 concilia137IDs(5rutas129plantillas3JS)/138fuentes,152+6citas ymuestreo explícito,sin137PASSindividuales. B4PASS133,659sprivado/sondeos yC6PASS110,320sgalería/teclado156SEPARADOS,nodiezcasosintegrados. Galería1/11110inicial8/135824complete/8hashdimidénticos155/paused404,18focusobs;privado9344WebP/API/denegaciones;poll4XHR/lang3,07–3,15s/quiet6,506/noJS0. Eager/dispatchstub/transicionescontroladas explícitos,sinworker/generación/proveedor/p95/LCP/WCAGglobal/apertura. PrimeraB3PASS1FAILobservadorpreservada,causaexactanoconfirmada. Sinappchange/candidate/optimizaciónforzada,otrosdueñosretenidos,MOD09alfinal. N07siguiente,N06yaaceptado377.

Refresco semántico399/341/README/vista17primeras4líneas,ASTvigentepreservado: 2009fuentes,19079nodos/82391relaciones,913comunidades. Base preservada,no reconstrucción global/semánticaexhaustiva,consumonativodesconocido. Grafo documental no sustituye evidencia runtime independiente.

