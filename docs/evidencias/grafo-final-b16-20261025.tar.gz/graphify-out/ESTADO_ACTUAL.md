# Grafo final reconstruido desde cero — alfa

Corpus:1922fuentes únicas;1371entradas ASTGraphify más núcleoCython parseado con3.0.12;551fuentes semánticas, incluidas configuraciones y plantillas. Cython participa en ambas capas.28lotes nativos leídos y conciliados;6606declaracionesPython y sus padres comprobados. No nodos/aristas/caché del grafo anterior reutilizados.

Seguimiento17: sólo vista de líneas1–6, con la precedencia de su encabezado vigente y las entradas previas conservadas como antecedentes. Cronología17-historial-desarrollo, carpeta17-historial, evidencias masivas,artifacts,medios,vendor ymetadatos de agentes excluidos expresamente. Documentos de hitos fechados del repositorio sí se leen, sin convertirlos en estado actual o navegación remota.976citas fuera del corpus conservan registro sin crédito de lectura del destino.

El grafo no acredita PASS, seguridad, legalidad, proveedores o producción. Semántica selectiva por fuentes completas, no todas las relaciones posibles. Consumo nativo no disponible; los ceros técnicos del generador inferior no significan coste cero. Referencias estáticas no son bindings runtime; las expresiones inciertas y colisiones se declaran. MultiDiGraph conserva relaciones paralelas; proyección ponderada simple sólo para comunidades/análisis.

141autorreferencias se distinguen:39recursiones de nombre directo en fuente estática,94anotaciones de llamada no resuelta,6anotaciones de base no resuelta y2citas. Las100anotaciones no son dependencias a sí mismo ni defectos de aplicación.194referencias externas/noresueltas se materializan sin inventar implementación. Las colisiones de declaración y de documentos input/lock están conciliadas con sus originales negativos preservados.

Etiquetas españolas derivadas de resúmenes frescos: navegación temática, no aceptación de sistemas. Comunidades recalculadas sobre topología nueva; la clasificación posterior de autorreferencias cambia atributos, no extremos ni pesos. El proyecto sigue enalfa;B16aceptado localmente, contrato aún pendiente del inventario diferencial yacta final.

