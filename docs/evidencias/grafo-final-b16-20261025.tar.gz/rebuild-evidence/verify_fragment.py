"""Independently check a fresh native fragment against assigned source bytes."""
import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path

work = Path(__file__).resolve().parent
chunk = int(sys.argv[1])
fragment = Path(sys.argv[2])
assigned = json.loads((work / f"chunk-{chunk:02d}-files.json").read_text())
data = json.loads(fragment.read_text())
errors = []
texts = {p: Path(p).read_text() for p in assigned}
coverage = data.get("coverage", [])
if {c.get("source_file") for c in coverage} != set(assigned) or len(coverage) != len(assigned):
    errors.append("coverage_set_or_count")
for row in coverage:
    source = row.get("source_file")
    if source not in texts:
        continue
    if row.get("read_complete") is not True:
        errors.append(f"incomplete:{source}")
    if row.get("sha256") != hashlib.sha256(Path(source).read_bytes()).hexdigest():
        errors.append(f"source_hash:{source}")
nodes = data.get("nodes", [])
counts = Counter(n.get("id") for n in nodes)
errors.extend(f"duplicate_node:{key}" for key, count in counts.items() if count > 1)
for node in nodes:
    if not re.fullmatch(r"[a-z0-9_]+", node.get("id", "")):
        errors.append(f"invalid_id:{node.get('id')}")
    if node.get("source_file") not in texts:
        errors.append(f"node_source:{node.get('id')}")
    if node.get("file_type") not in {"code", "document", "paper", "image", "rationale", "concept"}:
        errors.append(f"node_type:{node.get('id')}")
for number, edge in enumerate(data.get("edges", [])):
    if edge.get("source") not in counts or edge.get("target") not in counts:
        errors.append(f"edge_endpoint:{number}")
    source = edge.get("source_file")
    evidence = edge.get("evidence")
    if source not in texts or not isinstance(evidence, str) or not evidence or evidence not in texts.get(source, ""):
        errors.append(f"edge_literal:{number}")
        continue
    location = str(edge.get("source_location", ""))
    match = re.search(r"(?:L|:)(\d+)(?:[-:]\d+)?$", location)
    if not match:
        errors.append(f"edge_location_format:{number}")
    else:
        start = int(match.group(1))
        lines = texts[source].splitlines()
        # Multi-line literal evidence must begin on the declared line.
        if start < 1 or evidence not in "\n".join(lines[start - 1:start - 1 + evidence.count('\n') + 1]):
            errors.append(f"edge_location_evidence:{number}")
    confidence, score = edge.get("confidence"), edge.get("confidence_score")
    if confidence == "EXTRACTED" and score != 1.0:
        errors.append(f"confidence:{number}")
    elif confidence == "INFERRED" and score not in {.95, .85, .75, .65, .55}:
        errors.append(f"confidence:{number}")
    elif confidence == "AMBIGUOUS" and not (isinstance(score, (int, float)) and .1 <= score <= .3):
        errors.append(f"confidence:{number}")
    elif confidence not in {"EXTRACTED", "INFERRED", "AMBIGUOUS"}:
        errors.append(f"confidence:{number}")
result = {"chunk": chunk, "state": "VERIFIED_LITERAL_SCOPE_NOT_GLOBAL_SEMANTIC_PROOF" if not errors else "REJECTED_REQUIRES_CORRECTION", "sources": len(assigned), "nodes": len(nodes), "edges": len(data.get("edges", [])), "errors": errors, "fragment_sha256": hashlib.sha256(fragment.read_bytes()).hexdigest(), "limits": "Literal citations, source identities and structure checked; extracted semantics still require parent review, not a runtime proof."}
(work / f"chunk-{chunk:02d}-verification.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
raise SystemExit(bool(errors))
