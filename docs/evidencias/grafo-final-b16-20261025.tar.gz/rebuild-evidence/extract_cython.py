"""Parse the actual .pyx with pinned Cython, without generating or loading code."""
import collections
import hashlib
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, '/home/felidae/.cache/uv/archive-v0/CC4EafotQhonO7E8')
import Cython
from Cython.Compiler.TreeFragment import parse_from_strings

assert Cython.__version__ == '3.0.12'
source = Path('apps/safety/_canonical_kernel.pyx')
tree = parse_from_strings('canonical_kernel', source.read_text())
work = Path(__file__).resolve().parent
norm = lambda value: re.sub('[^a-z0-9_]', '_', value.lower())
prefix = norm(str(source.with_suffix('')))
nodes = [{'id': prefix, 'label': source.name, 'file_type': 'code',
          'source_file': str(source), 'source_location': 'L1',
          '_origin': 'fresh_cython_ast', 'language': 'cython'}]
edges, declarations, calls = [], [], []
counts = collections.Counter()

def decl_name(node):
    if type(node).__name__ == 'DefNode':
        return node.name
    node = getattr(node, 'declarator', node)
    while getattr(node, 'base', None) is not None:
        node = node.base
    return getattr(node, 'name', None)

def visit(node, owner=None):
    if node is None:
        return
    if isinstance(node, (list, tuple)):
        for child in node:
            visit(child, owner)
        return
    if not hasattr(node, 'child_attrs'):
        return
    kind = type(node).__name__
    counts[kind] += 1
    if kind in {'DefNode', 'CFuncDefNode'}:
        name = decl_name(node)
        assert name
        identity = prefix + '_' + norm(name)
        declarations.append({'name': name, 'line': node.pos[1], 'kind': kind, 'id': identity})
        owner = identity
    elif kind == 'CVarDefNode':
        for item in node.declarators:
            if type(item).__name__ == 'CFuncDeclaratorNode':
                name = decl_name(item)
                declarations.append({'name': name, 'line': node.pos[1],
                                     'kind': 'ExternalCDeclaration', 'id': prefix + '_' + norm(name)})
    if kind in {'SimpleCallNode', 'GeneralCallNode'}:
        function = node.function
        expression = getattr(function, 'name', None) or getattr(function, 'attribute', None)
        calls.append({'owner': owner or prefix, 'expression': expression,
                      'function_node_kind': type(function).__name__, 'line': node.pos[1]})
    for attr in node.child_attrs:
        visit(getattr(node, attr, None), owner)

visit(tree)
assert {d['name'] for d in declarations} == {'canonical_python_budget', '_pure', '_walk', 'try_check', 'check'}
for d in declarations:
    nodes.append({'id': d['id'], 'label': d['name'], 'file_type': 'code',
                  'source_file': str(source), 'source_location': f"L{d['line']}",
                  '_origin': 'fresh_cython_ast', 'language': 'cython',
                  'declaration_kind': d['kind']})
    edges.append({'source': prefix, 'target': d['id'], 'relation': 'defines',
                  'confidence': 'EXTRACTED', 'confidence_score': 1.0,
                  'source_file': str(source), 'source_location': f"L{d['line']}", 'weight': 1.0})
by_name = {d['name']: d for d in declarations}
unresolved = []
for call in calls:
    if call['expression'] in by_name and call['function_node_kind'] == 'NameNode':
        target = by_name[call['expression']]
        edges.append({'source': call['owner'], 'target': target['id'],
                      'relation': 'references' if target['kind'] == 'ExternalCDeclaration' else 'calls',
                      'confidence': 'EXTRACTED', 'confidence_score': 1.0,
                      'source_file': str(source), 'source_location': f"L{call['line']}",
                      'weight': 1.0, 'runtime_binding_verified': False})
    else:
        unresolved.append(call)

sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
manifest = json.loads(Path('apps/safety/_canonical_native/manifest.json').read_text())
assert sha(source) == manifest['source_sha256']
assert sha('scripts/build_canonical_kernel.py') == manifest['build_script_sha256']
assert sha('apps/safety/_canonical_native/_canonical_kernel.c') == manifest['generated_c_sha256']
result = {'nodes': nodes, 'edges': edges, 'cython_version': Cython.__version__,
          'ast_node_count': sum(counts.values()), 'ast_node_types': dict(counts),
          'declarations': declarations, 'unresolved_calls': unresolved,
          'source_sha256': sha(source), 'generated_c_source_bridge_verified': True,
          'limits': 'Fresh Cython parse and static local references; no compilation, native binary loading or runtime equivalence test. Generated C/binary excluded as derived artifacts; manifest hashes bridge source, build script and generated C.'}
(work / 'fresh-cython.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'state': 'FRESH_CYTHON_AST_EXTRACTED', 'ast_nodes': result['ast_node_count'],
                  'declarations': len(declarations), 'graph_nodes': len(nodes), 'graph_edges': len(edges),
                  'generated_c_bridge': True}))
