"""Build only from freshly extracted, verified inputs; never consume old graph."""
import collections
import hashlib
import json
import re
import subprocess
from pathlib import Path

import networkx as nx
from graphify.cluster import cluster, score_all
from graphify.export import to_json

root = Path.cwd()
work = Path(__file__).resolve().parent
stage = work / 'new-graphify-out'
stage.mkdir(exist_ok=True)
manifest = json.loads((work / 'source-manifest.json').read_text())
assert len(manifest) == 1922
for rel, row in manifest.items():
    assert hashlib.sha256((root / rel).read_bytes()).hexdigest() == row['sha256'], rel
assert json.loads((work / 'python-coverage-verification.json').read_text())['state'].startswith('PASS_')
normalize = lambda value: re.sub('[^a-z0-9_]', '_', value.lower())
view = str(work / 'views/docs/17-seguimiento-desarrollo.md')

def source_rel(raw):
    if raw == view:
        return 'docs/17-seguimiento-desarrollo.md'
    p = Path(raw)
    return str(p.relative_to(root)) if p.is_absolute() else str(p)

def location(raw):
    match = re.search(r'(?:L|:)(\d+)(?:[-:]\d+)?$', str(raw))
    return 'L' + match.group(1) if match else raw

nodes, edges, collisions, coverage = {}, [], [], []

def merge(data, origin):
    mapping = {}
    for original in data['nodes']:
        n = dict(original)
        if n.get('source_file'):
            n['source_file'] = source_rel(n['source_file'])
        n['source_location'] = location(n.get('source_location'))
        identity = n['id']
        if identity in nodes:
            existing = nodes[identity]
            if (existing.get('source_file'), existing.get('label')) == (n.get('source_file'), n.get('label')):
                existing.setdefault('additional_extraction_origins', []).append(origin)
                mapping[identity] = identity
                continue
            suffix = normalize(n.get('source_file', 'external')) + '_' + normalize(n.get('label', 'reference'))
            revised = identity + '_from_' + suffix
            assert revised not in nodes
            collisions.append({'original_id': identity, 'revised_id': revised,
                               'existing_source': existing.get('source_file'),
                               'new_source': n.get('source_file'), 'origin': origin})
            n['id'] = revised
        mapping[identity] = n['id']
        n.setdefault('extraction_origin', origin)
        if origin.startswith('fresh_native_semantic'):
            n.setdefault('temporal_scope', 'Documentary source claim; not independent runtime verification')
        nodes[n['id']] = n
    for original in data['edges']:
        e = dict(original)
        e['source'] = mapping.get(e['source'], e['source'])
        e['target'] = mapping.get(e['target'], e['target'])
        if e.get('source_file'):
            e['source_file'] = source_rel(e['source_file'])
        e['source_location'] = location(e.get('source_location'))
        e.setdefault('confidence_score', 1.0 if e.get('confidence') == 'EXTRACTED' else .75)
        e.setdefault('extraction_origin', origin)
        edges.append(e)

merge(json.loads((work / 'fresh-ast-completed.json').read_text()), 'fresh_graphify_ast_with_standard_python_reconciliation')
merge(json.loads((work / 'fresh-cython.json').read_text()), 'fresh_cython_ast')
for chunk in range(1, 29):
    verification = json.loads((work / f'chunk-{chunk:02d}-verification.json').read_text())
    assert verification['state'] == 'VERIFIED_LITERAL_SCOPE_NOT_GLOBAL_SEMANTIC_PROOF'
    task = json.loads((work / f'chunk-{chunk:02d}-task.json').read_text())
    fragment = Path(task['ALLOWED_SCOPE'][0])
    assert hashlib.sha256(fragment.read_bytes()).hexdigest() == verification['fragment_sha256']
    data = json.loads(fragment.read_text())
    coverage.extend(data['coverage'])
    merge(data, f'fresh_native_semantic_task_{chunk:02d}')
    target = work / 'semantic' / f'chunk-{chunk:02d}.json'
    target.parent.mkdir(exist_ok=True)
    target.write_bytes(fragment.read_bytes())

semantic_sources = {source_rel(row['source_file']) for row in coverage}
expected = {rel for rel, row in manifest.items() if row['category'] != 'code'}
assert len(coverage) == len(semantic_sources) == len(expected) == 551
assert semantic_sources == expected
for row in coverage:
    rel = source_rel(row['source_file'])
    assert row['read_complete'] is True and row['sha256'] == manifest[rel]['input_sha256']

# Explicit file handles make corpus coverage inspectable independently of symbol count.
handles = {}
for rel, row in manifest.items():
    handle = 'file_' + normalize(rel)
    assert handle not in nodes
    handles[rel] = handle
    nodes[handle] = {'id': handle, 'label': rel, 'file_type': 'code' if row['category'] == 'code' else 'document',
                     'source_file': rel, 'source_location': 'L1', 'extraction_origin': 'declared_corpus_manifest',
                     'semantic_scope': row['semantic_scope']}
for identity, node in list(nodes.items()):
    source = node.get('source_file')
    if source in handles and identity != handles[source]:
        edges.append({'source': handles[source], 'target': identity, 'relation': 'has_extracted_entity',
                      'confidence': 'EXTRACTED', 'confidence_score': 1.0,
                      'source_file': source, 'source_location': node.get('source_location'),
                      'weight': 1.0, 'extraction_origin': 'extraction_provenance_not_application_dependency'})

# Recompute local Markdown citations from the fresh corpus; excluded evidence stays a reference.
citation_refs = []
for rel, row in manifest.items():
    if not rel.endswith('.md'):
        continue
    text = Path(row['input_path']).read_text()
    for match in re.finditer(r'\]\(([^)\s]+)\)', text):
        raw_target = match.group(1)
        if raw_target.startswith('#'):
            continue
        clean = raw_target.split('#', 1)[0]
        if '://' in clean:
            continue
        target = (root / rel).parent / clean
        try:
            target_rel = str(target.resolve().relative_to(root))
        except ValueError:
            continue
        if target_rel not in handles:
            citation_refs.append({'source': rel, 'target': target_rel, 'status': 'outside_declared_corpus_reference_only'})
            continue
        edges.append({'source': handles[rel], 'target': handles[target_rel], 'relation': 'cites',
                      'confidence': 'EXTRACTED', 'confidence_score': 1.0, 'source_file': rel,
                      'source_location': 'L' + str(text[:match.start()].count('\n') + 1),
                      'evidence': match.group(0), 'weight': 1.0,
                      'extraction_origin': 'fresh_literal_markdown_citations'})

# Unresolved imported/lexical endpoints are explicit reference nodes, not fabricated code.
reference_ids = {}
for e in edges:
    for endpoint in ['source', 'target']:
        raw_id = e[endpoint]
        if raw_id in nodes:
            continue
        identity = reference_ids.setdefault(raw_id, 'unresolved_reference_' + normalize(str(raw_id)) + '_' + hashlib.sha256(str(raw_id).encode()).hexdigest()[:8])
        if identity not in nodes:
            nodes[identity] = {'id': identity, 'label': str(raw_id), 'file_type': 'concept',
                              'source_file': None, 'source_location': None, 'external': True,
                              'resolution_status': 'external_or_unresolved_static_expression_not_runtime_binding',
                              'extraction_origin': 'fresh_unresolved_reference_materialization'}
        e[endpoint] = identity

G = nx.MultiDiGraph()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
G.graph.update(source_commit=head, build_kind='complete_fresh_corpus_rebuild',
               reused_previous_graph=False, native_token_usage=None,
               corpus_files=len(manifest), semantic_sources=551, structural_sources=1372)
for identity, n in nodes.items():
    G.add_node(identity, **{k: v for k, v in n.items() if k != 'id'})
for e in edges:
    assert e['source'] in nodes and e['target'] in nodes
    G.add_edge(e['source'], e['target'], **{k: v for k, v in e.items() if k not in {'source', 'target', 'key'}})
H = nx.Graph()
H.add_nodes_from(G.nodes(data=True))
for a, b, attrs in G.edges(data=True):
    weight = float(attrs.get('weight', 1.0))
    if H.has_edge(a, b):
        H[a][b]['weight'] += weight
    else:
        H.add_edge(a, b, weight=weight)
communities = cluster(H)
cohesion = score_all(H, communities)
labels = {cid: f'Community {cid}' for cid in communities}
assert to_json(G, communities, str(stage / 'graph.json'), built_at_commit=head, community_labels=labels)
(stage / 'SOURCE_MANIFEST.json').write_text(json.dumps(manifest, indent=2))
(stage / '.graphify_analysis.json').write_text(json.dumps({'communities': communities, 'cohesion': cohesion}, ensure_ascii=False))
(stage / '.graphify_python').write_text('/home/felidae/.local/share/uv/tools/graphifyy/bin/python3')
(stage / '.graphify_root').write_text(str(root))
summaries = []
for cid, members in communities.items():
    ranked = sorted(members, key=lambda n: H.degree(n), reverse=True)
    summaries.append({'community': cid, 'size': len(members), 'cohesion': cohesion[cid],
                      'top_nodes': [{'id': n, 'label': G.nodes[n].get('label'), 'source_file': G.nodes[n].get('source_file')} for n in ranked[:12]]})
(work / 'community-summaries.json').write_text(json.dumps(summaries, ensure_ascii=False, indent=2))
proof = {'state': 'FRESH_GRAPH_BUILT_PENDING_LABELS_AND_FINAL_AUDIT', 'source_commit': head,
         'source_files': len(manifest), 'semantic_sources': 551, 'structural_sources': 1372,
         'semantic_chunks': 28, 'nodes': G.number_of_nodes(), 'edges': G.number_of_edges(),
         'communities': len(communities), 'self_loops': nx.number_of_selfloops(G),
         'cross_fragment_identity_collisions': collisions,
         'unresolved_reference_nodes': len(reference_ids), 'excluded_citation_references': len(citation_refs),
         'prior_graph_reused': False, 'runtime_tests_credited_by_graph': False,
         'limits': ['Semantic extraction is selective, not every possible relation',
                    'Named declaration coverage is not runtime binding proof',
                    'MultiDiGraph preserves all extracted parallel relations; weighted simple projection only for clustering',
                    'Sources outside declared corpus retained as references without body-read claims',
                    'Native token usage unavailable; technical zeros are not measured cost']}
(work / 'fresh-build-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
(work / 'excluded-citation-references.json').write_text(json.dumps(citation_refs, indent=2))
print(json.dumps({k: proof[k] for k in ['state', 'source_files', 'nodes', 'edges', 'communities', 'unresolved_reference_nodes']}))
