"""Verify every named Python declaration and lexical parent from source AST."""
import ast
import json
from collections import defaultdict
from pathlib import Path

root = Path.cwd()
work = Path(__file__).resolve().parent
graph = json.loads((work / 'fresh-ast-completed.json').read_text())
by_name = defaultdict(list)
for n in graph['nodes']:
    if n.get('qualified_name'):
        by_name[(n['source_file'], n['qualified_name'])].append(n)
definitions = {(e['source'], e['target'], e.get('source_file'), e.get('source_location'))
               for e in graph['edges'] if e.get('_origin') == 'fresh_python_standard_ast'}
file_ids = {n['source_file']: n['id'] for n in graph['nodes']
            if n.get('file_type') == 'code' and n.get('label') == Path(n.get('source_file', '')).name}
errors, checked = [], []

class Verify(ast.NodeVisitor):
    def __init__(self, path):
        self.path, self.stack = path, []

    def visit_named(self, node):
        full = '.'.join([name for name, _ in self.stack] + [node.name])
        rows = by_name[(self.path, full)]
        acceptable = {f'L{x}' for x in [node.lineno] + [d.lineno for d in node.decorator_list]}
        rows = [n for n in rows if acceptable.intersection(
            {n.get('source_location')} | set(n.get('additional_declaration_locations', [])))]
        if len(rows) != 1:
            errors.append({'source': self.path, 'line': node.lineno, 'qualified_name': full, 'matches': len(rows)})
            identity = None
        else:
            identity = rows[0]['id']
            parent = self.stack[-1][1] if self.stack else file_ids[self.path]
            if (parent, identity, self.path, f'L{node.lineno}') not in definitions:
                errors.append({'source': self.path, 'line': node.lineno, 'missing_lexical_parent': full})
        checked.append((self.path, full, node.lineno))
        self.stack.append((node.name, identity))
        self.generic_visit(node)
        self.stack.pop()

    visit_ClassDef = visit_named
    visit_FunctionDef = visit_named
    visit_AsyncFunctionDef = visit_named

for raw in json.loads((work / 'detect.json').read_text())['files']['code']:
    path = Path(raw)
    if path.suffix == '.py':
        Verify(str(path.relative_to(root))).visit(ast.parse(path.read_text()))
assert len(checked) == 6606
ids = [n['id'] for n in graph['nodes']]
assert len(ids) == len(set(ids))
result = {'state': 'PASS_ALL_NAMED_PYTHON_DECLARATIONS_AND_PARENTS' if not errors else 'FAIL',
          'checked_declarations': len(checked), 'node_ids_unique': True, 'errors': errors,
          'limits': 'Declaration and lexical containment coverage, not complete dynamic call resolution or runtime behavior.'}
(work / 'python-coverage-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
raise SystemExit(bool(errors))
