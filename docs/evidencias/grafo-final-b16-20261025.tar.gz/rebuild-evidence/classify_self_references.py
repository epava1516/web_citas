"""Prevent extractor self-links from claiming recursion or self-inheritance."""
import ast
import collections
import json
import re
from pathlib import Path

work = Path(__file__).resolve().parent
path = work / 'new-graphify-out/graph.json'
data = json.loads(path.read_text())
nodes = {n['id']: n for n in data['nodes']}
trees = {}
dispositions = []
for edge in data['links']:
    if edge['source'] != edge['target']:
        continue
    relation = edge.get('relation')
    if relation not in {'calls', 'inherits'}:
        dispositions.append({'source': edge['source'], 'relation': relation, 'disposition': 'literal_citation_or_non_call_self_relation'})
        continue
    source = edge.get('source_file', '')
    location = re.match(r'L(\d+)', str(edge.get('source_location', '')))
    line = int(location.group(1)) if location else None
    owner = nodes[edge['source']]
    name = owner.get('qualified_name', owner.get('label', '')).split('.')[-1].removesuffix('()').lstrip('.')
    expressions = []
    direct = False
    if source.endswith('.py') and line is not None:
        if source not in trees:
            trees[source] = ast.parse(Path(source).read_text())
        tree = trees[source]
        if relation == 'calls':
            calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and n.lineno <= line <= n.end_lineno]
            expressions = list(dict.fromkeys(ast.unparse(n.func) for n in calls))
            direct = any(isinstance(n.func, ast.Name) and n.func.id == name for n in calls)
        else:
            classes = [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)
                       and line in [n.lineno] + [d.lineno for d in n.decorator_list]]
            expressions = list(dict.fromkeys(ast.unparse(b) for n in classes for b in n.bases))
    elif edge.get('extraction_origin') == 'fresh_cython_ast' and relation == 'calls':
        direct = True  # Native Cython pass emits local NameNode calls only.
        expressions = [name]
    row = {'source': edge['source'], 'source_file': source, 'line': line,
           'original_relation': relation, 'expressions': expressions}
    if relation == 'calls' and direct:
        edge['self_reference_status'] = 'direct_name_recursion_in_static_source_not_runtime_proof'
        row['disposition'] = 'direct_name_recursion_in_static_source'
    else:
        edge['original_relation'] = relation
        edge['relation'] = 'unresolved_call_annotation' if relation == 'calls' else 'unresolved_base_annotation'
        edge['confidence'] = 'AMBIGUOUS'
        edge['confidence_score'] = .2
        edge['qualified_expressions'] = expressions
        edge['target_binding_verified'] = False
        edge['edge_semantics'] = 'owner_self_annotation_no_callee_or_base_dependency_asserted'
        row['disposition'] = edge['relation']
    dispositions.append(row)
proof = {'state': 'SELF_REFERENCES_CLASSIFIED_WITHOUT_CHANGING_TOPOLOGY',
         'counts': dict(collections.Counter(r['disposition'] for r in dispositions)),
         'dispositions': dispositions,
         'community_impact': 'Endpoints and weights unchanged; fresh community topology and labels remain valid.',
         'limits': 'Direct source recursion is static only; annotations are not dependency edges or application defect counts.'}
(work / 'self-reference-dispositions.json').write_text(json.dumps(proof, indent=2) + '\n')
data['graph']['self_reference_policy'] = proof['limits']
path.write_text(json.dumps(data, ensure_ascii=False))
print(json.dumps(proof['counts']))
