"""Finalize the fresh graph's labels, report, visual and reproducibility metadata."""
import collections
import hashlib
import importlib.metadata
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import networkx as nx
from graphify.analyze import god_nodes, surprising_connections, suggest_questions
from graphify.export import to_html, to_json
from graphify.report import generate

root = Path.cwd()
work = Path(__file__).resolve().parent
stage = work / 'new-graphify-out'
data = json.loads((stage / 'graph.json').read_text())
labels = {}
for i in range(1, 4):
    fragment = json.loads(Path(f'/tmp/web-modelos-graph-labels-{i:02d}/labels-{i:02d}.json').read_text())
    expected = {str(row['community']) for row in json.loads((work / f'labels-{i:02d}-input.json').read_text())}
    assert set(fragment) == expected and not set(fragment).intersection(labels)
    assert all(isinstance(v, str) and 2 <= len(v.split()) <= 5 for v in fragment.values())
    labels.update(fragment)
assert len(labels) == 846
labels = {int(k): v for k, v in labels.items()}
analysis = json.loads((stage / '.graphify_analysis.json').read_text())
communities = {int(k): v for k, v in analysis['communities'].items()}
cohesion = {int(k): v for k, v in analysis['cohesion'].items()}
assert set(labels) == set(communities)
G = nx.MultiDiGraph()
G.graph.update(data['graph'])
G.graph.update(updated_at=datetime.now(timezone.utc).isoformat(),
               extraction_scope='full_declared_corpus_with_explicit_section_views',
               community_detection='fresh_Leiden_on_weighted_projection',
               native_token_usage=None)
for n in data['nodes']:
    G.add_node(n['id'], **{k: v for k, v in n.items() if k != 'id'})
for e in data['links']:
    G.add_edge(e['source'], e['target'], **{k: v for k, v in e.items() if k not in {'source', 'target', 'key'}})
H = nx.Graph()
H.add_nodes_from(G.nodes(data=True))
for a, b, attrs in G.edges(data=True):
    weight = float(attrs.get('weight', 1.0))
    if H.has_edge(a, b):
        H[a][b]['weight'] += weight
    else:
        H.add_edge(a, b, weight=weight)
gods = god_nodes(H)
surprises = surprising_connections(H, communities)
questions = suggest_questions(H, communities, labels)
assert to_json(G, communities, str(stage / 'graph.json'),
               built_at_commit=data['built_at_commit'], community_labels=labels)
detect = json.loads((work / 'detect.json').read_text())
manifest = json.loads((stage / 'SOURCE_MANIFEST.json').read_text())
scope = '''# Grafo final reconstruido desde cero — alfa

Corpus:1922fuentes únicas;1371entradas ASTGraphify más núcleoCython parseado con3.0.12;551fuentes semánticas, incluidas configuraciones y plantillas. Cython participa en ambas capas.28lotes nativos leídos y conciliados;6606declaracionesPython y sus padres comprobados. No nodos/aristas/caché del grafo anterior reutilizados.

Seguimiento17: sólo vista de líneas1–6, con la precedencia de su encabezado vigente y las entradas previas conservadas como antecedentes. Cronología17-historial-desarrollo, carpeta17-historial, evidencias masivas,artifacts,medios,vendor ymetadatos de agentes excluidos expresamente. Documentos de hitos fechados del repositorio sí se leen, sin convertirlos en estado actual o navegación remota.976citas fuera del corpus conservan registro sin crédito de lectura del destino.

El grafo no acredita PASS, seguridad, legalidad, proveedores o producción. Semántica selectiva por fuentes completas, no todas las relaciones posibles. Consumo nativo no disponible; los ceros técnicos del generador inferior no significan coste cero. Referencias estáticas no son bindings runtime; las expresiones inciertas y colisiones se declaran. MultiDiGraph conserva relaciones paralelas; proyección ponderada simple sólo para comunidades/análisis.

141autorreferencias se distinguen:39recursiones de nombre directo en fuente estática,94anotaciones de llamada no resuelta,6anotaciones de base no resuelta y2citas. Las100anotaciones no son dependencias a sí mismo ni defectos de aplicación.194referencias externas/noresueltas se materializan sin inventar implementación. Las colisiones de declaración y de documentos input/lock están conciliadas con sus originales negativos preservados.

Etiquetas españolas derivadas de resúmenes frescos: navegación temática, no aceptación de sistemas. Comunidades recalculadas sobre topología nueva; la clasificación posterior de autorreferencias cambia atributos, no extremos ni pesos. El proyecto sigue enalfa;B16aceptado localmente, contrato aún pendiente del inventario diferencial yacta final.

'''
report = generate(H, communities, cohesion, labels, gods, surprises, detect,
                  {'input': 0, 'output': 0}, str(root), suggested_questions=questions)
(stage / 'GRAPH_REPORT.md').write_text(scope + report)
(stage / '.graphify_labels.json').write_text(json.dumps(labels, ensure_ascii=False, indent=2))
(stage / '.graphify_analysis.json').write_text(json.dumps({**analysis, 'gods': gods, 'surprises': surprises, 'questions': questions}, ensure_ascii=False))
# This installed exporter enforces 5000 nodes; project explicitly to communities
# rather than raising that bound or pretending the visual contains every symbol.
community_of = {node: cid for cid, members in communities.items() for node in members}
C = nx.DiGraph()
for cid, members in communities.items():
    C.add_node(f'community_{cid}', label=labels[cid], file_type='concept',
               source_file=None, member_count=len(members), internal_relation_count=0)
for a, b, attrs in G.edges(data=True):
    first, second = community_of[a], community_of[b]
    if first == second:
        C.nodes[f'community_{first}']['internal_relation_count'] += 1
        continue
    first, second = f'community_{first}', f'community_{second}'
    if not C.has_edge(first, second):
        C.add_edge(first, second, weight=0.0, relation='community_relations', relation_count=0)
    C[first][second]['weight'] += float(attrs.get('weight', 1.0))
    C[first][second]['relation_count'] += 1
visual_communities = {cid: [f'community_{cid}'] for cid in communities}
C.graph['view_scope'] = 'Community projection only; full17850symbolgraph in graph.json'
assert to_html(C, visual_communities, str(stage / 'graph.html'), community_labels=labels,
               member_counts={cid: len(members) for cid, members in communities.items()})
file_types = collections.Counter(Path(p).suffix or '[no extension]' for p in manifest)
policy = {'source_root': str(root), 'source_commit': data['built_at_commit'],
          'build_kind': 'complete_fresh_corpus_rebuild', 'old_graph_reused': False,
          'selected_files': sorted(manifest), 'source_counts_by_suffix': dict(file_types),
          'section_views': {'docs/17-seguimiento-desarrollo.md': 'lines1-6_only; prior entries within view remain dated antecedents'},
          'exclusions': [row for row in json.loads((work / 'tracked-exclusions.json').read_text()) if row['path'] not in manifest],
          'supplemental_detector_omissions_resolved': [row['path'] for row in json.loads((work / 'tracked-exclusions.json').read_text()) if row['path'] in manifest],
          'derived_native_artifacts': {'policy': 'GeneratedC/binary excluded from new extraction as derived; pinned manifest SHA bridges actualCython source/buildscript/generatedC', 'proof': 'fresh-cython.json'},
          'tools': {'graphifyy': importlib.metadata.version('graphifyy'), 'networkx': nx.__version__, 'Cython': '3.0.12',
                    'method': 'FreshGraphifyAST+Pythonastlexicalreconciliation+Cythonparser+nativeLLMsemantics+MultiDiGraph+freshLeiden'},
          'native_token_usage': None, 'runtime_tests_credited': False,
          'visualization_scope': '846communitynodes; full17850nodes in JSON. Direct fullHTMLrejected by installed5000nodeguard; limit preserved.',
          'automatic_update_limit': 'Partial source views require section-aware reconciliation; do not stamp full-file semantic coverage for followup17.'}
(stage / 'CORPUS_POLICY.json').write_text(json.dumps(policy, ensure_ascii=False, indent=2))
health = {'nodes': G.number_of_nodes(), 'relations': G.number_of_edges(), 'communities': len(communities),
          'source_files': len(manifest), 'semantic_sources': 551, 'structural_sources': 1372,
          'missing_endpoints': 0, 'dangling_endpoints': 0, 'self_loops': nx.number_of_selfloops(G),
          'self_reference_dispositions': json.loads((work / 'self-reference-dispositions.json').read_text())['counts'],
          'parallel_relations_preserved': G.number_of_edges() - len(set(G.edges())),
          'unresolved_reference_nodes': 194, 'failed_sources': 0,
          'community_detection': 'fresh_Leiden_weighted_projection; no prior memberships reused',
          'full_AST_refresh': True, 'full_semantic_corpus_refresh': True,
          'semantic_relation_exhaustiveness': False, 'native_token_usage': None}
(stage / 'GRAPH_HEALTH.json').write_text(json.dumps(health, indent=2))
(stage / 'ESTADO_ACTUAL.json').write_text(json.dumps({'phase': 'alpha', 'locally_closed': 15, 'roadmap_total': 18,
                                                   'B16': 'accepted_local_acta22', 'goal_complete': False,
                                                   'pending': ['inventory_differential', 'graph_integration_of_inventory', 'contract_final_act'],
                                                   **health}, indent=2))
(stage / 'ESTADO_ACTUAL.md').write_text(scope)
(stage / 'cost.json').write_text(json.dumps({'native_input_tokens': None, 'native_output_tokens': None,
                                           'reason': 'Native agent tool usage not exposed; schema zeros not measured usage',
                                           'prior_cost_history': 'preserved previous graph archive'}, indent=2))
outputs = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in stage.iterdir()
           if p.is_file() and p.name not in {'CURRENT_OUTPUTS.json', 'GRAPH_VERIFICATION.json'}}
(stage / 'CURRENT_OUTPUTS.json').write_text(json.dumps({'sha256': outputs, 'source_commit': data['built_at_commit']}, indent=2))
print(json.dumps({'state': 'FRESH_OUTPUTS_READY_FOR_INDEPENDENT_AUDIT', **health}))
