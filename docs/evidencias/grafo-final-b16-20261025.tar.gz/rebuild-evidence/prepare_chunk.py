"""Prepare a bounded native task; parent dispatches it after prior verification."""
import json
import sys
from pathlib import Path

work = Path(__file__).resolve().parent
chunk, slot = map(int, sys.argv[1:3])
task = json.loads((work / 'chunk-01-task.json').read_text())
files = json.loads((work / f'chunk-{chunk:02d}-files.json').read_text())
prompt = Path('/home/felidae/.codex/skills/graphify/references/extraction-spec.md').read_text().split('```\n', 1)[1].split('\n```', 1)[0]
output = f'/tmp/web-modelos-graph-final-{slot:02d}/graph-fragment-{chunk:02d}.json'
assert not Path(output).exists()
task.update(TASK_ID=f'graph-final-semantic-{chunk:02d}', RELEVANT_FILES=files,
            ALLOWED_SCOPE=[output],
            EXPECTED_OUTPUT=f'Write {output}; preserve earlier fragments; return structured contract report. Read every assigned file fully; byte consumption is not semantic reading.',
            EXTRACTION_PROMPT=prompt.replace('CHUNK_NUM', str(chunk)).replace('TOTAL_CHUNKS', '27').replace('FILE_LIST', '\n'.join(files)).replace('DEEP_MODE', 'false'))
task['CONTEXT'] = task['CONTEXT'].replace('web-modelos-graph-final-01', f'web-modelos-graph-final-{slot:02d}')
(work / f'chunk-{chunk:02d}-task.json').write_text(json.dumps(task, ensure_ascii=False, indent=2))
print(json.dumps({'task': str(work / f'chunk-{chunk:02d}-task.json'), 'output': output, 'files': len(files)}))
