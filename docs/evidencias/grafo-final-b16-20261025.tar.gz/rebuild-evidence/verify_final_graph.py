"""Independent byte, coverage, identity, topology and preservation gate."""
import collections
import hashlib
import json
import tarfile
from pathlib import Path

root = Path.cwd()
work = Path(__file__).resolve().parent
stage = work / 'new-graphify-out'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest = json.loads((stage / 'SOURCE_MANIFEST.json').read_text())
assert len(manifest) == 1922
for rel, row in manifest.items():
    assert sha(root / rel) == row['sha256'], rel
    assert sha(row['input_path']) == row['input_sha256'], rel
product = json.loads(Path('docs/evidencias/b16-final-candidate-reconciliation-20261025.json').read_text())['current_versioned_executable_sources']
assert len(product) == 1507
for rel, expected in product.items():
    assert sha(rel) == expected, rel
graph = json.loads((stage / 'graph.json').read_text())
assert graph['directed'] is True and graph['multigraph'] is True
nodes = {n['id']: n for n in graph['nodes']}
assert len(nodes) == len(graph['nodes']) == 17850
assert len(graph['links']) == 79100
assert all(e['source'] in nodes and e['target'] in nodes for e in graph['links'])
outside = [n for n in nodes.values() if n.get('source_file') and n['source_file'] not in manifest]
assert not outside, outside[:2]
assert set(manifest) <= {n.get('source_file') for n in nodes.values()}
communities = json.loads((stage / '.graphify_analysis.json').read_text())['communities']
flat = [n for members in communities.values() for n in members]
assert len(communities) == 846 and len(flat) == len(set(flat)) == len(nodes)
assert set(flat) == set(nodes)
labels = json.loads((stage / '.graphify_labels.json').read_text())
assert set(labels) == set(communities) and all(2 <= len(v.split()) <= 5 for v in labels.values())
assert all(str(n['community']) in labels and n['community_name'] == labels[str(n['community'])] for n in nodes.values())
source_coverage = []
for chunk in range(1, 29):
    proof = json.loads((work / f'chunk-{chunk:02d}-verification.json').read_text())
    assert proof['state'] == 'VERIFIED_LITERAL_SCOPE_NOT_GLOBAL_SEMANTIC_PROOF' and not proof['errors']
    fragment = work / 'semantic' / f'chunk-{chunk:02d}.json'
    assert sha(fragment) == proof['fragment_sha256']
    source_coverage += json.loads(fragment.read_text())['coverage']
assert len(source_coverage) == 551 and all(r['read_complete'] for r in source_coverage)
python = json.loads((work / 'python-coverage-verification.json').read_text())
assert python['state'].startswith('PASS_') and python['checked_declarations'] == 6606 and not python['errors']
cython = json.loads((work / 'fresh-cython.json').read_text())
assert cython['cython_version'] == '3.0.12' and cython['ast_node_count'] == 379
assert len(cython['declarations']) == 5 and cython['generated_c_source_bridge_verified']
ambiguous = [e for e in graph['links'] if e.get('relation') in {'unresolved_call_annotation', 'unresolved_base_annotation'}]
assert len(ambiguous) == 100
assert all(e.get('confidence') == 'AMBIGUOUS' and e.get('confidence_score') == .2
           and e.get('target_binding_verified') is False for e in ambiguous)
assert not any(e['source'] == e['target'] and e.get('relation') == 'inherits' for e in graph['links'])
original = json.loads((work / 'previous-graph-manifest.json').read_text())
archive = Path('docs/evidencias/grafo-previo-b16-20261025.tar.gz')
assert sha(archive) == original['archive_sha256']
with tarfile.open(archive) as stream:
    members = {m.name: m for m in stream.getmembers() if m.isfile()}
    assert set(members) == set(original['files'])
    for name, row in original['files'].items():
        payload = stream.extractfile(members[name]).read()
        assert len(payload) == row['bytes'] and hashlib.sha256(payload).hexdigest() == row['sha256']
outputs = json.loads((stage / 'CURRENT_OUTPUTS.json').read_text())['sha256']
for filename, expected in outputs.items():
    assert sha(stage / filename) == expected, filename
assert '<html' in (stage / 'graph.html').read_text().lower()
policy = json.loads((stage / 'CORPUS_POLICY.json').read_text())
assert policy['old_graph_reused'] is False
assert not {r['path'] for r in policy['exclusions']}.intersection(manifest)
result = {'result': 'PASS_FRESH_GRAPH_DECLARED_CORPUS', 'source_files': 1922,
          'source_sha_mismatches': 0, 'accepted_executable_sources_unchanged': 1507,
          'semantic_sources': 551, 'semantic_chunks': 28, 'structural_sources': 1372,
          'python_named_declarations_and_parents': 6606, 'cython_ast_nodes': 379,
          'nodes': len(nodes), 'relations': len(graph['links']), 'communities': 846,
          'missing_or_dangling_endpoints': 0, 'duplicate_node_ids': 0,
          'preserved_previous_archive_members': len(original['files']),
          'graph_sha256': sha(stage / 'graph.json'), 'prior_graph_reused': False,
          'self_annotations_not_dependencies': 100,
          'limits': ['Corpus defined by manifest; followup17only lines1–6',
                     'Selective semantics, not every possible relationship',
                     'Static names/imports and external references not runtime proof',
                     'No application tests credited or repeated by this gate',
                     'HTML is846communityprojection; fullgraph remainsJSON',
                     'Native token usage unavailable']}
(stage / 'GRAPH_VERIFICATION.json').write_text(json.dumps(result, indent=2) + '\n')
(work / 'final-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
