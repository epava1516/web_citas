"""Requirement-by-requirement local N10 acceptance, not whole-contract completion."""
import ast,collections,copy,hashlib,json,subprocess,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
W=Path('artifacts/recorridos-n10-20261026/n10f');load=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
path=Path('docs/evidencias/n10-e-matriz77-disposiciones-20261026.json');old=json.loads(subprocess.check_output(['git','show','HEAD:'+str(path)],text=True));assert sha(path)=='14ac63d2df6b6a5588d26a3923e12d839232aefa06a450b169c9bdb524bf1b0e'
f=load(W/'audit.json');assert f['result']=='PASS_SCOPED_CURRENT_PREVIOUS_CURRENT_OWNED_SOURCE_PROCESS_RETURN'
P=Path('artifacts/local-ci')/f['run'];assert load(P/'result.json')['result']=='PASS'and sha(P/'pytest.xml')==f['actual_JUnit_sha256']and f['cleanup_verified']and f['telegram']['delivery']=='sent'
assert len(f['actual']['phases'])==3 and all(p['exact_all_rows_files_and_migrations_unchanged']for p in f['actual']['phases'])
m=copy.deepcopy(old);row=m['rows']['runbook:O_RUNTIME_RETURN'];row.update(decision_state='verified_scoped_disposition',mandatory_gap=None,root_disposition='locally_verified_current_source_process_return_with_declared_maintenance_limits',modes='Actual0dcf89f->8589acd->0dcf89f three ownedGunicornsourceprocess phases,4syncworkers each, samePG/alreadyadmittedsession, sourcehashmarkers and6HTTP200',effects='All173models/through8mediafiles anddjango_migrations unchanged perphase; everyownprocessgroup closed before nextphase; no runtime/schema/data rollback',authority_and_target='ExplicitlyownedtestPG ci migrator andsyntheticverifiedstaff+Groupview/change, alreadyadmittedepoch1/MFA; privateconfig0600 andloopbackonly; not productionleastprivilege or freshlogin proof',reversibility_and_replay='Actual current source restored as finalphase; no writes during switch, no images/deployment/mixedworker/SLA claim')
row['current_sources']['apps/core/admin.py']=sha('apps/core/admin.py');row['current_sources']['tests/test_owned_current_source_return.py']=sha('tests/test_owned_current_source_return.py')
row['functional_evidence'].update(current_native_case={'run':f['run'],'nodeid':'tests.test_owned_current_source_return::test_current_previous_current_owned_source_process_return','actual_JUnit_sha256':f['actual_JUnit_sha256'],'source_phases':['current','previous','current'],'source_verified_worker_instances':12,'native_HTTP200':6,'data_files_migrations_unchanged':True},prior_sourcepair='37ccaaa/ae33175 historical only; current source0dcf is compared to8589 by actualtest',source_delta='753Gitpaths, onlyadmin.py differs; schema/deps/tasks/templates/Groupguards same')
row['cost_reference']={'kind':'actual_source_process_return_reference','run':f['run'],'spawn_to_ready_seconds':[p['spawn_to_ready_observed_seconds']for p in f['actual']['phases']],'HTTPsamples':[p['samples']for p in f['actual']['phases']],'exported_bytes':f['actual']['exported_source_bytes'],'limit':'One3phasecase, polling50ms, no performancebeforeafter/causalclaim; QAtotal separate'}
row['limits']=['Previous8589 lacksnativeAdminlogin epoch1fix: controlledmaintenance/admittedsessionread continuity only, not productive rollback approval','No imagebuild/switch, dependency upgrade/downgrade, migrations, writesduringreturn, mixedCelery, lostkey recovery, load, zerodowntime or externalprovider claim','Actualold3image726cycle retained separately with originalscope, never relabeled as current']
row['evidence_refs'].append('F')
m['proof_refs']['E']['archive_sha256']=sha(m['proof_refs']['E']['archive']);m['proof_refs']['F']={'doc':'docs/490-n10-f-retorno-procesos-actuales-verificado-20261026.md','archive':'docs/evidencias/n10-f-retorno-actual-y-aceptacion-20261026.tar.gz','source_gate':'Actual1PASS threephases12sourceverifiedworkerinstances6HTTP200; allrows/files/migrations exact; cleanup'}
assigned={r['id']:r for r in load(m['original_assignment']['source'])['actions']if'N10'in r['blocks']};assert len(assigned)==len(m['rows'])==77 and set(assigned)==set(m['rows'])
for key,value in m['rows'].items():
 if key!='runbook:O_RUNTIME_RETURN':assert value==old['rows'][key],key
 assert value['decision_state']=='verified_scoped_disposition'and value['mandatory_gap']is None and not value['whole_functionality_PASS_claimed']
 for file,h in value['current_sources'].items():assert sha(file)==h,file
 assert value['kind']==assigned[key]['kind']and value['original_variants']==assigned[key]['variants_and_dependencies']
# Confirm the existing acceptance roots remain applicable at the current cut.
cmd=load('artifacts/recorridos-n10-20261026/n10-command46-dispositions.json')
for file,r in cmd['source_identity'].items():assert sha(file)==r['current_sha256'],file
C_source_drift=[]
for file,r in load('artifacts/recorridos-n10-20261026/n10c/n10c-runbooks11-dispositions.json')['source_identity'].items():
 if sha(file)!=r['current_sha256']:
  assert file=='apps/core/admin.py'and hashlib.sha256(subprocess.check_output(['git','show','8589acd:'+file])).hexdigest()==r['current_sha256'],file
  C_source_drift.append({'file':file,'old_sha256':r['current_sha256'],'current_sha256':sha(file),'bridge':'D native login receiver only; Groupclass/helper AST verified below; F actual previous/current sources loaded; otherflow scope nativeD controls'})
assert len(C_source_drift)==1
for file,h in load('artifacts/recorridos-n10-20261026/n10c/dispatch-root-verification.json')['same_original_source_files'].items():assert sha(file)==h,file
for letter,ref in m['proof_refs'].items():
 if letter!='F':assert sha(ref['archive'])==ref['archive_sha256']
# Native Group behavior has no semantic delta from the accepted target-lock correction.
oldapp=ast.parse(subprocess.check_output(['git','show','ae33175:apps/core/admin.py'],text=True));newapp=ast.parse(Path('apps/core/admin.py').read_text())
for name in ['CurrentGroupAdmin','current_group_actor']:
 get=lambda t:next(n for n in t.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))and n.name==name)
 assert ast.dump(get(oldapp),include_attributes=False)==ast.dump(get(newapp),include_attributes=False)
# Actual accepted native case roots and terminal state, not documentation-only credit.
runs={'A16':'20261026-211007-c4c78619','B2':'20261026-213503-04860762','C2':'20261026-214709-7f404800','D_focal4':'20261026-222154-ba06d23e','E2':'20261026-224102-607397ac','F1':f['run']};counts={'A16':16,'B2':2,'C2':2,'D_focal4':4,'E2':2,'F1':1}
for label,run in runs.items():
 folder=Path('artifacts/local-ci')/run;r=load(folder/'result.json');cases=list(ET.parse(folder/'pytest.xml').iter('testcase'))
 assert r['result']=='PASS'and r['sources_unchanged']and len(cases)==counts[label]and all(c.find(k)is None for c in cases for k in ['failure','error','skipped'])
 assert load(folder/'telegram-notification.json')['delivery']=='sent'and all(v['absent']for v in r['cleanup'].values())
combined=load('artifacts/recorridos-n10-20261026/n10d/combined-audit.json');assert combined['unique_PASS']==10 and len(combined['reused6'])==6 and combined['original2_byteidentical']and combined['first_candidate7PASS3FAIL_retained']and combined['baseline1PASS1FAIL_retained']
requirements={'N10_R01_exact77_partition_and_original_variants':True,'N10_R02_source_modes_authority_effects_replay_cost_limits_eachID':True,'N10_R03_direct_service_metadata_and_nonselected_modes_distinct':True,'N10_R04_selected_operational_domains_actual_or_sourcebound_original_evidence':True,'N10_R05_current_admin_role_wait_login_MFA_and_selfsession_corrections':True,'N10_R06_current_source_return_actual_isolated_threephases':True,'N10_R07_no_app_latency_from_QA_no_provider_or_deployment_SLA':True,'N10_R08_sources_stable_own_cleanup_Telegram_durable_negative_retention':True}
assert all(requirements.values())
m.update(state='N10_ACCEPTED_LOCAL_SCOPED77_DISPOSITIONS',verified_scoped_dispositions=77,pending_selected_gaps=[],mandatory_accepted=10,acceptance_doc='docs/491-n10-aceptacion-local-operacion-20261026.md',current_product_commit='0dcf89ff1c6dcc9a2f7c3c29092a38de36d08c0a')
path.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
proof={'result':'PASS_N10_LOCAL_REQUIREMENTS_ACCEPTED_NOT_WHOLE_CONTRACT','requirements':requirements,'matrix':str(path),'matrix_sha256_before':hashlib.sha256(json.dumps(old,ensure_ascii=False,indent=2).encode()+b'\n').hexdigest(),'matrix_sha256_after':sha(path),'ids':77,'kind_counts':m['counts_by_kind'],'unchanged_other76rows':True,'pending_N10':[],'current_return_actual_run':f['run'],'C93byteidentical_plus1explicit_admin_bridge':C_source_drift,'native_case_roots':runs,'D_unique10_across2cuts_not_single10PASS':True,'mandatory_accepted':10,'mandatory_total':13,'remaining':['N11','N15','N02residual_user_deferred_to_development_end'],'conditioned':['N12','N13','N14'],'alpha_noindex':True,'whole_goal_complete':False}
(W/'acceptance-audit.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
