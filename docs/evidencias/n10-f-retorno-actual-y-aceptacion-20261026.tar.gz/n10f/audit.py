"""Original actual source-process return audit; no source-label-only acceptance."""
import hashlib,json,math,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
sys.path.insert(0,'scripts')
from run_local_ci import hashes
W=Path('artifacts/recorridos-n10-20261026/n10f');load=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=load(W/'freeze.json');im=load(W/'runtime-images.json');P=Path('artifacts/local-ci')/im['run'];r=load(P/'result.json')
assert r['result']=='PASS'and r['sources_unchanged']and r['workers']==1 and r['selection']==f['selection']
assert hashes()==load(P/'source-hashes.json')==f['sources']
for group in ['extra_sources','docs']:
 for p,h in f[group].items():assert sha(p)==h,p
assert sha('graphify-out/graph.json')==f['graph_sha256']
assert all(im[k]for k in ['matched_actual_runner_pid_and_start_ticks','all_observed','match_prelaunch_freeze'])
for name,row in r['cleanup'].items():
 assert row['absent']and row['removal_exit']==0
 assert subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0
assert not Path(load(P/'runner.json')['temporary']).exists()
telegram=load(P/'telegram-notification.json');assert telegram['delivery']=='sent'and telegram['result']=='PASS'
cases=list(ET.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==1
c=cases[0];assert all(c.find(k)is None for k in ['failure','error','skipped'])
d=json.loads(next(c.iter('property')).get('value'));assert d['current_product']=='0dcf89f'and d['previous_target']=='8589acd'and d['runtime_paths']==753 and d['runtime_delta']==['apps/core/admin.py']
assert d['installed_models']>=173 and d['media_files']==8
assert all(0<x<32*1024*1024 for x in d['exported_source_bytes'].values())and set(d['exported_source_bytes'])=={'current','previous'}
assert len(d['phases'])==3 and [v['source_phase']for v in d['phases']]==['current','previous','current']
current_hash=sha('apps/core/admin.py');previous_hash=hashlib.sha256(subprocess.check_output(['git','show','8589acd:apps/core/admin.py'])).hexdigest()
for phase in d['phases']:
 current=phase['source_phase']=='current';assert phase['source_admin_sha256']==(current_hash if current else previous_hash)
 assert phase['receiver_present']is current and phase['four_actual_sources_verified']and phase['ready_workers']==4
 assert math.isfinite(phase['spawn_to_ready_observed_seconds'])and 0<phase['spawn_to_ready_observed_seconds']<45 and phase['readiness_poll_seconds']==.05
 assert phase['master_exit']==0 and phase['children_absent']and phase['exact_all_rows_files_and_migrations_unchanged']
 assert len(phase['samples'])==2 and {v['label']:v['http_status']for v in phase['samples']}=={'health':200,'authorized_group_read':200}
 for sample in phase['samples']:assert math.isfinite(sample['seconds'])and 0<sample['seconds']<5 and sample['body_bytes']>0
proof={'result':'PASS_SCOPED_CURRENT_PREVIOUS_CURRENT_OWNED_SOURCE_PROCESS_RETURN','run':P.name,'counts':{'PASS':1,'FAIL':0,'ERROR':0,'SKIP':0},'junit_seconds':sum(float(s['time'])for s in r['junit']),'source_count':len(f['sources']),'sources_stable':True,'actual_JUnit_sha256':sha(P/'pytest.xml'),'actual':d,'images':im,'cleanup_verified':True,'telegram':telegram,'limits':['Source-process return, no imagebuild/switch or deployment claim','Alreadyadmittedsession/read continuity; previoussource lacksnativeAdminlogin epoch1fix, not a productive return approval','No writes during switch, traffic, mixedCeleryworkers or zerodowntime/SLA','All173model/throughrows8files/migrationrecords unchanged; twelve sourceverified workerinstances andsixHTTP200','Timingincludesreadinesspolling andlocalTCP, not capacity or universal app latency'],'N10_acceptance_pending_final_matrix_gate':True}
(W/'audit.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items()if k not in ['actual','images','telegram']}))
