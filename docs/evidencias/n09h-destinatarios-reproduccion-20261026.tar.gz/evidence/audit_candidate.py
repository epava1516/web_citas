import collections,hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
W=Path('artifacts/recorridos-n09-h-20261026');P=Path('artifacts/local-ci')/sys.argv[1]
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f,r,h=read(W/'candidate-freeze.json'),read(P/'result.json'),read(P/'source-hashes.json')
assert r['sources_unchanged'] and r['selection']==f['selection']
assert all(sha(p)==v for p,v in f['sources'].items())
assert set(f['sources'])-set(h)==set(f['sources_verified_separately'])
assert all(h[p]==v for p,v in f['sources'].items() if p in h)
cases=list(ET.parse(P/'pytest.xml').iter('testcase'));assert len(cases)==22
assert r['result']=='PASS'
assert all(c.find('failure')is None and c.find('error')is None and c.find('skipped')is None for c in cases)
records={}
for c in cases:
 props={p.get('name'):p.get('value') for p in c.iter('property')}
 if 'recipient_assessment_authority_wait'not in props:continue
 d=json.loads(props['recipient_assessment_authority_wait']);assert d['label'] not in records
 records[d['label']]={'runtime':d,'failure':c.find('failure')is not None,'error':c.find('error')is not None,'skip':c.find('skipped')is not None}
families=['assessment_inspect','assessment_propose','review_inspect','review_review']
assert set(records)=={a+':'+b for a in families for b in ['valid','permission']}
def wait_ok(row):
 d=row['runtime']
 return (d.get('actual_wait')
  and d.get('worker_pid')!=d.get('holder_pid') and d.get('holder_pid')in d.get('blocker_pids',[])
  and d.get('thread_finished') and d.get('connections_closed') and d.get('holder_released')
  and not d.get('final_snapshot_exception_type') and not row['error'] and not row['skip'])
def changes(d):
 if 'domain_before'not in d or 'domain_after'not in d:return None
 return sorted(k for k,v in d['domain_before']['tables'].items()if v!=d['domain_after']['tables'][k])
controls={};classified=[]
for family in families:
 row=records[family+':valid'];d=row['runtime'];expected={'safety.RightsAction'}
 if family in ['assessment_propose','review_review']:expected|={'safety.RightsRequest',('safety.RightsRectificationRecipientAssessment'if family=='assessment_propose'else'safety.RightsRectificationRecipientReview')}
 valid=bool(wait_ok(row) and not row['failure'] and d.get('status')=='success'
   and d.get('target_returns',0)>0 and set(changes(d)or[])==expected
   and d.get('files_before')==d.get('files_after'))
 controls[family]=valid
 classified.append({'family':family,'variant':'valid','verdict':'VALID_NATIVE_CONTROL'if valid else'INVALID_CONTROL_DIAGNOSTIC','changed_tables':changes(d),**row})
for label,row in records.items():
 family,variant=label.split(':')
 if variant=='valid':continue
 d=row['runtime'];admissible=bool(controls[family] and wait_ok(row))
 assert variant=='permission'
 admissible=bool(admissible and d.get('permission_revoked') and d.get('other_roles_preserved'))
 intact=(d.get('domain_before')==d.get('domain_after') and d.get('files_before')==d.get('files_after')
         and d.get('minimal_before')==d.get('minimal_after'))
 expected_status='PermissionDenied'if variant=='permission'else'ValidationError'
 private=d.get('target_returns_after_revocation',0)>0
 if not admissible:verdict='INVALID_NEGATIVE_DIAGNOSTIC'
 elif d.get('status')=='success' and private:
  verdict=('CONFIRMED_NATIVE_PRIVATE_RETURN_EFFECT_AFTER_PERMISSION_REVOCATION'if variant=='permission'
           else'CONFIRMED_NATIVE_PRIVATE_PROCESSING_AND_EFFECT_AFTER_PROOF_EXPIRED_DURING_WAIT')
 elif d.get('status')==expected_status and intact and private:
  verdict=('CONFIRMED_PRIVATE_TARGET_RETURN_BEFORE_LATE_PERMISSION_DENIAL'if variant=='permission'
           else'CONFIRMED_PRIVATE_TARGET_RETURN_BEFORE_LATE_PROOF_DENIAL')
 elif d.get('status')==expected_status and intact and not private and not row['failure']:
  assert d.get('target_calls_after_revocation',0)==0 
  verdict='DENIED_BEFORE_SELECTED_PRIVATE_BOUNDARY_NO_REPRODUCTION'
 else:verdict='UNCLASSIFIED_REQUIRES_REVIEW'
 classified.append({'family':family,'variant':variant,'verdict':verdict,'changed_tables':changes(d),**row})
for kind in ['container','volume','network']:
 cmd=['docker','ps','-aq']if kind=='container'else['docker',kind,'ls','-q']
 assert not subprocess.check_output(cmd+['--filter','label=web-modelos-local-ci-run='+P.name],text=True).strip()
assert not Path(read(P/'runner.json')['temporary']).exists()
tg=read(P/'telegram-notification.json');assert tg['delivery']=='sent'
counts=dict(collections.Counter(x['verdict']for x in classified))
assert counts=={'VALID_NATIVE_CONTROL':4,'DENIED_BEFORE_SELECTED_PRIVATE_BOUNDARY_NO_REPRODUCTION':4},counts
variants=[];originals=[]
for c in cases:
 props={p.get('name'):p.get('value')for p in c.iter('property')}
 if 'recipient_assessment_authority_wait'in props:continue
 if 'recipient_authority_variant'not in props:
  originals.append({'name':c.get('name'),'classname':c.get('classname'),'seconds':c.get('time')});continue
 d=json.loads(props['recipient_authority_variant']);label=d['label'];assert d['domain_before']==d['domain_after']and d['files_before']==d['files_after']and d['minimal_before']==d['minimal_after'];assert d['target_calls']==d['target_returns']==0
 if label.startswith('replay:'):
  assert d['actual_wait_claimed']and d['actual_wait']and d['holder_pid']!=d['worker_pid']and d['holder_pid']in d['blocker_pids'];assert d['thread_finished']and d['connections_closed']and d['holder_released']and not d.get('final_snapshot_exception_type')
  if label.endswith(':valid'):assert d['status']=='success'and d['same_completed_pk']
  else:assert d['status']=='PermissionDenied'and d['permission_revoked']and d['other_roles_preserved']
 else:assert label.startswith('stale:')and not d['actual_wait_claimed']and d['persisted_change_confirmed']and d['status']=='PermissionDenied'
 variants.append(d)
assert len(variants)==8and len({d['label']for d in variants})==8
assert {d['label']for d in variants}=={'replay:'+a+':'+b for a in ['assessment_propose','review_review']for b in ['valid','permission']}|{'stale:assessment_inspect:session','stale:review_inspect:mfa','stale:assessment_inspect:inactive','stale:review_inspect:mfa_disabled'}
assert len(originals)==6
assert sum('test_account_final_rectification_review_and_atomic_close'in c['name']for c in originals)==2
assert sum('test_native_form_values_and_generic_denial'in c['name']for c in originals)==2
assert sum(c['classname']=='tests.test_recipient_assessments'for c in originals)==2
assert sha('tests/test_recipient_assessment_authority_wait.py')=='6a0999b8ba9c55161f57e71bb13a43271598d65b806b871a44d1912bb17cadb9'
out={'result':'PASS_CANDIDATE22_LOCAL_RECIPIENT_BOUNDARIES_NOT_WHOLE_N09','run':P.name,'original_result':r['result'],'junit':r['junit'],'frozen_sources':len(f['sources']),'verdict_counts':counts,'cases':classified,'variants':variants,'original_cases':originals,'cleanup_verified':True,'telegram':tg,'limits':'4ops2routes/4controls4rolewithdrawals;nativeexacttargetunsealnotallprojections/HTTP/worker/provider. F75E38G18retained;N09full139open8of13.'}
(W/'candidate-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k not in ['cases','variants']}))
