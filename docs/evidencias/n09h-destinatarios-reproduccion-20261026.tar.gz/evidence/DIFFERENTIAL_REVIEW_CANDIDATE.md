# N09H revisión diferencial propia acotada

Riesgo alto: autoridad y material privado. Estrategia quirúrgica sobre tres módulos; no certificación global. Basef95b301, reproducción8auditable4controles4éxitosindebidosdocumentada443.

Modelo: operador inicialmente legítimo pierde review_rectification o review_recipient_assessment durante Inventory/Assessment bloqueada; original sigue con Usercached y devuelveprivados/Action(+Assessment/Review/Request). Cuatro servicios en dos vistas; no explotación HTTP demostrada.

Diff: captura original/epochs anteslocks; User nuevo/fullroles/scope después; callbacks a execution_scope_matches/snapshot. current comparte captura de review. Replay exige autoridad sin forzar proof activo o nueva versión. Comprobaciones originales de independencia/lecturas/firma/source/latest/integridad conservadas. Extra proofchecks activos no son diagnóstico dedicado de caducidad y no dan aceptación de esa condición.

Helper común añade sólo keywordFalse y rama extra rol; AST restante idéntico tras retirarlos. Defaults anteriores misma lista y cuerpos; no lock de User operador. Publicpermission y cuatro firmas intactas. Caller search capture_authority defaults anteriores no habilitan flag; sólo recipient_review lo activa. current sólo consumidores internos conocidos en ese módulo. Historia de tres archivos y cuerpos originales se contrastan con Git antes de aceptar. No nueva fuente SQLmanual/entradausuario/red/archivo/shell. No migraciones/settings/UI/proveedor.

Instrumentos8originalesintactos+8variantesnuevas;selección22pendiente runtime. Positivosconefectosexactos/negativosconsnapshots/archivos/through;replaymismoPKsinprivadosactivos;staleafterintendedmutation sinwaitclaim. Límites: nativeonly/exactselectedtargetnotallprojections/noHTTPworkerprovider/noappspeedclaim. Root aceptará sólo tras runner/auditoría/limpiezaTelegram. Otros139IDs siguen abiertos.

Historia comprobada: helper28a02db; módulosrecipient heredados831bbbcf con soporteaccount posterior02210aa/98c66a6. Gitblame70–90assessment confirma check previoInventory del original. Búsqueda de consumidores current no halló llamadas externas enapps/tests; firma interna sólo anidada.
