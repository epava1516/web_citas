# Grafo alfa — base operativa N01E prerregistrada

Contrato340/341:N00aceptado1/13,N01abierto. N01D11PASS109peticiones auditadas,sin optimización de aplicación. Nueva conciliación352de19fichas/93citas,6basesHTTPparciales;presupuestos pendientes donde falten. Plan operativo4casos/18llamadas de servicio,backlog publicación0/10/100,otras tablas vacías;aún sin resultados.

Refresco focal semántico nativo del protocolo352 más ASTnuevo tests/test_operational_snapshot_baseline.py,2funciones; ASTprevio preservado. No es reconstrucción completa ni semántica exhaustiva. 1943fuentes,18134nodos/80205relaciones,860comunidades; membresías previas preservadas y nueva comunidad.1506fuentes ejecutables originales intactas;runner de medición variante explícita. Consumo nativo desconocido. HTMLproyecta comunidades, JSONcompleto;100anotaciones ambiguas previas conservadas. Semántica y relaciones estáticas no prueban runtime. Vista17líneas1–4,exclusiones previas conservadas.

