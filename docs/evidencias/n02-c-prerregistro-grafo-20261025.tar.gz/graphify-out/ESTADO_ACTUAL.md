# Grafo alfa — contraste agrupado N02C prerregistrado

N00/N01aceptados2/13,N02/N06abiertos,alfa. Protocolo364:1caso previsto,120guards reales con transacción/holds por llamada;12grupos10,primera pareja separada y5posteriores. Todas las5medias del candidato y su mediana deben mejorar para conclusión temporal local;si no,sigue inconcluso,sin ampliar/repetir por conveniencia.7→4SQL,2lecturas/hash/4locks porguard previstos. Aplicación y anteriores instrumentos intactos;14oráculos/negativoN02B no se repiten. Resultado363inconcluso preservado;no aceptaciónMOD09/HTTP/p95/producción.

Refresco focal semántico364+ASTnuevoinstrumento4funciones;ASTprevio preservado. 1960fuentes,18400nodos/80853relaciones,871comunidades. Base completa previa conservada,no reconstrucción global ni semántica exhaustiva.1505ejecutables originales intactos,1runnerinstrumental y1candidato guard explícito.100anotacionesambiguas conservadas,JSONcompleto/HTMLcomunidades;consumo nativo desconocido.

