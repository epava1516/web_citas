from config.settings import *
MEDIA_ROOT = '/tmp/claude-1000/-home-eduardo-web-citas/eeb2c24f-16b2-430e-a2b3-463b581c3ef1/scratchpad/r5b_short/pytest-temp/test_contract_arrival_rate_htt0/private'
CELERY_TASK_ALWAYS_EAGER = True
CELERY_TASK_EAGER_PROPAGATES = True
CELERY_BEAT_SCHEDULE = {}
CELERY_RESULT_BACKEND = "cache+memory://"
