"""Independent source/result/observation audit of the finite service baseline."""
import hashlib,json,math,statistics,sys
from pathlib import Path
from xml.etree import ElementTree as ET
run=Path(sys.argv[1]);w=Path('artifacts/recorridos-n01-e-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=json.loads((run/'result.json').read_text());assert r['result']=='PASS' and r['sources_unchanged']
assert all(c['absent'] for c in r['cleanup'].values());assert json.loads((run/'telegram-notification.json').read_text())['delivery']=='sent'
f=json.loads((w/'freeze.json').read_text())
for p,h in f['sha256'].items():assert sha(p)==h,p
cases=ET.parse(run/'pytest.xml').findall('.//testcase');assert len(cases)==4
cohorts=[]
for c in cases:
 assert not any(c.find(k) is not None for k in ['failure','error','skipped'])
 props={p.attrib['name']:p.attrib['value'] for p in c.findall('./properties/property')}
 if 'n01e_snapshot_samples' not in props:
  assert c.attrib['name']=='test_empty_snapshot_has_explicit_scope_and_read_only_aggregates';continue
 samples=json.loads(props['n01e_snapshot_samples']);assert len(samples)==6
 count=samples[0]['publication_rows'];assert count in (0,10,100)
 for i,s in enumerate(samples):
  assert set(s)=={'sample','phase','publication_rows','service_seconds_instrumented','sql_queries','sql_execute_seconds'}
  assert s['sample']==i and s['publication_rows']==count and s['phase']==('first' if i==0 else 'warm')
  assert isinstance(s['sql_queries'],int) and s['sql_queries']>0
  for k in ['service_seconds_instrumented','sql_execute_seconds']:assert isinstance(s[k],(int,float)) and math.isfinite(s[k]) and s[k]>=0
 warm=[s['service_seconds_instrumented']*1000 for s in samples[1:]]
 cohorts.append({'publication_rows':count,'samples':samples,'first_service_ms':samples[0]['service_seconds_instrumented']*1000,'warm_median_service_ms':statistics.median(warm),'warm_range_service_ms':[min(warm),max(warm)],'sql_query_counts':[s['sql_queries'] for s in samples]})
assert sorted(c['publication_rows'] for c in cohorts)==[0,10,100]
a={'result':'PASS_FINITE_SNAPSHOT_SERVICE_BASELINE','run':str(run),'cases':4,'service_samples':18,'cohorts':sorted(cohorts,key=lambda c:c['publication_rows']),'pytest_command_seconds':next(x['seconds'] for x in r['steps'] if x['name']=='pytest'),'source_freeze_unchanged':True,'owned_resources_absent':True,'terminal_telegram':'sent','scope':'Only publication backlog varies; other durable work tables empty. Instrumented service calls, first separated from5warm, no load/SLO/candidate/causal optimization/restore/broker/storage claims. Original readonly companion passes.','sha256':{str(p):sha(p) for p in [run/'result.json',run/'pytest.xml',run/'source-hashes.json',w/'freeze.json']}}
(w/'snapshot-audit.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps({k:v for k,v in a.items() if k not in ('cohorts','sha256')}))
for c in a['cohorts']:print(json.dumps({k:v for k,v in c.items() if k!='samples'}))
