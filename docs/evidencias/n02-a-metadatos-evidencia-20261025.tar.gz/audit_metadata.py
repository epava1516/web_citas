"""Independent paired-mechanism evidence audit; no application acceptance."""
import collections
import hashlib
import json
import math
import statistics
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

w=Path('artifacts/recorridos-n02-a-20261025');run=Path(sys.argv[1])
def pairs(items):
    out={}
    for k,v in items:
        assert k not in out, k
        out[k]=v
    return out
def invalid(v):
    raise ValueError(v)
def parse(s):return json.loads(s,object_pairs_hook=pairs,parse_constant=invalid)
def read(p):return parse(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def finite(v):return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and v>=0
r=read(run/'result.json')
assert r['result']=='PASS' and r['sources_unchanged']
assert r['cleanup'] and all(v['absent'] for v in r['cleanup'].values())
assert read(run/'telegram-notification.json')['delivery']=='sent'
runner=read(run/'runner.json')
assert not Path(runner['temporary']).exists()
journal=[parse(line) for line in (run/'pytest-reports.jsonl').read_text().splitlines()]
assert len(journal)==15 and all(j['outcome']=='passed' and finite(j['duration']) for j in journal)
assert len({(j['nodeid'],j['when']) for j in journal})==15
assert all({j['when'] for j in journal if j['nodeid']==name}=={'setup','call','teardown'} for name in {j['nodeid'] for j in journal})
f=read(w/'freeze.json')
assert runner['command']==f['command'][1:]
for p,h in f['sha256'].items():assert sha(p)==h,p
cases=ET.parse(run/'pytest.xml').findall('.//testcase')
expected={'test_current_image_metadata_paired_reference','test_sixteen_images_four_calls_keep_sixty_four_physical_reads','test_bulk_fresh_metadata_is_three_queries_and_preserves_single_bytes','test_bulk_rejects_mapping_changed_during_actual_blob_lock_wait','test_reverse_bulk_and_single_readers_complete_with_real_pg_locks'}
assert len(cases)==5 and {c.get('name') for c in cases}==expected
for c in cases:assert not any(c.find(k) is not None for k in ('failure','error','skipped'))
c=next(c for c in cases if c.get('name')=='test_current_image_metadata_paired_reference')
props=pairs((p.get('name'),p.get('value')) for p in c.findall('./properties/property'))
samples=parse(props['n02a_image_metadata_samples']);assert len(samples)==24
assert {(s['cohort'],s['round'],s['method']) for s in samples}=={(c,i,m) for c in (0,1) for i in range(6) for m in ('single','bulk')}
for s in samples:
    assert s['django_debug'] is False and s['revisions']==1500
    assert s['phase']==('first' if s['round']==0 else 'warm')
    assert s['physical_reads']==16 and abs(s['physical_bytes']-64*1024**2)<=.01*64*1024**2
    assert abs(s['candidate_bytes']-16*1024**2)<=.01*16*1024**2
    assert s['sql_queries']==(48 if s['method']=='single' else 3)
    assert all(finite(s[k]) for k in ('service_seconds_instrumented','thread_cpu_seconds','sql_execute_seconds'))
    assert len(s['manifest_digest'])==64 and int(s['manifest_digest'],16)>=0
summaries=[]
for cohort in (0,1):
    cohort_samples=[s for s in samples if s['cohort']==cohort]
    for k in ('physical_bytes','candidate_bytes','manifest_digest'):assert len({s[k] for s in cohort_samples})==1
    first={};warm={}
    for method in ('single','bulk'):
        selected=[s for s in cohort_samples if s['method']==method]
        first[method]=selected[0]['service_seconds_instrumented']*1000
        values=[s['service_seconds_instrumented']*1000 for s in selected if s['phase']=='warm'];assert len(values)==5
        warm[method]={'median_ms':statistics.median(values),'min_ms':min(values),'max_ms':max(values),'samples':5}
    before=warm['single']['median_ms'];after=warm['bulk']['median_ms']
    summaries.append({'cohort':cohort,'first_ms':first,'warm':warm,'median_reduction_ms':before-after,'median_reduction_percent':100*(before-after)/before,'sql_before':48,'sql_after':3,'reads_each':16,'bytes_each':cohort_samples[0]['physical_bytes']})
artifacts=[run/'result.json',run/'pytest.xml',run/'source-hashes.json',run/'pytest-reports.jsonl',w/'freeze.json',run/'runner.json',run/'native-manifest.json',run/'telegram-notification.json',Path(__file__)]
a={'result':'PASS_N02A_PAIRED_EXISTING_HELPERS','run':str(run),'cases':5,'samples':samples,'summary':summaries,'source_freeze_unchanged':True,'owned_resources_absent':True,'terminal_telegram':'sent','pytest_command_seconds':next(s['seconds'] for s in r['steps'] if s['name']=='pytest'),'scope':'Same-input existing helper mechanisms only, no integrated caller/application optimization or MOD09 p95 acceptance','sha256':{str(p):sha(p) for p in artifacts}}
(w/'metadata-audit.json').write_text(json.dumps(a,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in a.items() if k not in ('samples','sha256')}))
