# Grafo alfa — referencia encolada N06B prerregistrada

N00/N01aceptados2/13,N06abierto. Protocolo358:2casos/3inicios previstos,originales sin modificar,preparación eager y medición noeager con PostgreSQL/Redis propios y worker prefork2 con rol restringido real. Sin Beat/TCP/capacidad/proveedores;relojes petición/publicación-inicio/worker/disponibilidad observada separados. Comparación de modalidades no es optimización de código. Sin resultado nuevo todavía.

Refresco focal semántico nativo358 más ASTnuevo test_listing_start_queued_baseline.py,10nodos propios/43relaciones/8funciones. 1951fuentes,18261nodos/80502relaciones,865comunidades. ASTprevio/base reconstruida preservados,no reconstrucción completa ni semántica exhaustiva.1506ejecutables originales intactos,runner variante instrumental;consumo nativo desconocido. JSONcompleto/HTMLcomunidades;100anotaciones ambiguas/exclusiones previas conservadas,vista17líneas1–4. Semántica no prueba runtime.

