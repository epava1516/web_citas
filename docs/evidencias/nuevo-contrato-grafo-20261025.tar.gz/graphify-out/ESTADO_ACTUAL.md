# Grafo alfa — preparación del siguiente contrato de recorridos

Contrato anterior cerrado localmente por acta23 y commit16ac270:15/18aceptados;B14/B15/B17deuda, noPASS. Su grafo de cierre y archivos permanecen inmutables en docs/evidencias/contrato-grafo-registro-final-20261025.json. Base original reconstruida desde cero:1922fuentes,AST/semántica y28lotes. Refrescos posteriores son focales y explícitos, no nuevas reconstrucciones completas.

Nuevo contrato340 yroadmap341 preparados documentalmente a petición del usuario; ejecución técnica no iniciada:0/13bloques obligatorios aceptados,N12–N14condicionados. Inventario I01–I28primero;MOD09/I14yrecorridos como prioridad,QAespecífico aplazado. Proyecto enalfa;sin nuevos proveedores,personalización,datos reales oapertura.

Este refresco: 4 documentos, 75 entidades/221 relaciones semánticas nativas con cita,líneas ySHA comprobados. ASTsin cambios. Corpus vigente1927fuentes,17943nodos/79871relaciones,849comunidades. Se conservan membresías de base y se añade una comunidad documental;no detección global nueva. Seguimiento17sólo líneas1–4,con huellas separadas delarchivo completo yvista. Historial/evidencias masivas/vendor yotras exclusiones permanecen explícitas en política.

Semántica selectiva y referencias estáticas;no prueba de runtime,permisos,coste,seguridad,legalidad oPASS. Entidades antiguas sustituidas aún citadas desde otras fuentes conservan handles noresueltos, sin implementación inventada. Las100anotaciones ambiguas de llamadas/bases son anotaciones, no dependencias a sí mismas. Consumo nativo desconocido;ceros técnicos delgenerador no son coste cero.

JSON contiene elgrafo completo;HTMLproyecta sólo comunidades, manteniendo guarda de5000nodos sin abrir un render completo.

