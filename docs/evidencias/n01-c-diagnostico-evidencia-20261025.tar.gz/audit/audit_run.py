"""Audit paired native-state diagnosis after terminal notification."""
import hashlib,json,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
W=Path('artifacts/recorridos-n01-c-20261025');RUN=Path(sys.argv[1]);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=json.loads((W/'freeze.json').read_text());r=json.loads((RUN/'result.json').read_text());runner=json.loads((RUN/'runner.json').read_text())
assert r['result']=='PASS' and r['sources_unchanged'] and r['workers']==1 and all(s['exit']==0 for s in r['steps'])
for p,h in f['product_sha256'].items():assert sha(p)==h,p
for p,h in f['instrument_documents_graph_sha256'].items():assert sha(p)==h,p
cases=list(ET.parse(RUN/'pytest.xml').getroot().iter('testcase'));assert len(cases)==1
c=cases[0];node=c.get('file')+'::'+c.get('name');assert [node]==f['selected']
assert all(c.find(k) is None for k in ('failure','error','skipped'))
p={q.get('name'):q.get('value') for q in c.findall('./properties/property')};o=json.loads(p['n01c_observations']);assert set(o)=={'before','after'} and int(p['measured_requests'])==120
expected=[(lang,name) for lang in ('es','en') for name in ('listing','page2','profile','empty','detail')]
summary=[]
for phase in o:
 assert [(s['language'],s['scenario']) for s in o[phase]]==expected
 assert all(s['population']==100 and len(s['samples'])==6 and [q['index'] for q in s['samples']]==list(range(6)) for s in o[phase])
for a,b in zip(o['before'],o['after'],strict=True):
 assert a['expected_total']==b['expected_total']
 for old,new in zip(a['samples'],b['samples'],strict=True):
  assert old['ordered_ids_sha256']==new['ordered_ids_sha256'] and old['returned_count']==new['returned_count']
  assert old['seconds_instrumented']>0 and new['seconds_instrumented']>0 and old['queries']>0 and new['queries']>0
  if a['scenario'] in {'listing','page2','profile'}:assert old['route']=='fallback' and old['reason']=='state_unknown_over_limit'
  if b['scenario']!='detail':assert new['route']=='state'
 summary.append({'language':a['language'],'scenario':a['scenario'],'before_median5_seconds':a['subsequent_median_seconds'],'after_median5_seconds':b['subsequent_median_seconds'],'before_sql':sorted({s['queries'] for s in a['samples']}),'after_sql':sorted({s['queries'] for s in b['samples']}),'before_routes':sorted({str(s['route']) for s in a['samples']}),'after_routes':sorted({str(s['route']) for s in b['samples']})})
j=[json.loads(line) for line in (RUN/'pytest-reports.jsonl').read_text().splitlines()];assert len(j)==3 and {q['when'] for q in j}=={'setup','call','teardown'} and all(q['outcome']=='passed' and q['nodeid']==node for q in j)
for name,state in r['cleanup'].items():
 assert state['absent'];q=subprocess.run(['docker','container','inspect','--format','{{.Id}}',name],capture_output=True,text=True);assert q.returncode and 'no such' in(q.stdout+q.stderr).lower()
assert not Path(runner['temporary']).exists() and json.loads((RUN/'telegram-notification.json').read_text())['delivery']=='sent'
result={'result':'PASS_N01C_AUDIT','run':str(RUN),'pass':1,'fail':0,'error':0,'skip':0,'measured_requests':120,'phases':2,'segments_per_phase':10,'samples_per_segment':6,'preparation_seconds':float(p['preparation_seconds']),'dirty_before':int(p['preparation_dirty_before']),'all_listings_prepared_count':int(p['prepared_listing_count']),'summary':summary,'observations':o,'pytest_step_seconds':next(s['seconds'] for s in r['steps'] if s['name']=='pytest'),'frozen_original_sources_unchanged':1507,'helper_B_and_new_C_unchanged':True,'frozen_protocol_graph_unchanged_until_audit':True,'containers_temporary_absent':True,'telegram_delivery':'sent','product_changes':0,'N01_complete':False,'N04_complete':False,'limits':['Preparation command also updates PostgreSQL statistics/VACUUM; phaseorderandwarmupfixed. Notpurestateorcodeoptimization causalcomparison.','No realworkerBeatthroughput,TCP,p95,concurrency/capacity/othercohorts or allfilters/promotions.','Business-field equality/currentstate/zeroDirty and originalBresponseoracles checked by frozenCtest; audit checks source and success.'],'original_sha256':{q.name:sha(q) for q in RUN.iterdir() if q.is_file() and q.suffix in('.json','.jsonl','.xml','.log')},'freeze_sha256':sha(W/'freeze.json')}
Path('docs/evidencias/n01-c-diagnostico-auditoria-20261025.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in('observations','original_sha256')}))
