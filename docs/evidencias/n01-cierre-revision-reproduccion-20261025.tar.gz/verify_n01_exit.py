"""Verify N01 exit evidence, without repeating application batteries."""
import ast,hashlib,json,re,shutil
from pathlib import Path
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pairs(xs):
 d={}
 for k,v in xs:
  assert k not in d,k
  d[k]=v
 return d
def read(p):return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
w=Path('artifacts/recorridos-n01-f-20261025');rr=Path('/tmp/web-modelos-n01-sufficiency-review/report.json');review=read(rr);assert review['STATUS']=='complete' and not review['UNRESOLVED_ISSUES'];shutil.copy2(rr,w/'sufficiency/report.json')
policy='docs/354-n01-f-criterios-comparacion-escenarios-20261025.md';matrix='docs/evidencias/n01-f-criterios-escenarios-20261025.json';act='docs/355-n01-aceptacion-local-20261025.md';x=read(matrix);assert x['policy_sha256']==sha(policy)
n00=read('docs/evidencias/n00-matriz-acciones-prioridades-20261025.json');ids={r['id'] for r in n00['actions']};assert len(x['scenarios'])==19
families={'I01','I02','I03','I04','I05'};selectors=set();actions=set();text=Path(act).read_text()
assert '## Antes y después del bloque N01' in text and '| S01/N04 |' in text
for r in x['scenarios']:
 assert all(a in ids for a in r['actions']);actions.update(r['actions']);families.update(r['families'])
 assert re.search(r'^\| '+re.escape(r['id'])+r'/',text,re.M),r['id']
 assert r['budget_decision']['status']=='comparative_efficiency_criterion_selected_before_candidate'
 assert r['dataset_source_scope'] and r['roles'] and r['oracles'] and r['technical_criterion'] and r['before_candidate_requirements']
 for s in r['selectors']:
  p,fn=s['selector'].split('::');assert sha(p)==s['source_sha256'],p
  found=[n for n in ast.parse(Path(p).read_text()).body if isinstance(n,ast.FunctionDef) and n.name==fn];assert len(found)==1
  assert (found[0].lineno,found[0].end_lineno)==(s['line_start'],s['line_end']);selectors.add(s['selector'])
assert families=={f'I{i:02}' for i in range(1,29)}
audits=[]
for letter in ['a','b','c']:
 p=Path(f'docs/evidencias/n01-{letter}-diagnostico-auditoria-20261025.json');a=read(p);assert a['result'].startswith('PASS') and a['fail']==a['error']==a['skip']==0
 for name,h in a['original_sha256'].items():assert sha(Path(a['run'])/name)==h,(letter,name)
 raw=read(Path(a['run'])/'result.json');assert raw['result']=='PASS' and raw['sources_unchanged'];assert all(v['absent'] for v in raw['cleanup'].values());assert read(Path(a['run'])/'telegram-notification.json')['delivery']=='sent'
 audits.append({'path':str(p),'sha256':sha(p),'result':a['result']})
for name,cases,samples,key in [('n01-d-operaciones-auditoria',11,109,'operation_samples'),('n01-e-snapshot-auditoria',4,18,'service_samples')]:
 p=Path('docs/evidencias/'+name+'-20261025.json');a=read(p);assert a['result'].startswith('PASS') and a['cases']==cases and a[key]==samples and a['terminal_telegram']=='sent'
 for file,h in a['sha256'].items():assert sha(file)==h,file
 audits.append({'path':str(p),'sha256':sha(p),'result':a['result']})
product=read('docs/evidencias/b16-final-candidate-reconciliation-20261025.json')['current_versioned_executable_sources'];assert len(product)==1507
for p,h in product.items():
 if p!='scripts/run_local_ci.py':assert sha(p)==h,p
assert sha('docs/111-inventario-rendimiento-recorridos-beta-20261020.md')=='380b026c51b5e9647052838bb77a0712e9efff4ccdd857b5df3d4b545d921a95'
result={'result':'PASS_N01_EXIT_EVIDENCE','scope':'Planning and prior criteria accepted; not performance acceptance of N02-N10. All missing reference requirements preserved before candidates.','scenarios_S02_S09':19,'S01_separate_protocols_preserved':True,'families':28,'distinct_selected_action_references':len(actions),'unique_existing_selectors':len(selectors),'global_before_after_rows':20,'existing_executable_sources_unchanged':1506,'runner_measurement_variant':1,'no_application_candidate_changes':True,'audits':audits,'sha256':{p:sha(p) for p in [policy,matrix,act,str(w/'sufficiency/task.json'),str(w/'sufficiency/report.json')]},'technical_acceptance_by':'Codex','next_mandatory_accepted':2,'next_mandatory_total':13,'phase':'alpha'}
Path('docs/evidencias/n01-aceptacion-verificacion-20261025.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('sha256','audits')}))
