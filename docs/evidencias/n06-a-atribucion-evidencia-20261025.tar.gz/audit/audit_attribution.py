"""Audit finite attribution identity, original outcomes and scalar-only metrics."""
import hashlib,json,math,os,sys
from pathlib import Path
from xml.etree import ElementTree as ET
from django.apps import apps
import django

sys.path.insert(0, str(Path.cwd()))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
django.setup()
run=Path(sys.argv[1]);w=Path('artifacts/recorridos-n06-a-20261025');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=json.loads((run/'result.json').read_text());assert r['result']=='PASS' and r['sources_unchanged'];assert all(c['absent'] for c in r['cleanup'].values());assert json.loads((run/'telegram-notification.json').read_text())['delivery']=='sent'
f=json.loads((w/'freeze.json').read_text())
for p,h in f['sha256'].items():assert sha(p)==h,p
cases=ET.parse(run/'pytest.xml').findall('.//testcase');assert len(cases)==2
allowed={'ordinal','case','status','request_seconds_instrumented','sql_queries','sql_execute_seconds','stages','known_table_query_occurrences','verbs','task_always_eager'}
labels={'photo_task_eager','state_task_eager','create_draft','manager_authority','request_other'}
tables={m._meta.db_table for m in apps.get_models(include_auto_created=True)};samples=[]
for c in cases:
 assert not any(c.find(k) is not None for k in ['failure','error','skipped'])
 props={p.attrib['name']:p.attrib['value'] for p in c.findall('./properties/property')};items=json.loads(props['n06a_start_samples'])
 case='rejected_correction' if 'rejected_correction' in c.attrib['name'] else 'approved';assert len(items)==(2 if case=='rejected_correction' else 1)
 for ordinal,s in enumerate(items,1):
  assert set(s)==allowed and s['case']==case and s['ordinal']==ordinal and s['status']==302 and s['task_always_eager'] is True
  assert set(s['stages'])<=labels
  assert {'photo_task_eager','state_task_eager','create_draft','manager_authority'}<=set(s['stages'])
  assert s['sql_queries']==sum(v['sql_queries'] for v in s['stages'].values())==sum(s['verbs'].values())
  assert set(s['known_table_query_occurrences'])<=tables
  assert set(s['verbs'])<={'SELECT','INSERT','UPDATE','DELETE','SET','BEGIN','COMMIT','ROLLBACK','SAVEPOINT','RELEASE','OTHER'}
  for v in [s,*s['stages'].values()]:
   assert isinstance(v['sql_queries'],int) and v['sql_queries']>0
   assert isinstance(v['sql_execute_seconds'],(int,float)) and math.isfinite(v['sql_execute_seconds']) and v['sql_execute_seconds']>=0
  assert math.isfinite(s['request_seconds_instrumented']) and s['request_seconds_instrumented']>=s['sql_execute_seconds']
  assert all(isinstance(v,int) and v>0 for v in [*s['verbs'].values(),*s['known_table_query_occurrences'].values()])
  samples.append(s)
assert len(samples)==3
out={'result':'PASS_N06A_ATTRIBUTION_AUDIT','run':str(run),'cases':2,'start_samples':3,'samples':samples,'sources_unchanged':True,'owned_resources_absent':True,'terminal_telegram':'sent','pytest_command_seconds':next(s['seconds'] for s in r['steps'] if s['name']=='pytest'),'scope':'Instrumented successful start POSTs, original oracles and eager fixture preserved; SQL code-stack stage attribution, not broker/worker latency or CPU-stage wall attribution. No app candidate or optimization claim.','sha256':{str(p):sha(p) for p in [run/'result.json',run/'pytest.xml',run/'source-hashes.json',w/'freeze.json']}}
(w/'attribution-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ('samples','sha256')}))
for s in samples:print(json.dumps({k:s[k] for k in ['case','ordinal','sql_queries','stages']}))
