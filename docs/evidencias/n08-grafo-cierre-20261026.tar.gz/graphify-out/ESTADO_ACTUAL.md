# Grafo alfa — N08 aceptado localmente,8/13

417:17IDs en6grupos y8criterios; A2 único cambio de app2handlers aceptado412, B3válidos415/C1correctivo416 retenidos. Primer3PASS1FAIL preservado, no20PASSintegrados ni77nuevos, no2hijosejecutores. Tablas causales A2 y referencias actuales sin ganancias inventadas. N09 siguiente; N02restantealfinal sinPASStemporal,N12–14condicionados. Objetivocompleto aúnactivo, sinbeta/proveedores/reescriturafrontend.

Semántica417/full341/17top4nativa;16bloques28familias y66IDsroadmap previos preservados, N15relevofrontend futuro. 2035fuentes/19645nodos/83700relaciones/939comunidades. Actualizaciónfocal sobrebasepreservada,noN15rebuildniexhaustividadsemántica. Nativeusageunknown, userlateralpreservado/nostagingajeno.

