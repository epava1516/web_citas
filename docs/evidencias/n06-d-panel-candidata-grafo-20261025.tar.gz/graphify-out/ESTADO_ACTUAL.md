# N06D — candidata local aplicada, todavía sin medir

Referencia panel6PASS: propietario9/18/108SQL por1/10/100editores, editor7SQL. Candidata sólo añade select_related("user") a miembros activos para propietario. AST de fuente reextraído con forma idéntica; no detecta esta cadena de método. Identidad y diff exactos verificados por separado; no se afirma semántica exhaustiva ni mejora aún.

# Grafo alfa — Crecimiento del panel N06D preparado

N00/N01aceptados2/13. N02D367:1FAILtemporal2004,770sJUnit,no mejora global clara. Usuario acepta tiempos actuales en alfa y difiere optimización restanteMOD09al final del desarrollo. Guard local365conservado,2s/5s/FAILy deuda intactos,sin repetir batería. N06abierto: referencia encolada359,restantes variantes pendientes. Compactación y reactivación del mismo goal confirmadas por auditoría367, no nueva prueba de runtime del grafo.

N06C369:2PASS44HTTP,referencia de representación/MFA/revocación sin mejora de aplicación ni cierreN06. Hipótesis panel por editor pendiente de medir. Protocolo370: medir referencia primero, candidato select_relateduser sólo si N+1demostrado. Seis casos/cohortes1/10/100ESEN,propietario/editor,72muestras,primeraseparada+5posteriores. Sin ejecución ni cambio de aplicación aún. Refresco focal370yASTinstrumentopanel,previo preservado. 1968fuentes,18490nodos/81031relaciones,877comunidades. No reconstrucción global ni semántica exhaustiva. Relaciones documentales son afirmaciones de fuentes, no ejecución independiente. Consumo nativo desconocido. JSONcompleto y HTMLde comunidades; anotaciones ambiguas y multirrelaciones conservadas.

