import json,os,sys,time
from n02d_common import ROOT,WORK,SPEC,save
from codex_event_rpc import Rpc
sys.path.insert(0,str(ROOT/'scripts'))
from test_notifications import notify
save('n02d-auto-resume-state',{'state':'ARMED_WAITING_FOR_TERMINAL','pid':os.getpid(),'model_polling':False})
while True:
    try:terminal=json.loads((WORK/'n02d-background-watch-state.json').read_text())
    except (OSError,ValueError):terminal={}
    if terminal.get('state') in {'TERMINAL_NOTICE_CONFIRMED','FALLBACK_NOTICE_SENT','NOTICE_FAILED'}:break
    time.sleep(10)
try:
    rpc=Rpc()
    try:
        goal=rpc.call('thread/goal/get',{'threadId':SPEC['thread_id']})['goal']
        if not goal or goal['objective']!=SPEC['objective'] or goal['createdAt']!=SPEC['goal_created_at']:
            save('n02d-auto-resume-state',{'state':'SKIPPED_GOAL_IDENTITY_CHANGED'});raise SystemExit(0)
        if goal['status']=='paused':
            authorization=WORK/'n02d-pause-authorized.json'
            if not authorization.exists():
                save('n02d-auto-resume-state',{'state':'SKIPPED_NO_AUTHORIZED_TEST_PAUSE'});raise SystemExit(0)
            pause_file=WORK/'n02d-pause-receipt.json'
            for _ in range(30):
                if pause_file.exists():break
                time.sleep(1)
            pause=json.loads((pause_file if pause_file.exists() else authorization).read_text())
            if pause['goal_created_at']!=goal['createdAt'] or (WORK/'n02d-cancel-autoresume.json').exists():
                save('n02d-auto-resume-state',{'state':'SKIPPED_PAUSE_IDENTITY_CHANGED_OR_CANCELLED'});raise SystemExit(0)
            after=rpc.call('thread/goal/set',{'threadId':SPEC['thread_id'],'status':'active','origin':'user'})['goal']
            assert after['status']=='active' and after['createdAt']==goal['createdAt'] and after['objective']==goal['objective']
            assert after['tokensUsed']>=goal['tokensUsed'] and after['timeUsedSeconds']>=goal['timeUsedSeconds']
            assert after['tokenBudget']==goal['tokenBudget']
            save('n02d-resume-identity',{'createdAt_before':goal['createdAt'],'createdAt_after':after['createdAt'],'tokens_before':goal['tokensUsed'],'tokens_after':after['tokensUsed'],'seconds_before':goal['timeUsedSeconds'],'seconds_after':after['timeUsedSeconds'],'same_budget':True,'objective_omitted_in_request':True})
            state='RESUMED_AFTER_TERMINAL'
        elif goal['status']=='active':state='ALREADY_ACTIVE_AFTER_TERMINAL'
        else:
            save('n02d-auto-resume-state',{'state':'SKIPPED_GOAL_STATUS_CHANGED','goal_status':goal['status']});raise SystemExit(0)
    finally:rpc.close()
    notice=notify('N02D terminada; mismo objetivo activo, historial conservado. Revisar evidencia antes de aceptar o repetir.','REACTIVADO')
    save('n02d-auto-resume-state',{'state':state,'usage_history_preserved':True,'new_goal_created':False,'terminal_state':terminal.get('state'),'telegram':notice})
except Exception as error:
    notice=notify('N02D terminó pero falló la reactivación automática; revisar control y reactivar manualmente','ERROR REACTIVACIÓN')
    save('n02d-auto-resume-state',{'state':'AUTO_RESUME_FAILED','error_type':type(error).__name__,'telegram':notice})
    raise SystemExit(1)
