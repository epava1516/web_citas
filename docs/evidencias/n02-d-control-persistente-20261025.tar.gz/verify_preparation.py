"""Read-only control wiring, RPC identity and fixed single-sequence verification."""
import ast,hashlib,json,os,subprocess
from pathlib import Path
from codex_event_rpc import Rpc
w=Path(__file__).resolve().parent;spec=json.loads((w/'execution-spec.json').read_text())
assert spec['thread_id']==os.environ['CODEX_THREAD_ID']
rpc=Rpc()
try:
 g=rpc.call('thread/goal/get',{'threadId':spec['thread_id']})['goal'];assert g['status']=='active' and g['createdAt']==spec['goal_created_at'] and g['objective']==spec['objective']
finally:rpc.close()
for name in ['run_sequence.py','watch_terminal.py','resume_on_terminal.py','compact_after_pause.py','n02d_common.py','codex_event_rpc.py']:ast.parse((w/name).read_text())
assert hashlib.sha256((w/'codex_event_rpc.py').read_bytes()).hexdigest()==hashlib.sha256((w.parent/'beta-promotion-fix-20261020/codex_event_rpc.py').read_bytes()).hexdigest()
resume=(w/'resume_on_terminal.py').read_text();tree=ast.parse(resume);updates=[]
for n in ast.walk(tree):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='call' and n.args and isinstance(n.args[0],ast.Constant) and n.args[0].value=='thread/goal/set':updates.append(n)
assert len(updates)==1;params=updates[0].args[1];assert isinstance(params,ast.Dict);assert {k.value for k in params.keys}=={'threadId','status','origin'}
assert 'tokensUsed' in resume and 'timeUsedSeconds' in resume and 'tokenBudget' in resume and 'n02d-pause-authorized.json' in resume
compact=(w/'compact_after_pause.py').read_text();assert "'thread/compact/start'" in compact and "value=='completed'" in compact and "ids[0] not in before_turns" in compact and 'n02d-pause-authorized.json' in compact
main=(w/'run_sequence.py').read_text();assert "for phase in ('preflight','full')" in main and "report['result']=='READY_NOT_CAPACITY'" in main
for p in ['apps/safety/rights_portability_export.py','tests/test_held_seal_image_batch.py','tests/test_held_seal_guard_grouped_reference.py']:
 prior=json.loads(Path('artifacts/local-ci/20261025-134320-fefba16c/source-hashes.json').read_text());assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==prior[p]
full=spec['commands']['full'];pre=spec['commands']['preflight'];assert '--delivery-complete' in full and '--selection-concurrent' in full and '--preflight-only' in pre
for command in [full,pre]:assert command[-2:]==['--app-image',spec['image']] and command[command.index('--cpu-budget')+1]=='8'
assert not subprocess.check_output(['docker','ps','-q','--filter','label=web-modelos-capacity-run'],text=True).strip()
out={'result':'PASS_N02D_PREPARATION_NOT_RUNTIME','same_goal_verified':True,'goal_created_at':g['createdAt'],'single_fixed_preflight_then_full':True,'status_only_resume_no_objective_budget_mutation':True,'compaction_requires_new_completed_item':True,'rpc_helper_byte_identical':True,'application_and_previous_instruments_unchanged':True,'pending':'actualreadiness/fulllaunch/PIDchecks/prepausenotice/pause/compaction/autoresumeterminalaudit'}
(w/'preparation-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
