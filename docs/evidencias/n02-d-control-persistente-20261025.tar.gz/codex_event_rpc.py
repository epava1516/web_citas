"""Local documented App Server WebSocket over Unix; no model invocation."""
import base64,hashlib,json,os,socket,struct,time
from pathlib import Path
class Rpc:
    def __init__(self):
        self.sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);self.sock.settimeout(15)
        self.sock.connect(str(Path.home()/'.codex/app-server-control/app-server-control.sock'));self.next_id=0
        key=base64.b64encode(os.urandom(16)).decode()
        self.sock.sendall(('GET / HTTP/1.1\r\nHost: localhost\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: '+key+'\r\nSec-WebSocket-Version: 13\r\n\r\n').encode())
        h=b''
        while not h.endswith(b'\r\n\r\n'):
            h+=self.read(1)
            if len(h)>16384:raise RuntimeError('Oversized handshake')
        expected=base64.b64encode(hashlib.sha1((key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest())
        assert h.startswith(b'HTTP/1.1 101') and expected.lower() in h.lower()
        self.call('initialize',{'clientInfo':{'name':'web_modelos_terminal_wakeup','version':'1.0'},'capabilities':{'experimentalApi':True}})
        self.send({'method':'initialized','params':{}})
    def read(self,n):
        out=b''
        while len(out)<n:
            part=self.sock.recv(n-len(out))
            if not part:raise RuntimeError('App Server disconnected')
            out+=part
        return out
    def frame(self,payload,opcode=1):
        n=len(payload);head=bytes([128|opcode,128|(n if n<126 else 126 if n<65536 else 127)])
        if n>=126:head+=struct.pack('!H' if n<65536 else '!Q',n)
        mask=os.urandom(4);self.sock.sendall(head+mask+bytes(v^mask[i%4] for i,v in enumerate(payload)))
    def send(self,msg):self.frame(json.dumps(msg).encode())
    def receive(self):
        while True:
            a,b=self.read(2);n=b&127
            if n==126:n=struct.unpack('!H',self.read(2))[0]
            elif n==127:n=struct.unpack('!Q',self.read(8))[0]
            if n>32*1024**2:raise RuntimeError('Oversized App Server frame')
            mask=self.read(4) if b&128 else None;payload=self.read(n)
            if mask:payload=bytes(v^mask[i%4] for i,v in enumerate(payload))
            op=a&15
            if op==9:self.frame(payload,10);continue
            if op==8:raise RuntimeError('App Server closed')
            if op!=1 or not a&128:raise RuntimeError('Unexpected fragmented/control frame')
            return json.loads(payload)
    def call(self,method,params):
        self.next_id+=1;rid=self.next_id;self.send({'id':rid,'method':method,'params':params});end=time.monotonic()+20
        while time.monotonic()<end:
            msg=self.receive()
            if msg.get('id')!=rid:continue
            if 'error' in msg:raise RuntimeError(method+' error code '+str(msg['error'].get('code')))
            return msg.get('result')
        raise TimeoutError(method)
    def close(self):self.sock.close()
if __name__=='__main__':
    client=Rpc()
    try:
        result=client.call('thread/goal/get',{'threadId':'01a156b0-f93d-7162-86c8-f0024d0abfd2'})
        goal=result['goal'];assert goal['objective']=='vamos con el nuevo contrato'
        print(json.dumps({'same_thread_verified':True,'status':goal['status'],'tokensUsed':goal['tokensUsed']}))
    finally:client.close()
