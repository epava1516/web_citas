import json,os,re,subprocess,sys,time
from n02d_common import ROOT,WORK,save,alive
sys.path.insert(0,str(ROOT/'scripts'))
from test_notifications import notify
save('n02d-background-watch-state',{'state':'WAITING_EXISTING_RUN','pid':os.getpid()})
while not (WORK/'n02d-launch.json').exists():time.sleep(1)
meta=json.loads((WORK/'n02d-launch.json').read_text())
while alive(meta['main']):time.sleep(15)
# If the supervisor died, an owned runner may still be doing cleanup; wait for it.
try:runner=json.loads((WORK/'n02d-runner-state.json').read_text())['runner']
except (OSError,KeyError,ValueError):runner=None
while runner and alive(runner):time.sleep(15)
# Also wait for the actual launcher/controller if its wrapper disappeared.
try:
    state=json.loads((WORK/'n02d-runner-state.json').read_text());phase=state['phase']
    ids=set(re.findall(r'artifacts/capacity-environment/(\d{8}-\d{6}-[0-9a-f]{8})',(WORK/(phase+'-runner.log')).read_text()))
    if len(ids)==1:
        run=ids.pop();launched=json.loads((ROOT/'artifacts/capacity-environment'/run/'launcher-started.json').read_text())
        while alive({'pid':launched['pid'],'start_ticks':launched['start_ticks']}):time.sleep(15)
        while True:
            observed=subprocess.run(['docker','container','inspect','--format','{{json .State.Running}}',launched['controller']],capture_output=True,text=True,timeout=30)
            if observed.returncode!=0 or observed.stdout.strip()!='true':break
            time.sleep(15)
except (OSError,ValueError,KeyError,subprocess.SubprocessError):pass
try:
    r=json.loads((WORK/'n02d-sequence-result.json').read_text());assert r['notice']['delivery']=='sent'
    save('n02d-background-watch-state',{'state':'TERMINAL_NOTICE_CONFIRMED','result':r})
except Exception:
    receipt=notify('N02D terminó sin control terminal completo; revisar artefactos y limpieza','AVISO TERMINAL')
    save('n02d-background-watch-state',{'state':'FALLBACK_NOTICE_SENT' if receipt['delivery']=='sent' else 'NOTICE_FAILED','notice':receipt})
