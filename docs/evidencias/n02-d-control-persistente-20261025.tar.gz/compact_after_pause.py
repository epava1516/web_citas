import json,os,sys,time
from n02d_common import ROOT,WORK,SPEC,save
from codex_event_rpc import Rpc
sys.path.insert(0,str(ROOT/'scripts'))
from test_notifications import notify
save('n02d-compaction-state',{'state':'ARMED_WAITING_PAUSED_IDLE','pid':os.getpid(),'completion_method':'new persisted contextCompaction item in completed turn; ACK alone insufficient'})
def recent(rpc):
    page=rpc.call('thread/turns/list',{'threadId':SPEC['thread_id'],'limit':3,'itemsView':'full','sortDirection':'desc'})
    return ({turn['id'] for turn in page['data']}, {(turn['id'],item['id']):turn.get('status') for turn in page['data'] for item in turn.get('items',[]) if item.get('type')=='contextCompaction'})
try:
    for _ in range(120):
        rpc=Rpc()
        try:
            goal=rpc.call('thread/goal/get',{'threadId':SPEC['thread_id']})['goal']
            if not goal or goal['createdAt']!=SPEC['goal_created_at'] or goal['objective']!=SPEC['objective']:
                save('n02d-compaction-state',{'state':'SKIPPED_GOAL_CHANGED'});raise SystemExit(0)
            if (WORK/'n02d-sequence-result.json').exists():
                save('n02d-compaction-state',{'state':'SKIPPED_TEST_ALREADY_TERMINAL'});raise SystemExit(0)
            status=rpc.call('thread/read',{'threadId':SPEC['thread_id']})['thread']['status']
            if goal['status']=='paused' and status['type']=='idle' and (WORK/'n02d-pause-authorized.json').exists():
                save('n02d-pause-receipt',{'goal_created_at':goal['createdAt'],'objective':goal['objective'],'status':'paused','observed_after_idle':True,'tokensUsed':goal['tokensUsed'],'timeUsedSeconds':goal['timeUsedSeconds']})
                before_turns,before_items=recent(rpc);before=set(before_items);ack=rpc.call('thread/compact/start',{'threadId':SPEC['thread_id']})
                save('n02d-compaction-ack',{'state':'REQUEST_ACKNOWLEDGED','result':ack,'preexisting_compaction_ids':[list(x) for x in before],'preexisting_turn_ids':sorted(before_turns)})
                save('n02d-compaction-state',{'state':'REQUEST_ACKNOWLEDGED_NOT_COMPLETION'})
                deadline=time.monotonic()+300
                while time.monotonic()<deadline:
                    _,observed=recent(rpc)
                    completed=[ids for ids,value in observed.items() if ids not in before and ids[0] not in before_turns and value=='completed']
                    if completed:
                        save('n02d-compaction-state',{'state':'COMPACTION_COMPLETED','same_thread':True,'persisted_completed_items':[list(x) for x in completed]});raise SystemExit(0)
                    time.sleep(10)
                raise TimeoutError('No new completed persisted contextCompaction item observed')
        finally:rpc.close()
        time.sleep(5)
    raise TimeoutError('Paused idle boundary not reached')
except Exception as error:
    receipt=notify('No se confirmó compactación N02D; relevo guardado y prueba continúa','AVISO COMPACTACIÓN')
    save('n02d-compaction-state',{'state':'COMPACTION_NOT_CONFIRMED','error_type':type(error).__name__,'telegram':receipt})
