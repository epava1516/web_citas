import json,os,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
SPEC=json.loads((WORK/'execution-spec.json').read_text())
def save(name,data):
    data={**data,'updated_at_unix':time.time()}
    tmp=WORK/(name+'.tmp');tmp.write_text(json.dumps(data,indent=2)+'\n');tmp.replace(WORK/(name+'.json'))
def identity(pid,script=None,leader=False):
    fields=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
    assert fields[0]!='Z'
    if leader:assert os.getsid(pid)==pid
    if script:assert str(WORK/script).encode() in Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
    return {'pid':pid,'start_ticks':int(fields[19])}
def alive(meta):
    try:return identity(meta['pid'])=={k:meta[k] for k in ['pid','start_ticks']}
    except (OSError,AssertionError):return False
