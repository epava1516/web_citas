"""Freeze verified actual sources, corpus, cached images and persistent controls."""
import hashlib,json,os,platform,shutil,subprocess,sys,tarfile,time
from pathlib import Path
ROOT=Path.cwd();W=ROOT/'artifacts/recorridos-n02-d-20261025';S=W/'prereg/graph-integrated';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'scripts'));from run_local_ci import hashes
assert not (W/'n02d-launch.json').exists()
m=json.loads((S/'SOURCE_MANIFEST.json').read_text())
for p,r in m.items():assert sha(p)==r['sha256'],p
v=json.loads((S/'GRAPH_VERIFICATION.json').read_text());assert v['graph_sha256']==sha(S/'graph.json')
assert json.loads((W/'preparation-verification.json').read_text())['result']=='PASS_N02D_PREPARATION_NOT_RUNTIME'
assert shutil.disk_usage(ROOT).free>25*1024**3
assert not subprocess.check_output(['docker','ps','-q','--filter','label=web-modelos-capacity-run'],text=True).strip()
images={}
spec=json.loads((W/'execution-spec.json').read_text())
for name in [spec['image'],'postgres:17-alpine','redis:7.4-alpine','rustfs/rustfs@sha256:1803faef57627e2d9c2e7d89d655d712ddded5389040054987163043fecb6a3c','caddy@sha256:881bbc60f9986d5ab8e7cfd6cf7e4ef3c9c0439fef2429d035d065577882f028']:
 r=json.loads(subprocess.check_output(['docker','image','inspect',name]))[0];images[name]={'id':r['Id'],'repo_digests':r.get('RepoDigests',[])}
helpers=['execution-spec.json','n02d_common.py','codex_event_rpc.py','run_sequence.py','watch_terminal.py','resume_on_terminal.py','compact_after_pause.py','verify_preparation.py','handoff.md']
pre={'created_at_unix':time.time(),'sources':hashes(),'corpus_sources':{p:r['sha256'] for p,r in m.items()},'helpers_sha256':{p:sha(W/p) for p in helpers},'images':images,'graph_sha256':sha(S/'graph.json'),'manifest_sha256':sha(S/'SOURCE_MANIFEST.json'),'platform':platform.platform(),'affinity':sorted(os.sched_getaffinity(0)),'storage_free':shutil.disk_usage(ROOT).free,'meminfo':Path('/proc/meminfo').read_text()}
(W/'preregister.json').write_text(json.dumps(pre,indent=2)+'\n')
for p in S.iterdir():
 if p.is_file():shutil.copy2(p,ROOT/'graphify-out'/p.name)
E=ROOT/'docs/evidencias'
shutil.copy2(S/'GRAPH_VERIFICATION.json',E/'n02-d-prerregistro-grafo-verificacion-20261025.json')
shutil.copy2(W/'preparation-verification.json',E/'n02-d-control-preparacion-20261025.json')
for dest,files,base in [
 ('n02-d-prerregistro-grafo-20261025.tar.gz',[p for p in S.iterdir() if p.is_file()],S),
 ('n02-d-prerregistro-extraccion-20261025.tar.gz',[p for p in (W/'prereg').iterdir() if p.is_file()],W/'prereg'),
 ('n02-d-control-persistente-20261025.tar.gz',[W/p for p in helpers]+[W/'freeze_preparation.py',W/'preparation-verification.json',W/'preregister.json',W/'historical-source-differences.json'],W)]:
 with tarfile.open(E/dest,'w:gz') as t:
  for p in sorted(files):t.add(p,arcname=p.relative_to(base))
summary={'result':'FROZEN_PREPARATION_NOT_TEST_RESULT','sources':len(pre['sources']),'corpus_sources':len(m),'graph_sha256':pre['graph_sha256'],'helpers_sha256':pre['helpers_sha256'],'archives':{p.name:sha(p) for p in E.glob('n02-d-*.tar.gz')},'editorial_refresh':json.loads((W/'prereg/semantic-integration.json').read_text()).get('editorial_refresh')}
(E/'n02-d-prerregistro-congelacion-20261025.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
