"""Exactly one readiness control then one full MOD09 evaluation; never acceptance."""
import json,os,re,subprocess,sys
from xml.etree import ElementTree as ET
from n02d_common import ROOT,WORK,SPEC,save,identity
from codex_event_rpc import Rpc
os.chdir(ROOT);sys.path.insert(0,str(ROOT/'scripts'))
from run_local_ci import hashes
from test_notifications import notify
result={'state':'CONTROL_FAILED','test_result':'NOT_KNOWN','run':None,'phases':[]}
try:
 pre=json.loads((WORK/'preregister.json').read_text());assert hashes()==pre['sources']
 save('n02d-start',{'state':'SOURCE_FREEZE_VERIFIED','pid':os.getpid(),'sources':len(pre['sources'])})
 for phase in ('preflight','full'):
  if (WORK/'n02d-cancel-sequence.json').exists():raise RuntimeError('Sequencecancelled')
  rpc=Rpc()
  try:
   goal=rpc.call('thread/goal/get',{'threadId':SPEC['thread_id']})['goal']
   assert goal and goal['createdAt']==SPEC['goal_created_at'] and goal['objective']==SPEC['objective'] and goal['status']=='active'
  finally:rpc.close()
  for image,record in pre['images'].items():
   assert json.loads(subprocess.check_output(['docker','image','inspect',image]))[0]['Id']==record['id']
  assert hashes()==pre['sources'];command=SPEC['commands'][phase]
  with (WORK/(phase+'-runner.log')).open('wb') as log:
   proc=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,cwd=ROOT)
   save('n02d-runner-state',{'state':'RUNNING','phase':phase,'runner':identity(proc.pid),'command':command})
   code=proc.wait()
  ids=set(re.findall(r'artifacts/capacity-environment/(\d{8}-\d{6}-[0-9a-f]{8})',(WORK/(phase+'-runner.log')).read_text()));assert len(ids)==1
  run=ids.pop();base=ROOT/'artifacts/capacity-environment'/run
  report=json.loads((base/'report.json').read_text());launcher=json.loads((base/'launcher.json').read_text())
  unchanged=report.get('sources_unchanged') and launcher.get('sources_unchanged') and hashes()==pre['sources']
  cleanup=bool(launcher.get('cleanup')) and all(launcher['cleanup'].values())
  record={'phase':phase,'run':run,'exit':code,'test_result':report['result'],'sources_unchanged':bool(unchanged),'cleanup_reported':cleanup}
  result['phases'].append(record);result.update(run=run,test_result=report['result']);save('n02d-'+phase+'-terminal',record)
  if phase=='preflight':
   cases=ET.parse(base/'pytest.xml').findall('.//testcase');assert len(cases)==1
   assert not any(cases[0].find(k) is not None for k in ('failure','error','skipped'))
   assert code==0 and report['result']=='READY_NOT_CAPACITY' and unchanged and cleanup
   assert not launcher.get('archive_problems') and launcher.get('archive_within_ceiling')
   terminal=launcher['controller_terminal_state'];assert terminal['status']=='exited' and terminal['exit_code']==0 and not terminal['oom_killed']
   notice=notify('N02D control previo correcto; comienza una sola evaluación completa MOD09','INICIO')
   assert notice['delivery']=='sent'
  else:result.update(state='TERMINAL_REQUIRES_AUDIT',scope='OriginalPASS/FAIL/resourceevidence needs root audit; no automatic acceptance or repeat')
except BaseException as error:result.update(error_type=type(error).__name__)
finally:
 notice_result=result['test_result'] if result['state']=='TERMINAL_REQUIRES_AUDIT' else 'ERROR_CONTROL'
 result['notice']=notify('N02D secuencia MOD09 terminada; auditar tiempos,cuerpos,concurrencia y limpieza',notice_result,run_id=result.get('run'))
 save('n02d-sequence-result',result)
